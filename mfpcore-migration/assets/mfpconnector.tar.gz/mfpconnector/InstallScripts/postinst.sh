#!/bin/bash

# Create HTTPS Certification
mkdir -p /var/ssl_temp
chmod 755 -R /var/ssl_temp
if [ ! -e /var/mfpcore ]; then
	mkdir /var/mfpcore
fi

mkdir -p /usr/lib/mfpcore/ssl
chmod 600 -R /usr/lib/mfpcore/ssl
chown www-data:www-data /usr/lib/mfpcore/ssl

/usr/bin/openssl genrsa -aes128 -passout pass:x -out /var/ssl_temp/server.key 2048
/usr/bin/openssl rsa -in /var/ssl_temp/server.key -passin pass:x -out /var/ssl_temp/server.key
/usr/bin/openssl req -new -key /var/ssl_temp/server.key -out /var/ssl_temp/server.csr -subj "/C=JP/ST=Hyogo/L=Itami/O=KONICA MINOLTA/CN=mfpcore.nginx.com"
/usr/bin/openssl x509 -req -days 36500 -in /var/ssl_temp/server.csr -signkey /var/ssl_temp/server.key -out /var/ssl_temp/server.crt
/usr/bin/openssl pkcs12 -export -password pass: -inkey /var/ssl_temp/server.key -in /var/ssl_temp/server.crt -out /var/mfpcore/mfpcore.pfx
/bin/rm -rf /var/ssl_temp

systemctl enable mfpcore.service
systemctl restart mfpcore.service
