#!/bin/bash

# stop mfpconnector
systemctl stop mfpconnector
systemctl disable mfpconnector

# delete unnecessary files up to v1.2
if [ -e /etc/systemd/system/mfpconnector.service ]; then
	rm /etc/systemd/system/mfpconnector.service
fi

if [ -e /etc/mfpcore ]; then
	rm -r /etc/mfpcore
fi

if [ -e /home/shub/mfpconnector ]; then
	rm -r /home/shub/mfpconnector*
fi
