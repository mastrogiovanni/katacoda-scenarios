using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Xml;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Newtonsoft.Json;
using Sh.Common.Settings;
using Sh.Common.Settings.Iws;
using StubHttpServer;

namespace StubTestSample
{
    /// <summary>
    /// 
    /// </summary>
    /// <remarks>Ignore reason: This test uses real environment.</remarks>
    [Ignore]
    [TestClass]
    [DeploymentItem("TestData", "TestData")]
    public class ScanStubTest
    {
        /// <summary>
        /// Setting
        /// </summary>
        private MfpConnectorSetting setting;
        /// <summary>
        /// IWS SettingID
        /// </summary>
        private const string IWS_SETTING_ID = "iws_setting_test";

        /// <summary>
        /// stub web server
        /// </summary>
        private StubHttpServer.StubHttpServer httpServer;
        /// <summary>
        /// http server port
        /// </summary>
        private const ushort HTTP_SERVER_PORT = 8000;

        [TestInitialize]
        public void Initialize()
        {
            httpServer = new StubHttpServer.StubHttpServer();
            httpServer.Start(HTTP_SERVER_PORT);

            // setting for test
            setting = new MfpConnectorSetting()
            {
                LogPath = "./log",
                Iws = new IwsSetting()
                {
                    SettingId = IWS_SETTING_ID,
                    Definitions = new List<IwsWebApiSetting>(new IwsWebApiSetting[]
                    {
                        new IwsWebApiSetting() {
                            SettingId = IWS_SETTING_ID,
                            Protocol = "http",
                            IpAddress = "localhost",
                            Port = HTTP_SERVER_PORT,
                            AppId = "0A0243A4",
                            AuthUserName = "1",
                            AuthPassword = "1",
                            EnhancedServerAuth = new IwsEnhancedServerAuthSetting()
                            {
                                Use = false,
                                Values = new List<IwsEnhancedServerAuthValue>()
                                {
                                    new IwsEnhancedServerAuthValue()
                                    {
                                        ControlId = "code",
                                        ValueType = EnhancedServerAuthValueType.AuthParameterCode
                                    }
                                }
                            }
                        }
                    })
                }
            };
        }

        [TestCleanup]
        public void Cleanup()
        {
            httpServer.Dispose();
        }

        [TestMethod]
        [ScanTest(JsonFile = "normal_template")]
        public void TestScanJobstructure01()
        {
            DoTest(MethodBase.GetCurrentMethod());
        }

        [TestMethod]
        [ScanTest(JsonFile = "scanJobstructure_02", IsError = true)]
        public void TestScanJobstructure02()
        {
            DoTest(MethodBase.GetCurrentMethod());
        }

        [TestMethod]
        [ScanTest(JsonFile = "file_name_01", DocumentName = "scandata")]
        public void TestScanFileName01()
        {
            DoTest(MethodBase.GetCurrentMethod());
        }

        [TestMethod]
        [ScanTest(JsonFile = "file_name_02", DocumentName = "")]
        public void TestScanFileName02()
        {
            DoTest(MethodBase.GetCurrentMethod());
        }

        [TestMethod]
        [ScanTest(JsonFile = "file_name_03", DocumentName = null)]
        public void TestScanFileName03()
        {
            DoTest(MethodBase.GetCurrentMethod());
        }

        [TestMethod]
        [ScanTest(JsonFile = "resolution_01", Resolution = "200_200")]
        public void TestScanResolution01()
        {
            DoTest(MethodBase.GetCurrentMethod());
        }

        [TestMethod]
        [ScanTest(JsonFile = "resolution_02", Resolution = "300_300")]
        public void TestScanResolution02()
        {
            DoTest(MethodBase.GetCurrentMethod());
        }

        [TestMethod]
        [ScanTest(JsonFile = "resolution_03", Resolution = "400_400")]
        public void TestScanResolution03()
        {
            DoTest(MethodBase.GetCurrentMethod());
        }

        [TestMethod]
        [ScanTest(JsonFile = "resolution_04", Resolution = "600_600")]
        public void TestScanResolution04()
        {
            DoTest(MethodBase.GetCurrentMethod());
        }

        [TestMethod]
        [ScanTest(JsonFile = "resolution_05", Resolution = "HOGE")]
        public void TestScanResolution05()
        {
            DoTest(MethodBase.GetCurrentMethod());
        }

        [TestMethod]
        [ScanTest(JsonFile = "resolution_06", Resolution = null)]
        public void TestScanResolution06()
        {
            DoTest(MethodBase.GetCurrentMethod());
        }

        [TestMethod]
        [ScanTest(JsonFile = "file_type_01", FileType = "PDF")]
        public void TestScanFileType01()
        {
            DoTest(MethodBase.GetCurrentMethod());
        }

        [TestMethod]
        [ScanTest(JsonFile = "file_type_02", FileType = "CompactPDF")]
        public void TestScanFileType02()
        {
            DoTest(MethodBase.GetCurrentMethod());
        }

        [TestMethod]
        [ScanTest(JsonFile = "file_type_03", FileType = "TIFF")]
        public void TestScanFileType03()
        {
            DoTest(MethodBase.GetCurrentMethod());
        }

        [TestMethod]
        [ScanTest(JsonFile = "file_type_04", FileType = "JPEG")]
        public void TestScanFileType04()
        {
            DoTest(MethodBase.GetCurrentMethod());
        }

        [TestMethod]
        [ScanTest(JsonFile = "file_type_05", FileType = "XPS")]
        public void TestScanFileType05()
        {
            DoTest(MethodBase.GetCurrentMethod());
        }

        [TestMethod]
        [ScanTest(JsonFile = "file_type_06", FileType = "CompactXPS")]
        public void TestScanFileType06()
        {
            DoTest(MethodBase.GetCurrentMethod());
        }

        [TestMethod]
        [ScanTest(JsonFile = "file_type_07", FileType = "DOCX")]
        public void TestScanFileType07()
        {
            DoTest(MethodBase.GetCurrentMethod());
        }

        [TestMethod]
        [ScanTest(JsonFile = "file_type_08", FileType = "XLSX")]
        public void TestScanFileType08()
        {
            DoTest(MethodBase.GetCurrentMethod());
        }

        [TestMethod]
        [ScanTest(JsonFile = "file_type_09", FileType = "PPTX")]
        public void TestScanFileType09()
        {
            DoTest(MethodBase.GetCurrentMethod());
        }

        [TestMethod]
        [ScanTest(JsonFile = "file_type_10", FileType = "HOGE")]
        public void TestScanFileType10()
        {
            DoTest(MethodBase.GetCurrentMethod());
        }

        [TestMethod]
        [ScanTest(JsonFile = "file_type_11", FileType = null)]
        public void TestScanFileType11()
        {
            DoTest(MethodBase.GetCurrentMethod());
        }

        [TestMethod]
        [ScanTest(JsonFile = "mode_01", ColorMode = "Auto")]
        public void TestScanMode01()
        {
            DoTest(MethodBase.GetCurrentMethod());
        }

        [TestMethod]
        [ScanTest(JsonFile = "mode_02", ColorMode = "Full Color")]
        public void TestScanMode02()
        {
            DoTest(MethodBase.GetCurrentMethod());
        }

        [TestMethod]
        [ScanTest(JsonFile = "mode_03", ColorMode = "Single Color")]
        public void TestScanMode03()
        {
            DoTest(MethodBase.GetCurrentMethod());
        }

        [TestMethod]
        [ScanTest(JsonFile = "mode_04", ColorMode = "Gray Scale")]
        public void TestScanMode04()
        {
            DoTest(MethodBase.GetCurrentMethod());
        }

        [TestMethod]
        [ScanTest(JsonFile = "mode_05", ColorMode = "HOGE")]
        public void TestScanMode05()
        {
            DoTest(MethodBase.GetCurrentMethod());
        }

        [TestMethod]
        [ScanTest(JsonFile = "mode_06", ColorMode = null)]
        public void TestScanMode06()
        {
            DoTest(MethodBase.GetCurrentMethod());
        }

        /// <summary>
        /// Execute scan test
        /// </summary>
        /// <param name="jsonMessage">JSON message (send by WebSocket)</param>
        /// <param name="putAppDataAssertion">PutAppData request assertion</param>
        /// <param name="execAppScriptAssertion">ExecAppScript request assertion</param>
        /// <param name="finalAssertion">WebSocket response assertion</param>
        private void ScanTester(string jsonMessage, Action<string> putAppDataAssertion, Action<string> execAppScriptAssertion, Action<string> finalAssertion)
        {
            Exception breakingException = null;
            var waiting = true;

            // PutAppData
            httpServer.AddReceiveHandler(
                p => p.Url.PathAndQuery == "/IWS/WebAPI" && p.Method == "POST" && p.Headers["SoapAction"] == "http://www.konicaminolta.com/IWS/WebAPI/PutAppData",
                request =>
                {
                    try
                    {
                        using (StreamReader sr = new StreamReader(request.Payload, Encoding.UTF8))
                        {
                            putAppDataAssertion(sr.ReadToEnd());
                        }
                    }
                    catch (Exception e)
                    {
                        waiting = false;
                        breakingException = e;
                    }

                    // return success message
                    var payload =
                    "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" +
                    "<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" " +
                        "xmlns:SOAP-ENC=\"http://schemas.xmlsoap.org/soap/encoding/\" " +
                        "xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" " +
                        "xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\">\n" +
                    "  <SOAP-ENV:Body>\n" +
                    "    <PutAppDataResponse xmlns=\"http://www.konicaminolta.com/IWS/WebAPI/\">\n" +
                    "      <Result>\n" +
                    "        <ResultCode>1</ResultCode>\n" +
                    "      </Result>\n" +
                    "    </PutAppDataResponse>\n" +
                    "  </SOAP-ENV:Body>\n" +
                    "</SOAP-ENV:Envelope>";

                    return new HttpResponse()
                    {
                        StatusCode = 200,
                        ContentType = "text/xml",
                        IsChunked = true,
                        PayloadString = payload,
                    };
                });
            // ExecAppScript
            httpServer.AddReceiveHandler(
                p => p.Url.PathAndQuery == "/IWS/WebAPI" && p.Method == "POST" && p.Headers["SoapAction"] == "http://www.konicaminolta.com/IWS/WebAPI/ExecAppScript",
                request =>
                {
                    try
                    {
                        using (StreamReader sr = new StreamReader(request.Payload, Encoding.UTF8))
                        {
                            execAppScriptAssertion(sr.ReadToEnd());
                        }
                    }
                    catch (Exception e)
                    {
                        waiting = false;
                        breakingException = e;
                    }

                    // return success message
                    var payload =
                    "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" +
                    "<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" " +
                        "xmlns:SOAP-ENC=\"http://schemas.xmlsoap.org/soap/encoding/\" " +
                        "xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" " +
                        "xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\">\n" +
                    "  <SOAP-ENV:Body>\n" +
                    "    <ExecAppScriptResponse xmlns=\"http://www.konicaminolta.com/IWS/WebAPI/\">\n" +
                    "      <Result>\n" +
                    "        <ResultCode>1</ResultCode>\n" +
                    "      </Result>\n" +
                    "    </ExecAppScriptResponse>\n" +
                    "  </SOAP-ENV:Body>\n" +
                    "</SOAP-ENV:Envelope>";

                    return new HttpResponse()
                    {
                        StatusCode = 200,
                        ContentType = "text/xml",
                        IsChunked = true,
                        PayloadString = payload,
                    };
                });

            string actual = null;

            //WebSocket wc = new WebSocket("ws://localhost:" + setting.WebSocket.ListeningPort + "/scan",
            //    onMessage: msg => Task
            //        .Run(() => actual = msg.Text.ReadToEnd())
            //        .ContinueWith(task => waiting = false));
            //wc.Connect().Wait();
            //wc.Send(jsonMessage).Wait();
            
            // waiting for WebSocket reply
            while (waiting)
            {
                Thread.Sleep(1000);
            }

            // if exception occured, throw Fail here before finalAssertion.
            if (breakingException != null)
            {
                Assert.Fail(breakingException.Message);
            }

            finalAssertion(actual);
        }

        /// <summary>
        /// Load SOAP message
        /// </summary>
        /// <param name="rawXml">raw XML</param>
        /// <param name="nsmgr">XmlNamespaceManager</param>
        /// <returns></returns>
        private XmlDocument LoadSoapXml(string rawXml, out XmlNamespaceManager nsmgr)
        {
            var doc = new XmlDocument();
            doc.LoadXml(rawXml);
            nsmgr = new XmlNamespaceManager(doc.NameTable);
            nsmgr.AddNamespace("SOAP-ENV", "http://schemas.xmlsoap.org/soap/envelope/");
            nsmgr.AddNamespace("SOAP-ENC", "http://schemas.xmlsoap.org/soap/encoding/");
            nsmgr.AddNamespace("IWS", "http://www.konicaminolta.com/IWS/WebAPI/");
            return doc;
        }

        /// <summary>
        /// Get child node from XmlDocument
        /// </summary>
        /// <param name="doc">XmlDocument</param>
        /// <param name="nsmgr">XmlNamespaceManager</param>
        /// <param name="xpath">XPath</param>
        /// <returns></returns>
        private XmlNode GetNodeFromSoapXml(XmlDocument doc, XmlNamespaceManager nsmgr, string xpath)
        {
            return doc.SelectSingleNode(xpath, nsmgr);
        }

        /// <summary>
        /// Get value from XmlNode
        /// </summary>
        /// <param name="xmlnode">XmlNode</param>
        /// <param name="xpath">XPath</param>
        /// <param name="nsmgr">XmlNamespaceManager</param>
        /// <returns></returns>
        private string GetNodeValueFromNode(XmlNode xmlnode, string xpath, XmlNamespaceManager nsmgr = null)
        {
            if (nsmgr == null)
            {
                return xmlnode.SelectSingleNode(xpath).Value;
            }
            else
            {
                return xmlnode.SelectSingleNode(xpath, nsmgr).Value;
            }
        }

        private List<MultipartPayload> GetMultipartPayloads(string rawPayload)
        {
            var result = new List<MultipartPayload>();

            // split boundary
            var boundaries = rawPayload.Split(new string[] { "--MIME_boundary\r\n" }, StringSplitOptions.RemoveEmptyEntries);

            foreach (var boundary in boundaries)
            {
                // split header and payload
                var headerAndPayload = boundary.Split(new string[] { "\r\n\r\n" }, 2, StringSplitOptions.RemoveEmptyEntries);
                var header = headerAndPayload[0];
                var reqPayload = headerAndPayload[1].Replace("--MIME_boundary--", "");
                result.Add(new MultipartPayload(header, reqPayload));
            }

            return result;
        }
        private string CreateScanParameter(string jsonFileName)
        {
            string result = string.Empty;
            using (StreamReader sr = new StreamReader(jsonFileName, Encoding.GetEncoding("utf-8")))
            {
                result = sr.ReadToEnd();
            }
            return result;
        }

        private void RunScan(string jsonFileData, ScanTestAttribute testAttr)
        {
            // PutAppData
            Action<string> putAppDataAssertion = req =>
            {
                var payloads = GetMultipartPayloads(req);

                // -- IWS request --
                XmlNamespaceManager nsmgr;
                var doc = LoadSoapXml(payloads[0].Body, out nsmgr);
                var node = GetNodeFromSoapXml(doc, nsmgr, "/SOAP-ENV:Envelope/SOAP-ENV:Body/IWS:PutAppData");
                Assert.AreEqual(setting.Iws.CurrentSetting.AuthUserName, GetNodeValueFromNode(node, "IWS:RemoteAuthInfo/IWS:Name/text()", nsmgr));
                Assert.AreEqual(setting.Iws.CurrentSetting.AuthPassword, GetNodeValueFromNode(node, "IWS:RemoteAuthInfo/IWS:Password/text()", nsmgr));
                Assert.AreEqual(setting.Iws.CurrentSetting.AppId, GetNodeValueFromNode(node, "IWS:AppID/text()", nsmgr));
                Assert.AreEqual("/ScanSetting.json", GetNodeValueFromNode(node, "IWS:FilePath/text()", nsmgr));

                // -- data (JSON) --
                var xmlnode = JsonConvert.DeserializeXmlNode(payloads[1].Body, "json");
                if (testAttr.DocumentName != null)
                {
                    Assert.AreEqual(testAttr.DocumentName, GetNodeValueFromNode(xmlnode, "/json/file_name/text()"));
                }
                if (testAttr.Resolution != null)
                {
                    Assert.AreEqual(testAttr.Resolution, GetNodeValueFromNode(xmlnode, "/json/resolution/text()"));
                }
                if (testAttr.FileType != null)
                {
                    Assert.AreEqual(testAttr.FileType, GetNodeValueFromNode(xmlnode, "/json/file_type/text()"));
                }
                if (testAttr.ColorMode != null)
                {
                    Assert.AreEqual(testAttr.ColorMode, GetNodeValueFromNode(xmlnode, "/json/color/mode/text()"));
                }
            };

            // ExecAppScript
            Action<string> execAppScriptAssertion = req =>
            {
                XmlNamespaceManager nsmgr;
                var doc = LoadSoapXml(req, out nsmgr);
                var node = GetNodeFromSoapXml(doc, nsmgr, "/SOAP-ENV:Envelope/SOAP-ENV:Body/IWS:ExecAppScript");
                Assert.AreEqual(setting.Iws.CurrentSetting.AuthUserName, GetNodeValueFromNode(node, "IWS:RemoteAuthInfo/IWS:Name/text()", nsmgr));
                Assert.AreEqual(setting.Iws.CurrentSetting.AuthPassword, GetNodeValueFromNode(node, "IWS:RemoteAuthInfo/IWS:Password/text()", nsmgr));
                Assert.AreEqual(setting.Iws.CurrentSetting.AppId, GetNodeValueFromNode(node, "IWS:AppID/text()", nsmgr));
                Assert.AreEqual("/startScan.py", GetNodeValueFromNode(node, "IWS:ScriptPath/text()", nsmgr));
            };

            // Final Assertion (WebSocket reply)
            Action<string> finalAssertion = actual => Assert.AreEqual("OK", actual);

            ScanTester(
                jsonFileData,
                putAppDataAssertion,
                execAppScriptAssertion,
                finalAssertion);
        }
        private void DoTest(MethodBase testMethod)
        {
            ScanTestAttribute testAttr =
                (ScanTestAttribute)Attribute.GetCustomAttribute(testMethod, typeof(ScanTestAttribute));

            var jsonFile = testAttr.JsonFile;
            if (!jsonFile.EndsWith(".json"))
            {
                jsonFile += ".json";
            }

            var jsonFileData = CreateScanParameter("TestData\\" + jsonFile);

            try
            {
                RunScan(jsonFileData, testAttr);
            }
            catch (Exception ex)
            {
                if (testAttr.IsError)
                {
                    Assert.IsTrue(true);
                }
                else
                {
                    Assert.Fail("Exception occur", ex.Message);
                }
                return;
            }

            if (testAttr.IsError)
            {
                Assert.Fail("Exception not occur");
            }

            Assert.IsTrue(true);
        }

    }

    /// <summary>
    /// Multipart data payload
    /// </summary>
    struct MultipartPayload
    {
        /// <summary>
        /// Header
        /// </summary>
        public string Header { get; private set; }

        /// <summary>
        /// Body
        /// </summary>
        public string Body { get; private set; }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="header">Header</param>
        /// <param name="body">Body</param>
        public MultipartPayload(string header, string body)
        {
            Header = header;
            Body = body;
        }
    }
}
