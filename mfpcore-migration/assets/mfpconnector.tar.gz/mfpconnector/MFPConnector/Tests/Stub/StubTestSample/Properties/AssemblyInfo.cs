using System.Reflection;
using System.Runtime.InteropServices;

// General information about the assembly is controlled through the following set of attributes.
// To change the information that is associated with the assembly, 
// Please change the values of these attributes.
[assembly: AssemblyTitle("StubTestSample")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Microsoft")]
[assembly: AssemblyProduct("StubTestSample")]
[assembly: AssemblyCopyright("Copyright 息 Microsoft 2016")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// If you set the ComVisible to false, the type will not be able to see from the COM component in this assembly.
// If you need to access to the mold from the COM in this assembly,
// Please set the ComVisible attribute to true on that type
[assembly: ComVisible(false)]

// If this project is exposed to COM, the following GUID will be the ID of the typelib.
[assembly: Guid("1c8f61b3-e61e-4a0c-9c81-ef3c1758ee98")]

// Version information of the assembly is composed of the following four values:
//
//      Major version
//      Minor version
//      Build no
//      Revision
//
// You can specify all the values,
// Or use as follows: '*' can be the build number and revision number to the default value.
// [Assembly: AssemblyVersion ( "1.0 *.")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
