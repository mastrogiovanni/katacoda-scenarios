using System;

namespace StubTestSample
{
    [AttributeUsage(AttributeTargets.Property)]
    public class TestParamAttribute : Attribute
    {
        public bool IsParam { get; set; }
        public TestParamAttribute()
        {
            IsParam = false;
        }
    }

    // This is a positional argument
    [AttributeUsage(AttributeTargets.Method)]
    public class ScanTestAttribute : Attribute
    {
        public string JsonFile { get; set; }
        public string DocumentName { get; set; }
        public string Resolution { get; set; }
        public string FileType { get; set; }
        public string ColorMode { get; set; }
        public bool ErrorConnect { get; set; }
        public bool ErrorWriteSocket { get; set; }
        public bool IsError { get; set; }
        [TestParam(IsParam = true)]
        public string JOBNAME { get; set; }
        [TestParam(IsParam = true)]
        public string mfpservicesJobid { get; set; }

        public ScanTestAttribute()
        {
            JsonFile = "normal_template.json";
            DocumentName = "scantest.jpg";
            Resolution = "200_200";
            FileType = "JPEG";
            ColorMode = "Full Color";
            IsError = false;
            ErrorConnect = false;
            ErrorWriteSocket = false;
        }
    }
}
