using System;
using System.IO;
using System.Net;
using System.Net.Sockets;

namespace StubTcpServer
{
    /// <summary>
    /// Stub TCP Server
    /// </summary>
    public class StubTcpServer : IDisposable
    {
        /// <summary>
        /// TCP Server
        /// </summary>
        private TcpListener tcpListener;

        /// <summary>
        /// Start server
        /// </summary>
        /// <param name="port">listening port number</param>
        public void Start(ushort port = 9100)
        {
            if (tcpListener == null || !tcpListener.Server.IsBound)
            {
                tcpListener = new TcpListener(IPAddress.Any, port);
                tcpListener.Start();
                tcpListener.BeginAcceptTcpClient(ListeningCallback, tcpListener);
            }
        }

        /// <summary>
        /// Stop server
        /// </summary>
        public void Stop()
        {
            if (tcpListener != null)
            {
                tcpListener.Stop();
            }

            tcpListener = null;
        }

        /// <summary>
        /// Dispose server
        /// </summary>
        public void Dispose()
        {
            Stop();
        }

        /// <summary>
        /// Listener thread
        /// </summary>
        private void ListeningCallback(IAsyncResult ar)
        {
            try
            {
                var listener = (TcpListener)ar.AsyncState;
                var client = listener.EndAcceptTcpClient(ar);

                // do nothing
                using (var ms = new MemoryStream())
                {
                    client.GetStream().CopyTo(ms);

                    string folderName = DateTime.Today.ToString("yyyyMMddHHmmss");

                    string outpath = System.IO.Path.Combine(System.IO.Directory.GetCurrentDirectory(), folderName);

                    Directory.CreateDirectory(outpath);

                    using (FileStream dest = new FileStream(outpath + "/test.jpg", FileMode.Create, FileAccess.Write))
                    {
                        byte[] b = new byte[ms.Length];
                        dest.Write(b, 0, b.Length);
                    }

                }
                client.Close();

                listener.BeginAcceptTcpClient(ListeningCallback, listener);
            }
            catch
            {
                // do nothing
            } 
        }
    }
}
