using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Threading.Tasks;

namespace StubHttpServer
{
    /// <summary>
    /// Stub http server emulating IWS
    /// </summary>
    public class StubHttpServer : IDisposable
    {
        /// <summary>
        /// Event fired on data received
        /// </summary>
        private readonly Dictionary<Predicate<HttpRequest>, Func<HttpRequest, HttpResponse>> OnDataReceived = new Dictionary<Predicate<HttpRequest>, Func<HttpRequest, HttpResponse>>();

        /// <summary>
        /// Http listener
        /// </summary>
        private HttpListener httpListener;

        /// <summary>
        /// Start server
        /// </summary>
        /// <param name="port">listening port number</param>
        public void Start(ushort port = 80)
        {
            if (httpListener == null || !httpListener.IsListening)
            {
                httpListener = new HttpListener();
                httpListener.Prefixes.Add("http://localhost:" + port + "/");
                httpListener.Start();
                Task.Run(() => ListeningCallback());
            }
        }

        /// <summary>
        /// Stop server
        /// </summary>
        public void Stop()
        {
            if (httpListener != null && httpListener.IsListening)
            {
                httpListener.Stop();
                httpListener = null;
            }
        }

        /// <summary>
        /// Dispose server
        /// </summary>
        public void Dispose()
        {
            Stop();
        }

        /// <summary>
        /// Add receive handler
        /// </summary>
        /// <param name="executePredicate">execute predicate function</param>
        /// <param name="handler">handler method</param>
        public void AddReceiveHandler(Predicate<HttpRequest> executePredicate, Func<HttpRequest, HttpResponse> handler)
        {
            if (OnDataReceived.ContainsKey(executePredicate))
            {
                OnDataReceived[executePredicate] = handler;
            }
            else
            {
                OnDataReceived.Add(executePredicate, handler);
            }
        }

        /// <summary>
        /// Listener thread
        /// </summary>
        private void ListeningCallback()
        {
            while (httpListener.IsListening)
            {
                try
                {
                    // wait for receiving request
                    var context = httpListener.GetContext();

                    // create request data
                    var httpRequest = new HttpRequest
                    {
                        ContentLength = context.Request.ContentLength64,
                        ContentType = context.Request.ContentType,
                        Headers = context.Request.Headers,
                        Method = context.Request.HttpMethod,
                        Url = context.Request.Url,
                        UserAgent = context.Request.UserAgent,
                    };

                    foreach (var p in OnDataReceived.Keys)
                    {
                        if (p(httpRequest))
                        {
                            context.Request.InputStream.CopyTo(httpRequest.Payload);
                            httpRequest.Payload.Seek(0, SeekOrigin.Begin);

                            // callback
                            var httpResponse = OnDataReceived[p](httpRequest);

                            // create response for client
                            context.Response.StatusCode = httpResponse.StatusCode;
                            foreach (var header in httpResponse.Headers)
                            {
                                context.Response.AddHeader(header.Key, header.Value);
                            }
                            context.Response.ContentType = httpResponse.ContentType;
                            context.Response.SendChunked = httpResponse.IsChunked;
                            if (httpResponse.Payload.Length > 0)
                            {
                                httpResponse.Payload.CopyTo(context.Response.OutputStream);
                            }
                        }
                    }

                    context.Response.Close();
                }
                catch
                {
                    break;
                }
            }
        }
    }
}
