using System.Collections.Generic;
using System.IO;
using System.Text;

namespace StubHttpServer
{
    public class HttpResponse
    {
        /// <summary>
        /// Status code
        /// </summary>
        public int StatusCode { get; set; }

        /// <summary>
        /// Headers
        /// </summary>
        public Dictionary<string, string> Headers { get; private set; }

        /// <summary>
        /// Content-Type
        /// </summary>
        public string ContentType { get; set; }

        /// <summary>
        /// Payload (body)
        /// </summary>
        public MemoryStream Payload { get; private set; }

        /// <summary>
        /// Payload string (override existing payload)
        /// </summary>
        public string PayloadString
        {
            private get { return string.Empty; }
            set
            {
                var bytes = Encoding.UTF8.GetBytes(value);
                Payload = new MemoryStream(bytes);
                Payload.Seek(0, SeekOrigin.Begin);
            }
        }

        /// <summary>
        /// use chunked response
        /// </summary>
        public bool IsChunked { get; set; }

        /// <summary>
        /// Constructor
        /// </summary>
        public HttpResponse()
        {
            Payload = new MemoryStream();
            Headers = new Dictionary<string, string>();
        }
    }
}