using System;
using System.Collections.Specialized;
using System.IO;

namespace StubHttpServer
{
    /// <summary>
    /// 
    /// </summary>
    public class HttpRequest
    {
        /// <summary>
        /// Content-Length
        /// </summary>
        public long ContentLength { get; internal set; }

        /// <summary>
        /// Content-Type
        /// </summary>
        public string ContentType { get; internal  set; }

        /// <summary>
        /// Header
        /// </summary>
        public NameValueCollection Headers { get; internal set; }

        /// <summary>
        /// HTTP Method
        /// </summary>
        public string Method { get; internal set; }

        /// <summary>
        /// Payload (Body)
        /// </summary>
        public MemoryStream Payload { get; private set; }

        /// <summary>
        /// Requested URL
        /// </summary>
        public Uri Url { get; internal set; }

        /// <summary>
        /// User-Agent
        /// </summary>
        public string UserAgent { get; internal set; }

        /// <summary>
        /// Constructor
        /// </summary>
        public HttpRequest()
        {
            this.Payload = new MemoryStream();
        }
    }
}
