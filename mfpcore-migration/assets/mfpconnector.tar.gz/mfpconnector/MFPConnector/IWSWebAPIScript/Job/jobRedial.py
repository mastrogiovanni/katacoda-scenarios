#!/usr/bin/env python
# -*- coding: utf-8 -*-

import sys
import json
import urllib.request
import urllib.parse
import urllib.error

import mfp.job

PROTOCOL = "http"

HTTP_METHOD = "POST"
HTTP_HEADARS = {"Content-Type": "application/json"}

RESULT_KEY = "result"
JOBID_KEY = "job_id"
ERROR_KEY = "error"
ERROR_MSG_KEY = "errorMsg"

JOB_RESULT_OK = "OK"
JOB_RESULT_NG = "NG"

ENCODE_UTF8 = "utf-8"

class EnumException(Exception):
    def __init__(self, value):
        self.value = value

try:
    result = dict()

    # check url
    args = sys.argv
    parameter = args[1].split()
    url = parameter[0]
    job_id_arg = parameter[1]
    urlParseResult = urllib.parse.urlparse(url, scheme=PROTOCOL)

    if (urlParseResult[0] != PROTOCOL):
        raise EnumException("Protocol is illegal value.")
    if urlParseResult[1] == '':
        raise EnumException("Hostname is empty.")
    if (urlParseResult[2] == '') or (urlParseResult[2] == '/'):
        raise EnumException("Path is empty.")

    if not job_id_arg.isdigit():
        raise EnumException("Job_id is not number")

    # convert str -> int
    job_id = int(job_id_arg)

    mfp.job.redial(job_id)

    result[RESULT_KEY] = JOB_RESULT_OK
    result[JOBID_KEY] = job_id
    result[ERROR_KEY] = ""
    result[ERROR_MSG_KEY] = ""

except TypeError as ex:
    result[RESULT_KEY] = JOB_RESULT_NG
    result[JOBID_KEY] = ''
    result[ERROR_KEY] = "TypeError"
    result[ERROR_MSG_KEY] = str(ex)

except mfp.MFPInvalidStateErr as ex:
    result[RESULT_KEY] = JOB_RESULT_NG
    result[JOBID_KEY] = job_id
    result[ERROR_KEY] = "MFPInvalidStateErr"
    result[ERROR_MSG_KEY] = str(ex)

except EnumException as ex:
    result[RESULT_KEY] = JOB_RESULT_NG
    result[JOBID_KEY] = ''
    result[ERROR_KEY] = "EnumException"
    result[ERROR_MSG_KEY] = str(ex)

except Exception as ex:
    result[RESULT_KEY] = JOB_RESULT_NG
    result[JOBID_KEY] = ''
    result[ERROR_KEY] = "Exception"
    result[ERROR_MSG_KEY] = str(ex)

finally:
    try:
        json_data = json.dumps(result).encode(ENCODE_UTF8)

        request = urllib.request.Request(url, data=json_data, method=HTTP_METHOD, headers=HTTP_HEADARS)
        with urllib.request.urlopen(request) as response:
            pass
    except:
        pass