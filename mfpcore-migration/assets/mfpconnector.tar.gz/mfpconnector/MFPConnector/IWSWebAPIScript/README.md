# IWS WebAPI用Pythonスクリプト

## 目的

これらのファイルは、MFP Connectorよりコールされる。

## ファイル配置場所

pyファイルはすべて、 IWS Contents Uploader のルートに格納する。

## ファイル一覧

### スキャン (Scanフォルダ)

* StartScan.py  
ジョブ実行を行う

* ConvertTable.py  
StartScan.pyの内部でJSONの文字列とPython定数を対応させる

* DeleteScanResult.py  
ジョブ実行結果を削除する

* JSON_Specification_Sample フォルダ

    * Specification_ScanSetting.json  
    スキャン設定ファイルの仕様

    * Sample_ScanSetting.json  
    スキャン設定ファイルの例

    * Specification_ScanResult.json  
    スキャン結果ファイルの仕様

    * Sample_ScanResult.json  
    スキャン結果ファイルの例

### コピー (Copyフォルダ)

> 設定ファイル、結果ファイルの仕様についてはSHUBWP-336のドキュメントを参照

* startCopy.py  
ジョブ実行を行う

* removeFile.py  
ファイル削除を行う

### IWSジョブ実行 (IWSJobフォルダ)

> 設定ファイル、結果ファイルの仕様については
[IWSplatform Job Start](https://confluence.kmiservicehub.com/display/SHS/IWSplatform+Job+Start)
を参照

* __init__.py  
IWSJobフォルダを再帰参照対象（パッケージ）として扱うための参照ファイル。  

* convertTable.py  
setCopy.pyおよびsetScan.pyの内部でJSONの文字列とPython定数を対応させる  

* setCopy.py  
startJob.pyにimportされる。  
リクエストパラメータがCopyジョブであった場合、Copyジョブのパラメータを生成する  

* setScan.py  
startJob.pyにimportされる。  
リクエストパラメータがScanジョブであった場合、Scanジョブのパラメータを生成する  

* startJob.py  
ジョブ実行を行う  

* getInfo.py  
指定された情報の取得を行う  

## シーケンス

### スキャン

1. ジョブ設定ファイル( `/ScanSetting.json` )格納  
`PutAppData`

1. ジョブ実行 ( `/StartScan.py` )  
`ExecAppScript`  
> ジョブ設定ファイルは削除されます  

1. ジョブ実行結果 ( `/ScanResult.json` )取得  
`GetAppData`  
> ポーリングしてください

1. ジョブ実行結果ファイル削除( `/DeleteScanResult.py` )  
`ExecAppScript`

### コピー

1. ジョブ設定ファイル( `/copyRequest.json` )格納  
`PutAppData`

1. ジョブ実行( `/startCopy.py` )  
`ExecAppScript`  

1. ジョブ実行結果 ( `/copyResponse.json` )取得  
`GetAppData`  
> ポーリングしてください

1. ジョブ設定、実行結果ファイル削除( `/removeFile.py` )  
`ExecAppScript`

### IWSジョブ実行

1. ジョブ設定ファイル( `/IWSJobrequest.json` )格納  
`PutAppData`

1. ジョブ実行( `/startJob.py` )  
`ExecAppScript`  

> ジョブ実行結果はstartJob.pyからMFPConnectorに対してメッセージ送信し伝達するため、ジョブ実行結果のポーリングは不要。  
ポーリングを考慮しないため、ジョブ設定、実行結果ファイル削除はstartJob.pyに集約した。