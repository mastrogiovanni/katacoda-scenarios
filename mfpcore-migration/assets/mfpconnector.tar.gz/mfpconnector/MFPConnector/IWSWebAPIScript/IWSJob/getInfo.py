# -*- coding: utf-8 -*-
import sys
import socket
import pickle
from contextlib import closing

try:
    exec_script=sys.argv[1]
    exec(exec_script)
except Exception as e:
    result = e
finally:
    host = '4c8664bb.wph.local'
    port = 5005

    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    with closing(sock):

        data = pickle.dumps(result)

        sock.sendto(data, (host, port))


