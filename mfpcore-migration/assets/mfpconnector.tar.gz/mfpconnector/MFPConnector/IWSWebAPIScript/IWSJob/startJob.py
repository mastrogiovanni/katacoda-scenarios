# -*- coding: utf-8 -*-

import sys
import os
import json
import traceback
import socket
import mfp

REQ_FILE_PATH = '/IWSJobrequest.json'

JOB_TYPE_KEY = 'job_type'

JOB_TYPE_COPY = 'copy'
JOB_TYPE_SCAN = 'scan'

COPY_PARAM = 'copy_param'
SCAN_PARAM = 'scan_param'

RESULT_OK = "OK"
RESULT_NG = "NG"

MFP_CONNECTOR = 'be222949.wph.local'
MFP_CONNECTOR_PORT = 5005

def startJob():
    try:
        # parse IWSJobrequest.json
        with open(REQ_FILE_PATH,'r') as reqFp:
            reqJson = json.load(reqFp)
        # change import module by 'job_type' 
        if reqJson[JOB_TYPE_KEY] == JOB_TYPE_COPY:
            from setCopy import createIWSJobObject  # @UnresolvedImport @UnusedImport
            param = reqJson[COPY_PARAM]
            
        elif reqJson[JOB_TYPE_KEY] == JOB_TYPE_SCAN:
            from setScan import createIWSJobObject  # @Reimport
            param = reqJson[SCAN_PARAM]
        else:
            raise mfp.MFPValidationErr
    
        # create IWSJobObject
        iwsJobObject = createIWSJobObject(param)
        # execute IWSJob
        jobid = mfp.job.start(iwsJobObject)
        # Write response json data.
        resJson = json.dumps({ "result": RESULT_OK, "job_id": jobid })
    except mfp.MFPDocumentDetectionErr:
        print("mfp.MFPDocumentDetectionErr", file=sys.stderr)
        resJson = json.dumps({ "result": RESULT_NG, "error": "MFPDocumentDetectionErr" })
    except mfp.MFPInvalidStateErr:
        print("mfp.MFPInvalidStateErr", file=sys.stderr)
        resJson = json.dumps({ "result": RESULT_NG, "error": "MFPInvalidStateErr" })
    except mfp.MFPValidationErr:
        print("mfp.MFPValidationErr", file=sys.stderr)
        resJson = json.dumps({ "result": RESULT_NG, "error": "MFPValidationErr" })
    except mfp.MFPPermissionErr:
        print("mfp.MFPPermissionErr", file=sys.stderr)
        resJson = json.dumps({ "result": RESULT_NG, "error": "MFPPermissionErr" })
    except mfp.MFPException:
        print("mfp.MFPException", file=sys.stderr)
        resJson = json.dumps({ "result": RESULT_NG, "error": "MFPException" })
    except:
        traceback.print_exc(file=sys.stderr)
        resJson = json.dumps({ "result": RESULT_NG, "error": "ScriptException" })
    finally:
        try:
            # delete script
            os.remove(REQ_FILE_PATH)
            # send response data toward MfpConnector
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.sendto(bytes(resJson, "utf-8"), (MFP_CONNECTOR, MFP_CONNECTOR_PORT))
        except:
            traceback.print_exc(file=sys.stderr)
        finally:
            sock.close()

if __name__ == "__main__":
    startJob()