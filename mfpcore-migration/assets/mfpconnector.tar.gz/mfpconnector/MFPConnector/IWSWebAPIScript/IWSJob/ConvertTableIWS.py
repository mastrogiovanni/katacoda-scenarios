# -*- coding: UTF-8 -*-
from mfp import *  # @UnusedWildImport

scan_side_table = {
    "SIMPLEX"      :ScanSide.SIMPLEX,
    "DUPLEX"       :ScanSide.DUPLEX,
    "COVER_DUPLEX" :ScanSide.COVER_DUPLEX
}

original_size_type_table = {
    "AUTO"         :OriginalSizeType.AUTO,
    "STANDARD"     :OriginalSizeType.STANDARD
}

paper_size_table = {
    "UNKNOWN"              : PaperSize.UNKNOWN,
    "SEF_A3"               : PaperSize.SEF_A3,
    "SEF_A4"               : PaperSize.SEF_A4,
    "LEF_A4"               : PaperSize.LEF_A4,
    "SEF_A5"               : PaperSize.SEF_A5,
    "LEF_A5"               : PaperSize.LEF_A5,
    "SEF_A6"               : PaperSize.SEF_A6,
    "LEF_A6"               : PaperSize.LEF_A6,
    "SEF_B4"               : PaperSize.SEF_B4,
    "SEF_B5"               : PaperSize.SEF_B5,
    "LEF_B5"               : PaperSize.LEF_B5,
    "SEF_B6"               : PaperSize.SEF_B6,
    "LEF_B6"               : PaperSize.LEF_B6,
    "SEF_LEDGER"           : PaperSize.SEF_LEDGER,
    "SEF_11x15"            : PaperSize.SEF_11x15,
    "SEF_11x14"            : PaperSize.SEF_11x14,
    "SEF_LEGAL"            : PaperSize.SEF_LEGAL,
    "SEF_LETTER"           : PaperSize.SEF_LETTER,
    "LEF_LETTER"           : PaperSize.LEF_LETTER,
    "SEF_EXECTIVE"         : PaperSize.SEF_EXECTIVE,
    "LEF_EXECTIVE"         : PaperSize.LEF_EXECTIVE,
    "SEF_INVOICE"          : PaperSize.SEF_INVOICE,
    "LEF_INVOICE"          : PaperSize.LEF_INVOICE,
    "SEF_POSTCARD_JP"      : PaperSize.SEF_POSTCARD_JP,
    "LEF_POSTCARD_JP"      : PaperSize.LEF_POSTCARD_JP,
    "SEF_POSTCARD_EU"      : PaperSize.SEF_POSTCARD_EU,
    "LEF_POSTCARD_EU"      : PaperSize.LEF_POSTCARD_EU,
    "SEF_FOOLSCAP"         : PaperSize.SEF_FOOLSCAP,
    "SEF_8K"               : PaperSize.SEF_8K,
    "SEF_16K"              : PaperSize.SEF_16K,
    "LEF_16K"              : PaperSize.LEF_16K,
    "SEF_A0x2"             : PaperSize.SEF_A0x2,
    "SEF_A0"               : PaperSize.SEF_A0,
    "SEF_A1"               : PaperSize.SEF_A1,
    "SEF_A2"               : PaperSize.SEF_A2,
    "SEF_B0"               : PaperSize.SEF_B0,
    "SEF_B1"               : PaperSize.SEF_B1,
    "SEF_B2"               : PaperSize.SEF_B2,
    "SEF_B3"               : PaperSize.SEF_B3,
    "SEF_48x64"            : PaperSize.SEF_48x64,
    "SEF_36x48"            : PaperSize.SEF_36x48,
    "SEF_24x36"            : PaperSize.SEF_24x36,
    "SEF_18x24"            : PaperSize.SEF_18x24,
    "SEF_44x68"            : PaperSize.SEF_44x68,
    "SEF_34x44"            : PaperSize.SEF_34x44,
    "SEF_22x34"            : PaperSize.SEF_22x34,
    "SEF_17x22"            : PaperSize.SEF_17x22,
    "SEF_PHOTO_JP_E"       : PaperSize.SEF_PHOTO_JP_E,
    "LEF_PHOTO_JP_E"       : PaperSize.LEF_PHOTO_JP_E,
    "SEF_PHOTO_JP_L"       : PaperSize.SEF_PHOTO_JP_L,
    "LEF_PHOTO_JP_L"       : PaperSize.LEF_PHOTO_JP_L,
    "SEF_9x13"             : PaperSize.SEF_9x13,
    "LEF_9x13"             : PaperSize.LEF_9x13,
    "SEF_10x15"            : PaperSize.SEF_10x15,
    "LEF_10x15"            : PaperSize.LEF_10x15,
    "SEF_13x18"            : PaperSize.SEF_13x18,
    "LEF_13x18"            : PaperSize.LEF_13x18,
    "SEF_4x6"              : PaperSize.SEF_4x6,
    "LEF_4x6"              : PaperSize.LEF_4x6,
    "SEF_3x5"              : PaperSize.SEF_3x5,
    "LEF_3x5"              : PaperSize.LEF_3x5,
    "SEF_225x325"          : PaperSize.SEF_225x325,
    "LEF_225x325"          : PaperSize.LEF_225x325,
    "NOT_STANDARD_SIZE"    : PaperSize.NOT_STANDARD_SIZE,
    "SEF_12x18"            : PaperSize.SEF_12x18,
    "SEF_10x14"            : PaperSize.SEF_10x14,
    "SEF_GOVERMENT_LETTER" : PaperSize.SEF_GOVERMENT_LETTER,
    "SEF_8x10"             : PaperSize.SEF_8x10,
    "JP_LETTER_L3"         : PaperSize.JP_LETTER_L3,
    "JP_LETTER_K2"         : PaperSize.JP_LETTER_K2,
    "JP_LETTER_Y1"         : PaperSize.JP_LETTER_Y1,
    "JP_LETTER_Y2"         : PaperSize.JP_LETTER_Y2,
    "JP_LETTER_Y4"         : PaperSize.JP_LETTER_Y4,
    "JP_LETTER_Y6"         : PaperSize.JP_LETTER_Y6,
    "ENVELOPE_KING_SIZE"   : PaperSize.ENVELOPE_KING_SIZE,
    "ENVELOPE_COM10"       : PaperSize.ENVELOPE_COM10,
    "ENVELOPE_DL"          : PaperSize.ENVELOPE_DL,
    "ENVELOPE_C5"          : PaperSize.ENVELOPE_C5,
    "ENVELOPE_B5"          : PaperSize.ENVELOPE_B5,
    "SEF_A3_W"             : PaperSize.SEF_A3_W,
    "SEF_B4_W"             : PaperSize.SEF_B4_W,
    "LEF_A4_W"             : PaperSize.LEF_A4_W,
    "SEF_A4_W"             : PaperSize.SEF_A4_W,
    "LEF_B5_W"             : PaperSize.LEF_B5_W,
    "SEF_B5_W"             : PaperSize.SEF_B5_W,
    "LEF_A5_W"             : PaperSize.LEF_A5_W,
    "SEF_A5_W"             : PaperSize.SEF_A5_W,
    "SEF_LEDGER_W"         : PaperSize.SEF_LEDGER_W,
    "LEF_LETTER_W"         : PaperSize.LEF_LETTER_W,
    "SEF_LETTER_W"         : PaperSize.SEF_LETTER_W,
    "LEF_INVOICE_W"        : PaperSize.LEF_INVOICE_W,
    "SEF_INVOICE_W"        : PaperSize.SEF_INVOICE_W,
    "MEMORY1"              : PaperSize.MEMORY1,
    "MEMORY2"              : PaperSize.MEMORY2,
    "MEMORY3"              : PaperSize.MEMORY3,
    "MEMORY4"              : PaperSize.MEMORY4,
    "MEMORY5"              : PaperSize.MEMORY5,
    "LONGPAPER"            : PaperSize.LONGPAPER,
    "SEF_SRA3"             : PaperSize.SEF_SRA3,
    "ENVELOPE_C4"          : PaperSize.ENVELOPE_C4,
    "JP_LETTER_L4"         : PaperSize.JP_LETTER_L4,
    "JP_LETTER_Y3"         : PaperSize.JP_LETTER_Y3,
    "JP_LETTER_K1"         : PaperSize.JP_LETTER_K1,
    "JP_LETTER_K3"         : PaperSize.JP_LETTER_K3,
    "LETTER_PLUS"          : PaperSize.LETTER_PLUS,
    "DOUBLE_POSTCARD"      : PaperSize.DOUBLE_POSTCARD,
    "MONARCH"              : PaperSize.MONARCH,
    "NOT_SELECTED"         : PaperSize.NOT_SELECTED
}

original_type_table = {
    "TEXT"                     :OriginalType.TEXT,
    "PHOTO_PHOTO_PAPER"        :OriginalType.PHOTO_PHOTO_PAPER,
    "PHOTO_PRINTED_PHOTO"      :OriginalType.PHOTO_PRINTED_PHOTO,
    "DOT_MATRIX_ORIGINAL"      :OriginalType.DOT_MATRIX_ORIGINAL,
    "TEXT_PHOTO_PHOTO_PAPER"   :OriginalType.TEXT_PHOTO_PHOTO_PAPER,
    "TEXT_PHOTO_PRINTED_PHOTO" :OriginalType.TEXT_PHOTO_PRINTED_PHOTO,
    "MAP"                      :OriginalType.MAP,
    "COPIED_ORIGINAL"          :OriginalType.COPIED_ORIGINAL,
    "SIMPLE_BINARY"            :OriginalType.SIMPLE_BINARY
}

background_removal_type_table = {
    "AUTO"    :BackgroundRemovalLevel.AUTO,
    "MANUAL"  :BackgroundRemovalLevel.MANUAL
}

color_mode_table = {
    "AUTO"          :ColorMode.AUTO,
    "FULL_COLOR"    :ColorMode.FULL_COLOR,
    "SINGLE_COLOR"  :ColorMode.SINGLE_COLOR,
    "GRAY_SCALE"    :ColorMode.GRAY_SCALE
}

color_table = {
    "NOT_SELECTED" :Color.NOT_SELECTED,
    "BLACK"        :Color.BLACK
}

paper_tray_table = {
    "AUTO"    :InputTray.AUTO,
    "MANUAL"  :InputTray.MANUAL,
    "TRAY_1"  :InputTray.TRAY_1,
    "TRAY_2"  :InputTray.TRAY_2,
    "TRAY_3"  :InputTray.TRAY_3,
    "TRAY_4"  :InputTray.TRAY_4,
    "TRAY_5"  :InputTray.TRAY_5
}

magnification_table = {
    "AUTO"   :Magnification.AUTO,
    "FULL"   :Magnification.FULL,
    "ZOOM"   :Magnification.ZOOM,
    "SMALL"  :Magnification.SMALL
}

combine_table = {
    "SINGLE"  :Combine.SINGLE,
    "TWO"     :Combine.TWO,
    "FOUR_H"  :Combine.FOUR_H,
    "FOUR_V"  :Combine.FOUR_V,
    "EIGHT_H" :Combine.EIGHT_H,
    "EIGHT_V" :Combine.EIGHT_V
}

sort_type_table = {
    "SORT"  :SortType.SORT,
    "GROUP" :SortType.GROUP,
    "AUTO"  :SortType.AUTO
}

staple_mode_table = {
    "NOT_SELECTED" :StapleMode.NOT_SELECTED,
    "CORNER"       :StapleMode.CORNER,
    "CENTER"       :StapleMode.CENTER,
    "TWO_SIDE"     :StapleMode.TWO_SIDE
}

staple_position_table = {
    "AUTO"  :StaplePosition.AUTO,
    "TOP"   :StaplePosition.TOP,
    "LEFT"  :StaplePosition.LEFT,
    "RIGHT" :StaplePosition.RIGHT
}

staple_angle_table = {
    "AUTO"    :StapleAngle.AUTO,
    "ANGLE_0" :StapleAngle.ANGLE_0
}

hole_punch_mode_table = {
    "NOT_SELECTED" :PunchMode.NOT_SELECTED,
    "TWO_HOLE"     :PunchMode.TWO_HOLE,
    "THREE_HOLE"   :PunchMode.THREE_HOLE,
    "FOUR_HOLE"    :PunchMode.FOUR_HOLE
}

hole_punch_position_table = {
    "AUTO"  :PunchPosition.AUTO,
    "TOP"   :PunchPosition.TOP,
    "LEFT"  :PunchPosition.LEFT,
    "RIGHT" :PunchPosition.RIGHT
}

mixed_original_table = {
    "NOT_SELECTED"    :MixedOriginal.NOT_SELECTED,
    "SAME_WIDTH"      :MixedOriginal.SAME_WIDTH,
    "DIFFERENT_WIDTH" :MixedOriginal.DIFFERENT_WIDTH,
}

watermark_type_table = {
    "NOT_SELECTED" :WatermarkType.NOT_SELECTED,
    "INVALID_COPY" :WatermarkType.INVALID_COPY,
    "COPY"         :WatermarkType.COPY,
    "INVALID"      :WatermarkType.INVALID,
    "PRIVATE"      :WatermarkType.PRIVATE,
    "UNAUTHORIZED" :WatermarkType.UNAUTHORIZED,
    "DRAFT"        :WatermarkType.DRAFT,
    "CONFIDENTIAL" :WatermarkType.CONFIDENTIAL,
    "ILLEGAL_COPY" :WatermarkType.ILLEGAL_COPY
}

watermark_color_table = {
    "BLACK"   :WatermarkColor.BLACK,
    "MAGENTA" :WatermarkColor.MAGENTA,
    "CYAN"    :WatermarkColor.CYAN
}

resolution_table = {
    "200X200" :Resolution.DPI_200_200,
    "300X300" :Resolution.DPI_300_300,
    "400X400" :Resolution.DPI_400_400,
    "600X600" :Resolution.DPI_600_600,
}

fax_resolution_table = {
    "NORMAL"     :FaxResolution.NORMAL,
    "FINE"       :FaxResolution.FINE,
    "SUPER_FINE" :FaxResolution.SUPER_FINE,
    "ULTRA_FINE" :FaxResolution.ULTRA_FINE
}

page_setting_table = {
    "EACH"  :PageSetting.EACH,
    "ALL"  :PageSetting.ALL
}

file_type_table = {
    "PDF"        :FileType.PDF,
    "COMPACTPDF" :FileType.COMPACT_PDF,
    "TIFF"       :FileType.TIFF,
    "JPEG"       :FileType.JPEG,
    "XPS"        :FileType.XPS,
    "COMPACTXPS" :FileType.COMPACT_XPS,
    "DOCX"       :FileType.DOCX,
    "XLSX"       :FileType.XLSX,
    "PPTX"       :FileType.PPTX
}

original_direction_table = {
    "TOP"    :OriginalDirection.TOP,
    "BOTTOM" :OriginalDirection.BOTTOM,
    "LEFT"   :OriginalDirection.LEFT,
    "RIGHT"  :OriginalDirection.RIGHT
}

background_removal_type_table = {
    "AUTO"   :BackgroundRemovalLevel.AUTO,
    "MANUAL" :BackgroundRemovalLevel.MANUAL
}

stamp_kind_table = {
    "URGENT"               :StampKind.URGENT,
    "PLEASE_REPLY"         :StampKind.PLEASE_REPLY,
    "TOP_SECRET"           :StampKind.TOP_SECRET,
    "FOR_YOUR_INFORMATION" :StampKind.FOR_YOUR_INFORMATION,
    "DO_NOT_COPY"          :StampKind.DO_NOT_COPY,
    "IMPORTANT"            :StampKind.IMPORTANT,
    "CONFIDENTIAL"         :StampKind.CONFIDENTIAL,
    "DRAFT"                :StampKind.DRAFT
}
stamp_position_table = {
    "TOP_LEFT"      :StampPosition.TOP_LEFT,
    "TOP"           :StampPosition.TOP,
    "TOP_RIGHT"     :StampPosition.TOP_RIGHT,
    "LEFT"          :StampPosition.LEFT,
    "CENTER"        :StampPosition.CENTER,
    "RIGHT"         :StampPosition.RIGHT,
    "BOTTOM_LEFT"   :StampPosition.BOTTOM_LEFT,
    "BOTTOM"        :StampPosition.BOTTOM,
    "BOTTOM_RIGHT"  :StampPosition.BOTTOM_RIGHT
}
stamp_color_table = {
    "BLACK"   :StampColor.BLACK,
    "RED"     :StampColor.RED,
    "GREEN"   :StampColor.GREEN,
    "BLUE"    :StampColor.BLUE,
    "YELLOW"  :StampColor.YELLOW,
    "MAGENTA" :StampColor.MAGENTA,
    "CYAN"    :StampColor.CYAN
}

stamp_page_table = {
    "ALL_PAGES"         :StampPage.ALL_PAGES,
    "FIRST_PAGE_ONLY"   :StampPage.FIRST_PAGE_ONLY
}

stamp_textsize_table = {
    "MINIMAL"     :StampTextSize.MINIMAL,
    "STANDARD"    :StampTextSize.STANDARD
}

mixed_original_table = {
    "NOT_SELECTED"    :MixedOriginal.NOT_SELECTED,
    "SAME_WIDTH"      :MixedOriginal.SAME_WIDTH,
    "DIFFERENT_WIDTH" :MixedOriginal.DIFFERENT_WIDTH
}

import mfp.job
file_type_table = dict()
try:
    file_type_table["PDF"]        = mfp.job.FileTypePDF()
    
except:
    pass

try:
    file_type_table["COMPACTPDF"] = mfp.job.FileTypeCompactPDF()
except:
    pass

try:
    file_type_table["TIFF"]       = mfp.job.FileTypeTIFF()
except:
    pass

try:
    file_type_table["JPEG"]       = mfp.job.FileTypeJPEG()
except:
    pass

try:
    file_type_table["XPS"]        = mfp.job.FileTypeXPS()
except:
    pass

try:
    file_type_table["COMPACTXPS"] = mfp.job.FileTypeCompactXPS()
except:
    pass

try:
    file_type_table["DOCX"]       = mfp.job.FileTypeDOCX()
except:
    pass

try:
    file_type_table["XLSX"]       = mfp.job.FileTypeXLSX()
except:
    pass

try:
    file_type_table["PPTX"]       = mfp.job.FileTypePPTX()
except:
    pass

pdf_encryption_table = {
    "NOT_ENCRYPT" :PDFEncryption.NOT_ENCRYPT,
    "LOW"         :PDFEncryption.LOW,
    "LEVEL1"      :PDFEncryption.LEVEL1,
    "LEVEL2"      :PDFEncryption.LEVEL2,
}

pdfa_table = {
    "NOT_SETTING":PDFAMode.NOT_SETTING,
    "PDFA_1A"    :PDFAMode.PDFA_1A,
    "PDFA_1B"    :PDFAMode.PDFA_1B
}

ocr_language_table = {
    "JAPANESE"    :LanguageOcrType.JAPANESE,
    "ENGLISH"     :LanguageOcrType.ENGLISH,
    "FRENCH"      :LanguageOcrType.FRENCH,
    "ITALIAN"     :LanguageOcrType.ITALIAN,
    "GERMAN"      :LanguageOcrType.GERMAN,
    "SPANISH"     :LanguageOcrType.SPANISH,
    "CHINESE_CN"  :LanguageOcrType.CHINESE_CN,
    "CHINESE_TW"  :LanguageOcrType.CHINESE_TW,
    "HANGUL"      :LanguageOcrType.HANGUL,
    "DUTCH"       :LanguageOcrType.DUTCH,
    "DANISH"      :LanguageOcrType.DANISH,
    "NORWEGIAN"   :LanguageOcrType.NORWEGIAN,
    "SWEDISH"     :LanguageOcrType.SWEDISH,
    "FINNISH"     :LanguageOcrType.FINNISH,
    "PORTUGUESE"  :LanguageOcrType.PORTUGUESE,
    "TURKISH"     :LanguageOcrType.TURKISH,
    "GREEK"       :LanguageOcrType.GREEK,
    "CZECH"       :LanguageOcrType.CZECH,
    "POLISH"      :LanguageOcrType.POLISH,
    "HUNGARIAN"   :LanguageOcrType.HUNGARIAN,
    "SLOVAK"      :LanguageOcrType.SLOVAK,
    "RUSSIAN"     :LanguageOcrType.RUSSIAN,
    "CATALAN"     :LanguageOcrType.CATALAN,
    "LITHUANIAN"  :LanguageOcrType.LITHUANIAN,
    "ESTONIAN"    :LanguageOcrType.ESTONIAN,
    "LATVIAN"     :LanguageOcrType.LATVIAN,
    "SLOVENE"     :LanguageOcrType.SLOVENE,
    "ROMANIAN"    :LanguageOcrType.ROMANIAN,
    "UKRAINIAN"   :LanguageOcrType.UKRAINIAN,
    "BULGARIAN"   :LanguageOcrType.BULGARIAN,
    "CROATIAN"    :LanguageOcrType.CROATIAN
}

output_method_table = {
    "TEXT_PRIORITY"     :OutputMethod.TEXT_PRIORITY,
    "IMAGE_PRIORITY"    :OutputMethod.IMAGE_PRIORITY,
    "IMAGE_AND_TEXT"    :OutputMethod.IMAGE_AND_TEXT,
    "TEXT_ONLY"         :OutputMethod.TEXT_ONLY
}

#end.

