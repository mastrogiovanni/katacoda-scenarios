# -*- coding: utf-8 -*-
###################################################################################
PAGE_SETTING_KEY = 'page_setting'

SCAN_SIDE_KEY = 'scan_side'

RESOLUTION_KEY = 'resolution'

FAX_RESOLUTION_KEY = 'fax_resolution'

DENSITY_KEY = 'density'

PAPER_SIZE_KEY = 'paper_size'
PAPER_SIZE_TYPE_KEY = 'type'
PAPER_SIZE_DATA_KEY = 'data'

ORIGINAL_DIRECTION_KEY = 'original_direction'

ORIGINAL_TYPE_KEY = 'original_type'

BACK_DENSITY_KEY = 'back_density'
BACK_DENSITY_TYPE_KEY = 'type'
BACK_DENSITY_LEVEL_KEY = 'level'

FILE_NAME_KEY = 'file_name'

COLOR_KEY ='color'
COLOR_MODE_KEY ='mode'
COLOR_COLOR_KEY ='color'

FILE_TYPE_KEY = 'file_type'

PDF_PARAM_KEY = 'pdf_param'
PDF_PARAM_ENCRYPTION_KEY = 'encryption'
PDF_PARAM_DOCPASS_KEY = 'docpass'
PDF_PARAM_AUTHPASS_KEY = 'authpass'
PDF_PARAM_PDFA_KEY = 'pdfa'
PDF_PARAM_WEB_OPTIMIZATION_KEY = 'web_optimization'
PDF_PARAM_SEARCHABLE_PDF_KEY = 'searchable_pdf'
PDF_PARAM_OCR_SETTING_KEY = 'ocr_setting'
PDF_PARAM_OCR_SETTING_LANGUAGE_KEY = 'language'
PDF_PARAM_OCR_SETTING_ADJUST_ROTATE_KEY = 'adjust_rotate'
PDF_PARAM_OUTLINE_KEY = 'outline_pdf'

MS_PARAM_KEY = 'ms_param'
MS_PARAM_OCR_KEY = 'ocr'
MS_PARAM_OCR_SETTING_KEY = 'ocr_setting'
MS_PARAM_OCR_SETTING_LANGUAGE_KEY = 'language'
MS_PARAM_OCR_SETTING_ADJUST_ROTATE_KEY = 'adjust_rotate'
MS_PARAM_METHOD_KEY = 'method'

STAMP_KEY = 'stamp'
STAMP_KIND_KEY = 'kind'
STAMP_PAGE_KEY = 'page'
STAMP_POSITION_KEY = 'position'
STAMP_TEXT_SIZE_KEY = 'text_size'
STAMP_COLOR_KEY = 'color'

TX_LIST_KEY = 'tx_list'
TX_LIST_TX_NUNM_KEY = 'tx_num'
TX_LIST_TX_BASE = 'tx'
TX_LIST_KIND_KEY = 'kind'

TX_LIST_EMAIL_SUBJECT_KEY = 'subject'
TX_LIST_EMAIL_BODY_KEY = 'body'
TX_LIST_EMAIL_ADDRESS_BASE = 'address'
TX_LIST_EMAIL_ADDRESS_NUM_KEY = 'address_num'
TX_LIST_EMAIL_FROM_ADDRESS_KEY = 'from_address'

TX_LIST_SMB_HOST_KEY = 'host_address'
TX_LIST_SMB_DIR_KEY = 'dir'
TX_LIST_SMB_USER_KEY = 'user'
TX_LIST_SMB_PASSWORD_KEY = 'password'

TX_LIST_WEBDAV_HOST_KEY = 'host_address'
TX_LIST_WEBDAV_DIR_KEY = 'dir'
TX_LIST_WEBDAV_USER_KEY = 'user'
TX_LIST_WEBDAV_PASSWORD_KEY = 'password'
TX_LIST_WEBDAV_USE_PROXY_KEY = 'use_proxy'
TX_LIST_WEBDAV_PORT_NO_KEY = 'port_no'
TX_LIST_WEBDAV_USE_SSL_KEY = 'use_ssl'

TX_LIST_FAX_ADDRESS_NUM_KEY = 'address_num'
TX_LIST_FAX_ADDRESS_BASE = 'address'
TX_LIST_FAX_USE_OVERSEAS_TX_KEY = 'use_overseas_tx'
TX_LIST_FAX_USE_ECM_KEY = 'use_ecm'
TX_LIST_FAX_USE_CHECK_DEST_AND_SEND_KEY = 'use_check_dest_and_send'
TX_LIST_FAX_CREDENTIAL_PASSWORD_KEY = 'credential'

TX_LIST_HDD_DIR_KEY = 'dir'

MULTI_FEED_DETECT_KEY = 'multi_feed_detect'

BLANK_PAGE_REMOVAL_KEY = 'blank_page_removal'

MIXED_ORIGINAL_KEY = 'mixed_original'


###################################################################################

def createIWSJobObject(param):
    try:
        from ConvertTableIWS import scan_side_table
        from ConvertTableIWS import resolution_table
        from ConvertTableIWS import fax_resolution_table
        from ConvertTableIWS import page_setting_table
        from ConvertTableIWS import file_type_table
        from ConvertTableIWS import original_direction_table
        from ConvertTableIWS import background_removal_type_table
        from ConvertTableIWS import stamp_kind_table
        from ConvertTableIWS import stamp_position_table
        from ConvertTableIWS import stamp_color_table
        from ConvertTableIWS import mixed_original_table
        from ConvertTableIWS import original_size_type_table
        from ConvertTableIWS import paper_size_table
        from ConvertTableIWS import original_type_table
        from ConvertTableIWS import color_mode_table
        from ConvertTableIWS import color_table
        from ConvertTableIWS import pdf_encryption_table
        from ConvertTableIWS import pdfa_table
        from ConvertTableIWS import ocr_language_table
        from ConvertTableIWS import output_method_table
        from ConvertTableIWS import stamp_page_table
        from ConvertTableIWS import stamp_textsize_table
        import mfp  # @UnusedImport
        import mfp.job
        iwsJobObject = mfp.job.Scan()

        if SCAN_SIDE_KEY in param:
            if param[SCAN_SIDE_KEY] not in scan_side_table:
                raise mfp.MFPValidationErr
            iwsJobObject.set_scan_side(scan_side_table[param[SCAN_SIDE_KEY]])

        if RESOLUTION_KEY in param:
            if param[RESOLUTION_KEY] not in resolution_table:
                raise mfp.MFPValidationErr
            iwsJobObject.set_resolution(resolution_table[param[RESOLUTION_KEY]])

        if FAX_RESOLUTION_KEY in param:
            if param[FAX_RESOLUTION_KEY] not in fax_resolution_table:
                raise mfp.MFPValidationErr
            iwsJobObject.set_fax_resolution(fax_resolution_table[param[FAX_RESOLUTION_KEY]])

        if FILE_NAME_KEY in param:
            iwsJobObject.set_file_name(param[FILE_NAME_KEY])

        if PAGE_SETTING_KEY in param:
            if param[PAGE_SETTING_KEY] not in page_setting_table:
                raise mfp.MFPValidationErr
            iwsJobObject.set_page_setting(page_setting_table[param[PAGE_SETTING_KEY]])

        if FILE_TYPE_KEY in param:
            if param[FILE_TYPE_KEY] not in file_type_table:
                raise mfp.MFPValidationErr

            file_type = file_type_table[param[FILE_TYPE_KEY]]

            #PDF or CompactPDF
            if isinstance(file_type, mfp.job.FileTypePDF) or isinstance(file_type, mfp.job.FileTypeCompactPDF):
                if PDF_PARAM_KEY in param:
                    #Encryption
                    if PDF_PARAM_ENCRYPTION_KEY in param[PDF_PARAM_KEY]:
                        if param[PDF_PARAM_KEY][PDF_PARAM_ENCRYPTION_KEY] not in pdf_encryption_table:
                            raise mfp.MFPValidationErr

                        #Document password dose not set
                        if PDF_PARAM_DOCPASS_KEY not in param[PDF_PARAM_KEY]:
                            file_type.set_encryption(pdf_encryption_table[param[PDF_PARAM_KEY][PDF_PARAM_ENCRYPTION_KEY]])
                        else:
                            #Auth password
                            if PDF_PARAM_AUTHPASS_KEY not in param[PDF_PARAM_KEY]:
                                file_type.set_encryption(pdf_encryption_table[param[PDF_PARAM_KEY][PDF_PARAM_ENCRYPTION_KEY]],param[PDF_PARAM_KEY][PDF_PARAM_DOCPASS_KEY])
                            else:
                                file_type.set_encryption(pdf_encryption_table[param[PDF_PARAM_KEY][PDF_PARAM_ENCRYPTION_KEY]],param[PDF_PARAM_KEY][PDF_PARAM_DOCPASS_KEY],param[PDF_PARAM_KEY][PDF_PARAM_AUTHPASS_KEY])

                    #PDFA
                    if PDF_PARAM_PDFA_KEY in param[PDF_PARAM_KEY]:
                        if param[PDF_PARAM_KEY][PDF_PARAM_PDFA_KEY] not in pdfa_table:
                            raise mfp.MFPValidationErr
                        file_type.set_pdfa(pdfa_table[param[PDF_PARAM_KEY][PDF_PARAM_PDFA_KEY]])

                    #Web optimization
                    if PDF_PARAM_WEB_OPTIMIZATION_KEY in param[PDF_PARAM_KEY]:
                        file_type.set_web_optimization(param[PDF_PARAM_KEY][PDF_PARAM_WEB_OPTIMIZATION_KEY])

                    #Searchable PDF
                    if PDF_PARAM_SEARCHABLE_PDF_KEY in param[PDF_PARAM_KEY]:
                        if PDF_PARAM_OCR_SETTING_KEY not in param[PDF_PARAM_KEY]:
                            file_type.set_searchable_pdf(param[PDF_PARAM_KEY][PDF_PARAM_SEARCHABLE_PDF_KEY])
                        else:
                            #required(language)
                            if PDF_PARAM_OCR_SETTING_LANGUAGE_KEY not in param[PDF_PARAM_KEY][PDF_PARAM_OCR_SETTING_KEY]:
                                raise mfp.MFPValidationErr
                            if param[PDF_PARAM_KEY][PDF_PARAM_OCR_SETTING_KEY][PDF_PARAM_OCR_SETTING_LANGUAGE_KEY] not in ocr_language_table:
                                raise mfp.MFPValidationErr
                            #required(rotate)
                            if PDF_PARAM_OCR_SETTING_ADJUST_ROTATE_KEY not in param[PDF_PARAM_KEY][PDF_PARAM_OCR_SETTING_KEY]:
                                raise mfp.MFPValidationErr
                            ocr_setting = mfp.job.OcrSetting()
                            ocr_setting.set_language(ocr_language_table[param[PDF_PARAM_KEY][PDF_PARAM_OCR_SETTING_KEY][PDF_PARAM_OCR_SETTING_LANGUAGE_KEY]])
                            ocr_setting.set_adjust_rotate(param[PDF_PARAM_KEY][PDF_PARAM_OCR_SETTING_KEY][PDF_PARAM_OCR_SETTING_ADJUST_ROTATE_KEY])

                            file_type.set_searchable_pdf(param[PDF_PARAM_KEY][PDF_PARAM_SEARCHABLE_PDF_KEY],ocr_setting)

                    #Only Compact PDF
                    if isinstance(file_type, mfp.job.FileTypeCompactPDF):
                        #Outline PDF
                        if PDF_PARAM_OUTLINE_KEY in param[PDF_PARAM_KEY]:
                            file_type.set_outline_pdf(param[PDF_PARAM_KEY][PDF_PARAM_OUTLINE_KEY])

            #TIFF
            elif isinstance(file_type, mfp.job.FileTypeTIFF):
                pass
            #JPEG
            elif isinstance(file_type, mfp.job.FileTypeJPEG):
                pass
            #XPS
            elif isinstance(file_type, mfp.job.FileTypeXPS):
                pass
            #CompactXPS
            elif isinstance(file_type, mfp.job.FileTypeCompactXPS):
                pass
            #DOCX or XLSX or PPTX
            elif isinstance(file_type, mfp.job.FileTypeDOCX) or isinstance(file_type, mfp.job.FileTypeXLSX) or isinstance(file_type, mfp.job.FileTypePPTX):
                if MS_PARAM_KEY in param:
                    #required(ocr)
                    if MS_PARAM_OCR_KEY not in param[MS_PARAM_KEY]:
                        raise mfp.MFPValidationErr

                    #option(ocr_setting)
                    if MS_PARAM_OCR_SETTING_KEY not in param[MS_PARAM_KEY]:
                        file_type.set_ocr(param[MS_PARAM_KEY][MS_PARAM_OCR_KEY])
                    else:
                        #required(language)
                        if MS_PARAM_OCR_SETTING_LANGUAGE_KEY not in param[MS_PARAM_KEY][MS_PARAM_OCR_SETTING_KEY]:
                            raise mfp.MFPValidationErr
                        if param[MS_PARAM_KEY][MS_PARAM_OCR_SETTING_KEY][MS_PARAM_OCR_SETTING_LANGUAGE_KEY] not in ocr_language_table:
                            raise mfp.MFPValidationErr
                        #required(adjust_rotate)
                        if MS_PARAM_OCR_SETTING_ADJUST_ROTATE_KEY not in param[MS_PARAM_KEY][MS_PARAM_OCR_SETTING_KEY]:
                            raise mfp.MFPValidationErr

                        ocr_setting = mfp.job.OcrSetting()
                        ocr_setting.set_language(ocr_language_table[param[MS_PARAM_KEY][MS_PARAM_OCR_SETTING_KEY][MS_PARAM_OCR_SETTING_LANGUAGE_KEY]])
                        ocr_setting.set_adjust_rotate(param[MS_PARAM_KEY][MS_PARAM_OCR_SETTING_KEY][MS_PARAM_OCR_SETTING_ADJUST_ROTATE_KEY])

                        #only PPTX
                        if isinstance(file_type, mfp.job.FileTypePPTX):
                            file_type.set_ocr(param[MS_PARAM_KEY][MS_PARAM_OCR_KEY],ocr_setting)
                        else:
                            #option(method)
                            if MS_PARAM_METHOD_KEY not in param[MS_PARAM_KEY]:
                                file_type.set_ocr(param[MS_PARAM_KEY][MS_PARAM_OCR_KEY],ocr_setting)
                            else:
                                if param[MS_PARAM_KEY][MS_PARAM_METHOD_KEY] not in output_method_table:
                                    raise mfp.MFPValidationErr
                                file_type.set_ocr(param[MS_PARAM_KEY][MS_PARAM_OCR_KEY],ocr_setting,output_method_table[param[MS_PARAM_KEY][MS_PARAM_METHOD_KEY]])

            iwsJobObject.set_file_type(file_type)

        if COLOR_KEY in param:
            #required(mode)
            if COLOR_MODE_KEY not in param[COLOR_KEY]:
                raise mfp.MFPValidationErr
            if param[COLOR_KEY][COLOR_MODE_KEY] not in color_mode_table:
                raise mfp.MFPValidationErr

            #option(color)
            if COLOR_COLOR_KEY not in param[COLOR_KEY]:
                iwsJobObject.set_color(color_mode_table[param[COLOR_KEY][COLOR_MODE_KEY]])
            else:
                if param[COLOR_KEY][COLOR_COLOR_KEY] not in color_table:
                    raise mfp.MFPValidationErr
                iwsJobObject.set_color(color_mode_table[param[COLOR_KEY][COLOR_MODE_KEY]],color_table[param[COLOR_KEY][COLOR_COLOR_KEY]])

        if ORIGINAL_TYPE_KEY in param:
            if param[ORIGINAL_TYPE_KEY] not in original_type_table:
                raise mfp.MFPValidationErr
            iwsJobObject.set_original_type(original_type_table[param[ORIGINAL_TYPE_KEY]])

        if PAPER_SIZE_KEY in param:
            #required(type)
            if PAPER_SIZE_TYPE_KEY not in param[PAPER_SIZE_KEY]:
                raise mfp.MFPValidationErr
            if param[PAPER_SIZE_KEY][PAPER_SIZE_TYPE_KEY] not in original_size_type_table:
                raise mfp.MFPValidationErr

            #option(data)
            if PAPER_SIZE_DATA_KEY not in param[PAPER_SIZE_KEY]:
                iwsJobObject.set_paper_size(original_size_type_table[param[PAPER_SIZE_KEY][PAPER_SIZE_TYPE_KEY]])
            else:
                if param[PAPER_SIZE_KEY][PAPER_SIZE_DATA_KEY] not in paper_size_table:
                    raise mfp.MFPValidationErr
                iwsJobObject.set_paper_size(original_size_type_table[param[PAPER_SIZE_KEY][PAPER_SIZE_TYPE_KEY]],paper_size_table[param[PAPER_SIZE_KEY][PAPER_SIZE_DATA_KEY]])

        if ORIGINAL_DIRECTION_KEY in param:
            if param[ORIGINAL_DIRECTION_KEY] not in original_direction_table:
                raise mfp.MFPValidationErr
            iwsJobObject.set_original_direction(original_direction_table[param[ORIGINAL_DIRECTION_KEY]])

        if DENSITY_KEY in param:
            iwsJobObject.set_density(param[DENSITY_KEY])

        if BACK_DENSITY_KEY in param:
            #required(type)
            if BACK_DENSITY_TYPE_KEY not in param[BACK_DENSITY_KEY]:
                raise mfp.MFPValidationErr
            if param[BACK_DENSITY_KEY][BACK_DENSITY_TYPE_KEY] not in background_removal_type_table:
                raise mfp.MFPValidationErr

            #option(level)
            if BACK_DENSITY_LEVEL_KEY not in param[BACK_DENSITY_KEY]:
                iwsJobObject.set_back_density(background_removal_type_table[param[BACK_DENSITY_KEY][BACK_DENSITY_TYPE_KEY]])
            else:
                iwsJobObject.set_back_density(background_removal_type_table[param[BACK_DENSITY_KEY][BACK_DENSITY_TYPE_KEY]],param[BACK_DENSITY_KEY][BACK_DENSITY_LEVEL_KEY])

        if STAMP_KEY in param:
            #required(kind)
            if STAMP_KIND_KEY not in param[STAMP_KEY]:
                raise mfp.MFPValidationErr
            if param[STAMP_KEY][STAMP_KIND_KEY] not in stamp_kind_table:
                raise mfp.MFPValidationErr

            #required(page)
            if STAMP_PAGE_KEY not in param[STAMP_KEY]:
                raise mfp.MFPValidationErr
            if param[STAMP_KEY][STAMP_PAGE_KEY] not in stamp_page_table:
                raise mfp.MFPValidationErr

            #required(position)
            if STAMP_POSITION_KEY not in param[STAMP_KEY]:
                raise mfp.MFPValidationErr
            if param[STAMP_KEY][STAMP_POSITION_KEY] not in stamp_position_table:
                raise mfp.MFPValidationErr

            #required(size)
            if STAMP_TEXT_SIZE_KEY not in param[STAMP_KEY]:
                raise mfp.MFPValidationErr
            if param[STAMP_KEY][STAMP_TEXT_SIZE_KEY] not in stamp_textsize_table:
                raise mfp.MFPValidationErr

            #required(color)
            if STAMP_COLOR_KEY not in param[STAMP_KEY]:
                raise mfp.MFPValidationErr
            if param[STAMP_KEY][STAMP_COLOR_KEY] not in stamp_color_table:
                raise mfp.MFPValidationErr

            stamp = mfp.job.Stamp()
            stamp.set_kind(stamp_kind_table[param[STAMP_KEY][STAMP_KIND_KEY]])
            stamp.set_page(stamp_page_table[param[STAMP_KEY][STAMP_PAGE_KEY]])
            stamp.set_position(stamp_position_table[param[STAMP_KEY][STAMP_POSITION_KEY]])
            stamp.set_text_size(stamp_textsize_table[param[STAMP_KEY][STAMP_TEXT_SIZE_KEY]])
            stamp.set_color(stamp_color_table[param[STAMP_KEY][STAMP_COLOR_KEY]])

            iwsJobObject.set_stamp(stamp)

        if MULTI_FEED_DETECT_KEY in param:
            iwsJobObject.set_multi_feed_detect(param[MULTI_FEED_DETECT_KEY])

        if BLANK_PAGE_REMOVAL_KEY in param:
            iwsJobObject.set_blank_page_removal(param[BLANK_PAGE_REMOVAL_KEY])
 
        if MIXED_ORIGINAL_KEY in param:
            if param[MIXED_ORIGINAL_KEY] not in mixed_original_table:
                raise mfp.MFPValidationErr
            iwsJobObject.set_mixed_original(mixed_original_table[param[MIXED_ORIGINAL_KEY]])

        if TX_LIST_KEY in param:
            #required(tx_num)
            if TX_LIST_TX_NUNM_KEY not in param[TX_LIST_KEY]:
                raise mfp.MFPValidationErr
            tx_num = param[TX_LIST_KEY][TX_LIST_TX_NUNM_KEY]

            send_list = []
            for num in range(1,tx_num+1):
                tx_key=TX_LIST_TX_BASE + str(num)
                #required(txX)
                if tx_key not in param[TX_LIST_KEY]:
                    raise mfp.MFPValidationErr

                tx_param = param[TX_LIST_KEY][tx_key]
                #required(kind)
                if TX_LIST_KIND_KEY not in tx_param:
                    raise mfp.MFPValidationErr

                kind = tx_param[TX_LIST_KIND_KEY]
                if kind == "Email":
                    if TX_LIST_EMAIL_ADDRESS_BASE + '1' not in tx_param:
                        raise mfp.MFPValidationErr

                    #required(from_address)
                    if TX_LIST_EMAIL_FROM_ADDRESS_KEY not in tx_param:
                        raise mfp.MFPValidationErr
                    tx = mfp.job.TxEMail(tx_param[TX_LIST_EMAIL_FROM_ADDRESS_KEY])

                    #option(send_address)
                    address_num = tx_param[TX_LIST_EMAIL_ADDRESS_NUM_KEY]
                    for num in range(1, address_num+1):
                        address_key = TX_LIST_EMAIL_ADDRESS_BASE + str(num)
                        tx.add_send_address(tx_param[address_key])
                    
                    #option(subject)
                    if TX_LIST_EMAIL_SUBJECT_KEY in tx_param:
                        tx.set_subject(tx_param[TX_LIST_EMAIL_SUBJECT_KEY])
                    #option(body)
                    if TX_LIST_EMAIL_BODY_KEY in tx_param:
                        tx.set_body(tx_param[TX_LIST_EMAIL_BODY_KEY])

                elif kind == "SMB":
                    #required(host)
                    if TX_LIST_SMB_HOST_KEY not in tx_param:
                        raise mfp.MFPValidationErr
                    tx = mfp.job.TxSMB(tx_param[TX_LIST_SMB_HOST_KEY])

                    #option(dir)
                    if TX_LIST_SMB_DIR_KEY in tx_param:
                        tx.set_dir(tx_param[TX_LIST_SMB_DIR_KEY])

                    #option(user)
                    if TX_LIST_SMB_USER_KEY in tx_param:
                        #option(password)
                        if TX_LIST_SMB_PASSWORD_KEY not in tx_param:
                            tx.set_auth(tx_param[TX_LIST_SMB_USER_KEY])
                        else:
                            tx.set_auth(tx_param[TX_LIST_SMB_USER_KEY],tx_param[TX_LIST_SMB_PASSWORD_KEY])

                elif kind == "WebDAV":
                    #required(host)
                    if TX_LIST_WEBDAV_HOST_KEY not in tx_param:
                        raise mfp.MFPValidationErr

                    #option(port)
                    if TX_LIST_WEBDAV_PORT_NO_KEY not in tx_param:
                        tx = mfp.job.TxWebDAV(tx_param[TX_LIST_WEBDAV_HOST_KEY])
                    else:
                        tx = mfp.job.TxWebDAV(tx_param[TX_LIST_WEBDAV_HOST_KEY],tx_param[TX_LIST_WEBDAV_PORT_NO_KEY])

                    #option(dir)
                    if TX_LIST_WEBDAV_DIR_KEY in tx_param:
                        tx.set_dir(tx_param[TX_LIST_WEBDAV_DIR_KEY])

                    #option(user)
                    if TX_LIST_WEBDAV_USER_KEY in tx_param:
                        #option(password)
                        if TX_LIST_WEBDAV_PASSWORD_KEY not in tx_param:
                            tx.set_auth(tx_param[TX_LIST_WEBDAV_USER_KEY])
                        else:
                            tx.set_auth(tx_param[TX_LIST_WEBDAV_USER_KEY],tx_param[TX_LIST_WEBDAV_PASSWORD_KEY])

                    #option(proxy)
                    if TX_LIST_WEBDAV_USE_PROXY_KEY in tx_param:
                        tx.set_use_proxy(tx_param[TX_LIST_WEBDAV_USE_PROXY_KEY])

                    #option(ssl)
                    if TX_LIST_WEBDAV_USE_SSL_KEY in tx_param:
                        tx.set_use_ssl(tx_param[TX_LIST_WEBDAV_USE_SSL_KEY])

                elif kind == "Fax":
                    if TX_LIST_FAX_ADDRESS_BASE + '1' not in tx_param:
                        raise mfp.MFPValidationErr
                    tx = mfp.job.TxFax()

                    #option(address)
                    address_num = tx_param[TX_LIST_FAX_ADDRESS_NUM_KEY]
                    for num in range(1, address_num+1):
                        address_key = TX_LIST_FAX_ADDRESS_BASE + str(num)
                        tx.add_send_address(tx_param[address_key])
                    
                    #option(use_overseas_tx)
                    if TX_LIST_FAX_USE_OVERSEAS_TX_KEY in tx_param:
                        tx.set_use_overseas_tx(tx_param[TX_LIST_FAX_USE_OVERSEAS_TX_KEY])

                    #option(use_ecm)
                    if TX_LIST_FAX_USE_ECM_KEY in tx_param:
                        tx.set_use_ecm(tx_param[TX_LIST_FAX_USE_ECM_KEY])

                    #option(use_check_dest_and_send)
                    if TX_LIST_FAX_USE_CHECK_DEST_AND_SEND_KEY in tx_param:
                        tx.set_use_check_dest_and_send(tx_param[TX_LIST_FAX_USE_CHECK_DEST_AND_SEND_KEY])

                    #option(credential)
                    if TX_LIST_FAX_CREDENTIAL_PASSWORD_KEY in tx_param:
                        credential = mfp.job.FaxSendCredential(tx_param[TX_LIST_FAX_CREDENTIAL_PASSWORD_KEY])
                        tx.set_credential(credential)

                elif kind == "HDD":
                    #required(dir)
                    if TX_LIST_HDD_DIR_KEY not in tx_param:
                        raise mfp.MFPValidationErr
                    tx = mfp.job.TxHDD(tx_param[TX_LIST_HDD_DIR_KEY])
                else:
                    raise mfp.MFPValidationErr

                send_list.append(tx)

            iwsJobObject.set_tx_list(send_list)

    except Exception as e:
        import traceback
        import sys
        traceback.print_exc(file=sys.stderr)
        raise e
    return iwsJobObject