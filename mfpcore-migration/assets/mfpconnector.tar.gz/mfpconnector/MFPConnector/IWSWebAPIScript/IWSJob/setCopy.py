# -*- coding: utf-8 -*-
###################################################################################

SCAN_SIDE_KEY = 'scan_side'

DENSITY_KEY = 'density'

ORIGINAL_SIZE_KEY = 'original_size'
ORIGINAL_SIZE_TYPE_KEY = 'type'
ORIGINAL_SIZE_DATA_KEY = 'data'

ORIGINAL_TYPE_KEY = 'original_type'

BACKGROUND_REMOVAL_KEY = 'background_removal'
BACKGROUND_REMOVAL_TYPE_KEY = 'type'
BACKGROUND_REMOVAL_LEVEL_KEY = 'level'

NUM_OF_SET_KEY = 'num_of_set'

COLOR_KEY ='color'
COLOR_MODE_KEY ='mode'
COLOR_COLOR_KEY ='color'

PAPER_TRAY_KEY ='paper_tray'
PAPER_TRAY_INPUT_TRAY_KEY ='input_tray'
PAPER_TRAY_PAPER_SIZE_KEY ='paper_size'

ZOOM_KEY = 'zoom'
ZOOM_MAGNIFICATION_KEY = 'magnification'
ZOOM_RATIO_X_KEY = 'ratio_x'
ZOOM_RATIO_Y_KEY = 'ratio_y'

COMBINE_KEY = 'combine'

DUPLEX_KEY = 'duplex'

AUTO_ROTATE_KEY = 'auto_rotate'

SORT_TYPE = 'sort_type'

OFFSET_KEY = 'offset'

STAPLE_KEY = 'staple'
STAPLE_MODE_KEY = 'mode'
STAPLE_POSITION_KEY = 'position'
STAPLE_ANGLE_KEY = 'angle'

HOLE_PUNCH_KEY = 'hole_punch'
HOLE_PUNCH_MODE_KEY = 'mode'
HOLE_PUNCH_POSITION_KEY = 'position'

MULTI_FEED_DETECT_KEY = 'multi_feed_detect'

BLANK_PAGE_REMOVAL_KEY = 'blank_page_removal'

MIXED_ORIGINAL_KEY = 'mixed_original'

WATERMARK_KEY = 'watermark'
WATERMARK_TYPE_KEY = 'type'
WATERMARK_COLOR_KEY = 'color'

###################################################################################

def createIWSJobObject(param):
    try:
        from ConvertTableIWS import scan_side_table
        from ConvertTableIWS import original_size_type_table
        from ConvertTableIWS import paper_size_table
        from ConvertTableIWS import original_type_table
        from ConvertTableIWS import background_removal_type_table
        from ConvertTableIWS import color_mode_table
        from ConvertTableIWS import color_table
        from ConvertTableIWS import paper_tray_table
        from ConvertTableIWS import magnification_table
        from ConvertTableIWS import combine_table
        from ConvertTableIWS import sort_type_table
        from ConvertTableIWS import staple_mode_table
        from ConvertTableIWS import staple_position_table
        from ConvertTableIWS import staple_angle_table
        from ConvertTableIWS import hole_punch_mode_table
        from ConvertTableIWS import hole_punch_position_table
        from ConvertTableIWS import mixed_original_table
        from ConvertTableIWS import watermark_type_table
        from ConvertTableIWS import watermark_color_table
        import mfp  # @UnusedImport
        import mfp.job
        iwsJobObject = mfp.job.Copy()

        if SCAN_SIDE_KEY in param:
            if param[SCAN_SIDE_KEY] not in scan_side_table:
                raise mfp.MFPValidationErr
            iwsJobObject.set_scan_side(scan_side_table[param[SCAN_SIDE_KEY]])

        if DENSITY_KEY in param:
            iwsJobObject.set_density(param[DENSITY_KEY])

        if ORIGINAL_SIZE_KEY in param:
            #required(type)
            if ORIGINAL_SIZE_TYPE_KEY not in param[ORIGINAL_SIZE_KEY]:
                raise mfp.MFPValidationErr
            if param[ORIGINAL_SIZE_KEY][ORIGINAL_SIZE_TYPE_KEY] not in original_size_type_table:
                raise mfp.MFPValidationErr

            #option(data)
            if ORIGINAL_SIZE_DATA_KEY not in param[ORIGINAL_SIZE_KEY]:
                iwsJobObject.set_original_size(original_size_type_table[param[ORIGINAL_SIZE_KEY][ORIGINAL_SIZE_TYPE_KEY]])
            else:
                if param[ORIGINAL_SIZE_KEY][ORIGINAL_SIZE_DATA_KEY] not in paper_size_table:
                    raise mfp.MFPValidationErr
                iwsJobObject.set_original_size(original_size_type_table[param[ORIGINAL_SIZE_KEY][ORIGINAL_SIZE_TYPE_KEY]],paper_size_table[param[ORIGINAL_SIZE_KEY][ORIGINAL_SIZE_DATA_KEY]])

        if ORIGINAL_TYPE_KEY in param:
            if param[ORIGINAL_TYPE_KEY] not in original_type_table:
                raise mfp.MFPValidationErr
            iwsJobObject.set_original_type(original_type_table[param[ORIGINAL_TYPE_KEY]])

        if BACKGROUND_REMOVAL_KEY in param:
            #required(type)
            if BACKGROUND_REMOVAL_TYPE_KEY not in param[BACKGROUND_REMOVAL_KEY]:
                raise mfp.MFPValidationErr
            if param[BACKGROUND_REMOVAL_KEY][BACKGROUND_REMOVAL_TYPE_KEY] not in background_removal_type_table:
                raise mfp.MFPValidationErr

            #option(level)
            if BACKGROUND_REMOVAL_LEVEL_KEY not in param[BACKGROUND_REMOVAL_KEY]:
                iwsJobObject.set_background_removal(background_removal_type_table[param[BACKGROUND_REMOVAL_KEY][BACKGROUND_REMOVAL_TYPE_KEY]])
            else:
                iwsJobObject.set_background_removal(background_removal_type_table[param[BACKGROUND_REMOVAL_KEY][BACKGROUND_REMOVAL_TYPE_KEY]],param[BACKGROUND_REMOVAL_KEY][BACKGROUND_REMOVAL_LEVEL_KEY])

        if NUM_OF_SET_KEY in param:
            iwsJobObject.set_num_of_set(param[NUM_OF_SET_KEY])

        if COLOR_KEY in param:
            #required(mode)
            if COLOR_MODE_KEY not in param[COLOR_KEY]:
                raise mfp.MFPValidationErr
            if param[COLOR_KEY][COLOR_MODE_KEY] not in color_mode_table:
                raise mfp.MFPValidationErr

            #option(color)
            if COLOR_COLOR_KEY not in param[COLOR_KEY]:
                iwsJobObject.set_color(color_mode_table[param[COLOR_KEY][COLOR_MODE_KEY]])
            else:
                if param[COLOR_KEY][COLOR_COLOR_KEY] not in color_table:
                    raise mfp.MFPValidationErr
                iwsJobObject.set_color(color_mode_table[param[COLOR_KEY][COLOR_MODE_KEY]],color_table[param[COLOR_KEY][COLOR_COLOR_KEY]])

        if PAPER_TRAY_KEY in param:
            #required(tray)
            if PAPER_TRAY_INPUT_TRAY_KEY not in param[PAPER_TRAY_KEY]:
                raise mfp.MFPValidationErr
            if param[PAPER_TRAY_KEY][PAPER_TRAY_INPUT_TRAY_KEY] not in paper_tray_table:
                raise mfp.MFPValidationErr

            #required(size)
            if PAPER_TRAY_PAPER_SIZE_KEY not in param[PAPER_TRAY_KEY]:
                raise mfp.MFPValidationErr
            if param[PAPER_TRAY_KEY][PAPER_TRAY_PAPER_SIZE_KEY] not in paper_size_table:
                raise mfp.MFPValidationErr

            tray = mfp.job.PaperTray(paper_tray_table[param[PAPER_TRAY_KEY][PAPER_TRAY_INPUT_TRAY_KEY]])
            tray.set_paper_size(paper_size_table[param[PAPER_TRAY_KEY][PAPER_TRAY_PAPER_SIZE_KEY]])
            iwsJobObject.set_paper_tray(tray)

        if ZOOM_KEY in param:
            #required(magnification)
            if ZOOM_MAGNIFICATION_KEY not in param[ZOOM_KEY]:
                raise mfp.MFPValidationErr
            if param[ZOOM_KEY][ZOOM_MAGNIFICATION_KEY] not in magnification_table:
                raise mfp.MFPValidationErr

            ratio = mfp.Size(float(param[ZOOM_KEY][ZOOM_RATIO_X_KEY]),float(param[ZOOM_KEY][ZOOM_RATIO_Y_KEY]))
            iwsJobObject.set_zoom(magnification_table[param[ZOOM_KEY][ZOOM_MAGNIFICATION_KEY]],ratio)

        if COMBINE_KEY in param:
            if param[COMBINE_KEY] not in combine_table:
                raise mfp.MFPValidationErr
            iwsJobObject.set_combine(combine_table[param[COMBINE_KEY]])

        if DUPLEX_KEY in param:
            iwsJobObject.set_duplex(param[DUPLEX_KEY])

        if AUTO_ROTATE_KEY in param:
            iwsJobObject.set_auto_rotate(param[AUTO_ROTATE_KEY])

        if SORT_TYPE in param:
            if param[SORT_TYPE] not in sort_type_table:
                raise mfp.MFPValidationErr
            iwsJobObject.set_sort_type(sort_type_table[param[SORT_TYPE]])

        if OFFSET_KEY in param:
            iwsJobObject.set_offset(param[OFFSET_KEY])

        if STAPLE_KEY in param:
            #required(mode)
            if STAPLE_MODE_KEY not in param[STAPLE_KEY]:
                raise mfp.MFPValidationErr
            if param[STAPLE_KEY][STAPLE_MODE_KEY] not in staple_mode_table:
                raise mfp.MFPValidationErr

            #option(position)
            if STAPLE_POSITION_KEY not in param[STAPLE_KEY]:
                iwsJobObject.set_staple(staple_mode_table[param[STAPLE_KEY][STAPLE_MODE_KEY]])
            else:
                if param[STAPLE_KEY][STAPLE_POSITION_KEY] not in staple_position_table:
                    raise mfp.MFPValidationErr
                #option(angle)
                if STAPLE_ANGLE_KEY not in param[STAPLE_KEY]:
                    iwsJobObject.set_staple(staple_mode_table[param[STAPLE_KEY][STAPLE_MODE_KEY]],staple_position_table[param[STAPLE_KEY][STAPLE_POSITION_KEY]])
                else:
                    if param[STAPLE_KEY][STAPLE_ANGLE_KEY] not in staple_angle_table:
                        raise mfp.MFPValidationErr
                    iwsJobObject.set_staple(staple_mode_table[param[STAPLE_KEY][STAPLE_MODE_KEY]],staple_position_table[param[STAPLE_KEY][STAPLE_POSITION_KEY]],staple_angle_table[param[STAPLE_KEY][STAPLE_ANGLE_KEY]])

        if HOLE_PUNCH_KEY in param:
            #required(mode)
            if HOLE_PUNCH_MODE_KEY not in param[HOLE_PUNCH_KEY]:
                raise mfp.MFPValidationErr
            if param[HOLE_PUNCH_KEY][HOLE_PUNCH_MODE_KEY] not in hole_punch_mode_table:
                raise mfp.MFPValidationErr

            #option(position)
            if HOLE_PUNCH_POSITION_KEY not in param[HOLE_PUNCH_KEY]:
                iwsJobObject.set_hole_punch(hole_punch_mode_table[param[HOLE_PUNCH_KEY][HOLE_PUNCH_MODE_KEY]])
            else:
                if param[HOLE_PUNCH_KEY][HOLE_PUNCH_POSITION_KEY] not in hole_punch_position_table:
                    raise mfp.MFPValidationErr
                iwsJobObject.set_hole_punch(hole_punch_mode_table[param[HOLE_PUNCH_KEY][HOLE_PUNCH_MODE_KEY]],hole_punch_position_table[param[HOLE_PUNCH_KEY][HOLE_PUNCH_POSITION_KEY]])

        if MULTI_FEED_DETECT_KEY in param:
            iwsJobObject.set_multi_feed_detect(param[MULTI_FEED_DETECT_KEY])

        if BLANK_PAGE_REMOVAL_KEY in param:
            iwsJobObject.set_blank_page_removal(param[BLANK_PAGE_REMOVAL_KEY])

        if MIXED_ORIGINAL_KEY in param:
            if param[MIXED_ORIGINAL_KEY] not in mixed_original_table:
                raise mfp.MFPValidationErr
            iwsJobObject.set_mixed_original(mixed_original_table[param[MIXED_ORIGINAL_KEY]])

        if WATERMARK_KEY in param:
            #required(type)
            if WATERMARK_TYPE_KEY not in param[WATERMARK_KEY]:
                raise mfp.MFPValidationErr
            if param[WATERMARK_KEY][WATERMARK_TYPE_KEY] not in watermark_type_table:
                raise mfp.MFPValidationErr

            #option(color)
            if WATERMARK_COLOR_KEY not in param[WATERMARK_KEY]:
                iwsJobObject.set_watermark(watermark_type_table[param[WATERMARK_KEY][WATERMARK_TYPE_KEY]])
            else:
                if param[WATERMARK_KEY][WATERMARK_COLOR_KEY] not in watermark_color_table:
                    raise mfp.MFPValidationErr
                iwsJobObject.set_watermark(watermark_type_table[param[WATERMARK_KEY][WATERMARK_TYPE_KEY]],watermark_color_table[param[WATERMARK_KEY][WATERMARK_COLOR_KEY]])
    except Exception as e:
        import traceback
        import sys
        traceback.print_exc(file=sys.stderr)
        raise e
    return iwsJobObject
