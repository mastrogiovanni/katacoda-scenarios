#!/usr/bin/env python
# -*- coding: utf-8 -*-

import sys
import os
import json

json_dict = json.loads(sys.argv[1])
for x in json_dict:
    if x['DeletionPattern'] == 0:
        filePath = x['FileName']
        if (os.path.isfile(filePath)):
            print("begin removeFile: " + filePath, file=sys.stderr)
            os.remove("." + filePath)
            print("end removeFile: " + filePath, file=sys.stderr)
        else:
            print("not necessary removeFile: " + filePath, file=sys.stderr)
