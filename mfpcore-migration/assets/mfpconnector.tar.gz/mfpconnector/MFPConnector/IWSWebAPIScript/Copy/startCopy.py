#!/usr/bin/env python
# -*- coding: utf-8 -*-

import sys
import os
import json
import traceback
import ConvertTableIWS
import mfp
import mfp.job
import enum

REQ_FILE_PATH = "/copyRequest.json"
RES_FILE_PATH = "/copyResponse.json"
RESULT_OK = "OK"
RESULT_NG = "NG"
PAPER_DIRECTION_SEF ="SEF"
PAPER_DIRECTION_LEF ="LEF"
COMBINE_FOUR_IN_ONE = "FOUR"
COMBINE_EIGHT_IN_ONE = "EIGHT"
PAPER_SIZE_AUTO = "AUTO"
PAPER_TRAY_AUTO = "AUTO"
is_combination_prohibited = False

class MarketArea(enum.Enum):
    NorthAmerica = 1
    Europe = 2
    Japan = 3

class EnumException(Exception):
    def __init__(self, value):
        self.value = value

class ApsException(Exception):
    def __init__(self, value):
        self.value = value

def check_originalpaper_direction(sizecode):
    if(mfp.PaperSize.SEF_A3 == sizecode
    or mfp.PaperSize.SEF_A4 == sizecode
    or mfp.PaperSize.SEF_A5 == sizecode
    or mfp.PaperSize.SEF_A6 == sizecode
    or mfp.PaperSize.SEF_B4 == sizecode
    or mfp.PaperSize.SEF_B5 == sizecode
    or mfp.PaperSize.SEF_B6 == sizecode
    or mfp.PaperSize.SEF_LEDGER == sizecode
    or mfp.PaperSize.SEF_LEGAL == sizecode
    or mfp.PaperSize.SEF_LETTER == sizecode
    or mfp.PaperSize.SEF_EXECTIVE == sizecode
    or mfp.PaperSize.SEF_INVOICE == sizecode
    or mfp.PaperSize.SEF_POSTCARD_JP == sizecode
    or mfp.PaperSize.SEF_POSTCARD_EU == sizecode
    or mfp.PaperSize.SEF_FOOLSCAP == sizecode
    or mfp.PaperSize.SEF_8K == sizecode
    or mfp.PaperSize.SEF_16K == sizecode
    or mfp.PaperSize.SEF_PHOTO_JP_E == sizecode
    or mfp.PaperSize.SEF_PHOTO_JP_L == sizecode
    or mfp.PaperSize.SEF_9x13 == sizecode
    or mfp.PaperSize.SEF_10x15 == sizecode
    or mfp.PaperSize.SEF_13x18 == sizecode
    or mfp.PaperSize.SEF_4x6 == sizecode
    or mfp.PaperSize.SEF_3x5 == sizecode
    or mfp.PaperSize.SEF_225x325 == sizecode):
        return PAPER_DIRECTION_SEF

    elif(mfp.PaperSize.LEF_A4 == sizecode
    or mfp.PaperSize.LEF_A5 == sizecode
    or mfp.PaperSize.LEF_A6 == sizecode
    or mfp.PaperSize.LEF_B5 == sizecode
    or mfp.PaperSize.LEF_B6 == sizecode
    or mfp.PaperSize.LEF_LETTER == sizecode
    or mfp.PaperSize.LEF_EXECTIVE == sizecode
    or mfp.PaperSize.LEF_INVOICE == sizecode
    or mfp.PaperSize.LEF_POSTCARD_JP == sizecode
    or mfp.PaperSize.LEF_POSTCARD_EU == sizecode
    or mfp.PaperSize.LEF_16K == sizecode
    or mfp.PaperSize.LEF_PHOTO_JP_E == sizecode
    or mfp.PaperSize.LEF_PHOTO_JP_L == sizecode
    or mfp.PaperSize.LEF_9x13 == sizecode
    or mfp.PaperSize.LEF_10x15 == sizecode
    or mfp.PaperSize.LEF_13x18 == sizecode
    or mfp.PaperSize.LEF_4x6 == sizecode
    or mfp.PaperSize.LEF_3x5 == sizecode
    or mfp.PaperSize.LEF_225x325 == sizecode):
        return PAPER_DIRECTION_LEF

try:
    # Read request file.
    with open(REQ_FILE_PATH, "r") as reqFp:
        req = json.load(reqFp)

    # Check enum parameters.
    if ("color" in req):
        if req["color"]["mode"] not in ConvertTableIWS.color_mode_table:
            raise EnumException("Illegal color Mode value.")
    if ("color" in req) and ("color" in req["color"]):
        if req["color"]["color"] not in ConvertTableIWS.color_table:
            raise EnumException("Illegal color value.")
    if "combine" in req:
        if req["combine"] not in ConvertTableIWS.combine_table:
            raise EnumException("Illegal combine value.")
    if "in_duplex" in req:
        if req["in_duplex"] not in ConvertTableIWS.scan_side_table:
            raise EnumException("Illegal in_duplex value.")
    if ("in_paper_size" in req) and ("type" in req["in_paper_size"]):
        if req["in_paper_size"]["type"] not in ConvertTableIWS.original_size_type_table:
            raise EnumException("Illegal in_paper_size type value.")
    if ("out_paper_size" in req) and ("tray" in req["out_paper_size"]):
        if req["out_paper_size"]["tray"] not in ConvertTableIWS.paper_tray_table:
            raise EnumException("Illegal out_paper_size tray value.")
    if ("staple" in req) and ("model" in req["staple"]):
        if req["staple"]["model"] not in ConvertTableIWS.staple_mode_table:
            raise EnumException("Illegal staple mode value.")
    if ("punch" in req) and ("mode" in req["punch"]):
        if req["punch"]["mode"] not in ConvertTableIWS.hole_punch_mode_table:
            raise EnumException("Illegal punch mode value.")
    if ("background_removal" in req) and ("type" in req["background_removal"]):
        if req["background_removal"]["type"] not in ConvertTableIWS.background_removal_type_table:
            raise EnumException("Illegal background_removal type value.")

    #original size.
    original_size = req["in_paper_size"]
    original_type = original_size["type"]
    original_data = original_size["data"]

    #out_paper_size  paper_tray
    out_paper_size = req["out_paper_size"]
    out_paper_tray = out_paper_size["tray"]
    paper_tray = mfp.job.PaperTray(ConvertTableIWS.paper_tray_table[out_paper_tray])
    out_paper_data = out_paper_size["size"]

    #fit_to_page
    zoom = req["fit_to_page"]

    #staple
    staple      = req["staple"]
    staple_mode = staple["model"]
    staple_position = staple["position"]

    #punch
    punch      = req["punch"]
    punch_mode = punch["mode"]
    punch_position = punch["position"]

    # Get N in 1
    combine_pages = req["combine"]

    #MarketArea
    market_area = req["market_area"]

    # Get paper size. Get original paper direction.
    if mfp.device.is_document_on(mfp.Device.PLATEN):
        sizecode = mfp.device.get_document_size(mfp.Device.PLATEN)
    elif mfp.device.is_document_on(mfp.Device.ADF):
        sizecode = mfp.device.get_document_size(mfp.Device.ADF)
    try:
        original_paper_direction = check_originalpaper_direction(sizecode)
    except NameError:
        original_paper_direction = PAPER_DIRECTION_SEF

    # Get output paper direction
    output_paper_direction = out_paper_data[0:3]

    #judge combination prohibition
    #The market area is NorthAmerica
    if(MarketArea.NorthAmerica.name == market_area):
        #Input paper size is AUTO and paper tray is AUTO and saizecode is LEF_13x18
        if(PAPER_SIZE_AUTO == original_type and PAPER_TRAY_AUTO == out_paper_tray and mfp.PaperSize.LEF_13x18 == sizecode):
            is_combination_prohibited = True
            raise mfp.MFPValidationErr
    #The market area is Europe
    if(MarketArea.Europe.name == market_area):
        #Input paper size is AUTO and paper tray is AUTO
        if(PAPER_SIZE_AUTO == original_type and PAPER_TRAY_AUTO == out_paper_tray):
            #Paper sizecode SEF_A6 or SEF_LETTER or SEF_4x6 or SEF_POSTCARD_JP or SEF_POSTCARD_EU or SEF_10x15
            if(mfp.PaperSize.SEF_A6 == sizecode or mfp.PaperSize.SEF_4x6 == sizecode or mfp.PaperSize.SEF_POSTCARD_JP == sizecode or mfp.PaperSize.SEF_POSTCARD_EU == sizecode or mfp.PaperSize.SEF_10x15 == sizecode):
                is_combination_prohibited = True
                raise mfp.MFPValidationErr
    if (PAPER_DIRECTION_SEF == output_paper_direction or PAPER_DIRECTION_LEF == output_paper_direction):
        #If punch is exist and punch is not not selected
        #If staple is exist and staple is not not selected
        if ((punch_position and ConvertTableIWS.hole_punch_mode_table[punch_mode] != mfp.PunchMode.NOT_SELECTED)
        or (staple_position and ConvertTableIWS.staple_mode_table[staple_mode] != mfp.StapleMode.NOT_SELECTED)):
            #N in 1 : Single, Fit to Page : ON
            #N in 1 : 4 in 1
            if ((ConvertTableIWS.combine_table[combine_pages] == mfp.Combine.SINGLE and zoom == "ON")
            or COMBINE_FOUR_IN_ONE in combine_pages):
                #punch
                if (ConvertTableIWS.hole_punch_mode_table[punch_mode] != mfp.PunchMode.NOT_SELECTED): 
                    #position : LEFT or RIGHT
                    if (ConvertTableIWS.hole_punch_position_table[punch_position] == mfp.PunchPosition.LEFT or 
                    ConvertTableIWS.hole_punch_position_table[punch_position] == mfp.PunchPosition.RIGHT ):
                        #input_paper_size : SEF and output_paper_size : LEF
                        if (original_paper_direction == PAPER_DIRECTION_SEF and output_paper_direction == PAPER_DIRECTION_LEF ) :
                            is_combination_prohibited = True
                            raise mfp.MFPValidationErr
                        #input_paper_size : LEF and output_paper_size : SEF
                        elif (original_paper_direction == PAPER_DIRECTION_LEF and output_paper_direction == PAPER_DIRECTION_SEF ) :
                            is_combination_prohibited = True
                            raise mfp.MFPValidationErr
                    #position : TOP
                    elif (ConvertTableIWS.hole_punch_position_table[punch_position] == mfp.PunchPosition.TOP):
                        #input_paper_size : SEF and output_paper_size : SEF
                        if (original_paper_direction == PAPER_DIRECTION_SEF and output_paper_direction == PAPER_DIRECTION_SEF ) :
                            is_combination_prohibited = True
                            raise mfp.MFPValidationErr
                        #input_paper_size : LEF and output_paper_size : LEF
                        elif (original_paper_direction == PAPER_DIRECTION_LEF and output_paper_direction == PAPER_DIRECTION_LEF ) :
                            is_combination_prohibited = True
                            raise mfp.MFPValidationErr
                #staple
                elif(ConvertTableIWS.staple_mode_table[staple_mode] != mfp.StapleMode.NOT_SELECTED):
                    #mode Corner
                    if(ConvertTableIWS.staple_mode_table[staple_mode] == mfp.StapleMode.CORNER):
                        #position LEFT or RIGHT
                        if(ConvertTableIWS.staple_position_table[staple_position] == mfp.StaplePosition.LEFT or
                        ConvertTableIWS.staple_position_table[staple_position] == mfp.StaplePosition.RIGHT):
                            #input_paper_size : SEF and output_paper_size : LEF
                            if (original_paper_direction == PAPER_DIRECTION_SEF and output_paper_direction == PAPER_DIRECTION_LEF ) :
                                is_combination_prohibited = True
                                raise mfp.MFPValidationErr
                            #input_paper_size : LEF and output_paper_size : SEF
                            elif (original_paper_direction == PAPER_DIRECTION_LEF and output_paper_direction == PAPER_DIRECTION_SEF ) :
                                is_combination_prohibited = True
                                raise mfp.MFPValidationErr
                    #mode Twoside
                    elif(ConvertTableIWS.staple_mode_table[staple_mode] == mfp.StapleMode.TWO_SIDE):
                        #position LEFT or RIGHT
                        if(ConvertTableIWS.staple_position_table[staple_position] == mfp.StaplePosition.LEFT or
                        ConvertTableIWS.staple_position_table[staple_position] == mfp.StaplePosition.RIGHT):
                            #input_paper_size : SEF and output_paper_size : LEF
                            if (original_paper_direction == PAPER_DIRECTION_SEF and output_paper_direction == PAPER_DIRECTION_LEF ) :
                                is_combination_prohibited = True
                                raise mfp.MFPValidationErr
                            #input_paper_size : LEF and output_paper_size : SEF
                            elif (original_paper_direction == PAPER_DIRECTION_LEF and output_paper_direction == PAPER_DIRECTION_SEF ) :
                                is_combination_prohibited = True
                                raise mfp.MFPValidationErr
                        #position TOP
                        elif(ConvertTableIWS.staple_position_table[staple_position] == mfp.StaplePosition.TOP):
                            #input_paper_size : SEF and output_paper_size : SEF
                            if (original_paper_direction == PAPER_DIRECTION_SEF and output_paper_direction == PAPER_DIRECTION_SEF ) :
                                is_combination_prohibited = True
                                raise mfp.MFPValidationErr
                            #input_paper_size : LEF and output_paper_size : LEF
                            elif (original_paper_direction == PAPER_DIRECTION_LEF and output_paper_direction == PAPER_DIRECTION_LEF ) :
                                is_combination_prohibited = True
                                raise mfp.MFPValidationErr
            #N in 1 : 2 in 1
            #N in 1 : 8 in 1
            elif (ConvertTableIWS.combine_table[combine_pages] == mfp.Combine.TWO
            or COMBINE_EIGHT_IN_ONE in combine_pages):
                #punch
                if (ConvertTableIWS.hole_punch_mode_table[punch_mode] != mfp.PunchMode.NOT_SELECTED): 
                    #position : LEFT or RIGHT
                    if (ConvertTableIWS.hole_punch_position_table[punch_position] == mfp.PunchPosition.LEFT or 
                    ConvertTableIWS.hole_punch_position_table[punch_position] == mfp.PunchPosition.RIGHT ):
                        #input_paper_size : SEF and output_paper_size : SEF
                        if (original_paper_direction == PAPER_DIRECTION_SEF and output_paper_direction == PAPER_DIRECTION_SEF ) :
                            is_combination_prohibited = True
                            raise mfp.MFPValidationErr
                        #input_paper_size : LEF and output_paper_size : LEF
                        elif (original_paper_direction == PAPER_DIRECTION_LEF and output_paper_direction == PAPER_DIRECTION_LEF ) :
                            is_combination_prohibited = True
                            raise mfp.MFPValidationErr
                    #position : TOP
                    elif (ConvertTableIWS.hole_punch_position_table[punch_position] == mfp.PunchPosition.TOP):
                        #input_paper_size : SEF and output_paper_size : LEF
                        if (original_paper_direction == PAPER_DIRECTION_SEF and output_paper_direction == PAPER_DIRECTION_LEF ) :
                            is_combination_prohibited = True
                            raise mfp.MFPValidationErr
                        #input_paper_size : LEF and output_paper_size : SEF
                        elif (original_paper_direction == PAPER_DIRECTION_LEF and output_paper_direction == PAPER_DIRECTION_SEF ) :
                            is_combination_prohibited = True
                            raise mfp.MFPValidationErr
                #staple
                elif(ConvertTableIWS.staple_mode_table[staple_mode] != mfp.StapleMode.NOT_SELECTED):
                    #mode Corner
                    if(ConvertTableIWS.staple_mode_table[staple_mode] == mfp.StapleMode.CORNER):
                        #position LEFT or RIGHT
                        if(ConvertTableIWS.staple_position_table[staple_position] == mfp.StaplePosition.LEFT or
                        ConvertTableIWS.staple_position_table[staple_position] == mfp.StaplePosition.RIGHT):
                            #input_paper_size : SEF and output_paper_size : SEF
                            if (original_paper_direction == PAPER_DIRECTION_SEF and output_paper_direction == PAPER_DIRECTION_SEF ) :
                                is_combination_prohibited = True
                                raise mfp.MFPValidationErr
                            #input_paper_size : LEF and output_paper_size : LEF
                            elif (original_paper_direction == PAPER_DIRECTION_LEF and output_paper_direction == PAPER_DIRECTION_LEF ) :
                                is_combination_prohibited = True
                                raise mfp.MFPValidationErr
                    #mode Twoside
                    elif(ConvertTableIWS.staple_mode_table[staple_mode] == mfp.StapleMode.TWO_SIDE):
                        #position LEFT or RIGHT
                        if(ConvertTableIWS.staple_position_table[staple_position] == mfp.StaplePosition.LEFT or
                        ConvertTableIWS.staple_position_table[staple_position] == mfp.StaplePosition.RIGHT):
                            #input_paper_size : SEF and output_paper_size : SEF
                            if (original_paper_direction == PAPER_DIRECTION_SEF and output_paper_direction == PAPER_DIRECTION_SEF ) :
                                is_combination_prohibited = True
                                raise mfp.MFPValidationErr
                            #input_paper_size : LEF and output_paper_size : LEF
                            elif (original_paper_direction == PAPER_DIRECTION_LEF and output_paper_direction == PAPER_DIRECTION_LEF ) :
                                is_combination_prohibited = True
                                raise mfp.MFPValidationErr
                        #position TOP
                        elif(ConvertTableIWS.staple_position_table[staple_position] == mfp.StaplePosition.TOP):
                            #input_paper_size : SEF and output_paper_size : LEF
                            if (original_paper_direction == PAPER_DIRECTION_SEF and output_paper_direction == PAPER_DIRECTION_LEF ) :
                                is_combination_prohibited = True
                                raise mfp.MFPValidationErr
                            #input_paper_size : LEF and output_paper_size : SEF
                            elif (original_paper_direction == PAPER_DIRECTION_LEF and output_paper_direction == PAPER_DIRECTION_SEF ) :
                                is_combination_prohibited = True
                                raise mfp.MFPValidationErr

    #judge APS error
    if (PAPER_TRAY_AUTO == out_paper_tray):
        aps_error_list = [mfp.PaperSize.SEF_POSTCARD_JP, mfp.PaperSize.SEF_POSTCARD_EU, mfp.PaperSize.SEF_A6, 
        mfp.PaperSize.SEF_EXECTIVE, mfp.PaperSize.LEF_EXECTIVE, mfp.PaperSize.SEF_SRA3, mfp.PaperSize.SEF_12x18]

        if sizecode in aps_error_list:
            raise ApsException("All APS checking has occured error.")

        #The market area is NorthAmerica
        if (MarketArea.NorthAmerica.name == market_area):
            aps_error_list = [
                mfp.PaperSize.SEF_A3,
                mfp.PaperSize.SEF_A5,
                mfp.PaperSize.LEF_A5,
                mfp.PaperSize.SEF_B4, 
                mfp.PaperSize.SEF_B5,
                mfp.PaperSize.LEF_B5,
                mfp.PaperSize.SEF_B6,
                mfp.PaperSize.SEF_FOOLSCAP,
                mfp.PaperSize.SEF_8K,
                mfp.PaperSize.SEF_16K,
                mfp.PaperSize.LEF_16K
                ]

            if sizecode in aps_error_list:
                raise ApsException("US APS checking has occured exception.")

        #The market area is Europe
        elif (MarketArea.Europe.name == market_area):
            aps_error_list = [
                mfp.PaperSize.SEF_LEDGER,
                mfp.PaperSize.SEF_LEGAL,
                mfp.PaperSize.SEF_INVOICE,
                mfp.PaperSize.LEF_INVOICE
                ]

            if sizecode in aps_error_list:
                raise ApsException("EU APS checking has occured exception.")

        #The market area is Japan
        elif (MarketArea.Japan.name == market_area):
            aps_error_list = [
                mfp.PaperSize.SEF_LEDGER,
                mfp.PaperSize.SEF_LEGAL,
                mfp.PaperSize.SEF_INVOICE,
                mfp.PaperSize.LEF_INVOICE,
                mfp.PaperSize.SEF_FOOLSCAP,
                mfp.PaperSize.SEF_8K,
                mfp.PaperSize.SEF_16K,
                mfp.PaperSize.LEF_16K
                ]

            if sizecode in aps_error_list:
                raise ApsException("JP APS checking has occured exception.")

    # Create copy job.
    copy=mfp.job.Copy()
    if "copies" in req:
        copy.set_num_of_set(req["copies"])
    if "density" in req:
        copy.set_density(req["density"])
    if "combine" in req:
        copy.set_combine(ConvertTableIWS.combine_table[req["combine"]])
    if "out_duplex" in req:
        copy.set_duplex(req["out_duplex"])
    if "color" in req:
        if not("color" in req["color"]):
            copy.set_color(ConvertTableIWS.color_mode_table[req["color"]["mode"]])
        else:
            copy.set_color(ConvertTableIWS.color_mode_table[req["color"]["mode"]], ConvertTableIWS.color_table[req["color"]["color"]])
    if "in_duplex" in req:
        copy.set_scan_side(ConvertTableIWS.scan_side_table[req["in_duplex"]])

    #set original size.
    if original_type == "AUTO":
        copy.set_original_size(ConvertTableIWS.original_size_type_table[original_type])
    elif original_type == "STANDARD":
        copy.set_original_size(ConvertTableIWS.original_size_type_table[original_type], ConvertTableIWS.paper_size_table[original_data])

    #set out_paper_size  paper_tray
    if "size" in req["out_paper_size"]:
        paper_tray.set_paper_size(ConvertTableIWS.paper_size_table[out_paper_data])
    copy.set_paper_tray(paper_tray)

    #set fit_to_page
    if zoom == "ON":
        copy.set_zoom(ConvertTableIWS.magnification_table["AUTO"])
    else:
        copy.set_zoom(ConvertTableIWS.magnification_table["FULL"])

    #set staple
    if not("position" in req["staple"]) or staple_mode == "NOT_SELECTED":
        copy.set_staple(ConvertTableIWS.staple_mode_table[staple_mode])
    else:
        copy.set_staple(ConvertTableIWS.staple_mode_table[staple_mode], ConvertTableIWS.staple_position_table[staple_position])

    #set punch
    if not("position" in req["punch"]) or punch_mode == "NOT_SELECTED":
        copy.set_hole_punch(ConvertTableIWS.hole_punch_mode_table[punch_mode])
    else:
        copy.set_hole_punch(ConvertTableIWS.hole_punch_mode_table[punch_mode], ConvertTableIWS.hole_punch_position_table[punch_position])

    #background_removal
    background_removal = req["background_removal"]
    background_removal_type = background_removal["type"]
    if background_removal_type == "AUTO":
        copy.set_background_removal(ConvertTableIWS.background_removal_type_table[background_removal_type])
    elif background_removal_type == "MANUAL":
        background_removal_level = background_removal["level"]
        copy.set_background_removal(ConvertTableIWS.background_removal_type_table[background_removal_type], background_removal_level)

    jobid = mfp.job.start(copy)
    # Write response file.
    with open(RES_FILE_PATH, "w") as resFp:
        json.dump({ "result": RESULT_OK, "job_id": jobid }, resFp)
except mfp.MFPDocumentDetectionErr:
    traceback.print_exc(file=sys.stderr)
    print("mfp.MFPDocumentDetectionErr", file=sys.stderr)
    with open(RES_FILE_PATH, "w") as resFp:
        json.dump({ "result": RESULT_NG, "error": "MFPDocumentDetectionErr" }, resFp)
except mfp.MFPInvalidStateErr:
    traceback.print_exc(file=sys.stderr)
    print("mfp.MFPInvalidStateErr", file=sys.stderr)
    with open(RES_FILE_PATH, "w") as resFp:
        json.dump({ "result": RESULT_NG, "error": "MFPInvalidStateErr" }, resFp)
except mfp.MFPValidationErr:
    traceback.print_exc(file=sys.stderr)
    print("mfp.MFPValidationErr", file=sys.stderr)
    with open(RES_FILE_PATH, "w") as resFp:
        json.dump({ "result": RESULT_NG, "is_combination_prohibited": is_combination_prohibited }, resFp)
except mfp.MFPException:
    traceback.print_exc(file=sys.stderr)
    print("mfp.MFPException", file=sys.stderr)
    with open(RES_FILE_PATH, "w") as resFp:
        json.dump({ "result": RESULT_NG, "error": "MFPException" }, resFp)
except EnumException as e:
    traceback.print_exc(file=sys.stderr)
    print("EnumException")
    with open(RES_FILE_PATH, "w") as resFp:
        json.dump({ "result": RESULT_NG, "error": "EnumException: " + e.value }, resFp)
except ApsException :
    traceback.print_exc(file=sys.stderr)
    print("ApsException", file=sys.stderr)
    with open(RES_FILE_PATH, "w") as resFp:
        json.dump({ "result": RESULT_NG, "error": "APSSizeError" }, resFp)
except:
    traceback.print_exc(file=sys.stderr)
    with open(RES_FILE_PATH, "w") as resFp:
        json.dump({ "result": RESULT_NG }, resFp)
finally:
    try:
        #delete request.
        os.remove(REQ_FILE_PATH)
    except:
        traceback.print_exc(file=sys.stderr)

