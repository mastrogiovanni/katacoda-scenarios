# -*- coding: UTF-8 -*-

import os
import os.path
import traceback
import sys

#json file.
RESULT_FILE_NAME  = "/ScanResult.json"

try:
    #delete result.
    if os.path.exists(RESULT_FILE_NAME):
        os.remove(RESULT_FILE_NAME)

except:
    traceback.print_exc(file=sys.stderr)

