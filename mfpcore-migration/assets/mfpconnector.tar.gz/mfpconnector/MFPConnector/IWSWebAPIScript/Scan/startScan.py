# -*- coding: UTF-8 -*-

import os
import sys
import traceback
import json
import ConvertTableIWS
import codecs

#json file.
SETTING_FILE_NAME = "/scanRequest.json"
RESULT_FILE_NAME  = "/scanResponse.json"

#Job setting.
RESOLUTION_KEY = "resolution"

SCAN_SIDE_KEY = "in_duplex"

SEND_FILE_NAME_KEY    = "file_name"
SEND_FILE_TYPE_KEY    = "file_type"

FAX_RESOLUTION_KEY  = "fax_resolution"

COLOR_SETTING_KEY = "color"
COLOR_MODE_KEY    = "mode"
COLOR_KEY         = "color"

PAPER_SIZE_KEY      = "in_paper_size"
PAPER_SIZE_TYPE_KEY = "type"
PAPER_SIZE_DATA_KEY = "data"

WEBDAV_SETTING_KEY = "webdav_settings"
WEBDAV_HOST_KEY    = "host"
WEBDAV_PORT_KEY    = "port"

WEBDAV_DIR_KEY      = "dir"
WEBDAV_USER_KEY     = "user"
WEBDAV_PASSWORD_KEY = "password"
WEBDAV_PROXY_KEY    = "proxy"
WEBDAV_SSL_KEY      = "ssl"

FAX_SETTING_KEY                 = "txfax"
FAX_ADDRESS_KEY                 = "address"
FAX_USE_OVERSEAS_TX_KEY         = "use_overseas_tx"
FAX_USE_ECM_KEY                 = "use_ecm"
FAX_USE_CHECK_DEST_AND_SEND_KEY = "use_check_dest_and_send"
FAX_PASSWORD_KEY                = "password"

DENSITY_KEY         = "density"

BACK_DENSITY_KEY        = "background_removal"
BACK_DENSITY_TYPE_KEY   = "type"
BACK_DENSITY_LEVEL_KEY  = "level"

#Job result.
RESULT_KEY = "result"
JOBID_KEY  = "job_id"
RESULT_OK = "OK"
RESULT_NG = "NG"
RESULT_ERROR = "error"

#Paper type
PAPER_TYPE_AUTO = "AUTO"
PAPER_TYPE_STANDARD = "STANDARD"

try:
    result = dict()

    #JOSN load.
    with codecs.open(SETTING_FILE_NAME, 'r', 'utf_8') as fh:
        data = json.load(fh)
        import sys

    import mfp

    #Job setting.
    scan=mfp.job.Scan()

    webdav_flg = 0 
    if WEBDAV_SETTING_KEY in data:
        webdav_setting = data[WEBDAV_SETTING_KEY]

        if WEBDAV_HOST_KEY in webdav_setting:
            host = webdav_setting[WEBDAV_HOST_KEY]
        else:
            raise mfp.MFPValidationErr

        if WEBDAV_PORT_KEY in webdav_setting:
            port = webdav_setting[WEBDAV_PORT_KEY]
        else:
            raise mfp.MFPValidationErr

        if WEBDAV_DIR_KEY in webdav_setting:
            dir1 = webdav_setting[WEBDAV_DIR_KEY]
        else:
            raise mfp.MFPValidationErr

        if WEBDAV_USER_KEY in webdav_setting:
            user = webdav_setting[WEBDAV_USER_KEY]
        else:
            raise mfp.MFPValidationErr

        if WEBDAV_PASSWORD_KEY in webdav_setting:
            password = webdav_setting[WEBDAV_PASSWORD_KEY]
        else:
            raise mfp.MFPValidationErr

#       if WEBDAV_PROXY_KEY in webdav_setting:
#           proxy = webdav_setting[WEBDAV_PROXY_KEY]
#       else:
#           raise mfp.MFPValidationErr
#       if WEBDAV_SSL_KEY in webdav_setting:
#           ssl = webdav_setting[WEBDAV_SSL_KEY]
#       else:
#           raise mfp.MFPValidationErr

        tx_webdav = mfp.job.TxWebDAV(host,port)
        tx_webdav.set_dir(dir1)
        tx_webdav.set_auth(user,password)
#       tx_webdav.set_use_proxy(proxy)
#       tx_webdav.set_use_ssl(ssl)

        scan.set_tx_list([tx_webdav])
        webdav_flg = 1

    fax_flg = 0
    if FAX_SETTING_KEY in data:
        fax_setting = data[FAX_SETTING_KEY]

        tx_fax = mfp.job.TxFax()

        if FAX_ADDRESS_KEY in fax_setting:
            fax_address = fax_setting[FAX_ADDRESS_KEY]
            tx_fax.add_send_address(fax_address)
        else:
            raise mfp.MFPValidationErr

        if FAX_USE_OVERSEAS_TX_KEY in fax_setting:
            fax_use_overseas_tx = fax_setting[FAX_USE_OVERSEAS_TX_KEY]
            tx_fax.set_use_overseas_tx(fax_use_overseas_tx)

        if FAX_USE_ECM_KEY in fax_setting:
            fax_use_ecm = fax_setting[FAX_USE_ECM_KEY]
            tx_fax.set_use_ecm(fax_use_ecm)

        if FAX_USE_CHECK_DEST_AND_SEND_KEY in fax_setting:
            fax_use_check_dest_and_send = fax_setting[FAX_USE_CHECK_DEST_AND_SEND_KEY]
            tx_fax.set_use_check_dest_and_send(fax_use_check_dest_and_send)

        if FAX_PASSWORD_KEY in fax_setting:
            fax_password = fax_setting[FAX_PASSWORD_KEY]
            tx_fax.set_credential(mfp.job.FaxSendCredential(fax_password))

        scan.set_tx_list([tx_fax])
        fax_flg = 1

    if (webdav_flg == 0 and fax_flg == 0):
        raise mfp.MFPValidationErr

    if SEND_FILE_NAME_KEY in data:
        send_file_name = data[SEND_FILE_NAME_KEY]
        scan.set_file_name(send_file_name)
    else:
        raise mfp.MFPValidationErr

    if SEND_FILE_TYPE_KEY in data:
        send_file_type = data[SEND_FILE_TYPE_KEY]
        file_type = ConvertTableIWS.file_type_table[send_file_type]
        if isinstance(file_type, mfp.job.FileTypeJPEG):
            #page setting.
            scan.set_page_setting(mfp.PageSetting.EACH)
        scan.set_file_type(file_type)
    else:
        if (webdav_flg == 1 and fax_flg == 0):
            raise mfp.MFPValidationErr

    if RESOLUTION_KEY in data:
        resoluttion = data[RESOLUTION_KEY]
        if resoluttion not in ConvertTableIWS.resolution_table:
            raise mfp.MFPValidationErr
        scan.set_resolution(ConvertTableIWS.resolution_table[resoluttion])
    else:
        if (webdav_flg == 1 and fax_flg == 0):
            raise mfp.MFPValidationErr

    if FAX_RESOLUTION_KEY in data:
        fax_resolution = data[FAX_RESOLUTION_KEY]
        if fax_resolution not in ConvertTableIWS.fax_resolution_table:
            raise mfp.MFPValidationErr
        scan.set_fax_resolution(ConvertTableIWS.fax_resolution_table[fax_resolution])
    else:
        if (webdav_flg == 0 and fax_flg == 1):
            raise mfp.MFPValidationErr

    if SCAN_SIDE_KEY in data:
        scan_side = data[SCAN_SIDE_KEY]
        if scan_side not in ConvertTableIWS.scan_side_table:
            raise mfp.MFPValidationErr
        scan.set_scan_side(ConvertTableIWS.scan_side_table[scan_side])
    else:
        raise mfp.MFPValidationErr

    if COLOR_SETTING_KEY in data:
        color_setting = data[COLOR_SETTING_KEY]
        if COLOR_MODE_KEY in color_setting:
            color_mode = color_setting[COLOR_MODE_KEY]
            if color_mode not in ConvertTableIWS.color_mode_table:
                raise mfp.MFPValidationErr
        else:
            raise mfp.MFPValidationErr

        if COLOR_KEY in color_setting:
            color = color_setting[COLOR_KEY]
            if color not in ConvertTableIWS.color_table:
                raise mfp.MFPValidationErr
        else:
            raise mfp.MFPValidationErr
        scan.set_color(ConvertTableIWS.color_mode_table[color_mode],ConvertTableIWS.color_table[color])
    else:
        if (webdav_flg == 1 and fax_flg == 0):
            raise mfp.MFPValidationErr

    if PAPER_SIZE_KEY in data:
        paper_size = data[PAPER_SIZE_KEY]
        if PAPER_SIZE_TYPE_KEY in paper_size:
            paper_type = paper_size[PAPER_SIZE_TYPE_KEY]
            if paper_type not in ConvertTableIWS.original_size_type_table:
                raise mfp.MFPValidationErr
        else:
            raise mfp.MFPValidationErr

        if PAPER_SIZE_DATA_KEY in paper_size:
            paper_data = paper_size[PAPER_SIZE_DATA_KEY]
            if paper_data not in ConvertTableIWS.paper_size_table:
                raise mfp.MFPValidationErr
        else:
            if paper_type != "AUTO":
                raise mfp.MFPValidationErr

        if paper_type == "AUTO":
            scan.set_paper_size(ConvertTableIWS.original_size_type_table[paper_type])
        elif paper_type == "STANDARD":
            scan.set_paper_size(ConvertTableIWS.original_size_type_table[paper_type], ConvertTableIWS.paper_size_table[paper_data])
    else:
        raise mfp.MFPValidationErr

    if DENSITY_KEY in data:
        density = data[DENSITY_KEY]
        scan.set_density(density)
    
    if BACK_DENSITY_KEY in data:
        back_density = data[BACK_DENSITY_KEY]
        if BACK_DENSITY_TYPE_KEY in back_density:
            back_density_type = back_density[BACK_DENSITY_TYPE_KEY]
            if back_density_type not in ConvertTableIWS.background_removal_type_table:
                raise mfp.MFPValidationErr
        else:
            raise mfp.MFPValidationErr

        if back_density_type == "AUTO":
            scan.set_back_density(ConvertTableIWS.background_removal_type_table[back_density_type])
        elif back_density_type == "MANUAL":
            if BACK_DENSITY_LEVEL_KEY in back_density:
                back_density_level = back_density[BACK_DENSITY_LEVEL_KEY]
                scan.set_back_density(ConvertTableIWS.background_removal_type_table[back_density_type], back_density_level)
            else:
                raise mfp.MFPValidationErr
    else:
        raise mfp.MFPValidationErr

    #Job start.
    jobid = mfp.job.start(scan)

    #result.
    result[RESULT_KEY] = RESULT_OK
    result[JOBID_KEY] = jobid

except Exception as ex:
    result[RESULT_KEY] = RESULT_NG
    result[RESULT_ERROR] = str(type(ex)) + " " + str(ex)
    traceback.print_exc(file=sys.stderr)
finally:
    try:
        #save result.
        fp=open(RESULT_FILE_NAME,'w')
        json.dump(result,fp)
    except:
        traceback.print_exc(file=sys.stderr)

    try:
        #delete setting.
        os.remove(SETTING_FILE_NAME)
    except:
        traceback.print_exc(file=sys.stderr)

