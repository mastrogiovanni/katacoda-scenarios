﻿//// NML: All commented out due to the major rollback on the Refactoring of the IWS project.

////using System;
////using System.IO;
////using System.Text;
////using System.Threading.Tasks;
////using Microsoft.Extensions.Logging;
////using Moq;
////using Newtonsoft.Json;
////using ServiceHub.Common.Settings;
////using ServiceHub.Common.Settings.Iws;
////using ServiceHub.Connectors.IWS.Actions.Interfaces;
////using ServiceHub.Connectors.IWS.Model;
////using ServiceHub.Connectors.IWS.ResponseListener;
////using ServiceHub.Connectors.IWS.Tests.Utility;
////using ServiceHub.Connectors.IWS.Util;
////using ServiceHub.Connectors.OpenAPI.Model;
////using Xunit;

////namespace ServiceHub.Connectors.IWS.Tests
////{
////    [Trait("AbstractIwsConnectorTests", "Unit")]
////    public class AbstractIwsConnectorTests
////    {
////        private const string IwsSettingsJson = "{\"setting_id\": \"sh\",\"definitions\": [{\"setting_id\": \"sh\",\"ip_address\": \"mfpdevice.wph.local\",\"protocol\": \"https\",\"port\": 8091,\"app_id\": \"0A0246WH\",\"auth_username\": \"1\",\"auth_password\": \"1\",\"mfpdevice_username\": \"Admin\",\"callback_url_base\": \"http://1faa0002.wph.local/services/mfpcore\",\"callback_timeout\": 10000,\"uriPath\": {\"webApi\": \"/IWS/WebAPI/\"},\"scriptPath\": {\"removeFile\": \"/removeFile.py\"},\"enhanced_server_auth\": {\"use\": true,\"values\": [{\"control_id\": \"code\",\"value_type\": \"AuthParameterCode\"}]}},{\"setting_id\": \"stub\",\"ip_address\": \"8b464935.wph.local\",\"protocol\": \"http\",\"port\": 8091,\"app_id\": \"0A0246WH\",\"auth_username\": \"1\",\"auth_password\": \"1\",\"callback_url_base\": \"http://1faa0002.wph.local/services/mfpstub\",\"callback_timeout\": 10000,\"enhanced_server_auth\": {\"use\": false,\"values\": [{\"control_id\": \"code\",\"value_type\": \"AuthParameterCode\"}]}},{\"setting_id\": \"debug\",\"ip_address\": \"mfpdevice.wph.local\",\"protocol\": \"https\",\"port\": 8091,\"app_id\": \"0A0246WH\",\"auth_username\": \"1\",\"auth_password\": \"1\",\"callback_url_base\": \"http://be222949.wph.local:62766\",\"callback_timeout\": 10000,\"enhanced_server_auth\": {\"use\": false,\"values\": [{\"control_id\": \"code\",\"value_type\": \"AuthParameterCode\"}]}}],\"app_install\": {\"folder_path\": \"~/App_Data\",\"file_name\": \"ServiceHub.iws\",\"form_content_name\": \"specialapp\"}}";
////        private readonly IIwsConnector _abstractIwsConnector;
////        private readonly IwsThreadWorker _iwsThreadWorker;
////        private readonly Mock<IResponseListenerBuilder> _iwsResponseListenerBuilderMock;
////        private readonly Mock<IAppFactory> _appDataActionFactoryMock;
////        private readonly OpenApiRequestSettings _openApiRequestSettings;
////        private readonly AuthParameter _authParameter = new AuthParameter { Code = "authCode" };
////        private readonly ILogger<IwsConnectorUser> _logger;

////        public AbstractIwsConnectorTests()
////        {
////            _logger = Mock.Of<ILogger<IwsConnectorUser>>();
////            var setting = new MfpConnectorSetting { Iws = JsonConvert.DeserializeObject<IwsSetting>(IwsSettingsJson) };
////            _iwsResponseListenerBuilderMock = new Mock<IResponseListenerBuilder>(MockBehavior.Strict);
////            _appDataActionFactoryMock = new Mock<IAppFactory>(MockBehavior.Strict);
////            _openApiRequestSettings = OpenApiFixture.GetOpenApiSetting();
////            _iwsThreadWorker = new IwsThreadWorker();

////            _abstractIwsConnector = new IwsConnectorUser(
////                _logger,
////                setting,
////                _iwsResponseListenerBuilderMock.Object,
////                _openApiRequestSettings,
////                _iwsThreadWorker,
////                _appDataActionFactoryMock.Object);
////        }

////        [Fact]
////        public void Ctor_WhenIwsSettingsContainsError_ExpectArgumentNullException()
////        {
////            var setting = new MfpConnectorSetting { Iws = JsonConvert.DeserializeObject<IwsSetting>(IwsSettingsJson) };
////            setting.Iws.CurrentSetting.Protocol = ""; // One of the many possible errors

////            var ex = Assert.Throws<ArgumentNullException>(() =>
////            {
////                var _ = new IwsConnectorUser(
////                    _logger,
////                    setting,
////                    _iwsResponseListenerBuilderMock.Object,
////                    _openApiRequestSettings,
////                    _iwsThreadWorker,
////                    _appDataActionFactoryMock.Object);
////            });

////            Assert.Equal("iwsSettings", ex.ParamName);
////        }

////        [Fact]
////        public async Task PutAppDataAsync_WhenFilePathIsNull_ExpectArgumentNullException()
////        {
////            // We use IWS Connector in order to access the abstract level.
////            var err = await Assert.ThrowsAsync<ArgumentNullException>(
////                () => _abstractIwsConnector.PutAppDataAsync(null, null, string.Empty));

////            Assert.Equal("Value cannot be null.\r\nParameter name: filePath", err.Message);
////            Assert.Equal("filePath", err.ParamName);
////        }

////        [Fact]
////        public async Task PutAppDataAsync_WhenAuthParameterIsNull_ExpectArgumentNullException()
////        {
////            var err = await Assert.ThrowsAsync<ArgumentNullException>(
////                () => _abstractIwsConnector.PutAppDataAsync("aFilePath", null, string.Empty));

////            Assert.Equal("Value cannot be null.\r\nParameter name: authParameter", err.Message);
////            Assert.Equal("authParameter", err.ParamName);
////        }

////        [Fact]
////        public async Task PutAppDataAsync_WhenDataStreamCannotRead_ExpectArgumentException()
////        {
////            var memStream = new MemoryStream(Encoding.UTF8.GetBytes(string.Empty));
////            var doNothingStream = new ReadOrWriteStream(memStream, false, false);

////            var err = await Assert.ThrowsAsync<ArgumentException>(
////                () => _abstractIwsConnector.PutAppDataAsync("aFilePath", _authParameter, doNothingStream));

////            Assert.Equal("CanRead is False\r\nParameter name: streamData", err.Message);
////        }

////        [Fact]
////        public async Task PutAppDataAsync_WhenDataStreamIsNull_ExpectArgumentNullException()
////        {
////            var err = await Assert.ThrowsAsync<ArgumentNullException>(
////                () => _abstractIwsConnector.PutAppDataAsync("aFilePath", _authParameter, (Stream)null));

////            Assert.Equal("Value cannot be null.\r\nParameter name: streamData", err.Message);
////            Assert.Equal("streamData", err.ParamName);
////        }

////        [Fact]
////        public async Task PutAppDataAsync_WhenDataStringIsNull_ExpectArgumentNullException()
////        {
////            var err = await Assert.ThrowsAsync<ArgumentNullException>(
////                () => _abstractIwsConnector.PutAppDataAsync("aFilePath", _authParameter, (string)null));

////            Assert.Equal("Value cannot be null.\r\nParameter name: data", err.Message);
////            Assert.Equal("data", err.ParamName);
////        }

////        [Fact]
////        public async Task PutAppDataAsync_WhenArgumentsAreValid_ExpectSuccess()
////        {
////            var appDataAction = Mock.Of<IApp>();
////            _appDataActionFactoryMock.Setup(m => m.CreatePut(It.IsAny<IwsWebApiUriData>(), It.IsAny<IwsWebApiReqCommon>()))
////                .Returns(appDataAction);
////            var memStream = new MemoryStream(Encoding.UTF8.GetBytes("Something"));

////            await _abstractIwsConnector.PutAppDataAsync(string.Empty, _authParameter, memStream);

////            _appDataActionFactoryMock.VerifyAll();
////        }

////        [Fact]
////        public async Task ExecAppScriptAsync_WhenScriptPathIsNull_ExpectArgumentNullException()
////        {
////            var err = await Assert.ThrowsAsync<ArgumentNullException>(() => _abstractIwsConnector.ExecAppScriptAsync(null, _authParameter));

////            Assert.Equal("Value cannot be null.\r\nParameter name: scriptPath", err.Message);
////            Assert.Equal("scriptPath", err.ParamName);
////        }

////        [Theory]
////        [InlineData("/startScan.py")]
////        [InlineData("")]
////        public async Task ExecAppScriptAsync_WhenStartExecution_ExpectSuccess(string scriptPath)
////        {
////            var appAction = Mock.Of<IAppExec>();

////            _appDataActionFactoryMock.Setup(m => m.CreateExecutor(It.IsAny<IwsWebApiUriData>(), It.IsAny<IwsWebApiReqCommon>()))
////                .Returns(appAction);

////            await _abstractIwsConnector.ExecAppScriptAsync(scriptPath, _authParameter);

////            _appDataActionFactoryMock.VerifyAll();
////        }

////        [Fact]
////        public async Task ExecAppScriptAsync_WhenExecutorThrowsIwsExceptionCodeRunning500_ExpectRetryBeforeSuccess()
////        {
////            var appAction = new Mock<IAppExec>(MockBehavior.Strict);

////            appAction.Setup(m => m.SetRequestParameter(It.IsAny<string>(), It.IsAny<AuthParameter>(), It.IsAny<string>()));
////            appAction.SetupSequence(m => m.InvokeAsync())
////                .Throws(new IwsException(string.Format(IwsException.NetworkErrMsg, 500)))
////                .Returns(Task.CompletedTask);

////            _appDataActionFactoryMock.Setup(m => m.CreateExecutor(It.IsAny<IwsWebApiUriData>(), It.IsAny<IwsWebApiReqCommon>()))
////                .Returns(appAction.Object);

////            await _abstractIwsConnector.ExecAppScriptAsync("aSampleScript.py", _authParameter);

////            appAction.VerifyAll();
////            _appDataActionFactoryMock.VerifyAll();
////        }

////        [Fact]
////        public async Task ExecAppScriptAsync_WhenExecutorThrowsIwsException_ExpectIwsException()
////        {
////            var appAction = new Mock<IAppExec>(MockBehavior.Strict);

////            appAction.Setup(m => m.SetRequestParameter(It.IsAny<string>(), It.IsAny<AuthParameter>(), It.IsAny<string>()));
////            appAction.SetupSequence(m => m.InvokeAsync())
////                .Throws<IwsException>();

////            _appDataActionFactoryMock.Setup(m => m.CreateExecutor(It.IsAny<IwsWebApiUriData>(), It.IsAny<IwsWebApiReqCommon>()))
////                .Returns(appAction.Object);

////            var ex = await Assert.ThrowsAsync<IwsException>(() => _abstractIwsConnector.ExecAppScriptAsync("aSampleScript.py", _authParameter));

////            Assert.NotEqual(string.Format(IwsException.NetworkErrMsg, 500), ex.Message);

////            appAction.VerifyAll();
////            _appDataActionFactoryMock.VerifyAll();
////        }

////        [Fact]
////        public async Task ExecuteAndWaitResponseAsync_WhenScriptPathIsNull_ExpectArgumentNullException()
////        {
////            var err = await Assert.ThrowsAsync<ArgumentNullException>(() => _abstractIwsConnector.ExecuteAndWaitResponseAsync(
////                null, _authParameter, null, null));

////            Assert.Equal("Value cannot be null.\r\nParameter name: scriptPath", err.Message);
////            Assert.Equal("scriptPath", err.ParamName);
////        }

////        [Theory]
////        [InlineData(null)]
////        [InlineData("")]
////        [InlineData("  ")]
////        public async Task ExecuteAndWaitResponseAsync_WhenDataWithNoInPath_ExpectArgumentNullException(string inpath)
////        {
////            var err = await Assert.ThrowsAsync<ArgumentNullException>(() => _abstractIwsConnector.ExecuteAndWaitResponseAsync(
////                "a fake path", _authParameter, "fake data", inpath));

////            Assert.Equal("Value cannot be null.\r\nParameter name: inPath", err.Message);
////            Assert.Equal("inPath", err.ParamName);
////        }

////        [Fact]
////        public async Task ExecuteAndWaitResponseAsync_WhenValidParameters_ExpectSuccess()
////        {
////            ((AbstractIwsConnector<IwsConnectorUser>)_abstractIwsConnector).PollingDurationMs = 1; // Needed otherwise we wayt 90 seconds.
////            var fakeListener = Mock.Of<IResponseListener>();
////            var fakeAppExecParam = Mock.Of<IAppExecParam>();

////            _appDataActionFactoryMock
////                .Setup(m => m.CreateExecutorParam(It.IsAny<IwsWebApiUriData>(), It.IsAny<IwsWebApiReqCommon>()))
////                .Returns(fakeAppExecParam);
////            _iwsResponseListenerBuilderMock.Setup(m => m.Create()).Returns(fakeListener);

////            var emptyResponse = await _abstractIwsConnector
////                .ExecuteAndWaitResponseAsync("a fake path", _authParameter, "fake data", "in/path").ConfigureAwait(false);

////            Assert.Empty(emptyResponse);
////            _appDataActionFactoryMock.VerifyAll();
////            _iwsResponseListenerBuilderMock.VerifyAll();
////        }


////        [Fact]
////        public async Task ExecuteAsync_WhenScriptPathIsNull_ExpectArgumentNullException()
////        {
////            var err = await Assert.ThrowsAsync<ArgumentNullException>(() => _abstractIwsConnector.ExecuteAsync(
////                null, _authParameter, null, null, null));

////            Assert.Equal("Value cannot be null.\r\nParameter name: scriptPath", err.Message);
////            Assert.Equal("scriptPath", err.ParamName);
////        }

////        [Theory]
////        [InlineData(null)]
////        [InlineData("")]
////        [InlineData("  ")]
////        public async Task ExecuteAsync_WhenDataWithNoInPath_ExpectArgumentNullException(string inpath)
////        {
////            var err = await Assert.ThrowsAsync<ArgumentNullException>(() => _abstractIwsConnector.ExecuteAsync(
////                "a fake path", _authParameter, "fake data", null, inpath));

////            Assert.Equal("Value cannot be null.\r\nParameter name: inPath", err.Message);
////            Assert.Equal("inPath", err.ParamName);
////        }

////        [Fact]
////        public async Task InstallSpecialAppAsync_WhenValidParameter_ExpectSuccess()
////        {
////            var fakeInstall = Mock.Of<IAppInstaller>();
////            _appDataActionFactoryMock.Setup(m => m.CreateInstallSpecial(
////                It.IsAny<IwsWebApiUriData>(),
////                It.IsAny<IwsWebApiReqCommon>(),
////                It.IsAny<string>())).Returns(fakeInstall);

////              await _abstractIwsConnector
////                .InstallSpecialAppAsync("appId", "appModulePath", "serialNumber").ConfigureAwait(false);

////            _appDataActionFactoryMock.VerifyAll();
////        }

////        [Theory]
////        [InlineData("")]
////        [InlineData("   ")]
////        [InlineData(null)]
////        public async Task InstallSpecialAppAsync_WhenAppIdIsInvalid_ExpectArgumentIsNullException(string appId)
////        {
////            var ex = await Assert.ThrowsAsync<ArgumentNullException>(() => _abstractIwsConnector
////                .InstallSpecialAppAsync(appId, "appModulePath", "serialNumber"));

////            Assert.Equal("appId", ex.ParamName);
////        }

////        [Theory]
////        [InlineData("")]
////        [InlineData("   ")]
////        [InlineData(null)]
////        public async Task InstallSpecialAppAsync_WhenAppModulePathIsInvalid_ExpectArgumentIsNullException(string appModulePath)
////        {
////            var ex = await Assert.ThrowsAsync<ArgumentNullException>(() => _abstractIwsConnector
////                .InstallSpecialAppAsync("appId", appModulePath, "serialNumber"));

////            Assert.Equal("appModulePath", ex.ParamName);
////        }

////        [Theory]
////        [InlineData("")]
////        [InlineData("   ")]
////        [InlineData(null)]
////        public async Task InstallSpecialAppAsync_WhenSerialNoIsInvalid_ExpectArgumentIsNullException(string serialNo)
////        {
////            var ex = await Assert.ThrowsAsync<ArgumentNullException>(() => _abstractIwsConnector
////                .InstallSpecialAppAsync("appId", "appModulePath", serialNo));

////            Assert.Equal("serialNo", ex.ParamName);
////        }

////        [Fact]
////        public async Task UninstallSpecialAppAsync_WhenValidParameter_ExpectSuccess()
////        {
////            var fakeUninstall = Mock.Of<IAppInstaller>();
////            _appDataActionFactoryMock.Setup(m => m.CreateUninstallSpecial(
////                It.IsAny<IwsWebApiUriData>(),
////                It.IsAny<IwsWebApiReqCommon>())).Returns(fakeUninstall);

////            await _abstractIwsConnector
////              .UninstallSpecialAppAsync("appId", "serialNumber").ConfigureAwait(false);

////            _appDataActionFactoryMock.VerifyAll();
////        }

////        [Theory]
////        [InlineData("")]
////        [InlineData("   ")]
////        [InlineData(null)]
////        public async Task UninstallSpecialAppAsync_WhenAppIdIsInvalid_ExpectArgumentIsNullException(string appId)
////        {
////            var ex = await Assert.ThrowsAsync<ArgumentNullException>(() => _abstractIwsConnector
////                .UninstallSpecialAppAsync(appId, "serialNumber"));

////            Assert.Equal("appId", ex.ParamName);
////        }

////        [Theory]
////        [InlineData("")]
////        [InlineData("   ")]
////        [InlineData(null)]
////        public async Task UninstallSpecialAppAsync_WhenSerialNoIsInvalid_ExpectArgumentIsNullException(string serialNo)
////        {
////            var ex = await Assert.ThrowsAsync<ArgumentNullException>(() => _abstractIwsConnector
////                .UninstallSpecialAppAsync("appId", serialNo));

////            Assert.Equal("serialNo", ex.ParamName);
////        }
////    }
////}
