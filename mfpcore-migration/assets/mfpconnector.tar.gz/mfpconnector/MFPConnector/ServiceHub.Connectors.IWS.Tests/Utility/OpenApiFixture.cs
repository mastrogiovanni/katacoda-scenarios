﻿using System.Collections.Generic;
using ServiceHub.Common.Settings;
using ServiceHub.Common.Settings.Ftp;
using ServiceHub.Common.Settings.Iws;
using ServiceHub.Common.Settings.OpenApi;
using ServiceHub.Common.Settings.PushNotification;
using ServiceHub.Connectors.OpenAPI.Model;

namespace ServiceHub.Connectors.IWS.Tests.Utility
{
    internal static class OpenApiFixture
    {
        public static OpenApiRequestSettings GetOpenApiSetting()
        {
            var mfpConnectorSetting = new MfpConnectorSetting()
            {
                Iws = new IwsSetting()
                {
                    SettingId = "iws_setting_test",
                    Definitions = new List<IwsWebApiSetting>(new[]
                    {
                        new IwsWebApiSetting() {
                        SettingId = "iws_setting_test",
                        Protocol = "http",
                        IpAddress = "localhost",
                        Port = 80,
                        AppId = "0A0243A4",
                        AuthUserName = "1",
                        AuthPassword = "1",
                        }
                    })
                },
                OpenApi = new OpenApiSetting
                {
                    Version = new OpenApiVersion
                    {
                        Major = 6,
                        Minor = 9,
                    },
                    Devices = new OpenApiDeviceSetting
                    {
                        SettingId = "unittest",
                        Definitions = new List<OpenApiDeviceDetailSetting>(new[]
                    {
                        new OpenApiDeviceDetailSetting
                        {
                            SettingId = "unittest",
                            DeviceIp = "10.128.47.39",
                            DevicePort = 50003,
                            UseSsl = true,
                            User = "",
                            Password = "",
                            NotifyIp = "172.16.188.16",
                            NotifyPort = 80,
                            KeepAlive = true,
                            Timeout = 10000,
                            Retry = new OpenApiRetrySetting
                            {
                                SetDeviceInfoDetail = new RetrySetting
                                {
                                    Count = 3,
                                    Interval = 100
                                }
                            },
                            EnhancedServerAuth = new OpenApiEnhancedServerAuthSetting
                            {
                                Use = false
                            },
                            AliveMonitor = new OpenApiAliveMonitorSetting
                            {
                                PingInterval = 1000,
                                PingTimeout = 1500,
                                PingErrorMax = 3,
                                OapConfirmTimeout = 10000,
                                OapConfirmPeriod = 10
                            }
                        }
                    })
                    }
                },
                PushNotification = new Dictionary<PushNotificationType, PushNotificationSetting>
                {
                    { PushNotificationType.MfpService, new PushNotificationSetting
                        {
                            SettingId = "unittest",
                            Definitions = new List<PushNotificationDefinition>(new[]
                            {
                                new PushNotificationDefinition
                                {
                                    SettingId = "unittest",
                                    Protocol = "http",
                                    Domain = "nginx.kmsh.com",
                                    Port = 80,
                                    PathBase = "/services/mfp"
                                }
                            })
                        }
                    }
                },
                Ftp = new FtpSetting
                {
                    SettingId = "debug",
                    Definitions = new List<FtpDefinition>
                    {
                        new FtpDefinition()
                        {
                            SettingId = "debug",
                            Iisw = new FtpIiswSetting
                            {
                                DownloadUrl = "test",
                            }
                        }
                    }
                }
            };
            var setting = new OpenApiRequestSettings(mfpConnectorSetting);

            return setting;
        }
    }
}
