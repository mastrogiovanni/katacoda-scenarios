﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace ServiceHub.Connectors.IWS.Tests.Utility
{
    /// <summary>
    /// Code from StackOverflow
    /// https://stackoverflow.com/questions/8397193/is-it-possible-to-set-canread-and-canwrite-properties-of-a-networkstream-objects
    /// </summary>
    /// <seealso cref="System.IO.Stream" />
    public class ReadOrWriteStream : Stream
    {
        private readonly Stream srcStream;
        private readonly bool canRead;
        private readonly bool canWrite;
        private bool disposed;

        public ReadOrWriteStream(Stream srcStream, bool canRead, bool canWrite)
        {
            this.disposed = false;
            this.srcStream = srcStream;
            this.canRead = canRead;
            this.canWrite = canWrite;
        }

        public override void Flush()
        {
            srcStream.Flush();
        }

        public override long Seek(long offset, SeekOrigin origin)
        {
            return srcStream.Seek(offset,
                                  origin);
        }

        public override void SetLength(long value)
        {
            if (!CanWrite)
                throw new NotSupportedException();
            srcStream.SetLength(value);
        }

        public override int Read(byte[] buffer, int offset, int count)
        {
            if (!CanRead)
                throw new NotSupportedException();
            return srcStream.Read(buffer,
                                  offset,
                                  count);
        }

        public override void Write(byte[] buffer, int offset, int count)
        {
            if (!CanWrite)
                throw new NotSupportedException();
            srcStream.Write(buffer,
                                   offset,
                                   count);

        }

        public override bool CanRead
        {
            get
            {
                return srcStream.CanRead && canRead;
            }
        }

        public override bool CanSeek
        {
            get
            {
                return srcStream.CanSeek;
            }
        }

        public override bool CanWrite
        {
            get
            {
                return srcStream.CanWrite && canWrite;
            }
        }

        public override IAsyncResult BeginRead(byte[] buffer, int offset, int count, AsyncCallback callback, object state)
        {
            if (!CanRead)
                throw new NotSupportedException();
            return srcStream.BeginRead(buffer,
                                       offset,
                                       count,
                                       callback,
                                       state);
        }

        public override int EndRead(IAsyncResult asyncResult)
        {
            return srcStream.EndRead(asyncResult);
        }

        public override IAsyncResult BeginWrite(byte[] buffer, int offset, int count, AsyncCallback callback, object state)
        {
            if (!CanWrite)
                throw new NotSupportedException();
            return srcStream.BeginWrite(buffer,
                                        offset,
                                        count,
                                        callback,
                                        state);
        }

        public override void EndWrite(IAsyncResult asyncResult)
        {
            srcStream.EndWrite(asyncResult);
        }

        public override long Length
        {
            get
            {
                return srcStream.Length;
            }
        }

        public override long Position
        {
            get
            {
                return srcStream.Position;
            }
            set
            {
                srcStream.Position = value;
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && !disposed)
            {
                srcStream.Dispose();
                disposed = true;
            }
            base.Dispose(disposing);
        }
    }
}
