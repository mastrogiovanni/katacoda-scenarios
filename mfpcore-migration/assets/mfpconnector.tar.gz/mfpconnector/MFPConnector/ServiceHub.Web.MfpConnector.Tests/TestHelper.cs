
using System.Xml;

using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace ServiceHub.Web.MfpConnector.Tests
{
    internal static class TestHelper
    {
        /// <summary>
        /// Compare JSON string equality.
        /// </summary>
        /// <param name="jsonX">JSON string parameter 1.</param>
        /// <param name="jsonY">JSON string parameter 2.</param>
        /// <returns>Compare result.</returns>
        public static void AreJsonEquals(string jsonX, string jsonY)
        {
            var jobjX = JsonConvert.DeserializeObject<JContainer>(jsonX);
            var jobjY = JsonConvert.DeserializeObject<JContainer>(jsonY);
            Xunit.Assert.Equal(jobjX, jobjY);
        }
    }
}
