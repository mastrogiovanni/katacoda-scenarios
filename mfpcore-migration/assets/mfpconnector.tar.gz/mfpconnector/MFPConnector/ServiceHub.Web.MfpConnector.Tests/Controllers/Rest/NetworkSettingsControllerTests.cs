using System;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

using Moq;
using Newtonsoft.Json;
using ServiceHub.Connectors.OpenAPI.Model;
using ServiceHub.Processors.Settings;
using ServiceHub.Processors.Settings.Model;
using ServiceHub.Web.MfpConnector.Controllers.Rest.Model;
using ServiceHub.Web.MfpConnector.Controllers.Rest.Settings;
using Xunit;

namespace ServiceHub.Web.MfpConnector.Tests.Controllers.Rest
{
    [Trait("NetworkSettingsController", "Unit")]
    public class NetworkSettingsControllerTests : RestControllerTestsBase
    {
        private const string ResultJsonOk = "{\"result\":\"OK\"}";
        private const string ResultJsonNg = "{\"result\":\"NG\"}";

        [Theory]
        [InlineData("10.128.47.39")]
        [InlineData("0.0.0.0")]
        [InlineData("255.255.255.255")]
        public async Task NotifyIpAddress_WhenValidData_ExpectSuccess(string addressV4)
        {
            var ipV6TypeOk = new[] { Ipv6Type.Local, Ipv6Type.Global };
            var ipAddressV6Ok = new[] {
                "2017:DB:A8:12:8:800:200C:417A",
                "0:0:0:0:0:0:0:0",
                "FFFF:FFFF:FFFF:FFFF:FFFF:FFFF:FFFF:FFFF"
            };

            foreach (var addressV6 in ipAddressV6Ok)
            {
                foreach (var typeV6 in ipV6TypeOk)
                {
                    var mockSettingsOperator = new Mock<ISettingsOperator>(MockBehavior.Strict);
                    mockSettingsOperator.Setup(m => m.NotifyDeviceNetworkSettingAsync(IpAddressType.IPv4, addressV4, Ipv6Type.Unidentified)).Returns(Task.FromResult(new AppResSetSHIPAddress()
                    {
                        Result = new OpenApiResult { ResultInfo = "Ack" }
                    }));
                    mockSettingsOperator.Setup(m => m.NotifyDeviceNetworkSettingAsync(IpAddressType.IPv6, addressV6, typeV6)).Returns(Task.FromResult(new AppResSetSHIPAddress()
                    {
                        Result = new OpenApiResult { ResultInfo = "Ack" }
                    }));

                    // Execute
                    var networkSettingController = new NetworkSettingsController(null, mockSettingsOperator.Object);
                    var response = (ObjectResult)await networkSettingController.NotifyIpAddress(
                        new NetworkSettingsRequest
                        {
                            IpAddressV4 = addressV4,
                            IpAddressV6 = addressV6,
                            IpV6Type = typeV6,
                        });

                    // Validate
                    Assert.Equal((int)HttpStatusCode.OK, response.StatusCode);
                    TestHelper.AreJsonEquals(ResultJsonOk, JsonConvert.SerializeObject(response.Value));
                    mockSettingsOperator.VerifyAll();
                }
            }
        }

        [Theory]
        [InlineData("10.128.47.39")]
        [InlineData("192.168.16.256")]
        [InlineData("123456789")]
        [InlineData(null)]
        [InlineData("")]
        [InlineData("\n")]
        [InlineData("/")]
        [InlineData(":")]
        [InlineData("*")]
        [InlineData("?")]
        [InlineData("\"")]
        [InlineData("<")]
        [InlineData(">")]
        [InlineData("|")]
        public async Task NotifyIpAddress_WhenInvalid_ExpectBadRequest(string addressV4)
        {
            var ipAddressV6Ng = new [] {
                "2017:DB:A8:12:8:800:200C:417A",
                "1:23:456:789:0:AB:CDEF:FFFF1",
                "1234567879ABCDEF",
                "2001:DB8::8:800:200C:417A",
                null,
                "",
                "\n",
                "/",
                ":",
                "*",
                "?",
                "\"",
                "<",
                ">",
                "|"
            };

            foreach (var addressV6 in ipAddressV6Ng)
            {
                // Note: There was also an another foreach but the IpV6Type was staying at null all the time
                // The test was either not writen properly from the start or it was a wanted behavior.
                
                // Prepare
                var mockSettingsOperator = new Mock<ISettingsOperator>(MockBehavior.Strict);

                // Execute
                var networkSettingController = new NetworkSettingsController(null, mockSettingsOperator.Object);
                var response = (ObjectResult)await networkSettingController.NotifyIpAddress(new NetworkSettingsRequest
                {
                    IpAddressV4 = addressV4,
                    IpAddressV6 = addressV6,
                    IpV6Type = null,
                });

                // Validate
                Assert.Equal((int)HttpStatusCode.BadRequest, response.StatusCode);
                TestHelper.AreJsonEquals(ResultJsonNg, JsonConvert.SerializeObject(response.Value));
                mockSettingsOperator.VerifyAll();
            }
        }
    }
}
