using System;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

using Moq;
using Newtonsoft.Json;
using ServiceHub.Connectors.IWS;
using ServiceHub.Processors.Common;
using ServiceHub.Processors.Copy.Model;
using ServiceHub.Processors.DeviceInfo;
using ServiceHub.Processors.Power;
using ServiceHub.Web.MfpConnector.Controllers.Rest.Jobs;
using ServiceHub.Web.MfpConnector.Controllers.Rest.Model;
using Xunit;

namespace ServiceHub.Web.MfpConnector.Tests.Controllers.Rest
{
    [Trait("CopyController", "Unit")]
    public class CopyControllerTests
    {
        private readonly CopyServiceSetting _copySetting = new CopyServiceSetting()
        {
            ScanSide = CopyScanSide.SIMPLEX,
            Density = 0,
            Color = new CopyColor()
            {
                Mode = CopyColorMode.AUTO,
                SelectColor = CopyColorSelectColor.NOT_SELECTED
            },
            OutPaperSize = new CopyOutPaperSize()
            {
                Tray = CopyTray.AUTO,
                Size = "SEF_A4"
            }
        };

        private readonly Mock<IMfpSender<CopyServiceSetting, CopyServiceResult>> _senderMock;
        private readonly Mock<IPowerOperator> _powerMock;
        private readonly Mock<IDeviceInfoOperator> _deviceInfoMock;
        private readonly ILogger<CopyController> _logger;

        public CopyControllerTests()
        {
            _logger = Mock.Of<ILogger<CopyController>>();
            _senderMock = new Mock<IMfpSender<CopyServiceSetting, CopyServiceResult>>(MockBehavior.Strict);
            _powerMock = new Mock<IPowerOperator>(MockBehavior.Strict);
            _deviceInfoMock = new Mock<IDeviceInfoOperator>(MockBehavior.Strict);
        }

        [Fact]
        public async Task Post_WhenValidCall_ExpectCreated()
        {
            var copyResult = new CopyServiceResult { JobId = 123, Result = "OK" };
            var expected = new CopyControllerResult
            {
                Result = copyResult.Result,
                JobId = copyResult.JobId,
                Error = copyResult.Error
            };

            _senderMock.Setup(m => m.SendToMfpAsync(It.IsAny<CopyServiceSetting>())).ReturnsAsync(copyResult);
            _powerMock.Setup(m => m.WakeUpToMfpAsync(It.IsAny<bool>())).ReturnsAsync(true);
            _deviceInfoMock.Setup(m => m.GetMfpManualTrayPaperSizeUnmatchAsync()).ReturnsAsync(false);

            var copyController = new CopyController(_logger, _deviceInfoMock.Object, null, _powerMock.Object, _senderMock.Object);
            var response = copyController.Post(_copySetting);
            var result = ((ObjectResult)await response);

            Assert.Equal((int)HttpStatusCode.Created, result.StatusCode);
            Assert.Equal(JsonConvert.SerializeObject(expected), JsonConvert.SerializeObject(result.Value));
            _senderMock.VerifyAll();
            _powerMock.VerifyAll();
        }

        [Fact]
        public async Task Post_WhenBadSettings_ExpectBadRequest()
        {
            // Execute
            var copyController = new CopyController(_logger, _deviceInfoMock.Object, null, null, null);
            var result = (ObjectResult)await copyController.Post(null);

            // Validate
            Assert.Equal((int)HttpStatusCode.BadRequest, result.StatusCode);
            Assert.NotNull(result.Value);
            Assert.Equal("NG", ((CopyControllerResult)result.Value).Result);
        }

        [Theory]
        [InlineData(CopyTray.AUTO)]
        [InlineData(CopyTray.TRAY_1)]
        [InlineData(CopyTray.TRAY_2)]
        public async Task Post_WhenPaperSizeUnmatch_ExpectCreated(CopyTray tray)
        {
            var copyResult = new CopyServiceResult { JobId = 123, Result = "OK" };
            var expected = new CopyControllerResult
            {
                Result = copyResult.Result,
                JobId = copyResult.JobId,
                Error = copyResult.Error
            };
            CopyServiceSetting _copySetting = new CopyServiceSetting()
            {
                ScanSide = CopyScanSide.SIMPLEX,
                Density = 0,
                Color = new CopyColor()
                {
                    Mode = CopyColorMode.AUTO,
                    SelectColor = CopyColorSelectColor.NOT_SELECTED
                },
                OutPaperSize = new CopyOutPaperSize()
                {
                    Tray = tray,
                    Size = "SEF_A4"
                }
            };

            _senderMock.Setup(m => m.SendToMfpAsync(It.IsAny<CopyServiceSetting>())).ReturnsAsync(copyResult);
            _powerMock.Setup(m => m.WakeUpToMfpAsync(It.IsAny<bool>())).ReturnsAsync(true);
            _deviceInfoMock.Setup(m => m.GetMfpManualTrayPaperSizeUnmatchAsync()).ReturnsAsync(true);

            var copyController = new CopyController(_logger, _deviceInfoMock.Object, null, _powerMock.Object, _senderMock.Object);
            var response = copyController.Post(_copySetting);
            var result = ((ObjectResult)await response);

            Assert.Equal((int)HttpStatusCode.Created, result.StatusCode);
            Assert.Equal(JsonConvert.SerializeObject(expected), JsonConvert.SerializeObject(result.Value));
            _senderMock.VerifyAll();
            _powerMock.VerifyAll();
        }

        [Fact]
        public async Task Post_WhenPaperSizeUnmatch_ExpectBadRequest()
        {
            var copyResult = new CopyServiceResult {Result = "NG", Error = "ManualPaperSizeDifferenceErr" };
            var expected = new CopyControllerResult
            {
                Result = copyResult.Result,
                Error = copyResult.Error
            };
            CopyServiceSetting _copySetting = new CopyServiceSetting()
            {
                ScanSide = CopyScanSide.SIMPLEX,
                Density = 0,
                Color = new CopyColor()
                {
                    Mode = CopyColorMode.AUTO,
                    SelectColor = CopyColorSelectColor.NOT_SELECTED
                },
                OutPaperSize = new CopyOutPaperSize()
                {
                    Tray = CopyTray.MANUAL,
                    Size = "SEF_A4"
                }
            };

            _senderMock.Setup(m => m.SendToMfpAsync(It.IsAny<CopyServiceSetting>())).ReturnsAsync(copyResult);
            _powerMock.Setup(m => m.WakeUpToMfpAsync(It.IsAny<bool>())).ReturnsAsync(true);
            _deviceInfoMock.Setup(m => m.GetMfpManualTrayPaperSizeUnmatchAsync()).ReturnsAsync(true);

            // Execute
            var copyController = new CopyController(_logger, _deviceInfoMock.Object, null, _powerMock.Object, _senderMock.Object);
            var response = await copyController.Post(_copySetting);
            var result = (ObjectResult)response;

            // Validate
            Assert.Equal((int)HttpStatusCode.BadRequest, result.StatusCode);
            Assert.NotNull(result.Value);
            Assert.Equal("NG", ((CopyControllerResult)result.Value).Result);
            Assert.Equal("ManualPaperSizeDifferenceErr", ((CopyControllerResult)result.Value).Error);
        }

        [Fact]
        public async Task Post_WhenSendingToMfpFail_ExpectInternalServerErrorMessage()
        {
            var ex = new Exception("dummy Exception");

            _senderMock.Setup(m => m.SendToMfpAsync(_copySetting)).Throws(ex);
            _powerMock.Setup(m => m.WakeUpToMfpAsync(It.IsAny<bool>())).ReturnsAsync(true);
            _deviceInfoMock.Setup(m => m.GetMfpManualTrayPaperSizeUnmatchAsync()).ReturnsAsync(false);

            var copyController = new CopyController(_logger, _deviceInfoMock.Object, null, _powerMock.Object, _senderMock.Object);
            var response = await copyController.Post(_copySetting);
            var result = (ObjectResult)response;

            Assert.Equal((int)HttpStatusCode.InternalServerError, result.StatusCode);
            Assert.Equal("Fatal", ((CopyControllerResult)result.Value).Error);

            _senderMock.VerifyAll();
            _powerMock.VerifyAll();
        }

        [Fact]
        public async Task Post_WhenFalseWakeUpToMfpAsync_ExpectInternalServerErrorMessage()
        {
            // Prepare
            _powerMock.Setup(m => m.WakeUpToMfpAsync(It.IsAny<bool>())).ReturnsAsync(false);

            // Execute
            var copyController = new CopyController(_logger, _deviceInfoMock.Object, null, _powerMock.Object, null);
            var response = (ObjectResult)await copyController.Post(_copySetting);

            // Validate
            var expected = new CopyControllerResult
            {
                JobId = null,
                Result = "NG",
                Error = "MFP wake up failed."
            };
            Assert.Equal((int)HttpStatusCode.InternalServerError, response.StatusCode);
            Assert.Equal(JsonConvert.SerializeObject(expected), JsonConvert.SerializeObject(response.Value));
            _powerMock.VerifyAll();
        }

        [Fact]
        public async Task Post_WhenNetworkError500_ExpectInternalServerErrorMessage()
        {
            // Prepare
            var copyResult = new CopyServiceResult()
            {
                JobId = null,
                Result = "NG",
                Error = "Fatal"
            };

            _senderMock.Setup(m => m.SendToMfpAsync(It.IsAny<CopyServiceSetting>())).ReturnsAsync(copyResult);
            _powerMock.Setup(m => m.WakeUpToMfpAsync(It.IsAny<bool>())).ReturnsAsync(true);
            _deviceInfoMock.Setup(m => m.GetMfpManualTrayPaperSizeUnmatchAsync()).ReturnsAsync(false);

            // Execute
            var copyController = new CopyController(_logger, _deviceInfoMock.Object, null, _powerMock.Object, _senderMock.Object);
            var response = (ObjectResult)await copyController.Post(_copySetting);

            // Validate
            var expected = new CopyControllerResult
            {
                Result = copyResult.Result,
                JobId = copyResult.JobId,
                Error = copyResult.Error
            };

            Assert.Equal((int)HttpStatusCode.InternalServerError, response.StatusCode);
            Assert.Equal(JsonConvert.SerializeObject(expected), JsonConvert.SerializeObject(response.Value));
            _senderMock.VerifyAll();
            _powerMock.VerifyAll();
        }

        [Fact]
        public async Task Post_WhenIwsExceptionNetworkError503_ExpectServiceUnavailableMessage()
        {
            var ex = new IwsException(string.Format(IwsException.NetworkErrMsg, (int)HttpStatusCode.ServiceUnavailable));
            var copyResult = new CopyServiceResult { JobId = null, Result = "NG", Error = "Fatal" };
            var expected = new CopyControllerResult
            {
                Result = copyResult.Result,
                JobId = copyResult.JobId,
                Error = copyResult.Error
            };

            _senderMock.Setup(m => m.SendToMfpAsync(It.IsAny<CopyServiceSetting>())).ThrowsAsync(ex);
            _powerMock.Setup(m => m.WakeUpToMfpAsync(It.IsAny<bool>())).ReturnsAsync(true);
            _deviceInfoMock.Setup(m => m.GetMfpManualTrayPaperSizeUnmatchAsync()).ReturnsAsync(false);

            var copyController = new CopyController(_logger, _deviceInfoMock.Object, null, _powerMock.Object, _senderMock.Object);
            var response = copyController.Post(_copySetting);
            var result = ((ObjectResult)await response);

            Assert.Equal((int)HttpStatusCode.ServiceUnavailable, result.StatusCode);
            Assert.Equal(JsonConvert.SerializeObject(expected), JsonConvert.SerializeObject(result.Value));
            _senderMock.VerifyAll();
            _powerMock.VerifyAll();
        }

        [Fact]
        public async Task Post_WhenNetworkError503_ExpectServiceUnavailableMessage()
        {
            var copyResult = new CopyServiceResult { JobId = null, Result = "NG", Error = "NetworkError[503]" };
            var expected = new CopyControllerResult
            {
                Result = copyResult.Result,
                JobId = copyResult.JobId,
                Error = "Fatal"
            };

            _senderMock.Setup(m => m.SendToMfpAsync(It.IsAny<CopyServiceSetting>())).ReturnsAsync(copyResult);
            _powerMock.Setup(m => m.WakeUpToMfpAsync(It.IsAny<bool>())).ReturnsAsync(true);
            _deviceInfoMock.Setup(m => m.GetMfpManualTrayPaperSizeUnmatchAsync()).ReturnsAsync(false);

            var copyController = new CopyController(_logger, _deviceInfoMock.Object, null, _powerMock.Object, _senderMock.Object);
            var response = copyController.Post(_copySetting);
            var result = ((ObjectResult)await response);

            Assert.Equal((int)HttpStatusCode.ServiceUnavailable, result.StatusCode);
            Assert.Equal(JsonConvert.SerializeObject(expected), JsonConvert.SerializeObject(result.Value));
            _senderMock.VerifyAll();
            _powerMock.VerifyAll();
        }

        [Fact]
        public async Task Post_WhenIwsExceptionNetworkErrorOtherThen503_ExpectInternalServerErrorMessage()
        {
            var ex = new IwsException(string.Format(IwsException.NetworkErrMsg, 504));
            var copyResult = new CopyServiceResult { JobId = null, Result = "NG", Error = "Fatal" };
            var expected = new CopyControllerResult
            {
                Result = copyResult.Result,
                JobId = copyResult.JobId,
                Error = copyResult.Error
            };

            _senderMock.Setup(m => m.SendToMfpAsync(It.IsAny<CopyServiceSetting>())).ThrowsAsync(ex);
            _powerMock.Setup(m => m.WakeUpToMfpAsync(It.IsAny<bool>())).ReturnsAsync(true);
            _deviceInfoMock.Setup(m => m.GetMfpManualTrayPaperSizeUnmatchAsync()).ReturnsAsync(false);

            var copyController = new CopyController(_logger, _deviceInfoMock.Object, null, _powerMock.Object, _senderMock.Object);
            var response = copyController.Post(_copySetting);
            var result = ((ObjectResult)await response);

            Assert.Equal((int)HttpStatusCode.InternalServerError, result.StatusCode);
            Assert.Equal(JsonConvert.SerializeObject(expected), JsonConvert.SerializeObject(result.Value));
            _senderMock.VerifyAll();
            _powerMock.VerifyAll();
        }
    }
}