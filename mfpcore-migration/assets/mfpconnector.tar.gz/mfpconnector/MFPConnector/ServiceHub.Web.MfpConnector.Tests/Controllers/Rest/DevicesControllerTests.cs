using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using System.Xml;
using KonicaMinolta.OpenApi;

using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using Newtonsoft.Json;
using ServiceHub.Common.Model;
using ServiceHub.Connectors.OpenAPI.Exceptions;
using ServiceHub.Processors.DeviceInfo;
using ServiceHub.Processors.DeviceInfo.Model;
using ServiceHub.Processors.Notify;
using ServiceHub.Processors.Notify.Model;
using ServiceHub.Web.MfpConnector.Controllers.Rest;
using ServiceHub.Web.MfpConnector.Controllers.Rest.Model;
using Xunit;
using OpenApiNackException = KonicaMinolta.OpenApi.OpenApiNackException;

namespace ServiceHub.Web.MfpConnector.Tests.Controllers.Rest
{
    [Trait("DevicesController", "Unit")]
    public class DevicesControllerTests
    {
        private readonly Mock<INotifySetter> _notifySetterMock;
        private readonly Mock<IDeviceInfoOperator> _deviceInfoOperatorMock;

        private readonly ILogger<DevicesController> _logger;

        private readonly MfpDeviceVersionInfo _mfpDeviceVersionInfo = new MfpDeviceVersionInfo()
        {
            TargetName = "ADF"
        };

        public DevicesControllerTests()
        {
            _logger = Mock.Of<ILogger<DevicesController>>();
            _notifySetterMock = new Mock<INotifySetter>(MockBehavior.Strict);
            _deviceInfoOperatorMock = new Mock<IDeviceInfoOperator>(MockBehavior.Strict);
        }

        [Fact]
        public async Task Get_WhenValid_ExpectSuccess()
        {
            // Prepare
            var expected = new List<NotifyDeviceStatus>
            {
                new NotifyDeviceStatus
                {
                    Type = "Printer",
                    Status = "Error2",
                    Detail = "error detail",
                    ErrorCode = 0,
                },
                new NotifyDeviceStatus
                {
                    Type = "Scanner",
                    Status = "Ready",
                    Detail = "Ready",
                    ErrorCode = 0,
                }
            };

            _notifySetterMock.Setup(m => m.GetDeviceListStatusAsync()).ReturnsAsync(expected);

            // Execute
            var devicesController = new DevicesController(_logger, null, _notifySetterMock.Object, null, null, null);
            var response = devicesController.Get();
            var result = (ObjectResult)await response;

            // Validate
            Assert.Equal((int)HttpStatusCode.OK, result.StatusCode);
            Assert.Equal(JsonConvert.SerializeObject(expected), JsonConvert.SerializeObject(result.Value));
            _notifySetterMock.VerifyAll();
        }

        [Fact]
        public void Get_WhenNotifySetterReturnEmptyResult_ExpectNoContent()
        {
            // Prepare
            _notifySetterMock.Setup(m => m.GetDeviceListStatusAsync()).ReturnsAsync((List<NotifyDeviceStatus>)null);

            // Execute
            var devicesController = new DevicesController(_logger, null, _notifySetterMock.Object, null, null, null);
            var response = devicesController.Get();

            // Validate
            Assert.True(response.Result is NoContentResult);
            Assert.Equal((int)HttpStatusCode.NoContent, ((NoContentResult)response.Result).StatusCode);
            _notifySetterMock.VerifyAll();
        }

        [Fact]
        public void Get_WhenNotifySetterThrows_ExpectInternalServerError()
        {
            // Execute
            var devicesController = new DevicesController(_logger, null, null, null, null, null);
            var response = devicesController.Get();

            // Validate
            Assert.Equal((int)HttpStatusCode.InternalServerError, ((ObjectResult)response.Result).StatusCode);
        }

        [Fact]
        public void GetMfpDeviceVersionAsync_WhenDeviceInfoOperatorReturnNack_ExpectInternalServerError()
        {
            // Prepare
            var xmlBody = "<Result>"
                        + "<ResultInfo>Nack</ResultInfo>"
                        + "<FaultRequest>AppReqGetDeviceInfoDetail</FaultRequest>"
                        + "<ErrorDetails>Error details</ErrorDetails>"
                        + "<ErrorDescription>Error description</ErrorDescription>"
                        + "</Result>";
            _deviceInfoOperatorMock.Setup(m => m.GetMfpDeviceVersionAsync(_mfpDeviceVersionInfo.TargetName))
                .Throws(new OpenApiNackException("AppReqGetDeviceInfoDetail is Nack", new OpenApiMessage(string.Empty), new OpenApiMessage(xmlBody)));

            // Execute
            var devicesController = new DevicesController(_logger, null, null, _deviceInfoOperatorMock.Object, null, null);
            var response = devicesController.GetMfpDeviceVersionAsync(_mfpDeviceVersionInfo);

            // Validate
            Assert.Equal((int)HttpStatusCode.InternalServerError, ((ObjectResult)response.Result).StatusCode);
            _deviceInfoOperatorMock.VerifyAll();
        }

        [Fact]
        public void GetMfpDeviceVersionAsync_WhenDeviceInfoOperatorReturnOpenApiNackExceptionWithAck_ExpectInternalServerError()
        {
            // Prepare
            var xmlBody = "<AppResGetDeviceInfoDetail>";
            xmlBody += "<Result>";
            xmlBody += "<ResultInfo>Ack</ResultInfo>";
            xmlBody += "</Result>";
            xmlBody += "<RequestItem>Version</RequestItem>";
            xmlBody += "<VersionList>";
            xmlBody += "<ArraySize>45</ArraySize>";
            xmlBody += "<Version>";
            xmlBody += "<Name>MFP Card Version</Name>";
            xmlBody += "<Code>A92T0Y0-F000-G00-06(00)</Code>";
            xmlBody += "</Version>";
            xmlBody += "<Version>";
            xmlBody += "<Name>MFP Controller BOOT Program</Name>";
            xmlBody += "<Code>A92T0Y0-1E00-G00-01(00)</Code>";
            xmlBody += "</Version>";
            xmlBody += "<Version>";
            xmlBody += "<Name>MFP Controller Linux Base</Name>";
            xmlBody += "<Code>Linux-3.10.40</Code>";
            xmlBody += "</Version>";
            xmlBody += "</VersionList>";
            xmlBody += "<RequestSourceSH>Off</RequestSourceSH>";
            xmlBody += "</AppResGetDeviceInfoDetail>";

            _deviceInfoOperatorMock.Setup(m => m.GetMfpDeviceVersionAsync(_mfpDeviceVersionInfo.TargetName))
                .Throws(
                    new OpenApiNackException(
                        "AppReqGetDeviceInfoDetail is Empty",
                        new OpenApiMessage(string.Empty),
                        new OpenApiMessage(xmlBody)));

            // Execute
            var devicesController = new DevicesController(_logger, null, null, _deviceInfoOperatorMock.Object, null, null);
            var response = devicesController.GetMfpDeviceVersionAsync(_mfpDeviceVersionInfo);

            // Validate
            Assert.Equal((int)HttpStatusCode.InternalServerError, ((ObjectResult)response.Result).StatusCode);
            _deviceInfoOperatorMock.VerifyAll();
        }

        [Fact]
        public async Task GetMfpDeviceVersionAsync_WhenValidData_ExpectSuccess()
        {
            // Prepare
            var version = "AAC10Y0-0024-G00-00";
            var returnData = $"{{\"version\":\"{version}\"}}";

            _deviceInfoOperatorMock.Setup(m => m.GetMfpDeviceVersionAsync(_mfpDeviceVersionInfo.TargetName)).ReturnsAsync(version);

            // Execute
            var devicesController = new DevicesController(_logger, null, null, _deviceInfoOperatorMock.Object, null, null);
            var response = await devicesController.GetMfpDeviceVersionAsync(_mfpDeviceVersionInfo);
            var resResult = (ObjectResult)response;

            // Validate
            Assert.Equal((int)HttpStatusCode.OK, resResult.StatusCode);
            var result = JsonConvert.SerializeObject(resResult.Value);
            Assert.Equal(returnData, result);
            _deviceInfoOperatorMock.VerifyAll();
        }

        [Fact]
        public async Task GetMfpDeviceVersionAsync_WhenParameterNull_ExpectArgumentNullException()
        {
            // Execute
            var devicesController = new DevicesController(_logger, null, null, _deviceInfoOperatorMock.Object, null, null);
            var result = await Assert.ThrowsAsync<ArgumentNullException>(async () => await devicesController.GetMfpDeviceVersionAsync(null));

            // Validate
            Assert.Equal("mfpDeviceVersionInfo",result.ParamName);
        }

        [Fact]
        public async Task GetMfpDeviceVersionAsync_WhenTargetNameNull_ExpectArgumentNullException()
        {
            // Prepare
            _mfpDeviceVersionInfo.TargetName = null;

            // Execute
            var devicesController = new DevicesController(_logger, null, null, _deviceInfoOperatorMock.Object, null, null);
            var result = await Assert.ThrowsAsync<ArgumentNullException>(async () => await devicesController.GetMfpDeviceVersionAsync(_mfpDeviceVersionInfo));

            // Validate
            Assert.Equal("TargetName", result.ParamName);
        }

        [Fact]
        public async Task GetMfpDeviceVersionAsync_WhenTargetNameSpace_ExpectArgumentException()
        {
            // Prepare
            _mfpDeviceVersionInfo.TargetName = "";

            // Execute
            var devicesController = new DevicesController(_logger, null, null, _deviceInfoOperatorMock.Object, null, null);
            var result = await Assert.ThrowsAsync<ArgumentException>(async () => await devicesController.GetMfpDeviceVersionAsync(_mfpDeviceVersionInfo));

            // Validate
            Assert.Equal("TargetName", result.ParamName);
        }

        [Fact]
        public void GetMfpFaxCapabilityInfo_WhenFaxEnabled_ExpectSuccess()
        {
            // Prepare
            var expected = new MfpFaxCapabilityInfo
            {
                FaxEnabled = true
            };

            _deviceInfoOperatorMock.Setup(m => m.GetMfpFaxCapabilityInfoAsync()).ReturnsAsync(expected);

            // Execute
            var devicesController = new DevicesController(_logger, null, null, _deviceInfoOperatorMock.Object, null, null);
            var response = devicesController.GetMfpFaxCapabilityInfo();
            var result = (ObjectResult)response.Result;

            // Validate
            Assert.Equal((int)HttpStatusCode.OK, result.StatusCode);
            Assert.Equal(JsonConvert.SerializeObject(expected), JsonConvert.SerializeObject(result.Value));
            _deviceInfoOperatorMock.VerifyAll();
        }

        [Fact]
        public void GetMfpFaxCapabilityInfo_WhenException_ExpectInternalServerError()
        {
            // Prepare
            _deviceInfoOperatorMock.Setup(m => m.GetMfpFaxCapabilityInfoAsync()).Throws(new Exception("dummy exception"));

            // Execute
            var devicesController = new DevicesController(_logger, null, null, null, null, null);
            var response = devicesController.GetMfpFaxCapabilityInfo();

            // ValidateGetMfpSupportFunctionsAsync
            Assert.Equal((int)HttpStatusCode.InternalServerError, ((ObjectResult)response.Result).StatusCode);
        }
        
        [Fact]
        public async Task GetMfpApplicationOptionAsync_WhenGettingDeviceInfoThrowsValid_ExpectSuccess()
        {
            // Prepare
            var expected = new MfpApplicationOption
            {
                Stamp = SwitchOption.On,
                Ooxml = SwitchOption.On
            };

            _deviceInfoOperatorMock.Setup(m => m.GetMfpApplicationOptionAsync()).ReturnsAsync(expected);

            // Execute
            var devicesController = new DevicesController(_logger, null, null, _deviceInfoOperatorMock.Object, null, null);
            var result = (ObjectResult)await devicesController.GetMfpApplicationOptionAsync();
            var actual = result.Value as MfpApplicationOptionResult;

            // Validate
            Assert.Equal((int)HttpStatusCode.OK, result.StatusCode);
            Assert.Equal(JsonConvert.SerializeObject(expected), JsonConvert.SerializeObject(actual));
            _deviceInfoOperatorMock.VerifyAll();
        }
        
        [Fact]
        public void GetMfpApplicationOptionAsync_WhenGettingDeviceInfoThrowsOpenApiRequestException_ExpectInternalServerError()
        {
            // Prepare
            _deviceInfoOperatorMock.Setup(m => m.GetMfpApplicationOptionAsync())
                .Throws(new OpenApiRequestException(OpenApiResultStatus.OtherError));

            // Execute
            var devicesController = new DevicesController(_logger, null, null, null, null, null);
            var response = devicesController.GetMfpApplicationOptionAsync();

            // Validate
            Assert.Equal((int)HttpStatusCode.InternalServerError, ((ObjectResult)response.Result).StatusCode);
        }

        [Fact]
        public void GetMfpApplicationOptionAsync_WhenGettingDeviceInfoThrowsOpenApiNackException_ExpectInternalServerError()
        {
            // Prepare
            _deviceInfoOperatorMock.Setup(m => m.GetMfpApplicationOptionAsync())
                .Throws(new OpenApiNackException(string.Empty,
                    new OpenApiMessage(string.Empty),
                    new OpenApiMessage(string.Empty)));

            // Execute
            var devicesController = new DevicesController(_logger, null, null, null, null, null);
            var response = devicesController.GetMfpApplicationOptionAsync();

            // Validate
            Assert.Equal((int)HttpStatusCode.InternalServerError, ((ObjectResult)response.Result).StatusCode);
        }

        [Fact]
        public void GetMfpApplicationOptionAsync_WhenGettingDeviceInfoThrowsXmlException_ExpectInternalServerError()
        {
            // Prepare
            _deviceInfoOperatorMock.Setup(m => m.GetMfpApplicationOptionAsync())
                .Throws(new XmlException());

            // Execute
            var devicesController = new DevicesController(_logger, null, null, null, null, null);
            var response = devicesController.GetMfpApplicationOptionAsync();

            // Validate
            Assert.Equal((int)HttpStatusCode.InternalServerError, ((ObjectResult)response.Result).StatusCode);
        }

        [Fact]
        public async Task GetMfpApplicationOptionAsync_WhenGettingDeviceInfoThrowsReturnEmptyResult_ExpectInternalServerError()
        {
            // Prepare
            var expected = new MfpApplicationOption();

            _deviceInfoOperatorMock.Setup(m => m.GetMfpApplicationOptionAsync()).Returns(Task.FromResult(expected));

            // Execute
            var devicesController = new DevicesController(_logger, null, null, null, null, null);
            var response = devicesController.GetMfpApplicationOptionAsync();
            var actual = ((ObjectResult)await devicesController.GetMfpApplicationOptionAsync()).Value as MfpApplicationOptionResult;

            // Validate
            Assert.Null(actual);
            Assert.Equal((int)HttpStatusCode.InternalServerError, ((ObjectResult)response.Result).StatusCode);
        }
        
        [Fact]
        public async Task GetMfpSupportFunctionsAsync_WhenGettingDeviceInfoThrowsValid_ExpectSuccess()
        {
            // Prepare
            var expected = new MfpSupportFunctions
            {
                Fax = false,
                Scan = true,
                Copy = true,
                Fax2 = false,
                Print = true,
                Fax3 = SwitchOption.Off,
                Fax4 = SwitchOption.Off
            };

            _deviceInfoOperatorMock.Setup(m => m.GetMfpSupportFunctionsAsync()).ReturnsAsync(expected);

            // Execute
            var devicesController = new DevicesController(_logger, null, null, _deviceInfoOperatorMock.Object, null, null);
            var result = (ObjectResult)await devicesController.GetMfpSupportFunctionsAsync();
            var actual = result.Value as MfpSupportFunctionsResult;

            // Validate
            Assert.Equal(JsonConvert.SerializeObject(expected), JsonConvert.SerializeObject(actual));
            Assert.Equal((int)HttpStatusCode.OK, result.StatusCode);
            _deviceInfoOperatorMock.VerifyAll();
        }

        [Fact]
        public void GetMfpSupportFunctionsAsync_WhenGettingDeviceInfoThrowsOpenApiRequestException_ExpectInternalServerError()
        {
            // Prepare
            _deviceInfoOperatorMock.Setup(m => m.GetMfpSupportFunctionsAsync())
                .Throws(new OpenApiRequestException(OpenApiResultStatus.OtherError));

            // Execute
            var devicesController = new DevicesController(_logger, null, null, null, null, null);
            var response = devicesController.GetMfpSupportFunctionsAsync();

            // Validate
            Assert.Equal((int)HttpStatusCode.InternalServerError, ((ObjectResult)response.Result).StatusCode);
        }

        [Fact]
        public void GetMfpSupportFunctionsAsync_Expect_OpenApiNackException()
        {
            // Prepare
            _deviceInfoOperatorMock.Setup(m => m.GetMfpSupportFunctionsAsync())
                .Throws(new OpenApiNackException(string.Empty,
                    new OpenApiMessage(string.Empty),
                    new OpenApiMessage(string.Empty)));

            // Execute
            var devicesController = new DevicesController(_logger, null, null, null, null, null);
            var response = devicesController.GetMfpSupportFunctionsAsync();

            // Validate
            Assert.Equal((int)HttpStatusCode.InternalServerError, ((ObjectResult)response.Result).StatusCode);
        }

        [Fact]
        public void GetMfpSupportFunctionsAsync_WhenGettingDeviceInfoThrowsXmlException_ExpectInternalServerError()
        {
            // Prepare
            _deviceInfoOperatorMock.Setup(m => m.GetMfpSupportFunctionsAsync())
                .Throws(new XmlException());

            // Execute
            var devicesController = new DevicesController(_logger, null, null, null, null, null);
            var response = devicesController.GetMfpSupportFunctionsAsync();

            // Validate
            Assert.Equal((int)HttpStatusCode.InternalServerError, ((ObjectResult)response.Result).StatusCode);
        }

        [Fact]
        public async Task GetMfpSupportFunctionsAsync_WhenGettingDeviceInfoThrowsReturnEmptyResult_ExpectInternalServerError()
        {
            // Prepare
            var expected = new MfpSupportFunctions();

            _deviceInfoOperatorMock.Setup(m => m.GetMfpSupportFunctionsAsync()).Returns(Task.FromResult(expected));

            // Execute
            var devicesController = new DevicesController(_logger, null, null, null, null, null);
            var response = devicesController.GetMfpSupportFunctionsAsync();
            var actual = ((ObjectResult)await devicesController.GetMfpSupportFunctionsAsync()).Value as MfpSupportFunctionsResult;

            // Validate
            Assert.Null(actual);
            Assert.Equal((int)HttpStatusCode.InternalServerError, ((ObjectResult)response.Result).StatusCode);
        }
        
        [Fact]
        public async Task GetMfpFinisherAsync_WhenGettingDeviceInfoValid_ExpectSuccess()
        {
            // Prepare
            var expected = new MfpFinisher
            {
                ProductName = string.Empty
            };

            _deviceInfoOperatorMock.Setup(m => m.GetMfpFinisherAsync()).ReturnsAsync(expected);

            // Execute
            var devicesController = new DevicesController(_logger, null, null, _deviceInfoOperatorMock.Object, null, null);
            var result = (ObjectResult)await devicesController.GetMfpFinisherAsync();
            var actual = result.Value as MfpFinisherResult;

            // Validate
            Assert.Equal(string.Empty, actual.ProductName);
            Assert.Equal((int)HttpStatusCode.OK, result.StatusCode);
            _deviceInfoOperatorMock.VerifyAll();
        }

        [Fact]
        public void GetMfpFinisherAsync_WhenGettingDeviceInfoThrowsOpenApiRequestException_ExpectInternalServerError()
        {
            // Prepare
            _deviceInfoOperatorMock.Setup(m => m.GetMfpFinisherAsync())
                .Throws(new OpenApiRequestException(OpenApiResultStatus.OtherError));

            // Execute
            var devicesController = new DevicesController(_logger, null, null, null, null, null);
            var response = devicesController.GetMfpFinisherAsync();

            // Validate
            Assert.Equal((int)HttpStatusCode.InternalServerError, ((ObjectResult)response.Result).StatusCode);
        }

        [Fact]
        public void GetMfpFinisherAsync_WhenGettingDeviceInfoThrowsOpenApiNackException_ExpectInternalServerError()
        {
            // Prepare
            _deviceInfoOperatorMock.Setup(m => m.GetMfpFinisherAsync())
                .Throws(new OpenApiNackException(string.Empty,
                    new OpenApiMessage(string.Empty),
                    new OpenApiMessage(string.Empty)));

            // Execute
            var devicesController = new DevicesController(_logger, null, null, null, null, null);
            var response = devicesController.GetMfpFinisherAsync();

            // Validate
            Assert.Equal((int)HttpStatusCode.InternalServerError, ((ObjectResult)response.Result).StatusCode);
        }

        [Fact]
        public void GetMfpFinisherAsync_WhenGettingDeviceInfoThrowsXmlException_ExpectInternalServerError()
        {
            // Prepare
            _deviceInfoOperatorMock.Setup(m => m.GetMfpFinisherAsync())
                .Throws(new XmlException());

            // Execute
            var devicesController = new DevicesController(_logger, null, null, null, null, null);
            var response = devicesController.GetMfpFinisherAsync();

            // Validate
            Assert.Equal((int)HttpStatusCode.InternalServerError, ((ObjectResult)response.Result).StatusCode);
        }

        [Fact]
        public async Task GetMfpFinisherAsync_WhenGettingDeviceInfoReturnEmptyResult_ExpectInternalServerError()
        {
            // Prepare
            var expected = new MfpFinisher();

            _deviceInfoOperatorMock.Setup(m => m.GetMfpFinisherAsync()).Returns(Task.FromResult(expected));

            // Execute
            var devicesController = new DevicesController(_logger, null, null, null, null, null);
            var response = devicesController.GetMfpFinisherAsync();
            var actual = ((ObjectResult)await devicesController.GetMfpFinisherAsync()).Value as MfpFinisherResult;

            // Validate
            Assert.Null(actual);
            Assert.Equal((int)HttpStatusCode.InternalServerError, ((ObjectResult)response.Result).StatusCode);
        }
        
        [Fact]
        public async Task GetEnvelopeModeStateAsync_WhenGettingDeviceInfoThrowsValid_ExpectSuccess()
        {
            // Prepare
            var expected = new Envelope
            {
                Mode = false
            };

            _deviceInfoOperatorMock.Setup(m => m.GetEnvelopeModeStateAsync()).ReturnsAsync(expected);

            // Execute
            var devicesController = new DevicesController(_logger, null, null, _deviceInfoOperatorMock.Object, null, null);
            var result = (ObjectResult)await devicesController.GetEnvelopeModeStateAsync();
            var actual = result.Value as EnvelopeResult;

            // Validate
            Assert.Equal(JsonConvert.SerializeObject(expected.Mode), JsonConvert.SerializeObject(actual.Mode));
            Assert.Equal((int)HttpStatusCode.OK, result.StatusCode);
            _deviceInfoOperatorMock.VerifyAll();
        }

        [Fact]
        public void GetEnvelopeModeStateAsync_WhenGettingDeviceInfoThrowsOpenApiRequestException_ExpectInternalServerError()
        {
            // Prepare
            _deviceInfoOperatorMock.Setup(m => m.GetEnvelopeModeStateAsync())
                .Throws(new OpenApiRequestException(OpenApiResultStatus.OtherError));

            // Execute
            var devicesController = new DevicesController(_logger, null, null, null, null, null);
            var response = devicesController.GetEnvelopeModeStateAsync();

            // Validate
            Assert.Equal((int)HttpStatusCode.InternalServerError, ((ObjectResult)response.Result).StatusCode);
        }

        [Fact]
        public void GetEnvelopeModeStateAsync_Expect_OpenApiNackException()
        {
            // Prepare
            _deviceInfoOperatorMock.Setup(m => m.GetEnvelopeModeStateAsync())
                .Throws(new OpenApiNackException(string.Empty,
                    new OpenApiMessage(string.Empty),
                    new OpenApiMessage(string.Empty)));

            // Execute
            var devicesController = new DevicesController(_logger, null, null, null, null, null);
            var response = devicesController.GetEnvelopeModeStateAsync();

            // Validate
            Assert.Equal((int)HttpStatusCode.InternalServerError, ((ObjectResult)response.Result).StatusCode);
        }

        [Fact]
        public void GetEnvelopeModeStateAsync_WhenGettingDeviceInfoThrowsXmlException_ExpectInternalServerError()
        {
            // Prepare
            _deviceInfoOperatorMock.Setup(m => m.GetEnvelopeModeStateAsync())
                .Throws(new XmlException());

            // Execute
            var devicesController = new DevicesController(_logger, null, null, null, null, null);
            var response = devicesController.GetEnvelopeModeStateAsync();

            // Validate
            Assert.Equal((int)HttpStatusCode.InternalServerError, ((ObjectResult)response.Result).StatusCode);
        }

        [Fact]
        public async Task GetEnvelopeModeStateAsync_WhenGettingDeviceInfoThrowsReturnEmptyResult_ExpectInternalServerError()
        {
            // Prepare
            var expected = new Envelope();

            _deviceInfoOperatorMock.Setup(m => m.GetEnvelopeModeStateAsync()).Returns(Task.FromResult(expected));

            // Execute
            var devicesController = new DevicesController(_logger, null, null, null, null, null);
            var response = devicesController.GetEnvelopeModeStateAsync();
            var actual = ((ObjectResult)await devicesController.GetEnvelopeModeStateAsync()).Value as EnvelopeResult;

            // Validate
            Assert.Null(actual);
            Assert.Equal((int)HttpStatusCode.InternalServerError, ((ObjectResult)response.Result).StatusCode);
        }
    }
}