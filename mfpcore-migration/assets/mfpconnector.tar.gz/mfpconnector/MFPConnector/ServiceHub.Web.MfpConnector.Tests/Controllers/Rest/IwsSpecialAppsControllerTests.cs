using System.IO;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Internal;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

using Moq;
using Newtonsoft.Json;
using ServiceHub.Connectors.IWS;
using ServiceHub.Processors.DeviceInfo;
using ServiceHub.Web.MfpConnector.Controllers.Rest.Iws;
using ServiceHub.Web.MfpConnector.Controllers.Rest.Model;
using Xunit;

namespace ServiceHub.Web.MfpConnector.Tests.Controllers.Rest
{
    [Trait("IwsSpecialAppsController", "Unit")]
    public class IwsSpecialAppsControllerTests : RestControllerTestsBase
    {
        private const string TestFileName1 = "testdata1.iws";
        private readonly byte[] _testData1 = System.Text.Encoding.ASCII.GetBytes("TEST_DATA_01");
        private readonly ILogger<IwsSpecialAppsController> _logger;

        public IwsSpecialAppsControllerTests()
        {
            _logger = Mock.Of<ILogger<IwsSpecialAppsController>>();
        }

        [Fact]
        public void Upload_WhenValidData_ExpectCreated()
        {
            var file = new FormFile(new MemoryStream(_testData1), 0, _testData1.Length, "specialapp", TestFileName1)
            {
                Headers = new HeaderDictionary(),
                ContentDisposition = "form-data"
            };

            var mockController = new Mock<IwsSpecialAppsController>(_logger, MfpConnectorSetting, null, null);
            var iwsSpecialAppsController = GetMockedController(mockController, false, false);
            var response = iwsSpecialAppsController.Upload(file);

            var result = (StatusCodeResult)response.Result; // TODO warning The return type is not always the same!

            Assert.Equal((int)HttpStatusCode.Created, result.StatusCode);
        }

        [Fact]
        public void Upload_WhenSaveFailed_ExpectInternalServerError()
        {
            var file = new FormFile(new MemoryStream(_testData1), 0, _testData1.Length, "specialapp", TestFileName1)
            {
                Headers = new HeaderDictionary()
            };

            var mockController = new Mock<IwsSpecialAppsController>(_logger, MfpConnectorSetting, null, null);
            var iwsSpecialAppsController = GetMockedController(mockController, true, false);
            var response = iwsSpecialAppsController.Upload(file);

            var result = (ObjectResult)response.Result;

            var expect = new IwsSpecialAppsControllerResult
            {
                ErrorCode = "File saving failed."
            };

            Assert.Equal(JsonConvert.SerializeObject(expect), JsonConvert.SerializeObject(result.Value));
            Assert.Equal((int)HttpStatusCode.InternalServerError, result.StatusCode);
        }

        [Fact]
        public void Upload_WhenNullFile_ExpectBadRequest()
        {
            var mockController = new Mock<IwsSpecialAppsController>(_logger, MfpConnectorSetting, null, null);
            var iwsSpecialAppsController = GetMockedController(mockController, false, false);
            var response = iwsSpecialAppsController.Upload(null);
            var result = (ObjectResult)response.Result;

            var expect = new IwsSpecialAppsControllerResult()
            {
                ErrorCode = "File not found or attached more than 1."
            };

            Assert.Equal(JsonConvert.SerializeObject(expect), JsonConvert.SerializeObject(result.Value));
            Assert.Equal((int)HttpStatusCode.BadRequest, result.StatusCode);
        }

        [Fact]
        public void Upload_WhenCodeInName_ExpectBadRequest()
        {
            var file = new FormFile(new MemoryStream(_testData1), 0, _testData1.Length, null, TestFileName1)
            {
                Headers = new HeaderDictionary()
            };

            var mockController = new Mock<IwsSpecialAppsController>(_logger, MfpConnectorSetting, null, null);
            var iwsSpecialAppsController = GetMockedController(mockController, false, false);
            var response = iwsSpecialAppsController.Upload(file);
            var result = (ObjectResult)response.Result;

            var expect = new IwsSpecialAppsControllerResult()
            {
                ErrorCode = "Attached file is not expected Content-Disposition name."
            };

            Assert.Equal(JsonConvert.SerializeObject(expect), JsonConvert.SerializeObject(result.Value));
            Assert.Equal((int)HttpStatusCode.BadRequest, result.StatusCode);
        }

        [Fact]
        public void Upload_WhenCodeInNameWithEmpty_ExpectBadRequest()
        {
            var file = new FormFile(new MemoryStream(_testData1), 0, _testData1.Length, string.Empty, TestFileName1)
            {
                Headers = new HeaderDictionary()
            };

            var mockController = new Mock<IwsSpecialAppsController>(_logger, MfpConnectorSetting, null, null);
            var iwsSpecialAppsController = GetMockedController(mockController, false, false);
            var response = iwsSpecialAppsController.Upload(file);
            var result = (ObjectResult)response.Result;


            var expect = new IwsSpecialAppsControllerResult()
            {
                ErrorCode = "Attached file is not expected Content-Disposition name."
            };

            Assert.Equal(JsonConvert.SerializeObject(expect), JsonConvert.SerializeObject(result.Value));
            Assert.Equal((int)HttpStatusCode.BadRequest, result.StatusCode);
        }

        [Fact]
        public void Upload_WhenCodeInNameWithWhitespace_ExpectBadRequest()
        {
            var file = new FormFile(new MemoryStream(_testData1), 0, _testData1.Length, " ", TestFileName1)
            {
                Headers = new HeaderDictionary()
            };

            var mockController = new Mock<IwsSpecialAppsController>(_logger, MfpConnectorSetting, null, null);
            var iwsSpecialAppsController = GetMockedController(mockController, false, false);
            var response = iwsSpecialAppsController.Upload(file);
            var result = (ObjectResult)response.Result;

            var expect = new IwsSpecialAppsControllerResult()
            {
                ErrorCode = "Attached file is not expected Content-Disposition name."
            };

            Assert.Equal(JsonConvert.SerializeObject(expect), JsonConvert.SerializeObject(result.Value));
            Assert.Equal((int)HttpStatusCode.BadRequest, result.StatusCode);
        }

        [Fact]
        public void Upload_WhenCodeInNameIsNewLine_ExpectBadRequest()
        {
            var file = new FormFile(new MemoryStream(_testData1), 0, _testData1.Length, "\n", TestFileName1)
            {
                Headers = new HeaderDictionary()
            };

            var mockController = new Mock<IwsSpecialAppsController>(_logger, MfpConnectorSetting, null, null);
            var iwsSpecialAppsController = GetMockedController(mockController, false, false);
            var response = iwsSpecialAppsController.Upload(file);
            var result = (ObjectResult)response.Result;

            var expect = new IwsSpecialAppsControllerResult()
            {
                ErrorCode = "Attached file is not expected Content-Disposition name."
            };

            Assert.Equal(JsonConvert.SerializeObject(expect), JsonConvert.SerializeObject(result.Value));
            Assert.Equal((int)HttpStatusCode.BadRequest, result.StatusCode);
        }

        [Fact]
        public void Upload_WhenCodeInNameIsASpecialCharacter_ExpectBadRequest()
        {
            var file = new FormFile(new MemoryStream(_testData1), 0, _testData1.Length, "①", TestFileName1)
            {
                Headers = new HeaderDictionary()
            };

            var mockController = new Mock<IwsSpecialAppsController>(_logger, MfpConnectorSetting, null, null);
            var iwsSpecialAppsController = GetMockedController(mockController, false, false);
            var response = iwsSpecialAppsController.Upload(file);
            var result = (ObjectResult)response.Result;

            var expect = new IwsSpecialAppsControllerResult
            {
                ErrorCode = "Attached file is not expected Content-Disposition name."
            };

            Assert.Equal(JsonConvert.SerializeObject(expect), JsonConvert.SerializeObject(result.Value));
            Assert.Equal((int)HttpStatusCode.BadRequest, result.StatusCode);
        }

        [Fact]
        public void Upload_WhenCodeInNameAsInvalidInputCode_ExpectBadRequest()
        {
            var file = new FormFile(new MemoryStream(_testData1), 0, _testData1.Length, "\\/:*?\"<>|", TestFileName1)
            {
                Headers = new HeaderDictionary()
            };

            var mockController = new Mock<IwsSpecialAppsController>(_logger, MfpConnectorSetting, null, null);
            var iwsSpecialAppsController = GetMockedController(mockController, false, false);
            var response = iwsSpecialAppsController.Upload(file);
            var result = (ObjectResult)response.Result;

            var expect = new IwsSpecialAppsControllerResult
            {
                ErrorCode = "Attached file is not expected Content-Disposition name."
            };

            Assert.Equal(JsonConvert.SerializeObject(expect), JsonConvert.SerializeObject(result.Value));
            Assert.Equal((int)HttpStatusCode.BadRequest, result.StatusCode);
        }

        [Fact]
        public void Upload_WhenCodeInFileNameIsNull_ExpectCreated() // Isn't wrong?
        {
            var file = new FormFile(new MemoryStream(_testData1), 0, _testData1.Length, "specialapp", null)
            {
                Headers = new HeaderDictionary()
            };

            var mockController = new Mock<IwsSpecialAppsController>(_logger, MfpConnectorSetting, null, null);
            var iwsSpecialAppsController = GetMockedController(mockController, false, false);
            var response = iwsSpecialAppsController.Upload(file);
            var result = (StatusCodeResult)response.Result;

            Assert.Equal((int)HttpStatusCode.Created, result.StatusCode);
        }

        [Fact]
        public void Upload_WhenCodeInFileNameIsEmpty_ExpectCreated() // Isn't wrong?
        {
            var file = new FormFile(new MemoryStream(_testData1), 0, _testData1.Length, "specialapp", "")
            {
                Headers = new HeaderDictionary()
            };

            var mockController = new Mock<IwsSpecialAppsController>(_logger, MfpConnectorSetting, null, null);
            var iwsSpecialAppsController = GetMockedController(mockController, false, false);
            var response = iwsSpecialAppsController.Upload(file);
            var result = (StatusCodeResult)response.Result;

            Assert.Equal((int)HttpStatusCode.Created, result.StatusCode);
        }

        [Fact]
        public void Upload_WhenCodeInFileNameAsWhitespace_ExpectCreated()
        {
            var file = new FormFile(new MemoryStream(_testData1), 0, _testData1.Length, "specialapp", " ")
            {
                Headers = new HeaderDictionary()
            };

            var mockController = new Mock<IwsSpecialAppsController>(_logger, MfpConnectorSetting, null, null);
            var iwsSpecialAppsController = GetMockedController(mockController, false, false);
            var response = iwsSpecialAppsController.Upload(file);
            var result = (StatusCodeResult)response.Result;

            Assert.Equal((int)HttpStatusCode.Created, result.StatusCode);
        }

        [Fact]
        public void Upload_WhenCodeInFileNameAsEscapeCode_ExpectCreated()
        {
            var file = new FormFile(new MemoryStream(_testData1), 0, _testData1.Length, "specialapp", "\n")
            {
                Headers = new HeaderDictionary()
            };

            var mockController = new Mock<IwsSpecialAppsController>(_logger, MfpConnectorSetting, null, null);
            var iwsSpecialAppsController = GetMockedController(mockController, false, false);
            var response = iwsSpecialAppsController.Upload(file);
            var result = (StatusCodeResult)response.Result;

            Assert.Equal((int)HttpStatusCode.Created, result.StatusCode);
        }

        [Fact]
        public void Upload_WhenCodeInFileNameAsUnicodeCharacters_ExpectCreated()
        {
            var file = new FormFile(new MemoryStream(_testData1), 0, _testData1.Length, "specialapp", "①")
            {
                Headers = new HeaderDictionary()
            };

            var mockController = new Mock<IwsSpecialAppsController>(_logger, MfpConnectorSetting, null, null);
            var iwsSpecialAppsController = GetMockedController(mockController, false, false);
            var response = iwsSpecialAppsController.Upload(file);
            var result = (StatusCodeResult)response.Result;

            Assert.Equal((int)HttpStatusCode.Created, result.StatusCode);
        }

        [Fact]
        public void Upload_WhenCodeInFileNameAsInvalidInputCode_ExpectCreated()
        {
            var file = new FormFile(new MemoryStream(_testData1), 0, _testData1.Length, "specialapp", "\\/:*?\"<>|")
            {
                Headers = new HeaderDictionary()
            };

            var mockController = new Mock<IwsSpecialAppsController>(_logger, MfpConnectorSetting, null, null);
            var iwsSpecialAppsController = GetMockedController(mockController, false, false);
            var response = iwsSpecialAppsController.Upload(file);
            var result = (StatusCodeResult)response.Result;

            Assert.Equal((int)HttpStatusCode.Created, result.StatusCode);
        }

        [Fact]
        public void Install_WhenInstallOk_ExpectCreated()
        {
            // Prepare
            var deviceInfoOperatorMock = new Mock<IDeviceInfoOperator>(MockBehavior.Strict);
            deviceInfoOperatorMock.Setup(m => m.GetSerialNumberAsync()).ReturnsAsync("A798001000003");

            var iwsConnectorAdminMock = new Mock<IIwsConnectorAdmin>(MockBehavior.Strict);
            iwsConnectorAdminMock.Setup(m => m.InstallSpecialAppAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
                .Returns(Task.Run(() => { }));

            // Execute
            var mockController = new Mock<IwsSpecialAppsController>(_logger, MfpConnectorSetting, iwsConnectorAdminMock.Object, deviceInfoOperatorMock.Object);
            var iwsSpecialAppsController = GetMockedController(mockController, false, false);
            var resp = iwsSpecialAppsController.Install();

            // Validate
            Assert.Equal((int)HttpStatusCode.Created, ((StatusCodeResult)resp.Result).StatusCode);
            iwsConnectorAdminMock.VerifyAll();
            deviceInfoOperatorMock.VerifyAll();
        }

        [Fact]
        public void Install_WhenOkButRaiseErrorDelete_ExpectCreated()
        {
            // Prepepare
            var deviceInfoOperatorMock = new Mock<IDeviceInfoOperator>(MockBehavior.Strict);
            deviceInfoOperatorMock.Setup(m => m.GetSerialNumberAsync()).ReturnsAsync("A798001000003");

            var iwsConnectorAdminMock = new Mock<IIwsConnectorAdmin>(MockBehavior.Strict);
            iwsConnectorAdminMock.Setup(m => m.InstallSpecialAppAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
                .Returns(Task.Run(() => { }));

            // Execute
            var mockController = new Mock<IwsSpecialAppsController>(_logger, MfpConnectorSetting, iwsConnectorAdminMock.Object, deviceInfoOperatorMock.Object);
            var iwsSpecialAppsController = GetMockedController(mockController, false, true);
            var resp = iwsSpecialAppsController.Install();

            // Validate
            Assert.Equal((int)HttpStatusCode.Created, ((StatusCodeResult)resp.Result).StatusCode);
            iwsConnectorAdminMock.VerifyAll();
            deviceInfoOperatorMock.VerifyAll();
        }

        [Fact]
        public async Task Install_WhenGetSerialFail_ExpectInternalServerError()
        {
            // Prepare
            var deviceInfoOperatorMock = new Mock<IDeviceInfoOperator>(MockBehavior.Strict);
            deviceInfoOperatorMock.Setup(m => m.GetSerialNumberAsync()).ReturnsAsync((string)null);

            // Execute
            var mockController = new Mock<IwsSpecialAppsController>(_logger, MfpConnectorSetting, null, deviceInfoOperatorMock.Object);
            var iwsSpecialAppsController = GetMockedController(mockController, false, false);

            var resp = iwsSpecialAppsController.Install();
            var result = (ObjectResult)await resp;

            // Validate
            var expect = new IwsSpecialAppsControllerResult()
            {
                ErrorCode = "serialNumber is null."
            };

            Assert.Equal(JsonConvert.SerializeObject(expect), JsonConvert.SerializeObject(result.Value));
            Assert.Equal((int)HttpStatusCode.InternalServerError, result.StatusCode);
            deviceInfoOperatorMock.VerifyAll();
        }

        [Fact]
        public async Task Install_WhenIwsConnectorAdminReturnIwsException_ExpectInternalServerError()
        {
            // Prepare
            var deviceInfoOperatorMock = new Mock<IDeviceInfoOperator>(MockBehavior.Strict);
            deviceInfoOperatorMock.Setup(m => m.GetSerialNumberAsync()).ReturnsAsync("A798001000003");

            var iwsConnectorAdmin = new Mock<IIwsConnectorAdmin>(MockBehavior.Strict);
            iwsConnectorAdmin.Setup(m => m.InstallSpecialAppAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
                .Throws(new IwsException("InstallSpecialApp", IwsResultCode.RequestError, 8202));

            // Execute
            var iwsSpecialAppsController = new IwsSpecialAppsController(_logger, MfpConnectorSetting, iwsConnectorAdmin.Object, deviceInfoOperatorMock.Object);
            var resp = iwsSpecialAppsController.Install();
            var result = (ObjectResult)await resp;

            // Validate
            Assert.Equal((int)HttpStatusCode.InternalServerError, result.StatusCode);
            iwsConnectorAdmin.VerifyAll();
            deviceInfoOperatorMock.VerifyAll();
        }

        [Fact]
        public async Task Install_WhenIwsConnectorAdminReturnIwsException_ExpectServiceUnavailable()
        {
            // Prepare
            var deviceInfoOperatorMock = new Mock<IDeviceInfoOperator>(MockBehavior.Strict);
            deviceInfoOperatorMock.Setup(m => m.GetSerialNumberAsync()).ReturnsAsync("A798001000003");

            var iwsConnectorAdmin = new Mock<IIwsConnectorAdmin>(MockBehavior.Strict);
            iwsConnectorAdmin.Setup(m => m.InstallSpecialAppAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
                .Throws(new IwsException(string.Format(IwsException.NetworkErrMsg, (int)HttpStatusCode.ServiceUnavailable)));

            // Execute
            var iwsSpecialAppsController = new IwsSpecialAppsController(_logger, MfpConnectorSetting, iwsConnectorAdmin.Object, deviceInfoOperatorMock.Object);
            var result = (ObjectResult)await iwsSpecialAppsController.Install();

            // Validate
            Assert.Equal((int)HttpStatusCode.ServiceUnavailable, result.StatusCode);
            var expect = new IwsSpecialAppsControllerResult
            {
                ErrorCode = string.Format(IwsException.NetworkErrMsg, (int)HttpStatusCode.ServiceUnavailable)
            };
            Assert.Equal(JsonConvert.SerializeObject(expect), JsonConvert.SerializeObject(result.Value));
            iwsConnectorAdmin.VerifyAll();
            deviceInfoOperatorMock.VerifyAll();
        }

        private IwsSpecialAppsController GetMockedController(Mock<IwsSpecialAppsController> mockController, bool raiseErrorSaveFile, bool raiseErrorDeleteFile)
        {
            mockController.CallBase = true;

            if (raiseErrorSaveFile)
            {
                mockController.Setup(m => m.SaveFileAsync(It.IsAny<Stream>(), It.IsAny<string>()))
                    .Throws(new IOException());
            }
            else
            {
                mockController.Setup(m => m.SaveFileAsync(It.IsAny<Stream>(), It.IsAny<string>()))
                    .Returns(Task.Run(() => { }));
            }

            if (raiseErrorDeleteFile)
            {
                mockController.Setup(m => m.DeleteFile(It.IsAny<string>()))
                    .Throws(new IOException());
            }
            else
            {
                mockController.Setup(m => m.DeleteFile(It.IsAny<string>()))
                    .Verifiable();
            }

            return mockController.Object;
        }
    }
}
