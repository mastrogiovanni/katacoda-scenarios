using System;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

using Moq;
using Newtonsoft.Json;
using ServiceHub.Common.Settings;
using ServiceHub.Connectors.IWS;
using ServiceHub.Processors.Common;
using ServiceHub.Processors.Power;
using ServiceHub.Processors.Scan.Model;
using ServiceHub.Web.MfpConnector.Controllers.Rest;
using ServiceHub.Web.MfpConnector.Controllers.Rest.Jobs;
using ServiceHub.Web.MfpConnector.Controllers.Rest.Model;
using Xunit;

namespace ServiceHub.Web.MfpConnector.Tests.Controllers.Rest
{
    [Trait("ScanController", "Unit")]
    public class ScanControllerTests : RestControllerTestsBase
    {
        private readonly ScanServiceSetting _requestNormal = new ScanServiceSetting
        {
            FileType = ScanFileType.JPEG,
            FileName = "sample_file",
            ScanSide = ScanSide.SIMPLEX,
            Resolution = "200X200",
            WebdavSettings = new WebDavSetting
            {
                Host = "172.16.188.6",
                Port = 8080,
                Dir = "12345678",
                User = "mfpservice",
                Password = "mfpservice"
            },
            Color = new ScanColor
            {
                Mode = ScanColorMode.AUTO
            }
        };

        private readonly ILogger<ScanController> _logger;
        private Mock<IMfpSender<ScanServiceSetting, ScanServiceResult>> _mockMfpSender;
        private Mock<IPowerOperator> _mockPowerOperator;

        public ScanControllerTests()
        {
            _logger = Mock.Of<ILogger<ScanController>>();
            _mockMfpSender = new Mock<IMfpSender<ScanServiceSetting, ScanServiceResult>>(MockBehavior.Strict);
            _mockPowerOperator = new Mock<IPowerOperator>(MockBehavior.Strict);
        }

        [Fact]
        public async Task Scan_WhenValidData_ExpectCreatedOk()
        {
            // Prepare
            var scanResult = new ScanServiceResult
            {
                JobId = 123,
                Result = "OK"
            };
            _mockMfpSender.Setup(m => m.SendToMfpAsync(It.IsAny<ScanServiceSetting>())).ReturnsAsync(scanResult);
            _mockPowerOperator.Setup(m => m.WakeUpToMfpAsync(It.IsAny<bool>())).ReturnsAsync(true);

            // Execute
            var scanController = new ScanController(_logger, null, _mockPowerOperator.Object, _mockMfpSender.Object);
            var response = (ObjectResult)await scanController.Scan(_requestNormal);

            // Validate
            var expected = new ScanControllerResult
            {
                Result = scanResult.Result,
                JobId = scanResult.JobId,
                Error = scanResult.Error
            };

            Assert.Equal((int)HttpStatusCode.Created, response.StatusCode);
            Assert.Equal(JsonConvert.SerializeObject(expected), JsonConvert.SerializeObject(response.Value));
            _mockMfpSender.VerifyAll();
            _mockPowerOperator.VerifyAll();
        }

        [Fact]
        public async Task Scan_WhenNullData_ExpectBadRequestWithNG()
        {
            // Execute
            var scanController = new ScanController(_logger, null, null, null);
            var response = (ObjectResult)await scanController.Scan(null);

            // Validate
            Assert.Equal((int)HttpStatusCode.BadRequest, response.StatusCode);
            Assert.Equal("NG", ((ScanControllerResult)response.Value).Result);
        }

        [Fact]
        public async Task Scan_WhenErrorWhileSendingToMfp_ExpectInternalServerError()
        {
            var ex = new Exception("dummy Exception");
            _mockMfpSender.Setup(m => m.SendToMfpAsync(It.IsAny<ScanServiceSetting>())).Throws(ex);
            _mockPowerOperator.Setup(m => m.WakeUpToMfpAsync(It.IsAny<bool>())).ReturnsAsync(true);

            var scanController = new ScanController(_logger, null, _mockPowerOperator.Object, _mockMfpSender.Object);
            var response = (ObjectResult)await scanController.Scan(_requestNormal);

            Assert.Equal((int)HttpStatusCode.InternalServerError, response.StatusCode);
            Assert.Contains(ex.Message, JsonConvert.SerializeObject(response.Value));
            _mockMfpSender.VerifyAll();
            _mockPowerOperator.VerifyAll();
        }

        [Fact]
        public async Task Scan_WhenFalseWakeUpToMfpAsync_ExpectInternalServerError()
        {
            // Prepare
            _mockPowerOperator.Setup(m => m.WakeUpToMfpAsync(It.IsAny<bool>())).ReturnsAsync(false);

            // Execute
            var scanController = new ScanController(_logger, null, _mockPowerOperator.Object, null);
            var response = (ObjectResult)await scanController.Scan(_requestNormal);

            // Validate
            var expected = new ScanControllerResult
            {
                JobId = null,
                Result = "NG",
                Error = "MFP wake up failed."
            };
            Assert.Equal((int)HttpStatusCode.InternalServerError, response.StatusCode);
            Assert.Equal(JsonConvert.SerializeObject(expected), JsonConvert.SerializeObject(response.Value));
            _mockPowerOperator.VerifyAll();
        }

        [Fact]
        public async Task Post_WhenNetworkError500_ExpectInternalServerError()
        {
            // Prepare
            var scanResult = new ScanServiceResult
            {
                JobId = null,
                Result = "NG",
                Error = "Fatal"
            };

            _mockMfpSender.Setup(m => m.SendToMfpAsync(It.IsAny<ScanServiceSetting>())).ReturnsAsync(scanResult);
            _mockPowerOperator.Setup(m => m.WakeUpToMfpAsync(It.IsAny<bool>())).ReturnsAsync(true);

            // Execute
            var scanController = new ScanController(_logger, null, _mockPowerOperator.Object, _mockMfpSender.Object);
            var response = (ObjectResult)await scanController.Scan(_requestNormal);

            // Validate
            var expected = new ScanControllerResult
            {
                Result = scanResult.Result,
                JobId = scanResult.JobId,
                Error = scanResult.Error
            };

            Assert.Equal((int)HttpStatusCode.InternalServerError, response.StatusCode);
            Assert.Equal(JsonConvert.SerializeObject(expected), JsonConvert.SerializeObject(response.Value));
            _mockMfpSender.VerifyAll();
            _mockPowerOperator.VerifyAll();
        }

        [Fact]
        public async Task Post_WhenIwsExceptionNetworkError503_ExpectServiceUnavailableMessage()
        {
            // Prepare
            var ex = new IwsException(string.Format(IwsException.NetworkErrMsg, (int)HttpStatusCode.ServiceUnavailable));
            var scanResult = new ScanServiceResult
            {
                JobId = null,
                Result = "NG",
                Error = "NetworkError[503]"
            };
            _mockMfpSender.Setup(m => m.SendToMfpAsync(It.IsAny<ScanServiceSetting>())).ThrowsAsync(ex);
            _mockPowerOperator.Setup(m => m.WakeUpToMfpAsync(It.IsAny<bool>())).ReturnsAsync(true);

            // Execute
            var scanController = new ScanController(_logger, null, _mockPowerOperator.Object, _mockMfpSender.Object);
            var response = (ObjectResult)await scanController.Scan(_requestNormal);

            // Validate
            var expected = new ScanControllerResult
            {
                Result = scanResult.Result,
                JobId = scanResult.JobId,
                Error = "Fatal"
            };

            Assert.Equal((int)HttpStatusCode.ServiceUnavailable, response.StatusCode);
            Assert.Equal(JsonConvert.SerializeObject(expected), JsonConvert.SerializeObject(response.Value));
            _mockMfpSender.VerifyAll();
            _mockPowerOperator.VerifyAll();
        }

        [Fact]
        public async Task Post_WhenNetworkError503_ExpectServiceUnavailableMessage()
        {
            // Prepare
            var scanResult = new ScanServiceResult
            {
                JobId = null,
                Result = "NG",
                Error = "NetworkError[503]"
            };

            _mockMfpSender.Setup(m => m.SendToMfpAsync(It.IsAny<ScanServiceSetting>())).ReturnsAsync(scanResult);
            _mockPowerOperator.Setup(m => m.WakeUpToMfpAsync(It.IsAny<bool>())).ReturnsAsync(true);

            // Execute
            var scanController = new ScanController(_logger, null, _mockPowerOperator.Object, _mockMfpSender.Object);
            var response = (ObjectResult)await scanController.Scan(_requestNormal);

            // Validate
            var expected = new ScanControllerResult
            {
                Result = scanResult.Result,
                JobId = scanResult.JobId,
                Error = "Fatal"
            };

            Assert.Equal((int)HttpStatusCode.ServiceUnavailable, response.StatusCode);
            Assert.Equal(JsonConvert.SerializeObject(expected), JsonConvert.SerializeObject(response.Value));
            _mockMfpSender.VerifyAll();
            _mockPowerOperator.VerifyAll();
        }

        [Fact]
        public async Task Post_WhenIwsExceptionNetworkErrorOtherThen503_ExpectInternalServerErrorMessage()
        {
            // Prepare
            var ex = new IwsException(string.Format(IwsException.NetworkErrMsg, 504));
            var scanResult = new ScanServiceResult
            {
                JobId = null,
                Result = "NG",
                Error = "Fatal"
            };
            _mockMfpSender.Setup(m => m.SendToMfpAsync(It.IsAny<ScanServiceSetting>())).ThrowsAsync(ex);
            _mockPowerOperator.Setup(m => m.WakeUpToMfpAsync(It.IsAny<bool>())).ReturnsAsync(true);

            // Execute
            var scanController = new ScanController(_logger, null, _mockPowerOperator.Object, _mockMfpSender.Object);
            var response = (ObjectResult)await scanController.Scan(_requestNormal);

            // Validate
            var expected = new ScanControllerResult
            {
                Result = scanResult.Result,
                JobId = scanResult.JobId,
                Error = scanResult.Error
            };

            Assert.Equal((int)HttpStatusCode.InternalServerError, response.StatusCode);
            Assert.Equal(JsonConvert.SerializeObject(expected), JsonConvert.SerializeObject(response.Value));
            _mockMfpSender.VerifyAll();
            _mockPowerOperator.VerifyAll();
        }
    }
}