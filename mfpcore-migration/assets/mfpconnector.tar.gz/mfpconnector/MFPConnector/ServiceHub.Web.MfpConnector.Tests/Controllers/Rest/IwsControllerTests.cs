using System;
using System.IO;
using System.Net;
using System.Threading.Tasks;

using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

using Moq;
using Newtonsoft.Json;

using ServiceHub.Common.Model;
using ServiceHub.Connectors.IWS;
using ServiceHub.Processors.Common;
using ServiceHub.Processors.Copy.Model;
using ServiceHub.Processors.Iws.Model;
using ServiceHub.Processors.Power;
using ServiceHub.Web.MfpConnector.Controllers.Rest.Iws;
using ServiceHub.Web.MfpConnector.Controllers.Rest.Model;
using Xunit;

namespace ServiceHub.Web.MfpConnector.Tests.Controllers.Rest
{
    [Trait("IwsController", "Unit")]
    public class IwsControllerTests
    {
        private const string JSON_SAMPLE_JOB_SETTINGS = @"{ \""density\"": 0 , \""num_of_set\"": 3 }";
        private readonly Mock<IMfpSender<IwsServiceSetting, IwsServiceResult>> _senderMock;
        private readonly Mock<IPowerOperator> _powerMock;
        private readonly ILogger<IwsController> _logger;

        public IwsControllerTests()
        {
            _logger = Mock.Of<ILogger<IwsController>>();
            _senderMock = new Mock<IMfpSender<IwsServiceSetting, IwsServiceResult>>(MockBehavior.Strict);
            _powerMock = new Mock<IPowerOperator>(MockBehavior.Strict);
        }

        [Fact]
        public async Task ExecuteJob_WhenIwsExceptionNetworkError503_ExpectServiceUnavailableMessage()
        {
            // Prepare
            var ex = new IwsException(string.Format(IwsException.NetworkErrMsg, (int)HttpStatusCode.ServiceUnavailable));
            var stream = new MemoryStream(System.Text.Encoding.UTF8.GetBytes(JSON_SAMPLE_JOB_SETTINGS));
            var httpContext = new DefaultHttpContext();
            httpContext.Request.Body = stream;
            httpContext.Request.ContentLength = stream.Length;

            var controllerContext = new ControllerContext()
            {
                HttpContext = httpContext,
            };
            var expectedResult = new IwsServiceResult { Result = "NG",JobId = null, Error = "NetworkError[503]" };
            var iwsControllerResult = new IwsControllerResult
            {
                Result = expectedResult.Result,
                JobId = expectedResult.JobId,
                Error = "Fatal"
            };

            _powerMock.Setup(m => m.WakeUpToMfpAsync(It.IsAny<bool>())).ReturnsAsync(true);
            _senderMock.Setup(m => m.SendToMfpAsync(It.IsAny<IwsServiceSetting>())).ThrowsAsync(ex);

            // Execute
            var sender = new IwsController(_logger, null, _powerMock.Object, _senderMock.Object)
            {
                ControllerContext = controllerContext
            };
            var response = sender.ExecuteJob("AuthCode");
            var result = (ObjectResult)await response;

            // Validate
            Assert.Equal((int)HttpStatusCode.ServiceUnavailable, result.StatusCode);
            Assert.Equal(JsonConvert.SerializeObject(iwsControllerResult), JsonConvert.SerializeObject(result.Value));
            _senderMock.VerifyAll();
            _powerMock.VerifyAll();
        }

        [Fact]
        public async Task ExecuteJob_WhenNetworkError503_ExpectServiceUnavailableMessage()
        {
            // Prepare
            var stream = new MemoryStream(System.Text.Encoding.UTF8.GetBytes(JSON_SAMPLE_JOB_SETTINGS));
            var httpContext = new DefaultHttpContext();
            httpContext.Request.Body = stream;
            httpContext.Request.ContentLength = stream.Length;

            var controllerContext = new ControllerContext()
            {
                HttpContext = httpContext,
            };
            var expectedResult = new IwsServiceResult { Result = "NG", JobId = null, Error = "NetworkError[503]" };

            _powerMock.Setup(m => m.WakeUpToMfpAsync(It.IsAny<bool>())).ReturnsAsync(true);
            _senderMock.Setup(m => m.SendToMfpAsync(It.IsAny<IwsServiceSetting>())).ReturnsAsync(expectedResult);

            // Execute
            var sender = new IwsController(_logger, null, _powerMock.Object, _senderMock.Object)
            {
                ControllerContext = controllerContext
            };
            var response = sender.ExecuteJob("AuthCode");
            var result = (ObjectResult)await response;

            var iwsControllerResult = new IwsControllerResult
            {
                Result = expectedResult.Result,
                JobId = expectedResult.JobId,
                Error = "Fatal"
            };

            // Validate
            Assert.Equal((int)HttpStatusCode.ServiceUnavailable, result.StatusCode);
            Assert.Equal(JsonConvert.SerializeObject(iwsControllerResult), JsonConvert.SerializeObject(result.Value));
            _senderMock.VerifyAll();
            _powerMock.VerifyAll();
        }

        [Fact]
        public async Task ExecuteJob_WhenIwsExceptionNetworkErrorOtherThen503_ExpectInternalServerErrorMessage()
        {
            // Prepare
            var ex = new IwsException(string.Format(IwsException.NetworkErrMsg, 504));
            var stream = new MemoryStream(System.Text.Encoding.UTF8.GetBytes(JSON_SAMPLE_JOB_SETTINGS));
            var httpContext = new DefaultHttpContext();
            httpContext.Request.Body = stream;
            httpContext.Request.ContentLength = stream.Length;

            var controllerContext = new ControllerContext()
            {
                HttpContext = httpContext,
            };
            var expectedResult = new IwsServiceResult { Result = "NG", JobId = null, Error = "Fatal" };
            var iwsControllerResult = new IwsControllerResult
            {
                Result = expectedResult.Result,
                JobId = expectedResult.JobId,
                Error = expectedResult.Error
            };

            _powerMock.Setup(m => m.WakeUpToMfpAsync(It.IsAny<bool>())).ReturnsAsync(true);
            _senderMock.Setup(m => m.SendToMfpAsync(It.IsAny<IwsServiceSetting>())).ThrowsAsync(ex);

            // Execute
            var sender = new IwsController(_logger, null, _powerMock.Object, _senderMock.Object)
            {
                ControllerContext = controllerContext
            };
            var response = sender.ExecuteJob("AuthCode");
            var result = (ObjectResult)await response;

            // Validate
            Assert.Equal((int)HttpStatusCode.InternalServerError, result.StatusCode);
            Assert.Equal(JsonConvert.SerializeObject(iwsControllerResult), JsonConvert.SerializeObject(result.Value));
            _senderMock.VerifyAll();
            _powerMock.VerifyAll();
        }

        [Fact]
        public async Task Post_WhenFalseWakeUpToMfpAsync_ExpectInternalServerErrorMessage()
        {
            // Prepare
            var stream = new MemoryStream(System.Text.Encoding.UTF8.GetBytes(JSON_SAMPLE_JOB_SETTINGS));
            var httpContext = new DefaultHttpContext();
            httpContext.Request.Body = stream;
            httpContext.Request.ContentLength = stream.Length;

            var controllerContext = new ControllerContext()
            {
                HttpContext = httpContext,
            };
            var expectedResult = new IwsServiceResult { Result = "NG", JobId = null, Error = "MFP wake up failed." };
            
            _powerMock.Setup(m => m.WakeUpToMfpAsync(It.IsAny<bool>())).ReturnsAsync(false);

            // Execute
            var sender = new IwsController(_logger, null, _powerMock.Object, _senderMock.Object)
            {
                ControllerContext = controllerContext
            };
            var response = sender.ExecuteJob("AuthCode");
            var result = (ObjectResult)await response;

            // Validate
            var iwsControllerResult = new IwsControllerResult
            {
                Result = expectedResult.Result,
                JobId = expectedResult.JobId,
                Error = expectedResult.Error
            };
            Assert.Equal((int)HttpStatusCode.InternalServerError, result.StatusCode);
            Assert.Equal(JsonConvert.SerializeObject(iwsControllerResult), JsonConvert.SerializeObject(result.Value));
            _powerMock.VerifyAll();
        }

        [Fact]
        public async Task Post_WhenNetworkError500_ExpectInternalServerErrorMessage()
        {
            // Prepare
            // Prepare
            var stream = new MemoryStream(System.Text.Encoding.UTF8.GetBytes(JSON_SAMPLE_JOB_SETTINGS));
            var httpContext = new DefaultHttpContext();
            httpContext.Request.Body = stream;
            httpContext.Request.ContentLength = stream.Length;

            var controllerContext = new ControllerContext()
            {
                HttpContext = httpContext,
            };
            var expectedResult = new IwsServiceResult { Result = "NG", JobId = null, Error = "Fatal" };

            _senderMock.Setup(m => m.SendToMfpAsync(It.IsAny<IwsServiceSetting>())).ReturnsAsync(expectedResult);
            _powerMock.Setup(m => m.WakeUpToMfpAsync(It.IsAny<bool>())).ReturnsAsync(true);

            // Execute
            var sender = new IwsController(_logger, null, _powerMock.Object, _senderMock.Object)
            {
                ControllerContext = controllerContext
            };
            var response = sender.ExecuteJob("AuthCode");
            var result = (ObjectResult)await response;

            // Validate
            var iwsControllerResult = new IwsControllerResult
            {
                Result = expectedResult.Result,
                JobId = expectedResult.JobId,
                Error = expectedResult.Error
            };

            Assert.Equal((int)HttpStatusCode.InternalServerError, result.StatusCode);
            Assert.Equal(JsonConvert.SerializeObject(iwsControllerResult), JsonConvert.SerializeObject(result.Value));
            _senderMock.VerifyAll();
            _powerMock.VerifyAll();
        }

        [Fact]
        public async Task ExecuteJob_WhenValidCall_ExpectCreated()
        {
            // Prepare
            var stream = new MemoryStream(System.Text.Encoding.UTF8.GetBytes(JSON_SAMPLE_JOB_SETTINGS));
            var httpContext = new DefaultHttpContext();
            httpContext.Request.Body = stream;
            httpContext.Request.ContentLength = stream.Length;

            var controllerContext = new ControllerContext()
            {
                HttpContext = httpContext,
            };
            var expectedResult = new IwsServiceResult { Result = "OK", JobId = 123, Error = null };
            var iwsControllerResult = new IwsControllerResult
            {
                Result = expectedResult.Result,
                JobId = expectedResult.JobId,
                Error = expectedResult.Error
            };

            _powerMock.Setup(m => m.WakeUpToMfpAsync(It.IsAny<bool>())).ReturnsAsync(true);
            _senderMock.Setup(m => m.SendToMfpAsync(It.IsAny<IwsServiceSetting>())).ReturnsAsync(expectedResult);

            // Execute
            var sender = new IwsController(_logger, null, _powerMock.Object, _senderMock.Object)
            {
                ControllerContext = controllerContext
            };
            var response = sender.ExecuteJob("AuthCode");
            var result = (ObjectResult)await response;

            // Validate
            Assert.Equal((int)HttpStatusCode.Created, result.StatusCode);
            Assert.Equal(JsonConvert.SerializeObject(iwsControllerResult), JsonConvert.SerializeObject(result.Value));
            _senderMock.VerifyAll();
            _powerMock.VerifyAll();
        }

        [Fact]
        public async Task ExecuteJob_WhenIwsException_ExpectInternalServerErrorMesseage()
        {
            // Prepare
            var stream = new MemoryStream(System.Text.Encoding.UTF8.GetBytes(JSON_SAMPLE_JOB_SETTINGS));
            var httpContext = new DefaultHttpContext();
            httpContext.Request.Body = stream;
            httpContext.Request.ContentLength = stream.Length;

            var controllerContext = new ControllerContext()
            {
                HttpContext = httpContext,
            };
            var expectedResult = new IwsServiceResult { Result = "NG", JobId = null, Error = "NetworkError[500]" };
            var iwsControllerResult = new IwsControllerResult
            {
                Result = expectedResult.Result,
                JobId = expectedResult.JobId,
                Error = expectedResult.Error
            };

            _powerMock.Setup(m => m.WakeUpToMfpAsync(It.IsAny<bool>())).ReturnsAsync(true);
            _senderMock.Setup(m => m.SendToMfpAsync(It.IsAny<IwsServiceSetting>())).ReturnsAsync(expectedResult);

            // Execute
            var sender = new IwsController(_logger, null, _powerMock.Object, _senderMock.Object)
            {
                ControllerContext = controllerContext
            };
            var response = sender.ExecuteJob("AuthCode");
            var result = (ObjectResult)await response;

            // Validate
            Assert.Equal((int)HttpStatusCode.InternalServerError, result.StatusCode);
            Assert.Equal(JsonConvert.SerializeObject(iwsControllerResult), JsonConvert.SerializeObject(result.Value));
            _senderMock.VerifyAll();
            _powerMock.VerifyAll();
        }

        [Fact]
        public async Task ExecuteJob_WhenException_ExpectInternalServerErrorMesseage()
        {
            // Prepare
            var ex = new Exception("dummy Exception");
            
            var stream = new MemoryStream(System.Text.Encoding.UTF8.GetBytes(JSON_SAMPLE_JOB_SETTINGS));
            var httpContext = new DefaultHttpContext();
            httpContext.Request.Body = stream;
            httpContext.Request.ContentLength = stream.Length;

            var controllerContext = new ControllerContext()
            {
                HttpContext = httpContext,
            };

            _powerMock.Setup(m => m.WakeUpToMfpAsync(It.IsAny<bool>())).ReturnsAsync(true);
            _senderMock.Setup(m => m.SendToMfpAsync(It.IsAny<IwsServiceSetting>())).ThrowsAsync(ex);

            // Execute
            var sender = new IwsController(_logger, null, _powerMock.Object, _senderMock.Object)
            {
                ControllerContext = controllerContext
            };
            var response = sender.ExecuteJob("AuthCode");
            var result = (ObjectResult)await response;

            // Validate
            Assert.Equal((int)HttpStatusCode.InternalServerError, result.StatusCode);
            Assert.Equal(new ExceptionMessage(ex).ToString(), ((IwsControllerResult)result.Value).Error);
            _senderMock.VerifyAll();
            _powerMock.VerifyAll();
        }

        [Fact]
        public async Task ExecuteJob_WhenBadSettings_ExpectBadRequest()
        {
            // Prepare

            // Execute
            var sender = new IwsController(_logger, null, null, null);
            var response = sender.ExecuteJob("AuthCode");
            var result = (ObjectResult)await response;

            // Validate
            Assert.Equal((int)HttpStatusCode.BadRequest, result.StatusCode);
            _senderMock.VerifyAll();
            _powerMock.VerifyAll();
        }
    }
}