using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

using Moq;
using Newtonsoft.Json;
using ServiceHub.Processors.Notify;
using ServiceHub.Processors.Notify.Model;
using ServiceHub.Web.MfpConnector.Controllers.Rest;
using Xunit;

namespace ServiceHub.Web.MfpConnector.Tests.Controllers.Rest
{
    [Trait("PartsController", "Unit")]
    public class PartsControllerTests : RestControllerTestsBase
    {
        [Fact]
        public async Task Get_WhenNormalBehavior_ExpectSuccess()
        {
            // Prepare
            var mockService = new Mock<INotifySetter>(MockBehavior.Strict);
            var expected = @"[{""type"": ""Adf"",""open"": true,""paper_exist"": false,""free_tray_info_list"":null},{""type"": ""Platen"",""open"": false,""paper_exist"": true,""free_tray_info_list"":null}]";
            mockService.Setup(m => m.GetDevicePartsStatusAsync())
                .ReturnsAsync(JsonConvert.DeserializeObject<List<NotifyDevicePartsStatus>>(expected));

            // Execute
            var partsController = new PartsController(null, mockService.Object);
            var response = (ObjectResult)await partsController.Get();

            // Validate
            Assert.Equal((int)HttpStatusCode.OK, response.StatusCode);
            TestHelper.AreJsonEquals(expected, JsonConvert.SerializeObject(response.Value));
            mockService.VerifyAll();
        }

        [Fact]
        public async Task Get_WhenEmptyResult_ExpectNoContent()
        {
            // Prepare
            var expected = string.Empty;
            var mockService = new Mock<INotifySetter>(MockBehavior.Strict);
            mockService.Setup(m => m.GetDevicePartsStatusAsync())
                .ReturnsAsync(JsonConvert.DeserializeObject<List<NotifyDevicePartsStatus>>(expected));

            // Execute
            var partsController = new PartsController(null, mockService.Object);
            var response = (NoContentResult)await partsController.Get();

            // Validate
            Assert.Equal((int)HttpStatusCode.NoContent, response.StatusCode);
            mockService.VerifyAll();
        }

        [Fact]
        public async Task Get_WhenNotifySetterThrows_ExpectInternalServerError()
        {
            // Prepare
            var mockService = new Mock<INotifySetter>(MockBehavior.Strict);
            mockService.Setup(m => m.GetDevicePartsStatusAsync()).Throws(new System.Exception("dummy exception"));

            // Execute
            var partsController = new PartsController(null, mockService.Object);
            var response = (ObjectResult)await partsController.Get();

            Assert.Equal((int)HttpStatusCode.InternalServerError, response.StatusCode);
            mockService.VerifyAll();
        }
    }
}