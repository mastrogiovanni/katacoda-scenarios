using System.Collections.Generic;
using Microsoft.Extensions.Logging;
using ServiceHub.Common.Settings;
using ServiceHub.Common.Settings.Ftp;
using ServiceHub.Common.Settings.Iws;
using ServiceHub.Common.Settings.Mfp;
using ServiceHub.Common.Settings.OpenApi;
using Xunit;

namespace ServiceHub.Web.MfpConnector.Tests.Controllers.Rest
{
    public abstract class RestControllerTestsBase
    {
        private const string SETTING_ID = "unittest";
        protected readonly MfpConnectorSetting MfpConnectorSetting;

        protected RestControllerTestsBase()
        {
            MfpConnectorSetting = new MfpConnectorSetting
            {
                Log = new ServiceHub.Common.Settings.Log.LogSetting
                {
                    Path = ".",
                    MinLevel = LogLevel.Debug,
                    MaxFileSize = 1048576,
                    MaxFileCount = 1
                },
                OpenApi = new OpenApiSetting
                {
                    Version = new OpenApiVersion
                    {
                        Major = 6,
                        Minor = 9,
                    },
                    Devices = new OpenApiDeviceSetting
                    {
                        SettingId = SETTING_ID,
                        Definitions = new List<OpenApiDeviceDetailSetting>(new []
                        {
                            new OpenApiDeviceDetailSetting
                            {
                                SettingId = "unittest",
                                DeviceIp = "127.0.0.1",
                                DevicePort = 50003,
                                UseSsl = true,
                                User = "",
                                Password = "",
                                NotifyIp = "127.0.0.1",
                                NotifyPort = 80,
                                KeepAlive = true,
                                Timeout = 10000,
                                EnhancedServerAuth = new OpenApiEnhancedServerAuthSetting
                                {
                                    Use = false
                                },
                                AliveMonitor = new OpenApiAliveMonitorSetting
                                {
                                    PingInterval = 1000,
                                    PingTimeout = 1500,
                                    PingErrorMax = 3,
                                    OapConfirmTimeout = 10000,
                                    OapConfirmPeriod = 10
                                }
                            }
                        })
                    }
                },
                Iws = new IwsSetting()
                {
                    SettingId = SETTING_ID,
                    Definitions = new List<IwsWebApiSetting>(new []
                    {
                        new IwsWebApiSetting() {
                            SettingId = SETTING_ID,
                            Protocol = "http",
                            IpAddress = "localhost",
                            Port = 80,
                            AppId = "0A0243A4",
                            AuthUserName = "1",
                            AuthPassword = "1",
                            MfpUserName = "a_random_username",
                            CallbackTimeout = 500,
                            EnhancedServerAuth = new IwsEnhancedServerAuthSetting()
                            {
                                Use = false,
                                Values = new List<IwsEnhancedServerAuthValue>
                                {
                                    new IwsEnhancedServerAuthValue() { ControlId = "code", ValueType = EnhancedServerAuthValueType.AuthParameterCode }
                                }
                            },
                        }
                    }),
                    CurrentSetting =
                    {
                        CallbackUrlBase = "http://localhost",
                    },
                    AppInstall = new IwsAppInstallSetting()
                    {
                        FolderPath = ".",
                        FileName = "ServiceHub.iws",
                        FormContentName = "specialapp"
                    }
                },
                Ftp = new FtpSetting()
                {
                    SettingId = "debug",
                    Definitions = new List<FtpDefinition>()
                    {
                        new FtpDefinition()
                        {
                            SettingId = "debug",
                            Iisw = new FtpIiswSetting()
                            {
                                DownloadUrl = "test",
                            }
                        }
                    }
                }
            };

            MfpSettingItemAdmin = MfpSettingItem.Load("../../../App_Data/AdminSettings.json");
            CategoryMfpSetting = CategoryMfpSetting.Load("../../../App_Data/SettingCategory.json");
        }

        protected MfpSettingItem MfpSettingItemAdmin { get; }
        protected CategoryMfpSetting CategoryMfpSetting { get; }
    }
}
