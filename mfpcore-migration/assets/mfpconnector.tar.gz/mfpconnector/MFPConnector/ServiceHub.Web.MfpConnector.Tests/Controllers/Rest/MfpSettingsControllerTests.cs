using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

using KonicaMinolta.OpenApi;

using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

using Moq;

using ServiceHub.Common.Extensions;
using ServiceHub.Common.Settings;
using ServiceHub.Common.Settings.Mfp;
using ServiceHub.Connectors.OpenAPI;
using ServiceHub.Processors.MfpSetting;
using ServiceHub.Processors.MfpSetting.Model;
using ServiceHub.Processors.Power;
using ServiceHub.Web.MfpConnector.Controllers.Rest.Model;
using ServiceHub.Web.MfpConnector.Controllers.Rest.Settings;

using Xunit;

namespace ServiceHub.Web.MfpConnector.Tests.Controllers.Rest
{
    // Todo Validate the things in here. Someone did some mofdifications
    [Trait("MfpSettingsController", "Unit")]
    public class MfpSettingsControllerTests : RestControllerTestsBase
    {
        private const string MFP_SETTING_ID = "mfp_setting_test";

        private const string IWS_SETTING_ID = "iws_setting_test";

        private const string SETTING_NAME_ENABLE = "Enable";

        private const string SETTING_NAME_PORTNO = "PortNo";

        private const string SETTING_NAME_PRODUCT_NAME = "ProductName";

        private const string DATATYPE_ENUM = "enum";

        private const string DATATYPE_SHORT = "unsigned short";

        private const string HEADER_NAME = "setting-names";

        private const string POWER_MODE_ON = "ON";

        private const string PORT_NO = "8090";

        private static readonly XmlDocument AppResGetDevicePermanentSetting = CreateXml(new[] {
            "<?xml version=\"1.0\" encoding=\"utf-8\"?>",
            "<m:AppResGetDevicePermanentSetting xmlns:m=\"http://www.konicaminolta.com/service/OpenAPI-6-9\">",
            "<Result><ResultInfo>Ack</ResultInfo></Result>",
            "<RequestItem>InternalWebServer</RequestItem>",
            "<InternalWebServer><Enable>On</Enable><PortNo>8090</PortNo><ProductName>TestProduct</ProductName></InternalWebServer>",
            "</m:AppResGetDevicePermanentSetting>"
        });
        private static readonly XmlDocument AppResSetDevicePermanentSetting = CreateXml(new[] {
            "<?xml version=\"1.0\" encoding=\"utf-8\"?>",
            "<m:AppResSetDevicePermanentSetting xmlns:m=\"http://www.konicaminolta.com/service/OpenAPI-6-9\">",
            "<Result><ResultInfo>Ack</ResultInfo></Result>",
            "<RequestItem>InternalWebServer</RequestItem>",
            "</m:AppResSetDevicePermanentSetting>"
        });
        private static readonly XmlDocument AppResSetUniversalSetting = CreateXml(new[] {
            "<?xml version=\"1.0\" encoding=\"utf-8\"?>",
            "<m:AppResSetUniversalSetting xmlns:m=\"http://www.konicaminolta.com/service/OpenAPI-6-9\">",
            "<Result><ResultInfo>Ack</ResultInfo></Result>",
            "<RequestItem>Panel</RequestItem>",
            "</m:AppResSetUniversalSetting>"
        });
        private static readonly XmlDocument AppResLogin = CreateXml(new[] {
            "<?xml version=\"1.0\" encoding=\"utf-8\"?>",
            "<m:AppResLogin xmlns:m=\"http://www.konicaminolta.com/service/OpenAPI-6-9\">",
            "<Result><ResultInfo>Ack</ResultInfo></Result>",
            "<AuthKey>abcdefghijklmnopqrst</AuthKey>",
            "<AuthNo>0</AuthNo>",
            "<DiscriminationNo></DiscriminationNo>",
            "<TrackInfo><TrackId></TrackId><TrackName></TrackName></TrackInfo>",
            "<CostCenterInfo><CostCenterId></CostCenterId><CostCenterName></CostCenterName><CostCenterReconfigure></CostCenterReconfigure></CostCenterInfo>",
            "</m:AppResLogin>"
        });
        private static readonly XmlDocument AppResLogout = CreateXml(new[] {
            "<?xml version=\"1.0\" encoding=\"utf-8\"?>",
            "<m:AppResLogout xmlns:m=\"http://www.konicaminolta.com/service/OpenAPI-6-9\">",
            "<Result><ResultInfo>Ack</ResultInfo></Result>",
            "</m:AppResLogout>"
        });
        private static readonly XmlDocument AppResExitDeviceLock = CreateXml(new[] {
            "<?xml version=\"1.0\" encoding=\"utf-8\"?>",
            "<m:AppResExitDeviceLock xmlns:m=\"http://www.konicaminolta.com/service/OpenAPI-6-9\">",
            "<Result><ResultInfo>Ack</ResultInfo></Result>",
            "</m:AppResExitDeviceLock>"
        });
        

        private static readonly GetSettingValue settings_item_panel_soundoutputset_buzzertypesetting = new GetSettingValue()
        {
            Result = true,
            Key = "settings_item_panel_soundoutputset_buzzertypesetting",
            Datatype = "int",
            Values = "0"
        };
        private static readonly GetSettingValue settings_item_panel_soundoutputset_buzzerlist_buzzerdata = new GetSettingValue()
        {
            Result = true,
            Key = "settings_item_panel_soundoutputset_buzzerlist_buzzerdata",
            Datatype = "int",
            Values = "1"
        };
        private static readonly GetSettingValue settings_item_panel_backlightbrightness_10per = new GetSettingValue()
        {
            Result = true,
            Key = "settings_item_panel_backlightbrightness",
            Datatype = "enum",
            Values = "10Per"
        };
        private static readonly GetSettingValue settings_item_panel_backlightbrightness_222 = new GetSettingValue()
        {
            Result = true,
            Key = "settings_item_panel_backlightbrightness",
            Datatype = "enum",
            Values = "222"
        };
        private static readonly GetSettingValue settings_item_openapi_openapienable = new GetSettingValue()
        {
            Result = true,
            Key = "settings_item_openapi_openapienable",
            Datatype = "enum",
            Values = "ON"
        };
        private static readonly GetSettingValue settings_item_iws_portno_webserver = new GetSettingValue()
        {
            Result = true,
            Key = "settings_item_iws_portno_webserver",
            Datatype = "short",
            Values = "8080"
        };
        private static readonly GetSettingValue settings_item_iws_portno_connectiontool = new GetSettingValue()
        {
            Result = true,
            Key = "settings_item_iws_portno_connectiontool",
            Datatype = "short",
            Values = "8090"
        };
        private readonly ILogger<MfpSettingsController> _logger;
        private readonly Mock<IOpenApiService> _mockOap;
        private readonly Mock<IPowerOperator> _mockPow;

        private static XmlDocument AppResGetUniversalSetting(string buzzerTypeSetting, string buzzerData, string backLightBrightness)
        {
            StringBuilder builder = new StringBuilder()
                .Append("<?xml version=\"1.0\" encoding=\"utf-8\"?>")
                .Append("<m:AppResGetUniversalSetting xmlns:m=\"http://www.konicaminolta.com/service/OpenAPI-6-9\">")
                .Append("<Result><ResultInfo>Ack</ResultInfo></Result>")
                .Append("<RequestItem>Panel</RequestItem>")
                .Append($"<Panel><SoundOutputSet><BuzzerTypeSetting>{buzzerTypeSetting}</BuzzerTypeSetting><BuzzerList><BuzzerData>{buzzerData}</BuzzerData></BuzzerList></SoundOutputSet><BackLightBrightness>{backLightBrightness}</BackLightBrightness></Panel>")
                .Append("</m:AppResGetUniversalSetting>");
            
            var xml = new XmlDocument();
            xml.LoadXml(builder.ToString());
            return xml;
        }

        private static XmlDocument AppResGetDeviceStatus2(string resultInfo, string deviceLock = "", string subPower = "", string sleep = "", string lowPower = "")
        {
            StringBuilder builder = new StringBuilder()
                .Append("<?xml version=\"1.0\" encoding=\"utf-8\"?>")
                .Append("<m:AppResGetDeviceStatus2 xmlns:m=\"http://www.konicaminolta.com/service/OpenAPI-6-9\">")
                .Append($"<Result><ResultInfo>{resultInfo}</ResultInfo></Result>")
                .Append("<PrinterStatus><Status></Status><Detail></Detail></PrinterStatus>")
                .Append("<ScannerStatus><Status></Status><Detail></Detail></ScannerStatus>")
                .Append($"<SystemStatus><ServiceMode></ServiceMode><AdminMode></AdminMode><DeviceLock>{deviceLock}</DeviceLock><TwainLock></TwainLock><ProgramUpdate></ProgramUpdate><Interrupt></Interrupt></SystemStatus>")
                .Append($"<PowerStatus><SubPower>{subPower}</SubPower><Sleep>{sleep}</Sleep><LowPower>{lowPower}</LowPower><SuperWarp></SuperWarp></PowerStatus>")
                .Append("</m:AppResGetDeviceStatus2>");

            var xml = new XmlDocument();
            xml.LoadXml(builder.ToString());
            return xml;
        }

        private static XmlDocument AppResGetDeviceInfoDetail(string openApiEnable)
        {
            StringBuilder builder = new StringBuilder()
                .Append("<?xml version=\"1.0\" encoding=\"utf-8\"?>")
                .Append("<m:AppResGetDeviceInfoDetail xmlns:m=\"http://www.konicaminolta.com/service/OpenAPI-6-9\">")
                .Append("<Result><ResultInfo>Ack</ResultInfo></Result>")
                .Append("<RequestItem>OpenApi</RequestItem>")
                .Append($"<OpenApi><OpenApiEnable>{openApiEnable}</OpenApiEnable></OpenApi>")
                .Append("</m:AppResGetDeviceInfoDetail>");

            var xml = new XmlDocument();
            xml.LoadXml(builder.ToString());
            return xml;
        }

        private static XmlDocument GetAppResGetDevicePermanentSetting(string portNo, string connectionToolPortNo)
        {
            StringBuilder builder = new StringBuilder()
                .Append("<?xml version=\"1.0\" encoding=\"utf-8\"?>")
                .Append("<m:AppResGetDevicePermanentSetting xmlns:m=\"http://www.konicaminolta.com/service/OpenAPI-6-9\">")
                .Append("<Result><ResultInfo>Ack</ResultInfo></Result>")
                .Append("<RequestItem>InternalWebServer</RequestItem>")
                .Append($"<InternalWebServer><PortNo>{portNo}</PortNo><ConnectionToolPortNo>{connectionToolPortNo}</ConnectionToolPortNo></InternalWebServer>")
                .Append("</m:AppResGetDevicePermanentSetting>");

            var xml = new XmlDocument();
            xml.LoadXml(builder.ToString());
            return xml;
        }

        private static XmlDocument AppResEnterDeviceLock(string lockKey)
        {
            StringBuilder builder = new StringBuilder()
                .Append("<?xml version=\"1.0\" encoding=\"utf-8\"?>")
                .Append("<m:AppResEnterDeviceLock xmlns:m=\"http://www.konicaminolta.com/service/OpenAPI-6-9\">")
                .Append("<Result><ResultInfo>Ack</ResultInfo></Result>")
                .Append($"<LockKey>{lockKey}</LockKey>")
                .Append("</m:AppResEnterDeviceLock>");

            var xml = new XmlDocument();
            xml.LoadXml(builder.ToString());
            return xml;
        }

        private readonly Mock<IMfpSettingsOperator> _mockMfpSettingOperator;
        private readonly Mock<CategoryMfpSetting> _mockCategoryMfpSetting;
        private readonly Mock<MfpSettingItem> _mockMfpSettingItem;
        private readonly Mock<IPowerOperator> _mockPowerOperator;

        public MfpSettingsControllerTests()
        {
            _logger = Mock.Of<ILogger<MfpSettingsController>>();
            _mockOap = new Mock<IOpenApiService>();
            _mockPow = new Mock<IPowerOperator>();
            _mockMfpSettingOperator = new Mock<IMfpSettingsOperator>();
            _mockCategoryMfpSetting = new Mock<CategoryMfpSetting>();
            _mockMfpSettingItem = new Mock<MfpSettingItem>();
            _mockPowerOperator = new Mock<IPowerOperator>();
        }

        public const string AdminMfpSettingPath = "~/App_Data/Settings.json";

        private readonly MfpSettingsSetRequest _content = new MfpSettingsSetRequest
        {
            SettingValues = new List<SetSettingValue>()
            {
                new SetSettingValue
                {
                    Name = "network_service.lpd_use",
                    Value = "false"
                }
            }

        };

        private readonly MfpSettingsSetRequest _contentSettingEmptyName = new MfpSettingsSetRequest
        {
            SettingValues = new List<SetSettingValue>()
            {
                new SetSettingValue
                {
                    Name = "",
                    Value = "false"
                }
            }

        };


        [Fact]
        public async Task
            SetDeviceSetting_WhenOpenApiFaultExceptionErrDetailsGeneralDuringDeviceLock_ExpectServiceUnavailable()
        {
            // Prepare
            var setSettingResult = new List<SetSettingResult>(new[]
            {
                new SetSettingResult()
                {
                    ErrorCode = "GeneralDuringDeviceLock"
                }
            });
        
            var mfpSettingItem = MfpSettingItem.Load(AdminMfpSettingPath.MapPath(Directory.GetCurrentDirectory())); ;

            _mockMfpSettingOperator.Setup(m => m.SetMfpSettingsAsync(It.IsAny<List<SetSettingValue>>()))
                .ReturnsAsync(setSettingResult);

            // Execute
            var mfpSettingController = new MfpSettingsController(
                null,
                _mockMfpSettingOperator.Object,
                _mockPowerOperator.Object,
                mfpSettingItem,
                _mockCategoryMfpSetting.Object,
                _logger);

            var response = (ObjectResult)await mfpSettingController.SetDeviceSetting(_content);

            Assert.Equal(response.StatusCode,(int)HttpStatusCode.ServiceUnavailable);
            _mockMfpSettingOperator.VerifyAll();
        }
        [Fact]
        public async Task
            SetDeviceSetting_WhenOpenApiFaultException_ExpectServiceUnavailable()
        {
            // Prepare
            var faultMesseage = new FaultMessage()
            {
                ErrorDetails = "GeneralDuringDeviceLock"
            };
            var mfpSettingItem = MfpSettingItem.Load(AdminMfpSettingPath.MapPath(Directory.GetCurrentDirectory()));

            _mockMfpSettingOperator.Setup(m => m.SetMfpSettingsAsync(It.IsAny<List<SetSettingValue>>()))
                .ThrowsAsync(new OpenApiFaultException(null, faultMesseage));

            // Execute
            var mfpSettingController = new MfpSettingsController(
                null,
                _mockMfpSettingOperator.Object,
                _mockPowerOperator.Object,
                mfpSettingItem,
                _mockCategoryMfpSetting.Object,
                _logger);

            var response = (ObjectResult)await mfpSettingController.SetDeviceSetting(_content);

            Assert.Equal(response.StatusCode, (int)HttpStatusCode.ServiceUnavailable);
            _mockMfpSettingOperator.VerifyAll();
        }

        [Fact]
        public async Task
            SetDeviceSetting_WhenEmptySettingName_ExpectBadRequest()
        {
            // Prepare
            var mfpSettingItem = MfpSettingItem.Load(AdminMfpSettingPath.MapPath(Directory.GetCurrentDirectory()));


            // Execute
            var mfpSettingController = new MfpSettingsController(
                null,
                _mockMfpSettingOperator.Object,
                _mockPowerOperator.Object,
                mfpSettingItem,
                _mockCategoryMfpSetting.Object,
                _logger);

            var response = (BadRequestResult)await mfpSettingController.SetDeviceSetting(_contentSettingEmptyName);

            Assert.Equal(response.StatusCode, (int)HttpStatusCode.BadRequest);
            _mockMfpSettingOperator.VerifyAll();
        }

        public static XmlDocument CreateXml(params string[] parts)
        {
            var builder = new StringBuilder();
            foreach (var part in parts)
            {
                builder.AppendLine(part);
            }

            var xml = new XmlDocument();
            xml.LoadXml(builder.ToString());
            return xml;
        }

        private static System.Linq.Expressions.Expression<Func<XmlDocument, bool>> Has(string tag)
        {
            return xdoc => xdoc.GetElementsByTagName(tag).Count != 0;
        }

        private static System.Linq.Expressions.Expression<Func<XmlDocument, bool>> XPath(params string[] xpathes)
        {
            return xdoc => Array.TrueForAll(xpathes, (xpath) => xdoc.SelectSingleNode(xpath) != null);
        }

    }
}
