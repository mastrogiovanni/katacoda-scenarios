using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using System.Xml;
using KonicaMinolta.OpenApi;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using Newtonsoft.Json;
using ServiceHub.Common.Settings;
using ServiceHub.Connectors.OpenAPI.Exceptions;
using ServiceHub.Processors.Job;
using ServiceHub.Processors.Job.Model;
using ServiceHub.Web.MfpConnector.Controllers.Rest.Jobs;
using Xunit;

namespace ServiceHub.Web.MfpConnector.Tests.Controllers.Rest
{
    [Trait("JobsController", "Unit")]
    public class JobsControllerTests
    {
        private const int Job1Id = 2263;
        private const string Job2Id = "22635";
        private const string JobIdNegative = "-1";
        private const string JobIdSymbol = "@#$";
        private const string JobIdWhiteSpace = " ";

        private readonly MfpJobResponse _jobResponseItem1 = new MfpJobResponse
        {
            MfpJobId = Job1Id,
            JobType = "Print",
            DriverJobId = "B4B52F7E094D0B0B03331C0150",
            Status = "Printing",
            NumberOfOriginals = 9,
        };
        private readonly MfpJobResponse _jobResponseItem2 = new MfpJobResponse
        {
            MfpJobId = Job1Id,
            JobType = "Print",
            DriverJobId = "B4B52F7E094D0B0B03331C0152",
            Status = "Printing",
            NumberOfOriginals = 12,
        };

        private readonly JobsManipulateRequest _jobRequestNormal = new JobsManipulateRequest
        {
            AuthParameter = new AuthParameter
            {
                Code = "testcode"
            }
        };

        private readonly ILogger<JobsController> _logger;
        private readonly Mock<IJobOperator> _jobOperatorMock;

        public JobsControllerTests()
        {
            _logger = Mock.Of<ILogger<JobsController>>();
            _jobOperatorMock = new Mock<IJobOperator>(MockBehavior.Strict);
        }

        [Fact]
        public async Task Get_WhenNoParam_ExpectSuccessWithAllJobs()
        {
            // Prepare
            var res = new List<MfpJobResponse>
            {
                _jobResponseItem1,
                _jobResponseItem2
            };
            _jobOperatorMock.Setup(m => m.GetJobsAsync(null)).ReturnsAsync(res);

            // Execute
            var jobsController = new JobsController(_logger, null, _jobOperatorMock.Object);
            var result = (ObjectResult)await jobsController.Get();

            // Validate
            Assert.Equal((int)HttpStatusCode.OK, result.StatusCode);
            Assert.Equal(JsonConvert.SerializeObject(res), JsonConvert.SerializeObject(result.Value));
            _jobOperatorMock.VerifyAll();
        }

        [Fact]
        public async Task Get_WhenJobOperatorReturnsNull_ExpectNoContent()
        {
            // Prepare
            _jobOperatorMock.Setup(m => m.GetJobsAsync(null)).ReturnsAsync((List<MfpJobResponse>)null);

            // Execute
            var jobsController = new JobsController(_logger, null, _jobOperatorMock.Object);
            var result = (NoContentResult)await jobsController.Get();

            // Validate
            Assert.Equal((int)HttpStatusCode.NoContent, result.StatusCode);
            _jobOperatorMock.VerifyAll();
        }

        [Fact]
        public async Task Get_WhenJobOperatorReturnEmptyList_ExpectNoContent()
        {
            // Prepare
            _jobOperatorMock.Setup(m => m.GetJobsAsync(null)).ReturnsAsync(new List<MfpJobResponse>());

            // Execute
            var jobsController = new JobsController(_logger, null, _jobOperatorMock.Object);
            var result = (NoContentResult)await jobsController.Get();

            // Validate
            Assert.Equal((int)HttpStatusCode.NoContent, result.StatusCode);
            _jobOperatorMock.VerifyAll();
        }

        [Fact]
        public async Task Get_WhenJobIdIsNull_ExpectInternalServerError()
        {
            // Prepare
            _jobOperatorMock.Setup(m => m.GetJobsAsync(null)).Throws(new XmlException("dummy"));

            // Execute
            var jobsController = new JobsController(_logger, null, _jobOperatorMock.Object);
            var result = (ObjectResult)await jobsController.Get();

            // Validate
            Assert.Equal((int)HttpStatusCode.InternalServerError, result.StatusCode);
            _jobOperatorMock.VerifyAll();
        }

        [Fact]
        public async Task Get_WhenIdIsValid_ExpectSuccess()
        {
            // Prepare
            var res = new List<MfpJobResponse>()
            {
                _jobResponseItem1,
                _jobResponseItem2
            };
            _jobOperatorMock.Setup(m => m.GetJobsAsync(Job1Id)).ReturnsAsync(res);

            // Execute
            var jobsController = new JobsController(_logger, null, _jobOperatorMock.Object);
            var result = (ObjectResult)await jobsController.Get(Job1Id.ToString());

            // Validate
            Assert.Equal((int)HttpStatusCode.OK, result.StatusCode);
            Assert.Equal(JsonConvert.SerializeObject(_jobResponseItem1), JsonConvert.SerializeObject(result.Value));
            _jobOperatorMock.VerifyAll();
        }

        [Fact]
        public async Task Get_WhenIdLengthZero_ExpectNotFound()
        {
            // Prepare
            _jobOperatorMock.Setup(m => m.GetJobsAsync(Job1Id)).ReturnsAsync(new List<MfpJobResponse>());

            // Execute
            var jobsController = new JobsController(_logger, null, _jobOperatorMock.Object);
            var result = (ObjectResult)await jobsController.Get(Job1Id.ToString());

            // Validate
            Assert.Equal((int)HttpStatusCode.NotFound, result.StatusCode);
            _jobOperatorMock.VerifyAll();
        }

        [Fact]
        public async Task Get_WhenIdExistButJobOperatorReturnEmptyList_ExpectNotFound()
        {
            // Prepare
            _jobOperatorMock.Setup(m => m.GetJobsAsync(Job1Id)).ReturnsAsync(new List<MfpJobResponse>());

            // Execute
            var jobsController = new JobsController(_logger, null, _jobOperatorMock.Object);
            var result = (ObjectResult)await jobsController.Get(Job1Id.ToString());

            // Validate
            Assert.Equal((int)HttpStatusCode.NotFound, result.StatusCode);
            _jobOperatorMock.VerifyAll();
        }

        [Fact]
        public async Task Get_WhenIdIsNull_ExpectNotFound()
        {
            // Prepare
            // Execute
            var jobsController = new JobsController(_logger, null, _jobOperatorMock.Object);
            var result = (ObjectResult)await jobsController.Get(null);

            // Validate
            Assert.Equal((int)HttpStatusCode.NotFound, result.StatusCode);
            _jobOperatorMock.VerifyAll();
        }

        [Fact]
        public async Task Delete_WhenValidData_ExpectNoContent()
        {
            // Prepare
            _jobOperatorMock.Setup(m => m.DeleteJobAsync(Job2Id, It.IsAny<string>())).ReturnsAsync(true);

            // Execute
            var jobsController = new JobsController(_logger, null, _jobOperatorMock.Object);
            var result = (StatusCodeResult)await jobsController.Delete(Job2Id, _jobRequestNormal);

            // Validate
            Assert.Equal((int)HttpStatusCode.NoContent, result.StatusCode);
            _jobOperatorMock.VerifyAll();
        }

        [Fact]
        public async Task Delete_WhenJobOperatorNotAck_ExpectNotFound()
        {
            // Prepare
            _jobOperatorMock.Setup(m => m.DeleteJobAsync(Job2Id, It.IsAny<string>())).ReturnsAsync(false);

            // Execute
            var jobsController = new JobsController(_logger, null, _jobOperatorMock.Object);
            var result = (StatusCodeResult)await jobsController.Delete(Job2Id, _jobRequestNormal);

            // Validate
            Assert.Equal((int)HttpStatusCode.NotFound, result.StatusCode);
            _jobOperatorMock.VerifyAll();
        }

        [Fact]
        public async Task Delete_WhenOpenAPIConnectError400_ExpectBadRequest()
        {
            // Prepare
            _jobOperatorMock.Setup(m => m.DeleteJobAsync(Job2Id, It.IsAny<string>()))
                .Throws(new OpenApiRequestException(OpenApiResultStatus.ConnectError, "Connect error."));

            // Execute
            var jobsController = new JobsController(_logger, null, _jobOperatorMock.Object);
            var result = (ObjectResult)await jobsController.Delete(Job2Id, _jobRequestNormal);

            // Validate
            Assert.Equal((int)HttpStatusCode.BadRequest, result.StatusCode);
            _jobOperatorMock.VerifyAll();
        }

        [Fact]
        public async Task Delete_WhenJsonFormatError_ExpectBadRequest()
        {
            // Prepare
            _jobOperatorMock.Setup(m => m.DeleteJobAsync(Job2Id, It.IsAny<string>()))
                .Throws(new OpenApiRequestException(OpenApiResultStatus.OtherError));

            // Execute
            var jobsController = new JobsController(_logger, null, _jobOperatorMock.Object);
            var result = (ObjectResult)await jobsController.Delete(Job2Id, new JobsManipulateRequest());

            // Validate
            Assert.Equal((int)HttpStatusCode.BadRequest, result.StatusCode);
            _jobOperatorMock.VerifyAll();
        }

        [Fact]
        public async Task Delete_WhenJobIdAsNotValidError_ExpectNotFound()
        {
            // Prepare
            _jobOperatorMock.Setup(m => m.DeleteJobAsync(Job2Id, It.IsAny<string>()))
                .ReturnsAsync(false);

            // Execute
            var jobsController = new JobsController(_logger, null, _jobOperatorMock.Object);
            var response = jobsController.Delete(Job2Id, _jobRequestNormal);
            var result = (StatusCodeResult)await response;

            // Validate
            Assert.Equal((int)HttpStatusCode.NotFound, result.StatusCode);
            _jobOperatorMock.VerifyAll();
        }

        [Fact]
        public async Task Delete_WhenJobIdAsOutOfRangeError_ExpectNotFound()
        {
            // Prepare
            _jobOperatorMock.Setup(m => m.DeleteJobAsync(JobIdNegative, It.IsAny<string>())).Returns(Task.FromResult(false));

            // Execute
            var jobsController = new JobsController(_logger, null, _jobOperatorMock.Object);
            var result = (StatusCodeResult)await jobsController.Delete(JobIdNegative, _jobRequestNormal);

            // Validate
            Assert.Equal((int)HttpStatusCode.NotFound, result.StatusCode);
            _jobOperatorMock.VerifyAll();
        }

        [Fact]
        public async Task Delete_WhenJobIdAsSymbolError_ExpectNotFound()
        {
            // Prepare
            _jobOperatorMock.Setup(m => m.DeleteJobAsync(JobIdSymbol, It.IsAny<string>()))
                .ReturnsAsync(false);

            // Execute
            var jobsController = new JobsController(_logger, null, _jobOperatorMock.Object);
            var result = (StatusCodeResult)await jobsController.Delete(JobIdSymbol, _jobRequestNormal);

            // Validate
            Assert.Equal((int)HttpStatusCode.NotFound, result.StatusCode);
            _jobOperatorMock.VerifyAll();
        }

        [Fact]
        public async Task Delete_WhenJobIdAsWhiteSpaceError_ExpectNotFound()
        {
            // Prepare
            _jobOperatorMock.Setup(m => m.DeleteJobAsync(JobIdWhiteSpace, It.IsAny<string>()))
                .ReturnsAsync(false);

            // Execute
            var jobsController = new JobsController(_logger, null, _jobOperatorMock.Object);
            var result = (StatusCodeResult)await jobsController.Delete(JobIdWhiteSpace, _jobRequestNormal);

            // Validate
            Assert.Equal((int)HttpStatusCode.NotFound, result.StatusCode);
            _jobOperatorMock.VerifyAll();
        }

        [Fact]
        public async Task Delete_WhenOpenApiFaultException_ExpectForbidden()
        {
            var faultMessage = new FaultMessage()
            {
                FaultCode = SoapFaultCode.Client,
                FaultString = "Client Error",
                FaultRequest = "AppReqDeleteJob",
                ErrorDetails = "AuthNotAllowedAuthSetting"
            };

            // Prepare
            _jobOperatorMock.Setup(m => m.DeleteJobAsync(JobIdWhiteSpace, It.IsAny<string>()))
                .ThrowsAsync(new OpenApiFaultException(new Exception(),faultMessage));

            // Execute
            var jobsController = new JobsController(_logger, null, _jobOperatorMock.Object);
            var result = (ObjectResult)await jobsController.Delete(JobIdWhiteSpace, _jobRequestNormal);

            // Validate
            Assert.Equal((int)HttpStatusCode.Forbidden, result.StatusCode);
            _jobOperatorMock.VerifyAll();
        }

        [Fact]
        public async Task Delete_WhenOpenApiFaultException_ExpectInternalServerError()
        {
            var faultMessage = new FaultMessage()
            {
                FaultCode = SoapFaultCode.Server,
                FaultString = "Server Error",
                FaultRequest = "AppReqDeleteJob",
                ErrorDetails = "AuthNotAllowedAuthSetting"
            };

            // Prepare
            _jobOperatorMock.Setup(m => m.DeleteJobAsync(JobIdWhiteSpace, It.IsAny<string>()))
                .ThrowsAsync(new OpenApiFaultException(new Exception(), faultMessage));

            // Execute
            var jobsController = new JobsController(_logger, null, _jobOperatorMock.Object);
            var result = (ObjectResult)await jobsController.Delete(JobIdWhiteSpace, _jobRequestNormal);

            // Validate
            Assert.Equal((int)HttpStatusCode.InternalServerError, result.StatusCode);
            _jobOperatorMock.VerifyAll();
        }
    }
}
