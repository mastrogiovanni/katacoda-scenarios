using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

using Moq;
using ServiceHub.Processors.Common.Model;
using ServiceHub.Processors.DeviceInfo;
using ServiceHub.Web.MfpConnector.Controllers.Rest;
using Xunit;

namespace ServiceHub.Web.MfpConnector.Tests.Controllers.Rest
{
    [Trait("MachineDataController", "Unit")]
    public class MachineDataControllerTests
    {
        private readonly Mock<IDeviceInfoOperator> _deviceInfoOperatorMock;
        private readonly ILogger<MachineDataController> _logger;

        public MachineDataControllerTests()
        {
            _logger = Mock.Of<ILogger<MachineDataController>>();
            _deviceInfoOperatorMock = new Mock<IDeviceInfoOperator>(MockBehavior.Strict);
        }

        [Fact]
        public async Task Get_WhenPathIsValid_ExpectProperFileContent()
        {
            // Prepare
            byte[] expectedBinary = new byte[255];

            for (int i = 0; i < expectedBinary.Length; i++)
            {
                expectedBinary[i] = (byte)i;
            }
            _deviceInfoOperatorMock.Setup(m => m.GetMachineImageFileAsync(It.IsAny<string>()))
                .ReturnsAsync(new AttachmentData { Binary = expectedBinary });

            // Execute
            var testTargetController = new MachineDataController(_logger, _deviceInfoOperatorMock.Object, null);
            var response = (FileContentResult)await testTargetController.Get("c:/temp/test.png");

            // Test
            Assert.Equal(expectedBinary.Length, response.FileContents.Length);
            for (int i = 0; i < expectedBinary.Length; i++)
            {
                Assert.Equal(expectedBinary[i], response.FileContents[i]);
            }

            _deviceInfoOperatorMock.VerifyAll();
        }

        [Fact]
        public void Get_WhenPathIsNull_ExpectBadRequest()
        {
            var testTargetController = new MachineDataController(_logger, null, null);

            var response = (ObjectResult)testTargetController.Get(null).Result;

            Assert.Equal((int)HttpStatusCode.BadRequest, response.StatusCode);
        }

        [Fact]
        public void Get_WhenPathIsEmpty_ExpectBadRequest()
        {
            // Execute
            var testTargetController = new MachineDataController(_logger, null, null);
            var response = (ObjectResult)testTargetController.Get(string.Empty).Result;

            // Validate
            Assert.Equal((int)HttpStatusCode.BadRequest, response.StatusCode); // Bad request does not exists in the contract.
        }

        [Fact]
        public async Task Get_WhenPathIsInvalid_ExpectInternalServerError()
        {
            _deviceInfoOperatorMock.Setup(m => m.GetMachineImageFileAsync(It.IsAny<string>()))
                .ReturnsAsync((AttachmentData)null);

            var testTargetController = new MachineDataController(_logger, _deviceInfoOperatorMock.Object, null);
            var response = (ObjectResult)await testTargetController.Get("c:\\temp\\test.png");

            Assert.Equal((int)HttpStatusCode.InternalServerError, response.StatusCode);
        }

        [Fact]
        public async Task Get_WhenDeviceInfoOperatorThrows_ExpectInternalServerError()
        {
            _deviceInfoOperatorMock.Setup(m => m.GetMachineImageFileAsync(It.IsAny<string>()))
                .Throws(new System.Exception());

            var testTargetController = new MachineDataController(_logger, _deviceInfoOperatorMock.Object, null);
            var response = (ObjectResult)await testTargetController.Get("c:\\temp\\test.png");

            Assert.Equal((int)HttpStatusCode.InternalServerError, response.StatusCode);
        }
    }
}