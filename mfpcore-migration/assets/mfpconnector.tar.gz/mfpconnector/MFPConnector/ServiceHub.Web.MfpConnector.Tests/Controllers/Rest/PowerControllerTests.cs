using System;
using System.Net;
using System.Threading.Tasks;

using KonicaMinolta.OpenApi;

using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

using Moq;
using Newtonsoft.Json;
using ServiceHub.Connectors.OpenAPI.Model;
using ServiceHub.Processors.Power;
using ServiceHub.Processors.ReadyManage;
using ServiceHub.Web.MfpConnector.Controllers.Rest;
using ServiceHub.Web.MfpConnector.Controllers.Rest.Model;
using Xunit;

namespace ServiceHub.Web.MfpConnector.Tests.Controllers.Rest
{
    [Trait("PowerController", "Unit")]
    public class PowerControllerTests : RestControllerTestsBase
    {
        private const string ResultJsonOk = "{\"result\":\"OK\"}";
        private const string ResultJsonNg = "{\"result\":\"NG\"}";
        private readonly ILogger<PowerController> _logger;
        private readonly Mock<IPowerOperator> _mockPowerOperator;
        private readonly Mock<IMfpReadyManage> _mockMfpReadyManage;

        public PowerControllerTests()
        {
            _logger = Mock.Of<ILogger<PowerController>>();
            _mockPowerOperator = new Mock<IPowerOperator>(MockBehavior.Strict);
            _mockMfpReadyManage = new Mock<IMfpReadyManage>(MockBehavior.Strict);
        }

        [Fact]
        public async Task Sleep_WhenChangePowerModeToLowPower_ExpectOk()
        {
            // Prepare
            _mockMfpReadyManage.Setup(m => m.Pause()).Returns(true);
            _mockPowerOperator.Setup(m => m.ChangePowerModeAsync(PowerMode.PowerModeRequestLowPower)).ReturnsAsync("Ack");

            var request = new PowerModeRequest { PowerMode = PowerMode.PowerModeRequestLowPower };

            // Execute
            var powerController = new PowerController(_logger, null, _mockPowerOperator.Object, _mockMfpReadyManage.Object);
            var response = (ObjectResult)await powerController.Sleep(request);

            // Validate
            Assert.Equal((int)HttpStatusCode.Created, response.StatusCode); // Should be a no content
            _mockPowerOperator.VerifyAll();
            _mockMfpReadyManage.VerifyAll();
        }

        [Fact]
        public async Task Sleep_WhenChangePowerModeToSleep_ExpectOkSleep()
        {
            // Prepare
            _mockMfpReadyManage.Setup(m => m.Pause()).Returns(true);
            _mockPowerOperator.Setup(m => m.ChangePowerModeAsync(PowerMode.PowerModeRequestSleep)).ReturnsAsync("Ack");

            var request = new PowerModeRequest { PowerMode = PowerMode.PowerModeRequestSleep };

            // Execute
            var powerController = new PowerController(_logger, null, _mockPowerOperator.Object, _mockMfpReadyManage.Object);
            var response = (ObjectResult)await powerController.Sleep(request);

            // Validate
            Assert.Equal((int)HttpStatusCode.Created, response.StatusCode); // Should be a no content
            _mockPowerOperator.VerifyAll();
            _mockMfpReadyManage.VerifyAll();
        }

        [Fact]
        public async Task Sleep_WhenChangePowerModeToSubPowerOff_ExpectOk()
        {
            // Prepare
            _mockMfpReadyManage.Setup(m => m.Pause()).Returns(true);
            _mockPowerOperator.Setup(m => m.ChangePowerModeAsync(PowerMode.PowerModeRequestSubPowerOff)).ReturnsAsync("Ack");

            var request = new PowerModeRequest { PowerMode = PowerMode.PowerModeRequestSubPowerOff };

            // Execute
            var powerController = new PowerController(_logger, null, _mockPowerOperator.Object, _mockMfpReadyManage.Object);
            var response = (ObjectResult)await powerController.Sleep(request);

            // Validate
            Assert.Equal((int)HttpStatusCode.Created, response.StatusCode);
            _mockPowerOperator.VerifyAll();
            _mockMfpReadyManage.VerifyAll();
        }

        [Fact]
        public async Task Sleep_WhenChangePowerModeToRequestErp_ExpectOk()
        {
            // Prepare
            _mockMfpReadyManage.Setup(m => m.Pause()).Returns(true);
            _mockPowerOperator.Setup(m => m.ChangePowerModeAsync(PowerMode.PowerModeRequestErp)).ReturnsAsync("Ack");

            var request = new PowerModeRequest { PowerMode = PowerMode.PowerModeRequestErp };

            // Execute
            var powerController = new PowerController(_logger, null, _mockPowerOperator.Object, _mockMfpReadyManage.Object);
            var response = (ObjectResult)await powerController.Sleep(request);

            // Validate
            Assert.Equal((int)HttpStatusCode.Created, response.StatusCode);
            _mockPowerOperator.VerifyAll();
            _mockMfpReadyManage.VerifyAll();
        }

        [Fact]
        public async Task Sleep_WhenChangePowerModeToInvalidMode_ExpectBadRequestWithNg()
        {
            // Prepare
            var request = new PowerModeRequest
            {
                PowerMode = (PowerMode)(-1)
            };

            // Execute
            var powerController = new PowerController(_logger, null, null, null);
            var response = (ObjectResult)await powerController.Sleep(request);

            // Validate
            Assert.Equal((int)HttpStatusCode.BadRequest, response.StatusCode);
        }

        [Fact]
        public async Task Sleep_WhenChangePowerModeToOverflowValue_ExpectBadRequestWithNg()
        {
            // Prepare
            var request = new PowerModeRequest
            {
                // Get the powermode + 1 to go over the last value
                PowerMode = (PowerMode)Enum.GetNames(typeof(PowerMode)).Length
            };

            // Execute
            var powerController = new PowerController(_logger, null, null, null);
            var response = (ObjectResult)await powerController.Sleep(request);

            // Validate
            Assert.Equal((int)HttpStatusCode.BadRequest, response.StatusCode);
            _mockPowerOperator.VerifyAll();
        }

        [Fact]
        public async Task Sleep_WhenChangePowerModeToNull_ExpectBadRequestWithNg()
        {
            // Prepare
            var request = new PowerModeRequest { PowerMode = null };

            // Execute
            var powerController = new PowerController(_logger, null, null, null);
            var response = (ObjectResult)await powerController.Sleep(request);

            // Validate
            Assert.Equal((int)HttpStatusCode.BadRequest, response.StatusCode);
        }

        [Fact]
        public async Task Sleep_WhenChangePowerModeObjectIsNull_ExpectBadRequestWithNg()
        {
            // Execute
            var powerController = new PowerController(_logger, null, null, null);
            var response = (ObjectResult)await powerController.Sleep(null);

            // Validate
            Assert.Equal((int)HttpStatusCode.BadRequest, response.StatusCode);
        }

        [Fact]
        public async Task Sleep_WhenErrorDetailsGeneralDuringDeviceLock_ExpectServiceUnavailable()
        {
            // Prepare
            var faultMesseage = new FaultMessage()
            {
                ErrorDescription = "req_changePowerSaveStatusInIdle"
            };
            _mockMfpReadyManage.Setup(m => m.Pause()).Returns(true);
            _mockMfpReadyManage.Setup(m => m.Resume()).Returns(true);
            _mockPowerOperator.Setup(m => m.ChangePowerModeAsync(PowerMode.PowerModeRequestLowPower)).ThrowsAsync(new OpenApiFaultException(null, faultMesseage));

            var request = new PowerModeRequest { PowerMode = PowerMode.PowerModeRequestLowPower };

            // Execute
            var powerController = new PowerController(_logger, null, _mockPowerOperator.Object, _mockMfpReadyManage.Object);
            var response = (ObjectResult)await powerController.Sleep(request);

            // Validate
            Assert.Equal((int)HttpStatusCode.ServiceUnavailable, response.StatusCode);
            Assert.Equal("NG", ((PowerControllerResult)response.Value).Result);
            _mockPowerOperator.VerifyAll();
            _mockMfpReadyManage.VerifyAll();
        }

        [Fact]
        public async Task Sleep_WhenErrorDetailsOtherThenGeneralDuringDeviceLock_ExpectInternalServerErrorMesseage()
        {
            // Prepare
            var faultMesseage = new FaultMessage()
            {
                ErrorDescription = ""
            };
            _mockMfpReadyManage.Setup(m => m.Pause()).Returns(true);
            _mockMfpReadyManage.Setup(m => m.Resume()).Returns(true);
            _mockPowerOperator.Setup(m => m.ChangePowerModeAsync(PowerMode.PowerModeRequestLowPower)).ThrowsAsync(new OpenApiFaultException(null, faultMesseage));

            var request = new PowerModeRequest { PowerMode = PowerMode.PowerModeRequestLowPower };

            // Execute
            var powerController = new PowerController(_logger, null, _mockPowerOperator.Object, _mockMfpReadyManage.Object);
            var response = (ObjectResult)await powerController.Sleep(request);

            // Validate
            Assert.Equal((int)HttpStatusCode.InternalServerError, response.StatusCode);
            Assert.Equal("NG", ((PowerControllerResult)response.Value).Result);
            _mockPowerOperator.VerifyAll();
            _mockMfpReadyManage.VerifyAll();
        }


        [Fact]
        public async Task WakeUp_WhenOk_ExpectCreatedOk()
        {
            // Prepare
            _mockMfpReadyManage.Setup(m => m.Resume()).Returns(true);
            _mockPowerOperator.Setup(m => m.WakeUpToMfpAsync(It.IsAny<bool>())).Returns(Task.FromResult(true));

            // Execute
            var powerController = new PowerController(_logger, null, _mockPowerOperator.Object, _mockMfpReadyManage.Object);
            var response = (ObjectResult)await powerController.WakeUp();

            // Validate
            Assert.Equal((int)HttpStatusCode.Created, response.StatusCode); // This should return a no content
            Assert.Equal(ResultJsonOk, JsonConvert.SerializeObject(response.Value));
            _mockPowerOperator.VerifyAll();
            _mockMfpReadyManage.VerifyAll();
        }

        [Fact]
        public async Task WakeUp_WhenAlreadyAwake_ExpectCreatedNg()
        {
            // Prepare
            _mockPowerOperator.Setup(m => m.WakeUpToMfpAsync(It.IsAny<bool>())).Returns(Task.FromResult(false));

            // Execute
            var powerController = new PowerController(_logger, null, _mockPowerOperator.Object, null);
            var response = (ObjectResult)await powerController.WakeUp();

            // Validate
            Assert.Equal((int)HttpStatusCode.Created, response.StatusCode); // The status should be different
            Assert.Equal(ResultJsonNg, JsonConvert.SerializeObject(response.Value));
            _mockPowerOperator.VerifyAll();
        }
    }
}