using System.Net;
using System.Text;
using System.Threading.Tasks;
using KonicaMinolta.OpenApi;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

using Moq;
using Newtonsoft.Json;
using ServiceHub.Processors.Animations;
using ServiceHub.Processors.DeviceInfo;
using ServiceHub.Web.MfpConnector.Controllers.Rest;
using Xunit;

namespace ServiceHub.Web.MfpConnector.Tests.Controllers.Rest
{
    [Trait("AnimationsController", "Unit")]
    public class AnimationsControllerTests
    {
        private readonly ILogger<AnimationsController> _logger;
        private readonly Mock<IAnimationsOperator> _animationOperatorMock;
        private readonly Mock<IDeviceInfoOperator> _deviceInfoOperatorMock;

        public AnimationsControllerTests()
        {
            _logger = Mock.Of<ILogger<AnimationsController>>();
            _animationOperatorMock = new Mock<IAnimationsOperator>(MockBehavior.Strict);
            _deviceInfoOperatorMock = new Mock<IDeviceInfoOperator>(MockBehavior.Strict);
        }

        [Fact]
        public void GetAnimationRom_WhenAnimationOperatorReturnNack_ExpectInternalServerError()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("<Result>");
            sb.AppendLine("  <ResultInfo>Nack</ResultInfo>");
            sb.AppendLine("  <FaultRequest>AppReqGetDeviceInfoDetail</FaultRequest>");
            sb.AppendLine("  <ErrorDetails>Error details</ErrorDetails>");
            sb.AppendLine("  <ErrorDescription>Error description</ErrorDescription>");
            sb.AppendLine("</Result>");
            var nack = sb.ToString();

            _animationOperatorMock.Setup(m => m.GetAnimationRomVersionAsync())
                .Throws(new OpenApiNackException("AppReqGetDeviceInfoDetail is Nack", new OpenApiMessage(""), new OpenApiMessage(nack)));

            var animationController = new AnimationsController(_logger, null, _animationOperatorMock.Object, null);
            var response = animationController.GetAnimationRomVersion();

            Assert.Equal((int)HttpStatusCode.InternalServerError, ((ObjectResult)response.Result).StatusCode);
            _animationOperatorMock.VerifyAll();
        }

        [Fact]
        public void GetAnimationRom_WhenAnimationOperatorReturnOpenApiNackExceptionWithAck_ExpectInternalServerError()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("<AppResGetDeviceInfoDetail>");
            sb.AppendLine("   <Result>");
            sb.AppendLine("      <ResultInfo>Ack</ResultInfo>");
            sb.AppendLine("   </Result>");
            sb.AppendLine("   <RequestItem>Version</RequestItem>");
            sb.AppendLine("   <VersionList>");
            sb.AppendLine("      <ArraySize>45</ArraySize>");
            sb.AppendLine("         <Version>");
            sb.AppendLine("            <Name>MFP Card Version</Name>");
            sb.AppendLine("            <Code>FW0003</Code>");
            sb.AppendLine("         </Version>");
            sb.AppendLine("         <Version>");
            sb.AppendLine("            <Name>Movie Data</Name>");
            sb.AppendLine("         </Version>");
            sb.AppendLine("         <Version>");
            sb.AppendLine("            <Name>MFP Controller PIC</Name>");
            sb.AppendLine("            <Code>A7970Y08200F0083</Code>");
            sb.AppendLine("         </Version>");
            sb.AppendLine("   </VersionList>");
            sb.AppendLine("</AppResGetDeviceInfoDetail>");

            _animationOperatorMock.Setup(m => m.GetAnimationRomVersionAsync())
                .Throws(
                    new OpenApiNackException(
                        "AppReqGetDeviceInfoDetail is Empty",
                        new OpenApiMessage(""),
                        new OpenApiMessage(sb.ToString())));

            var animationController = new AnimationsController(_logger, null, _animationOperatorMock.Object, null);
            var response = animationController.GetAnimationRomVersion();

            Assert.Equal((int)HttpStatusCode.InternalServerError, ((ObjectResult)response.Result).StatusCode);
            _animationOperatorMock.VerifyAll();
        }

        [Fact]
        public async Task GetAnimationRomVersion_WhenValidData_ExpectSuccess()
        {
            var version = "A7970Y0C000G0000";
            var serial = "A798001000003";
            var returnData = "{\"animation_rom_version\":\"" + version + "\",\"serial_number\":\"" + serial + "\"}";

            _animationOperatorMock.Setup(m => m.GetAnimationRomVersionAsync()).ReturnsAsync(version);
            _deviceInfoOperatorMock.Setup(m => m.GetSerialNumberAsync()).ReturnsAsync(serial);

            var animationController = new AnimationsController(_logger, null, _animationOperatorMock.Object, _deviceInfoOperatorMock.Object);
            var response = await animationController.GetAnimationRomVersion();
            var resResult = (ObjectResult)response;

            Assert.Equal((int)HttpStatusCode.OK, resResult.StatusCode);
            var result = JsonConvert.SerializeObject(resResult.Value);

            Assert.Equal(returnData, result);
            _deviceInfoOperatorMock.VerifyAll();
            _animationOperatorMock.VerifyAll();
        }

        [Fact]
        public void GetAnimationRomVersion_WhenDeviceInfoOperatorNack_ExpectInternalServerError()
        {
            var version = "A7970Y0C000G0000";
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("<Result>");
            sb.AppendLine("  <ResultInfo>Nack</ResultInfo>");
            sb.AppendLine("  <FaultRequest>AppReqGetDeviceInfoDetail</FaultRequest>");
            sb.AppendLine("  <ErrorDetails>Error details</ErrorDetails>");
            sb.AppendLine("  <ErrorDescription>Error description</ErrorDescription>");
            sb.AppendLine("</Result >");

            _animationOperatorMock.Setup(m => m.GetAnimationRomVersionAsync()).ReturnsAsync(version);
            _deviceInfoOperatorMock.Setup(m => m.GetSerialNumberAsync())
                .Throws(new OpenApiNackException("AppReqGetDeviceInfoDetail is Nack", new OpenApiMessage(""), new OpenApiMessage(sb.ToString())));

            var animationController = new AnimationsController(_logger, null, _animationOperatorMock.Object, _deviceInfoOperatorMock.Object);
            var response = animationController.GetAnimationRomVersion();

            Assert.Equal((int)HttpStatusCode.InternalServerError, ((ObjectResult)response.Result).StatusCode);
            _deviceInfoOperatorMock.VerifyAll();
            _animationOperatorMock.VerifyAll();
        }

        [Fact]
        public void GetAnimationRomVersion_WhenDeviceInfoOperatorNackExceptionWithAck_ExpectInternalServerError()
        {
            var version = "A7970Y0C000G0000";
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("<AppResGetDeviceInfoDetail>");
            sb.AppendLine("	<Result>");
            sb.AppendLine("		<ResultInfo>Ack</ResultInfo>");
            sb.AppendLine("	</Result>");
            sb.AppendLine("	<RequestItem>System</RequestItem>");
            sb.AppendLine("	<System>");
            sb.AppendLine("		<ProductName>KONICA MINOLTA bizhub C227</ProductName>");
            sb.AppendLine("		<ProductID>1.3.6.1.4.1.18334.1.1.1.2.1.133.2.6</ProductID>");
            sb.AppendLine("		<DeviceID />");
            sb.AppendLine("		<Oem>false</Oem>");
            sb.AppendLine("		<ExternalIfMode>None</ExternalIfMode>");
            sb.AppendLine("		<ControllerInfoList>");
            sb.AppendLine("			<ArraySize>1</ArraySize>");
            sb.AppendLine("			<ControllerInfo>");
            sb.AppendLine("				<Type>Printer</Type>");
            sb.AppendLine("				<Name>KONICA MINOLTA bizhub C227</Name>");
            sb.AppendLine("				<Version>A7970Y0-3000-G00-M0</Version>");
            sb.AppendLine("			</ControllerInfo>");
            sb.AppendLine("		</ControllerInfoList>");
            sb.AppendLine("		<SupportFunction>");
            sb.AppendLine("			<Copy>true</Copy>");
            sb.AppendLine("			<Print>true</Print>");
            sb.AppendLine("			<Scan>true</Scan>");
            sb.AppendLine("			<Fax>false</Fax>");
            sb.AppendLine("			<Fax2>false</Fax2>");
            sb.AppendLine("			<Fax3>Off</Fax3>");
            sb.AppendLine("			<Fax4>Off</Fax4>");
            sb.AppendLine("			<SipAdapter>false</SipAdapter>");
            sb.AppendLine("			<Ifax>false</Ifax>");
            sb.AppendLine("			<IpAddressFax>Off</IpAddressFax>");
            sb.AppendLine("			<JobNumberDisplayFunc>On</JobNumberDisplayFunc>");
            sb.AppendLine("			<UsbHostBoard>On</UsbHostBoard>");
            sb.AppendLine("			<Dsc>Off</Dsc>");
            sb.AppendLine("			<Dsc2>Off</Dsc2>");
            sb.AppendLine("			<Bluetooth>Off</Bluetooth>");
            sb.AppendLine("			<DualScan>Off</DualScan>");
            sb.AppendLine("			<InternalWebServer>On</InternalWebServer>");
            sb.AppendLine("			<CustomDocumentMode>Off</CustomDocumentMode>");
            sb.AppendLine("			<ExpansionNetworkAdapter>Off</ExpansionNetworkAdapter>");
            sb.AppendLine("			<DsBoard>Off</DsBoard>");
            sb.AppendLine("			<SlidePanel>Off</SlidePanel>");
            sb.AppendLine("			<AllowIPFilterSetting>On</AllowIPFilterSetting>");
            sb.AppendLine("			<BillingCounter>Off</BillingCounter>");
            sb.AppendLine("			<PowerSaveTimeUpperLimitChange>On</PowerSaveTimeUpperLimitChange>");
            sb.AppendLine("			<TxReportImageAttach>On</TxReportImageAttach>");
            sb.AppendLine("			<NetworkIf>SingleWired</NetworkIf>");
            sb.AppendLine("			<TouchPanel>ResistanceFilmMulti</TouchPanel>");
            sb.AppendLine("		</SupportFunction>");
            sb.AppendLine("		<GeneralContact>");
            sb.AppendLine("			<SiteName>KONICA MINOLTA Customer Support</SiteName>");
            sb.AppendLine("			<Info />");
            sb.AppendLine("			<ProductHelpUrl>http://pagescope.com</ProductHelpUrl>");
            sb.AppendLine("			<CorpUrl>http://konicaminolta.com</CorpUrl>");
            sb.AppendLine("			<SupplyInfo />");
            sb.AppendLine("			<PhoneNumber />");
            sb.AppendLine("			<EmailAddress />");
            sb.AppendLine("			<UtilityLink />");
            sb.AppendLine("			<OnlineHelpUrl>http://www.pagescope.com/download/webconnection/onlinehelp/C227/help.html</OnlineHelpUrl>");
            sb.AppendLine("			<DriverUrl />");
            sb.AppendLine("		</GeneralContact>");
            sb.AppendLine("		<UserContact>");
            sb.AppendLine("			<Contact />");
            sb.AppendLine("			<Name />");
            sb.AppendLine("			<Location />");
            sb.AppendLine("			<InternalNumber />");
            sb.AppendLine("		</UserContact>");
            sb.AppendLine("		<Time>");
            sb.AppendLine("			<Year>2017</Year>");
            sb.AppendLine("			<Month>4</Month>");
            sb.AppendLine("			<Day>3</Day>");
            sb.AppendLine("			<Hour>11</Hour>");
            sb.AppendLine("			<Minute>44</Minute>");
            sb.AppendLine("			<Second>39</Second>");
            sb.AppendLine("			<TimeZone2>");
            sb.AppendLine("				<GmtDirection>East</GmtDirection>");
            sb.AppendLine("				<Hour>9</Hour>");
            sb.AppendLine("				<Minute>0</Minute>");
            sb.AppendLine("			</TimeZone2>");
            sb.AppendLine("		</Time>");
            sb.AppendLine("	</System>");
            sb.AppendLine("</AppResGetDeviceInfoDetail>");

            _animationOperatorMock.Setup(m => m.GetAnimationRomVersionAsync()).ReturnsAsync(version);
            _deviceInfoOperatorMock.Setup(m => m.GetSerialNumberAsync())
                .Throws(new OpenApiNackException("AppReqGetDeviceInfoDetail is Empty", new OpenApiMessage(""), new OpenApiMessage(sb.ToString())));

            var animationController = new AnimationsController(_logger, null, _animationOperatorMock.Object, _deviceInfoOperatorMock.Object);
            var response = animationController.GetAnimationRomVersion();

            Assert.Equal((int)HttpStatusCode.InternalServerError, ((ObjectResult)response.Result).StatusCode);
            _deviceInfoOperatorMock.VerifyAll();
            _animationOperatorMock.VerifyAll();
        }
    }
}
