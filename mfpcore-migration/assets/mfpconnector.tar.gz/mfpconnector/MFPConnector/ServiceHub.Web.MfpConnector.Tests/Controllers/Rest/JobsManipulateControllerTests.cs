using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

using Moq;
using Newtonsoft.Json;
using ServiceHub.Common.Settings;
using ServiceHub.Connectors.OpenAPI.Exceptions;
using ServiceHub.Processors.Job;
using ServiceHub.Processors.Job.Model;
using ServiceHub.Web.MfpConnector.Controllers.Rest.Jobs;
using ServiceHub.Web.MfpConnector.Controllers.Rest.Model;
using Xunit;

namespace ServiceHub.Web.MfpConnector.Tests.Controllers.Rest
{
    [Trait("JobsManipulateController", "Unit")]
    public class JobsManipulateControllerTests : RestControllerTestsBase
    {
        private const string JobIdNormal = "22635";
        private const string JobIdNormal2 = "226356";
        private const string JobIdNegative = "-1";
        private const string JobIdSymbol = "@#$";
        private const string JobIdWhiteSpace = " ";
        private Mock<IJobRedialSender> _jobRedialSenderMock;

        private readonly JobsManipulateRequest _restartRequestNormal = new JobsManipulateRequest
        {
            Mode = Mode.RESTART,
            AuthParameter = new AuthParameter
            {
                Code = "testcode",
            }
        };
        private readonly JobsManipulateRequest _redialRequestNormal = new JobsManipulateRequest
        {
            Mode = Mode.REDIAL,
            AuthParameter = new AuthParameter
            {
                Code = "testcode",
            }
        };

        private readonly CallBackJobResult _jobResultOk = new CallBackJobResult
        {
            Result = "OK"
        };

        private readonly ILogger<JobsManipulateController> _logger;

        private readonly int _pushTimeout;
        private readonly Mock<IJobOperator> _jobOperatorMock;

        public JobsManipulateControllerTests()
        {
            _logger = Mock.Of<ILogger<JobsManipulateController>>();
            _pushTimeout = MfpConnectorSetting.Iws.CurrentSetting.CallbackTimeout;

            _jobOperatorMock = new Mock<IJobOperator>(MockBehavior.Strict);
            _jobRedialSenderMock = new Mock<IJobRedialSender>(MockBehavior.Strict);
        }

        [Fact]
        public void Manipulate_WhenRestartNormal_ExpectSuccess()
        {
            // Prepare
            _jobOperatorMock.Setup(m => m.RestartJobAsync(JobIdNormal, It.IsAny<string>())).Returns(Task.FromResult(true));

            // Execute
            var jobsManipulateController = new JobsManipulateController(_logger, null, null, _jobOperatorMock.Object);
            var response = jobsManipulateController.Manipulate(JobIdNormal, _restartRequestNormal);
            var result = (ObjectResult)response.Result;

            // Validate
            var expected = new JobsManipulateControllerResult
            {
                Success = true,
            };
            Assert.Equal((int)HttpStatusCode.OK, result.StatusCode);
            Assert.Equal(JsonConvert.SerializeObject(expected), JsonConvert.SerializeObject(result.Value));
            _jobOperatorMock.VerifyAll();
        }

        [Fact]
        public void Manipulate_WhenRestartRequestAndJobOperatorUnreachable_ExpectBadRequest()
        {
            // Prepare
            _jobOperatorMock.Setup(m => m.RestartJobAsync(JobIdNormal, It.IsAny<string>()))
                .Throws(new OpenApiRequestException(OpenApiResultStatus.ConnectError, "Connect error."));

            // Execute
            var jobsManipulateController = new JobsManipulateController(_logger, null, null, _jobOperatorMock.Object);
            var response = jobsManipulateController.Manipulate(JobIdNormal, _restartRequestNormal);
            var result = (ObjectResult)response.Result;

            // Validate
            var expected = new JobsManipulateControllerResult
            {
                Success = false
            };

            Assert.Equal((int)HttpStatusCode.BadRequest, result.StatusCode);
            Assert.Equal(JsonConvert.SerializeObject(expected), JsonConvert.SerializeObject(result.Value));
            _jobOperatorMock.VerifyAll();
        }

        [Fact]
        public void Manipulate_WhenRestartAndJobOperatorNack_ExpectBadRequest()
        {
            // Prepare
            _jobOperatorMock.Setup(m => m.RestartJobAsync(JobIdNormal, It.IsAny<string>()))
                .Throws(new KonicaMinolta.OpenApi.OpenApiNackException(string.Empty));

            // Execute
            var jobsManipulateController = new JobsManipulateController(_logger, null, null, _jobOperatorMock.Object);
            var response = jobsManipulateController.Manipulate(JobIdNormal, _restartRequestNormal);
            var result = (ObjectResult)response.Result;

            var expected = new JobsManipulateControllerResult
            {
                Success = false
            };

            // Validate
            Assert.Equal((int)HttpStatusCode.BadRequest, result.StatusCode);
            Assert.Equal(JsonConvert.SerializeObject(expected), JsonConvert.SerializeObject(result.Value));
            _jobOperatorMock.VerifyAll();
        }

        [Fact]
        public void Manipulate_WhenJobRequestHasNullValue_ExpectBadRequest()
        {
            // Execute
            var jobsManipulateController = new JobsManipulateController(_logger, null, null, null);
            var response = jobsManipulateController.Manipulate(JobIdNormal, null);
            var result = (ObjectResult)response.Result;

            // Validate
            var expected = new JobsManipulateControllerResult()
            {
                Success = false
            };

            Assert.Equal((int)HttpStatusCode.BadRequest, result.StatusCode);
            Assert.Equal(JsonConvert.SerializeObject(expected), JsonConvert.SerializeObject(result.Value));
        }

        [Fact]
        public void Manipulate_WhenRestartRequestHasJobIdOutOfRange_ExpectBadRequest()
        {
            // Prepare
            _jobOperatorMock.Setup(m => m.RestartJobAsync(JobIdNegative, It.IsAny<string>()))
                .Throws(new KonicaMinolta.OpenApi.OpenApiNackException(string.Empty));

            // Execute
            var jobsManipulateController = new JobsManipulateController(_logger, null, null, _jobOperatorMock.Object);
            var response = jobsManipulateController.Manipulate(JobIdNegative, _restartRequestNormal);
            var result = (ObjectResult)response.Result;

            // Validate
            var expected = new JobsManipulateControllerResult()
            {
                Success = false
            };

            Assert.Equal((int)HttpStatusCode.BadRequest, result.StatusCode);
            Assert.Equal(JsonConvert.SerializeObject(expected), JsonConvert.SerializeObject(result.Value));
            _jobOperatorMock.VerifyAll();
        }

        [Fact]
        public void Manipulate_WhenRestartRequestHasJobIdInvalid_ExpectBadRequest()
        {
            // Prepare
            _jobOperatorMock.Setup(m => m.RestartJobAsync(JobIdSymbol, It.IsAny<string>()))
                .Throws(new KonicaMinolta.OpenApi.OpenApiNackException(string.Empty));

            // Execute
            var jobsManipulateController = new JobsManipulateController(_logger, null, null, _jobOperatorMock.Object);
            var response = jobsManipulateController.Manipulate(JobIdSymbol, _restartRequestNormal);
            var result = (ObjectResult)response.Result;

            // Validate
            var expected = new JobsManipulateControllerResult()
            {
                Success = false
            };

            Assert.Equal((int)HttpStatusCode.BadRequest, result.StatusCode);
            Assert.Equal(JsonConvert.SerializeObject(expected), JsonConvert.SerializeObject(result.Value));
            _jobOperatorMock.VerifyAll();
        }

        [Fact]
        public void Manipulate_WhenRestartRequestHasJobIdWhiteSpace_ExpectBadRequest()
        {
            // Prepare
            _jobOperatorMock.Setup(m => m.RestartJobAsync(JobIdWhiteSpace, It.IsAny<string>())).Throws(new KonicaMinolta.OpenApi.OpenApiNackException(""));

            // Execute
            var jobsManipulateController = new JobsManipulateController(_logger, null, null, _jobOperatorMock.Object);
            var response = jobsManipulateController.Manipulate(JobIdWhiteSpace, _restartRequestNormal);
            var result = (ObjectResult)response.Result;

            // Validate
            var expected = new JobsManipulateControllerResult
            {
                Success = false
            };

            Assert.Equal((int)HttpStatusCode.BadRequest, result.StatusCode);
            Assert.Equal(JsonConvert.SerializeObject(expected), JsonConvert.SerializeObject(result.Value));
            _jobOperatorMock.VerifyAll();
        }

        [Fact]
        public void Manipulate_WhenRedialRequest_ExpetSuccess()
        {
            // Prepare
            _jobRedialSenderMock.Setup(m => m.SendToMfp());
            _jobRedialSenderMock.SetupSet(m => m.Parameter = It.IsAny<string>());

            // Execute
            var jobsManipulateController = new JobsManipulateController(_logger, MfpConnectorSetting, _jobRedialSenderMock.Object, null);

            // Note: Fake waiting because we have a static variable that gets updated in between.
            Task.Factory.StartNew(async () =>
            {
                await Task.Delay(_pushTimeout / 2);
            }).ContinueWith((task) => jobsManipulateController.RedialCallback(JobIdNormal, _jobResultOk));

            var response = jobsManipulateController.Manipulate(JobIdNormal, _redialRequestNormal);
            var result = (ObjectResult)response.Result;

            // Validate
            var expected = new JobsManipulateControllerResult()
            {
                Success = true
            };

            Assert.Equal((int)HttpStatusCode.OK, result.StatusCode);
            Assert.Equal(JsonConvert.SerializeObject(expected), JsonConvert.SerializeObject(result.Value));
            _jobRedialSenderMock.VerifyAll();
        }

        [Fact]
        public void Manipulate_WhenRedialRequestHasInvalidState_ExpectBadRequest()
        {
            // Prepare
            _jobRedialSenderMock.Setup(m => m.SendToMfp());
            _jobRedialSenderMock.SetupSet(m => m.Parameter = It.IsAny<string>());

            // Execute
            var jobsManipulateController = new JobsManipulateController(_logger, MfpConnectorSetting, _jobRedialSenderMock.Object, null);
            Task.Factory.StartNew(async () =>
                {
                    await Task.Delay(_pushTimeout / 2);
                }).ContinueWith((task) => jobsManipulateController.RedialCallback(JobIdNormal, new CallBackJobResult()
                {
                    Result = "NG",
                    Error = "MFP_INVALID_STATE"
                }));

            var response = jobsManipulateController.Manipulate(JobIdNormal, _redialRequestNormal);
            var result = (ObjectResult)response.Result;

            // Validate
            var expected = new JobsManipulateControllerResult()
            {
                Success = false
            };

            Assert.Equal((int)HttpStatusCode.BadRequest, result.StatusCode);
            Assert.Equal(JsonConvert.SerializeObject(expected), JsonConvert.SerializeObject(result.Value));
            _jobRedialSenderMock.VerifyAll();
        }

        [Fact]
        public void Manipulate_WhenRedialRequestHasNotWaitJobRedial_ExpectBadRequest()
        {
            // Prepare
            _jobRedialSenderMock.Setup(m => m.SendToMfp());
            _jobRedialSenderMock.SetupSet(m => m.Parameter = It.IsAny<string>());

            // Execute
            var jobsManipulateController = new JobsManipulateController(_logger, MfpConnectorSetting, _jobRedialSenderMock.Object, null);
            Task.Factory.StartNew(async () =>
            {
                await Task.Delay(_pushTimeout * 2);
            });

            var response = jobsManipulateController.Manipulate(JobIdNormal, _redialRequestNormal);
            var result = (ObjectResult)response.Result;

            // Validate
            var expected = new JobsManipulateControllerResult()
            {
                Success = false
            };

            Assert.Equal((int)HttpStatusCode.BadRequest, result.StatusCode);
            Assert.Equal(JsonConvert.SerializeObject(expected), JsonConvert.SerializeObject(result.Value));
            _jobRedialSenderMock.VerifyAll();
        }

        [Fact]
        public void Manipulate_WhenRedialRequestIsNullValue_ExpectBadRequest()
        {
            // Execute
            var jobsManipulateController = new JobsManipulateController(_logger, MfpConnectorSetting, null, null);
            Task.Factory.StartNew(async () =>
            {
                await Task.Delay(_pushTimeout / 2);
            }).ContinueWith((task) => jobsManipulateController.RedialCallback(JobIdNormal, null));

            var response = jobsManipulateController.Manipulate(JobIdNormal, null);
            var result = (ObjectResult)response.Result;

            // Validate
            var expected = new JobsManipulateControllerResult()
            {
                Success = false
            };

            Assert.Equal((int)HttpStatusCode.BadRequest, result.StatusCode);
            Assert.Equal(JsonConvert.SerializeObject(expected), JsonConvert.SerializeObject(result.Value));
        }

        [Fact]
        public void Manipulate_WhenRedialRequestHasNotExistingJobId_ExpectBadRequest()
        {
            // Prepare
            _jobRedialSenderMock.Setup(m => m.SendToMfp());
            _jobRedialSenderMock.SetupSet(m => m.Parameter = It.IsAny<string>());

            // Execute
            var jobsManipulateController = new JobsManipulateController(_logger, MfpConnectorSetting, _jobRedialSenderMock.Object, null);

            Task.Factory.StartNew(async () =>
            {
                await Task.Delay(_pushTimeout / 2);
            }).ContinueWith((task) => jobsManipulateController.RedialCallback(JobIdNormal, new CallBackJobResult()
            {
                Result = "NG",
                Error = "MFP_INVALID_STATE"
            }));

            var response = jobsManipulateController.Manipulate(JobIdNormal2, _redialRequestNormal);
            var result = (ObjectResult)response.Result;

            // Validate
            var expected = new JobsManipulateControllerResult()
            {
                Success = false
            };

            Assert.Equal((int)HttpStatusCode.BadRequest, result.StatusCode);
            Assert.Equal(JsonConvert.SerializeObject(expected), JsonConvert.SerializeObject(result.Value));
            _jobRedialSenderMock.VerifyAll();
        }

        [Fact]
        public void Manipulate_WhenRedialRequestHasJobIdOutOfRange_ExpectBadRequest()
        {
            // Prepare 
            _jobRedialSenderMock.Setup(m => m.SendToMfp());
            _jobRedialSenderMock.SetupSet(m => m.Parameter = It.IsAny<string>());

            // Execute
            var jobsManipulateController = new JobsManipulateController(_logger, MfpConnectorSetting, _jobRedialSenderMock.Object, null);
            Task.Factory.StartNew(async () =>
            {
                await Task.Delay(_pushTimeout / 2);
            }).ContinueWith((task) => jobsManipulateController.RedialCallback(
                JobIdNormal,
                new CallBackJobResult
                {
                    Result = "MG",
                    Error = "TYPE_ERROR"
                }
            ));

            var response = jobsManipulateController.Manipulate(JobIdNegative, _redialRequestNormal);
            var result = (ObjectResult)response.Result;

            // Validate
            var expected = new JobsManipulateControllerResult()
            {
                Success = false
            };

            Assert.Equal((int)HttpStatusCode.BadRequest, result.StatusCode);
            Assert.Equal(JsonConvert.SerializeObject(expected), JsonConvert.SerializeObject(result.Value));
            _jobRedialSenderMock.VerifyAll();
        }

        [Fact]
        public void Manipulate_WhenRedialRequestHasJobIdInvalid_ExpectBadRequest()
        {
            // Prepare
            _jobRedialSenderMock.Setup(m => m.SendToMfp());
            _jobRedialSenderMock.SetupSet(m => m.Parameter = It.IsAny<string>());

            // Execute
            var jobsManipulateController = new JobsManipulateController(_logger, MfpConnectorSetting, _jobRedialSenderMock.Object, null);
            Task.Factory.StartNew(async () =>
            {
                await Task.Delay(_pushTimeout / 2);
            }).ContinueWith((task) => jobsManipulateController.RedialCallback(JobIdSymbol, new CallBackJobResult()
            {
                Result = "NG",
                Error = "TYPE_ERROR"
            }));

            var response = jobsManipulateController.Manipulate(JobIdSymbol, _redialRequestNormal);
            var result = (ObjectResult)response.Result;

            // Validate
            var expected = new JobsManipulateControllerResult
            {
                Success = false
            };

            Assert.Equal((int)HttpStatusCode.BadRequest, result.StatusCode);
            Assert.Equal(JsonConvert.SerializeObject(expected), JsonConvert.SerializeObject(result.Value));
            _jobRedialSenderMock.VerifyAll();
        }

        [Fact]
        public void Manipulate_WhenRedialRequestHasJobIdWhiteSpace_ExpectBadRequest()
        {
            // Prepare
            _jobRedialSenderMock.Setup(m => m.SendToMfp());
            _jobRedialSenderMock.SetupSet(m => m.Parameter = It.IsAny<string>());

            // Execute
            var jobsManipulateController = new JobsManipulateController(_logger, MfpConnectorSetting, _jobRedialSenderMock.Object, null);
            Task.Factory.StartNew(async () =>
            {
                await Task.Delay(_pushTimeout / 2);
            }).ContinueWith((task) => jobsManipulateController.RedialCallback(JobIdWhiteSpace, new CallBackJobResult()
            {
                Result = "NG",
                Error = "TYPE_ERROR"
            }));

            var response = jobsManipulateController.Manipulate(JobIdWhiteSpace, _redialRequestNormal);
            var result = (ObjectResult)response.Result;

            // Validate
            var expected = new JobsManipulateControllerResult
            {
                Success = false
            };

            Assert.Equal((int)HttpStatusCode.BadRequest, result.StatusCode);
            Assert.Equal(JsonConvert.SerializeObject(expected), JsonConvert.SerializeObject(result.Value));
            _jobRedialSenderMock.VerifyAll();
        }
    }
}
