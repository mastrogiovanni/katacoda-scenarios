using System;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using Newtonsoft.Json;
using ServiceHub.Connectors.OpenAPI;
using ServiceHub.Processors.Setup;
using ServiceHub.Web.MfpConnector.Controllers.Rest;
using ServiceHub.Web.MfpConnector.Controllers.Rest.Model;
using Xunit;

namespace ServiceHub.Web.MfpConnector.Tests.Controllers.Rest
{
    [Trait("MfpFirmwareController", "Unit")]
    public class MfpFirmwareControllerTests : RestControllerTestsBase
    {
        private readonly ILogger<MfpFirmwareController> _logger;
        private readonly Mock<IOpenApiController> _mockOap;
        private readonly Mock<IFirmwareOperator> _mockFirmwareOperator;
        private readonly MfpFirmwareControllerResponse _MfpFirmwareControllerResponse
            = new MfpFirmwareControllerResponse()
        {
            Filename = "DummyFileName"
        };

        public MfpFirmwareControllerTests()
        {
            _logger = Mock.Of<ILogger<MfpFirmwareController>>();
            _mockOap = new Mock<IOpenApiController>(MockBehavior.Strict);
            _mockFirmwareOperator = new Mock<IFirmwareOperator>(MockBehavior.Strict);
        }

        [Fact]
        public async Task Download_WhenValidData_ExpectSuccessWithOK()
        {
            // Prepare
            var firmwareDetails = new MfpFirmwareControllerResponse() { Filename = "FirmwareFilename" };
            _mockFirmwareOperator.Setup(m => m.LetDownloadMfpFirmwareAsync(firmwareDetails.Filename)).ReturnsAsync(true);

            // Execute
            var mfpFirmwareController = new MfpFirmwareController(_logger, null, _mockFirmwareOperator.Object);
            var rsp = (ObjectResult)await mfpFirmwareController.Download(firmwareDetails);

            // Validate
            var expected = new MfpFirmwareControllerResult { Result = "OK" };

            Assert.Equal((int)HttpStatusCode.Created, rsp.StatusCode);
            Assert.Equal(JsonConvert.SerializeObject(expected), JsonConvert.SerializeObject(rsp.Value));
            _mockFirmwareOperator.VerifyAll();
        }

        [Fact]
        public async Task Download_WhenExceptionWhileDownloading_ExpectInternalServerErrorWithNG()
        {
            // Prepare
            var firmwareDetails = new MfpFirmwareControllerResponse() { Filename = "FirmwareFilename" };

            _mockFirmwareOperator.Setup(m => m.LetDownloadMfpFirmwareAsync(firmwareDetails.Filename))
                .Throws(new Exception("Download cancelled")); // TODO put the proper exception when cancelling

            // Execute
            var mfpFirmwareController = new MfpFirmwareController(_logger, null, _mockFirmwareOperator.Object);
            var rsp = (ObjectResult)await mfpFirmwareController.Download(firmwareDetails);

            // Validate
            var expected = new MfpFirmwareControllerResult { Result = "NG" };

            Assert.Equal((int)HttpStatusCode.InternalServerError, rsp.StatusCode);
            Assert.Equal(JsonConvert.SerializeObject(expected), JsonConvert.SerializeObject(rsp.Value));
            _mockFirmwareOperator.VerifyAll();
        }

        [Fact]
        public async Task Download_WhenIssueDownloading_ExpectInternalServerErrorWithNG()
        {
            // Prepare
            var firmwareDetails = new MfpFirmwareControllerResponse() { Filename = "FirmwareFilename" };

            _mockFirmwareOperator.Setup(m => m.LetDownloadMfpFirmwareAsync(firmwareDetails.Filename))
                .ReturnsAsync(false); // Usually return false instead of throws exception

            // Execute
            var mfpFirmwareController = new MfpFirmwareController(_logger, null, _mockFirmwareOperator.Object);
            var rsp = (ObjectResult)await mfpFirmwareController.Download(firmwareDetails);

            // Validate
            var expected = new MfpFirmwareControllerResult { Result = "NG" };

            Assert.Equal((int)HttpStatusCode.InternalServerError, rsp.StatusCode);
            Assert.Equal(JsonConvert.SerializeObject(expected), JsonConvert.SerializeObject(rsp.Value));
            _mockFirmwareOperator.VerifyAll();
        }

        [Fact]
        public async Task Update_WhenValidData_ExpectCreated()
        {
            // Prepare
            _mockFirmwareOperator.Setup(m => m.UpdateFirmwareAsync()).ReturnsAsync(true);

            // Execute
            var mfpFirmwareController = new MfpFirmwareController(_logger, null, _mockFirmwareOperator.Object);
            var rsp = (ObjectResult)await mfpFirmwareController.Update();

            // Validate
            var expected = new MfpFirmwareControllerResult { Result = "OK" };

            Assert.Equal((int)HttpStatusCode.Created, rsp.StatusCode); // Should be a 204 - No Content instead of Created
            Assert.Equal(JsonConvert.SerializeObject(expected), JsonConvert.SerializeObject(rsp.Value));
            _mockFirmwareOperator.VerifyAll();
        }

        [Fact]
        public async Task Update_WhenNack_ExpectInternalServerErrorWithNG()
        {
            // Prepare
            // Nack returns false
            _mockFirmwareOperator.Setup(m => m.UpdateFirmwareAsync()).ReturnsAsync(false);

            // Execute
            var mfpFirmwareController = new MfpFirmwareController(_logger, null, _mockFirmwareOperator.Object);
            var rsp = (ObjectResult)await mfpFirmwareController.Update();

            // Validate
            var expected = new MfpFirmwareControllerResult { Result = "NG" };

            Assert.Equal((int)HttpStatusCode.InternalServerError, rsp.StatusCode);
            Assert.Equal(JsonConvert.SerializeObject(expected), JsonConvert.SerializeObject(rsp.Value));
            _mockFirmwareOperator.VerifyAll();
        }

        [Fact]
        public async Task Update_WhenFirmwareOperatorThrowException_ExpectInternalServerErrorWithNG()
        {
            // Prepare
            _mockOap.Setup(m => m.UpdateFirmwareAsync()).Throws(new Exception());
            _mockFirmwareOperator.Setup(m => m.UpdateFirmwareAsync()).Throws(new Exception("Some error"));

            // Execute
            var mfpFirmwareController = new MfpFirmwareController(_logger, null, _mockFirmwareOperator.Object);
            var rsp = (ObjectResult)await mfpFirmwareController.Update();

            // Validate
            var expected = new MfpFirmwareControllerResult { Result = "NG" };

            Assert.Equal((int)HttpStatusCode.InternalServerError, rsp.StatusCode);
            Assert.Equal(JsonConvert.SerializeObject(expected), JsonConvert.SerializeObject(rsp.Value));
            _mockFirmwareOperator.VerifyAll();
            _mockFirmwareOperator.VerifyAll();
        }

        [Fact]
        public async Task Download_WhenParameterNull_ExpectArgumentNullException()
        {
            // Execute
            var mfpFirmwareController = new MfpFirmwareController(_logger, null, _mockFirmwareOperator.Object);
            var result = await Assert.ThrowsAsync<ArgumentNullException>(async () => await mfpFirmwareController.Download(null));

            // Validate
            Assert.Equal("firmware", result.ParamName);
        }

        [Fact]
        public async Task Download_WhenTargetNameNull_ExpectArgumentNullException()
        {
            // Prepare
            _MfpFirmwareControllerResponse.Filename = null;

            // Execute
            var mfpFirmwareController = new MfpFirmwareController(_logger, null, _mockFirmwareOperator.Object);
            var result = await Assert.ThrowsAsync<ArgumentNullException>(async () => await mfpFirmwareController.Download(_MfpFirmwareControllerResponse));
            
            // Validate
            Assert.Equal("Filename", result.ParamName);
        }

        [Fact]
        public async Task Download_WhenTargetNameSpace_ExpectArgumentException()
        {
            // Prepare
            _MfpFirmwareControllerResponse.Filename = "";

            // Execute
            var mfpFirmwareController = new MfpFirmwareController(_logger, null, _mockFirmwareOperator.Object);
            var result = await Assert.ThrowsAsync<ArgumentException>(async () => await mfpFirmwareController.Download(_MfpFirmwareControllerResponse));

            // Validate
            Assert.Equal("Filename", result.ParamName);
        }
    }
}