using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

using Moq;
using ServiceHub.Common.DeviceState;
using ServiceHub.Web.MfpConnector.Controllers.Rest;
using ServiceHub.Web.MfpConnector.Controllers.Rest.Model;
using Xunit;

namespace ServiceHub.Web.MfpConnector.Tests.Controllers.Rest
{
    [Trait("AliveController", "Unit")]
    public class AliveControllerTests
    {
        private readonly ILogger<AliveController> _logger;
        private readonly Mock<IDeviceStateContext> _deviceStateContextMock;

        public AliveControllerTests()
        {
            _logger = Mock.Of<ILogger<AliveController>>();
            _deviceStateContextMock = new Mock<IDeviceStateContext>(MockBehavior.Strict);
        }

        [Fact]
        public void Get_WhenStateOfStartUp_ExpectAliveTrue()
        {
            _deviceStateContextMock.Setup(c => c.Usable).Returns(true); // Startup

            var aliveController = new AliveController(_logger, null, _deviceStateContextMock.Object);
            var res = aliveController.Get();
            Assert.Equal(200, ((ObjectResult)res).StatusCode);

            var stateResultExcept = new MfpStateResult
            {
                Alive = true,
            };
            var resBody = ((ObjectResult)res).Value;
            Assert.NotNull(resBody);
            Assert.Equal(stateResultExcept.Alive, ((MfpStateResult)resBody).Alive);

            _deviceStateContextMock.VerifyAll();
        }

        [Fact]
        public void Get_WhenStateOfStop_ExpetAliveFalse()
        {
            _deviceStateContextMock.Setup(c => c.Usable).Returns(false); // Stop

            var aliveController = new AliveController(_logger, null, _deviceStateContextMock.Object);
            var res = aliveController.Get();
            Assert.Equal(200, ((ObjectResult)res).StatusCode);

            var stateResultExcept = new MfpStateResult
            {
                Alive = false,
            };
            var resBody = ((ObjectResult)res).Value;
            Assert.NotNull(resBody);
            Assert.Equal(stateResultExcept.Alive, ((MfpStateResult)resBody).Alive);

            _deviceStateContextMock.VerifyAll();
        }
    }
}
