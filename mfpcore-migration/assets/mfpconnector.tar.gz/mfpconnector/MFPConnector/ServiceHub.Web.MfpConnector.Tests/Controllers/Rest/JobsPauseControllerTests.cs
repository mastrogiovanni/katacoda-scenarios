using System.Net;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

using Moq;
using Newtonsoft.Json;
using ServiceHub.Common.Settings;
using ServiceHub.Connectors.IWS;
using ServiceHub.Processors.Job;
using ServiceHub.Processors.Job.Model;
using ServiceHub.Web.MfpConnector.Controllers.Rest.Jobs;
using ServiceHub.Web.MfpConnector.Controllers.Rest.Model;
using Xunit;

namespace ServiceHub.Web.MfpConnector.Tests.Controllers.Rest
{
    [Trait("JobsPauseController", "Unit")]
    public class JobsPauseControllerTests : RestControllerTestsBase
    {
        private readonly JobsManipulateRequest _requestNormal = new JobsManipulateRequest
        {
            AuthParameter = new AuthParameter { Code = "testcode" }
        };

        private readonly CallBackJobResult _callBackResultOk = new CallBackJobResult { Result = "OK" };
        private readonly int _callbackTimeout;
        private readonly Mock<IJobPauseSender> _mockJobPauseSender;
        private readonly ILogger<JobsPauseController> _logger;

        public JobsPauseControllerTests()
        {
            _logger = Mock.Of<ILogger<JobsPauseController>>();
            _mockJobPauseSender = new Mock<IJobPauseSender>();
            _callbackTimeout = MfpConnectorSetting.Iws.CurrentSetting.CallbackTimeout;
        }

        [Fact]
        public void Pause_WhenPauseOk_ExpectSuccess()
        {
            // Prepare
            _mockJobPauseSender.Setup(m => m.SendToMfp());

            // Execute
            var jobsPauseController = new JobsPauseController(_logger, MfpConnectorSetting, _mockJobPauseSender.Object);
            Task.Factory.StartNew(async () =>
            {
                await Task.Delay(_callbackTimeout / 3);
            }).ContinueWith(task => jobsPauseController.PauseCallback(_callBackResultOk));

            var response = (ObjectResult)jobsPauseController.Pause(_requestNormal);

            // Validate
            var expected = new PauseAllJobsControllerResult
            {
                Success = true
            };

            Assert.Equal((int)HttpStatusCode.OK, response.StatusCode);
            Assert.Equal(JsonConvert.SerializeObject(expected), JsonConvert.SerializeObject(response.Value));
            _mockJobPauseSender.VerifyAll();
        }

        [Fact]
        public void Pause_WhenPauseSenderIsUnreachable_ExpectBadRequest()
        {
            // Prepare
            _mockJobPauseSender.Setup(m => m.SendToMfp()).Throws(new IwsException("NetworkConnectionError"));
            var expectedResult = new PauseAllJobsControllerResult()
            {
                Success = false,
                ErrorCode = "UNREACHABLE"
            };

            // Execute
            var jobsPauseController = new JobsPauseController(_logger, MfpConnectorSetting, _mockJobPauseSender.Object);
            var response = (ObjectResult)jobsPauseController.Pause(_requestNormal);

            // Validate
            Assert.Equal((int)HttpStatusCode.BadRequest, response.StatusCode);
            Assert.Equal(JsonConvert.SerializeObject(expectedResult), JsonConvert.SerializeObject(response.Value));
            _mockJobPauseSender.VerifyAll();
        }

        [Fact]
        public void Pause_WhenMfpInvalidState_ExpectBadRequest()
        {
            // Execute
            var jobsPauseController = new JobsPauseController(_logger, MfpConnectorSetting, _mockJobPauseSender.Object);

            Task.Factory.StartNew(async () =>
            {
                await Task.Delay(_callbackTimeout / 2);
            }).ContinueWith((task) => jobsPauseController.PauseCallback(new CallBackJobResult
            {
                Result = "NG",
                Error = "MFP_INVALID_STATE"
            }));

            var response = (ObjectResult)jobsPauseController.Pause(_requestNormal);

            // Validate
            var expected = new PauseAllJobsControllerResult()
            {
                Success = false,
                ErrorCode = "MFP_INVALID_STATE",
            };

            Assert.Equal((int)HttpStatusCode.BadRequest, response.StatusCode);
            Assert.Equal(JsonConvert.SerializeObject(expected), JsonConvert.SerializeObject(response.Value));
            _mockJobPauseSender.VerifyAll();
        }

        [Fact]
        public void Pause_WhenTimeout_ExpectBadRequest()
        {
            // Execute
            var jobsPauseController = new JobsPauseController(_logger, MfpConnectorSetting, _mockJobPauseSender.Object);
            Task.Factory.StartNew(async () =>
            {
                await Task.Delay(_callbackTimeout * 2);
            }).ContinueWith((task) => jobsPauseController.PauseCallback(new CallBackJobResult
            {
                Result = "NG",
                Error = "TIMEOUT"
            })).ConfigureAwait(false);

            var response = (ObjectResult)jobsPauseController.Pause(_requestNormal);

            // Validate
            var expected = new PauseAllJobsControllerResult
            {
                Success = false,
                ErrorCode = "TIMEOUT"
            };

            Assert.Equal((int)HttpStatusCode.BadRequest, response.StatusCode);
            Assert.Equal(JsonConvert.SerializeObject(expected), JsonConvert.SerializeObject(response.Value));
            _mockJobPauseSender.VerifyAll();
        }

        [Fact]
        public void Pause_WhenJsonFormatError_ExpectBadRequest()
        {
            // Execute
            var jobsPauseController = new JobsPauseController(_logger, null, null);
            Task.Factory.StartNew(async () =>
            {
                await Task.Delay(_callbackTimeout / 2);
            }).ContinueWith((task) => jobsPauseController.PauseCallback(null));

            var response = (ObjectResult)jobsPauseController.Pause(null);

            // Validate
            var expected = new PauseAllJobsControllerResult
            {
                Success = false,
                ErrorCode = "UNEXPECTED"
            };

            Assert.Equal((int)HttpStatusCode.BadRequest, response.StatusCode);
            Assert.Equal(JsonConvert.SerializeObject(expected), JsonConvert.SerializeObject(response.Value));
        }
    }
}
