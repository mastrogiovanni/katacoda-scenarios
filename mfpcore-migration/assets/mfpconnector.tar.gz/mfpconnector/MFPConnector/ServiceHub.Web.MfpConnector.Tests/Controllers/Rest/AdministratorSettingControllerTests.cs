using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

using Moq;
using ServiceHub.Connectors.OpenAPI.Exceptions;
using ServiceHub.Processors.Settings;
using ServiceHub.Processors.Settings.Model;
using ServiceHub.Web.MfpConnector.Controllers.Rest.Model;
using ServiceHub.Web.MfpConnector.Controllers.Rest.Settings;
using Xunit;

namespace ServiceHub.Web.MfpConnector.Tests.Controllers.Rest
{
    [Trait("AdminSettingsController", "Unit")]
    public class AdministratorSettingControllerTests
    {
        private readonly ILogger<AdminSettingsController> _logger;

        public AdministratorSettingControllerTests()
        {
            _logger = Mock.Of<ILogger<AdminSettingsController>>();
        }

        private static List<SettingValue> SetAllSettingValues()
        {
            var res = new List<SettingValue>();

            var settingValue = new SettingValue()
            {
                Success = true,
                Name = "Auth_ColorManage",
                Values = "<valueTest>",
            };
            res.Add(settingValue);

            settingValue = new SettingValue()
            {
                Success = true,
                Name = "Auth_NoAuthPrintOn",
                Values = "<valueTest>",
            };
            res.Add(settingValue);

            settingValue = new SettingValue()
            {
                Success = true,
                Name = "Auth_SendAddressLimit",
                Values = "<valueTest>",
            };
            res.Add(settingValue);

            settingValue = new SettingValue()
            {
                Success = true,
                Name = "Fax_DefaultSenders",
                Values = "<valueTest>",
            };
            res.Add(settingValue);

            settingValue = new SettingValue()
            {
                Success = true,
                Name = "Fax_DialType",
                Values = "<valueTest>",
            };
            res.Add(settingValue);

            settingValue = new SettingValue()
            {
                Success = true,
                Name = "Fax_ReceiveOnSettings",
                Values = "<valueTest>",
            };
            res.Add(settingValue);

            settingValue = new SettingValue()
            {
                Success = true,
                Name = "Fax_DataProtectType",
                Values = "<valueTest>",
            };
            res.Add(settingValue);

            settingValue = new SettingValue()
            {
                Success = true,
                Name = "Fax_SendAuthPassword",
                Values = "<valueTest>",
            };
            res.Add(settingValue);

            settingValue = new SettingValue()
            {
                Success = true,
                Name = "Security_SendProhibit",
                Values = "<valueTest>",
            };
            res.Add(settingValue);

            settingValue = new SettingValue()
            {
                Success = true,
                Name = "SysConn_PrefixSuffix",
                Values = "<valueTest>",
            };
            res.Add(settingValue);

            settingValue = new SettingValue()
            {
                Success = true,
                Name = "Oplevel_OriginalSizeAutoDetectByUser",
                Values = "<valueTest>",
            };
            res.Add(settingValue);

            settingValue = new SettingValue()
            {
                Success = true,
                Name = "IFax_IsEnable",
                Values = "<valueTest>",
            };
            res.Add(settingValue);

            settingValue = new SettingValue()
            {
                Success = true,
                Name = "Scan_OcrLanguage",
                Values = "<valueTest>",
            };
            res.Add(settingValue);

            settingValue = new SettingValue()
            {
                Success = true,
                Name = "Scan_Pdf_A",
                Values = "<valueTest>",
            };
            res.Add(settingValue);

            settingValue = new SettingValue()
            {
                Success = true,
                Name = "Scan_LinearizedPdfg",
                Values = "<valueTest>",
            };
            res.Add(settingValue);

            settingValue = new SettingValue()
            {
                Success = true,
                Name = "Scan_is_enable_ocr",
                Values = "<valueTest>",
            };
            res.Add(settingValue);

            settingValue = new SettingValue()
            {
                Success = true,
                Name = "Scan_IsEnablePdf_A",
                Values = "<valueTest>",
            };
            res.Add(settingValue);

            settingValue = new SettingValue()
            {
                Success = true,
                Name = "Scan_IsEnableLinearizedPdf",
                Values = "<valueTest>",
            };
            res.Add(settingValue);

            settingValue = new SettingValue()
            {
                Success = true,
                Name = "Scan_FileNameAddString",
                Values = "<valueTest>",
            };
            res.Add(settingValue);

            settingValue = new SettingValue()
            {
                Success = true,
                Name = "Scan_FunctionInitial",
                Values = "<valueTest>",
            };
            res.Add(settingValue);

            settingValue = new SettingValue()
            {
                Success = true,
                Name = "WinNwk_IsEnable",
                Values = "<valueTest>",
            };
            res.Add(settingValue);

            settingValue = new SettingValue()
            {
                Success = true,
                Name = "Ubiquitous_UsePrint",
                Values = "<valueTest>",
            };
            res.Add(settingValue);

            settingValue = new SettingValue()
            {
                Success = true,
                Name = "Auth_AuthType",
                Values = "<valueTest>",
            };
            res.Add(settingValue);

            settingValue = new SettingValue()
            {
                Success = true,
                Name = "User_MultiFeedDetectSetting",
                Values = "<valueTest>",
            };
            res.Add(settingValue);

            settingValue = new SettingValue()
            {
                Success = true,
                Name = "MailSend_Auth",
                Values = "<valueTest>",
            };
            res.Add(settingValue);

            settingValue = new SettingValue()
            {
                Success = true,
                Name = "MailSend_BinaryDivisionSize",
                Values = "<valueTest>",
            };
            res.Add(settingValue);

            settingValue = new SettingValue()
            {
                Success = true,
                Name = "MailSend_Verification",
                Values = "<valueTest>",
            };
            res.Add(settingValue);

            settingValue = new SettingValue()
            {
                Success = true,
                Name = "MailSend_PopBeforeSmtp",
                Values = "<valueTest>",
            };
            res.Add(settingValue);

            settingValue = new SettingValue()
            {
                Success = true,
                Name = "MailSend_PortNo",
                Values = "<valueTest>",
            };
            res.Add(settingValue);

            settingValue = new SettingValue()
            {
                Success = true,
                Name = "MailSend_SslTslPortNo",
                Values = "<valueTest>",
            };
            res.Add(settingValue);

            settingValue = new SettingValue()
            {
                Success = true,
                Name = "MailSend_ServerLimitSize",
                Values = "<valueTest>",
            };
            res.Add(settingValue);

            settingValue = new SettingValue()
            {
                Success = true,
                Name = "MailSend_ServerAddress",
                Values = "<valueTest>",
            };
            res.Add(settingValue);

            settingValue = new SettingValue()
            {
                Success = true,
                Name = "MailSend_EncryptionSetting",
                Values = "<valueTest>",
            };
            res.Add(settingValue);

            settingValue = new SettingValue()
            {
                Success = true,
                Name = "MailSend_TimeOut",
                Values = "<valueTest>",
            };
            res.Add(settingValue);

            settingValue = new SettingValue()
            {
                Success = true,
                Name = "MailSend_IsEnable",
                Values = "<valueTest>",
            };
            res.Add(settingValue);

            settingValue = new SettingValue()
            {
                Success = true,
                Name = "MailSend_StatusNotify",
                Values = "<valueTest>",
            };
            res.Add(settingValue);

            settingValue = new SettingValue()
            {
                Success = true,
                Name = "MailSend_ScanSending",
                Values = "<valueTest>",
            };
            res.Add(settingValue);

            settingValue = new SettingValue()
            {
                Success = true,
                Name = "MailSend_TotalCounterNotify",
                Values = "<valueTest>",
            };
            res.Add(settingValue);
            return res;
        }

        [Fact]
        public async Task ObtainAdminSettings_WhenAdminSettingRequestIsNull_ExpectBadRequest()
        {
            List<string> requestItemList = new List<string>();

            var mockSettingsOperator = new Mock<ISettingsOperator>();
            mockSettingsOperator.Setup(m => m.ObtainAdminSettingsAsync(requestItemList)).Throws(new OpenApiRequestException(OpenApiResultStatus.ConnectError, "Connect error."));

            var testTargetController = new AdminSettingsController(_logger, mockSettingsOperator.Object, null);
            var response = await testTargetController.ObtainAdminSettings(null);

            Assert.Equal(400, ((ObjectResult)response).StatusCode);
        }

        [Fact]
        public async Task ObtainAdminSettings_WhenAdminSettingRequestIsManyItems_ExpectSuccess()
        {
            // set all settingvalues
            var res = SetAllSettingValues();

            List<string> requestItemList = new List<string>
            {
                "Auth_ColorManage",
                "Auth_NoAuthPrintOn",
                "Auth_SendAddressLimit",
                "Fax_DefaultSenders",
                "Fax_DialType",
                "Fax_ReceiveOnSettings",
                "Fax_DataProtectType",
                "Fax_SendAuthPassword",
                "Security_SendProhibit",
                "SysConn_PrefixSuffix",
                "Oplevel_OriginalSizeAutoDetectByUser",
                "IFax_IsEnable",
                "Scan_OcrLanguage",
                "Scan_Pdf_A",
                "Scan_LinearizedPdfg",
                "Scan_is_enable_ocr",
                "Scan_IsEnablePdf_A",
                "Scan_IsEnableLinearizedPdf",
                "Scan_FileNameAddString",
                "Scan_FunctionInitial",
                "WinNwk_IsEnable",
                "Ubiquitous_UsePrint",
                "Auth_AuthType",
                "User_MultiFeedDetectSetting",
                "MailSend_Auth",
                "MailSend_BinaryDivisionSize",
                "MailSend_Verification",
                "MailSend_PopBeforeSmtp",
                "MailSend_PortNo",
                "MailSend_SslTslPortNo",
                "MailSend_ServerLimit",
                "MailSend_ServerAddress",
                "MailSend_EncryptionSetting",
                "MailSend_TimeOut",
                "MailSend_IsEnable",
                "MailSend_StatusNotify",
                "MailSend_ScanSending",
                "MailSend_TotalCounterNotify"
            };

            var mockSettingsOperator = new Mock<ISettingsOperator>();
            mockSettingsOperator.Setup(m => m.ObtainAdminSettingsAsync(requestItemList)).ReturnsAsync(res);

            // Execute
            var testTargetController = new AdminSettingsController(_logger, mockSettingsOperator.Object, null);
            var response = await testTargetController.ObtainAdminSettings(new AdminSettingsRequest() { SettingsNames = new List<string>(new [] { "ALL" }) });

            // Test
            Assert.Equal((int)HttpStatusCode.OK, ((ObjectResult)response).StatusCode);
            var actual = ((ObjectResult)response).Value as AdminSettingsResponse;

            List<string> resultCount = new List<string>();
            Assert.NotNull(actual);
            foreach (SettingValue sv in res)
            {
                if (actual.SettingValues.FindIndex(v => v.Name == sv.Name) >= 0)
                {
                    resultCount.Add(sv.Name);
                }
            }

            Assert.Equal(res.Count, resultCount.Count);
            mockSettingsOperator.VerifyAll();
        }

        [Fact]
        public async Task ObtainAdminSettings_WhenAdminSettingRequestIsOneItem_ExpectSuccess()
        {
            // create response
            var settingValues = new List<SettingValue>();
            var settingValue = new SettingValue
            {
                Success = true,
                Name = "Current_Language",
                Values = "ENGLISH",
            };
            settingValues.Add(settingValue);
            var expected = new AdminSettingsResponse { SettingValues = settingValues };

            List<string> requestItemList = new List<string> { "Current_Language" };

            var mockSettingsOperator = new Mock<ISettingsOperator>();
            mockSettingsOperator.Setup(m => m.ObtainAdminSettingsAsync(requestItemList)).ReturnsAsync(settingValues);

            var testTargetController = new AdminSettingsController(_logger, mockSettingsOperator.Object, null);
            var response = await testTargetController.ObtainAdminSettings(new AdminSettingsRequest { SettingsNames = requestItemList });

            Assert.Equal((int)HttpStatusCode.OK, ((ObjectResult)response).StatusCode);
            var actual = ((ObjectResult)response).Value as AdminSettingsResponse;
            Assert.NotNull(actual);
            Assert.Equal(expected.SettingValues, actual.SettingValues);

            mockSettingsOperator.VerifyAll();
        }

        [Fact]
        public async Task ObtainAdminSettings_WhenAdminSettingsRequestNotExist_ExpectSuccess()
        {
            // Prepare
            var settingValues = new List<SettingValue>();
            var settingValue = new SettingValue
            {
                Success = false,
                Name = "FOOBAR_HOGEFUGA",
                Values = null,
            };
            settingValues.Add(settingValue);
            var expected = new AdminSettingsResponse
            {
                SettingValues = settingValues
            };

            List<string> requestItemList = new List<string> { "FOOBAR_HOGEFUGA" };
            var mockSettingsOperator = new Mock<ISettingsOperator>();
            mockSettingsOperator.Setup(m => m.ObtainAdminSettingsAsync(requestItemList)).ReturnsAsync(settingValues);

            // Execute
            var testTargetController = new AdminSettingsController(_logger, mockSettingsOperator.Object, null);
            var response = await testTargetController.ObtainAdminSettings(new AdminSettingsRequest { SettingsNames = requestItemList });

            // Validate
            Assert.Equal((int)HttpStatusCode.OK, ((ObjectResult)response).StatusCode);
            var actual = ((ObjectResult)response).Value as AdminSettingsResponse;
            Assert.NotNull(actual);
            Assert.Equal(expected.SettingValues, actual.SettingValues);

            mockSettingsOperator.VerifyAll();
        }

        [Fact]
        public async Task ObtainAdminSettings_WhenSendingEmptyRequestList_ExpectSuccess()
        {
            // create response
            var settingValues = new List<SettingValue>();
            var settingValue = new SettingValue
            {
                Success = false,
                Name = null,
                Values = null,
            };
            settingValues.Add(settingValue);
            var expected = new AdminSettingsResponse
            {
                SettingValues = settingValues
            };

            var requestItemList = new List<string> { null };
            // not exist item

            var mockSettingsOperator = new Mock<ISettingsOperator>();
            mockSettingsOperator.Setup(m => m.ObtainAdminSettingsAsync(requestItemList)).ReturnsAsync(settingValues);

            var testTargetController = new AdminSettingsController(_logger, mockSettingsOperator.Object, null);
            var response = await testTargetController.ObtainAdminSettings(new AdminSettingsRequest() { SettingsNames = requestItemList });

            Assert.Equal((int)HttpStatusCode.OK, ((ObjectResult)response).StatusCode);
            var actual = ((ObjectResult)response).Value as AdminSettingsResponse;
            Assert.NotNull(actual);
            Assert.Equal(expected.SettingValues, actual.SettingValues);

            mockSettingsOperator.VerifyAll();
        }

        [Fact]
        public async Task ObtainAdminSettings_WhenSettingsRequestContainsProhibitedCharacters_ExpectSuccess()
        {
            // create response
            var settingValues = new List<SettingValue>();
            var settingValue = new SettingValue()
            {
                Success = false,
                Name = "!#$%&'()-=^~\\|@`[{;+:*]},<.>/?\\_",
                Values = null,
            };
            settingValues.Add(settingValue);
            var expected = new AdminSettingsResponse()
            {
                SettingValues = settingValues
            };

            List<string> requestItemList = new List<string> { "!#$%&'()-=^~\\|@`[{;+:*]},<.>/?\\_" };
            // not exist item

            var mockSettingsOperator = new Mock<ISettingsOperator>();
            mockSettingsOperator.Setup(m => m.ObtainAdminSettingsAsync(requestItemList)).ReturnsAsync(settingValues);

            var testTargetController = new AdminSettingsController(_logger, mockSettingsOperator.Object, null);
            var response = await testTargetController.ObtainAdminSettings(new AdminSettingsRequest() { SettingsNames = requestItemList });

            Assert.Equal((int)HttpStatusCode.OK, ((ObjectResult)response).StatusCode);
            var actual = ((ObjectResult)response).Value as AdminSettingsResponse;
            Assert.NotNull(actual);
            Assert.Equal(expected.SettingValues, actual.SettingValues);

            mockSettingsOperator.VerifyAll();
        }

        [Fact]
        public async Task ObtainAdminSettings_WhenEmptySetting_ExpectBadRequest()
        {
            // create response
            var res = new AdminSettingsResponse()
            {
                SettingValues = new List<SettingValue>(),
            };

            var settingValue = new SettingValue();

            res.SettingValues.Add(settingValue);

            // Zero item
            List<string> requestItemList = new List<string>();

            var testTargetController = new AdminSettingsController(_logger, null, null);
            var response = await testTargetController.ObtainAdminSettings(new AdminSettingsRequest() { SettingsNames = requestItemList });

            Assert.Equal(400, ((StatusCodeResult)response).StatusCode);
        }

        [Fact]
        public async Task ObtainAdminSettings_WhenMultipleValidSettings_ExpectSuccess()
        {
            // create response
            var settingValues = new List<SettingValue> {
                new SettingValue
                    {
                        Success = true,
                        Name = "Current_Language",
                        Values = "<value1>",
                    },
                new SettingValue
                    {
                        Success = true,
                        Name = "Auth_AuthType",
                        Values = "<value2>",
                    },
                new SettingValue
                    {
                        Success = true,
                        Name = "MailSend_PopBeforeSmtp.Use",
                        Values = "<value3>",
                    }
            };

            var expected = new AdminSettingsResponse()
            {
                SettingValues = settingValues
            };

            var requestItemList = new List<string>
                {
                    "Current_Language",
                    "Auth_AuthType",
                    "MailSend_PopBeforeSmtp.Use"
                };

            var mockSettingsOperator = new Mock<ISettingsOperator>();
            mockSettingsOperator.Setup(m => m.ObtainAdminSettingsAsync(requestItemList)).ReturnsAsync(settingValues);

            var testTargetController = new AdminSettingsController(_logger, mockSettingsOperator.Object, null);
            var response = await testTargetController.ObtainAdminSettings(new AdminSettingsRequest() { SettingsNames = requestItemList });

            Assert.Equal((int)HttpStatusCode.OK, ((ObjectResult)response).StatusCode);
            var actual = ((ObjectResult)response).Value as AdminSettingsResponse;
            Assert.NotNull(actual);
            Assert.Equal(expected.SettingValues, actual.SettingValues);

            mockSettingsOperator.VerifyAll();
        }

        [Fact]
        public async Task ObtainAdminSettings_WhenMultipleSettingsWithAnyValid_ExpectSuccess()
        {
            // create response
            var settingValues = new List<SettingValue>
            {
                new SettingValue
                {
                    Success = true,
                    Name = "Current_Language",
                    Values = "<value1>",
                },
                new SettingValue
                {
                    Success = true,
                    Name = "Auth_AuthType",
                    Values = "<value2>",
                },
                new SettingValue
                {
                    Success = false,
                    Name = "FOOBAR_HOGEFUGA",
                    Values = null,
                }
            };

            var expected = new AdminSettingsResponse()
            {
                SettingValues = settingValues
            };

            List<string> requestItemList = new List<string> { "Current_Language", "Auth_AuthType", "FOOBAR_HOGEFUGA" };

            var mockSettingsOperator = new Mock<ISettingsOperator>();
            mockSettingsOperator.Setup(m => m.ObtainAdminSettingsAsync(requestItemList)).ReturnsAsync(settingValues);

            var testTargetController = new AdminSettingsController(_logger, mockSettingsOperator.Object, null);
            var response = await testTargetController.ObtainAdminSettings(new AdminSettingsRequest() { SettingsNames = requestItemList });

            Assert.Equal((int)HttpStatusCode.OK, ((ObjectResult)response).StatusCode);
            var actual = ((ObjectResult)response).Value as AdminSettingsResponse;
            Assert.NotNull(actual);
            Assert.Equal(expected.SettingValues, actual.SettingValues);

            mockSettingsOperator.VerifyAll();
        }

        [Fact]
        public async Task ObtainAdminSettings_WhenMultipleSettingsNoExist_ExpectSuccess()
        {
            // create response
            var settingValues = new List<SettingValue>
            {
                new SettingValue
                {
                    Success = false,
                    Name = "FOOBAR_HOGEFUGA1",
                    Values = null,
                },
                new SettingValue
                {
                    Success = false,
                    Name = "FOOBAR_HOGEFUGA2",
                    Values = null,
                },
                new SettingValue
                {
                    Success = false,
                    Name = "FOOBAR_HOGEFUGA3",
                    Values = null,
                },
            };

            var expected = new AdminSettingsResponse
            {
                SettingValues = settingValues
            };

            List<string> requestItemList = new List<string>
            {
                "FOOBAR_HOGEFUGA1",
                "FOOBAR_HOGEFUGA2",
                "FOOBAR_HOGEFUGA3"
            };

            var mockSettingsOperator = new Mock<ISettingsOperator>();
            mockSettingsOperator.Setup(m => m.ObtainAdminSettingsAsync(requestItemList)).ReturnsAsync(settingValues);

            var testTargetController = new AdminSettingsController(_logger, mockSettingsOperator.Object, null);
            var response = await testTargetController.ObtainAdminSettings(new AdminSettingsRequest { SettingsNames = requestItemList });

            Assert.Equal((int)HttpStatusCode.OK, ((ObjectResult)response).StatusCode);
            var actual = ((ObjectResult)response).Value as AdminSettingsResponse;
            Assert.NotNull(actual);
            Assert.Equal(expected.SettingValues, actual.SettingValues);

            mockSettingsOperator.VerifyAll();
        }

        [Fact]
        public async Task ObtainAdminSettings_WhenMultipleSettingsOverlap_ExpectSuccess()
        {
            // create response
            var settingValues = new List<SettingValue>
            {
                new SettingValue
                {
                    Success = true,
                    Name = "Current_Language",
                    Values = "<value1>",
                },
                new SettingValue
                {
                    Success = true,
                    Name = "Current_Language",
                    Values = "<value2>",
                },
                new SettingValue
                {
                    Success = true,
                    Name = "MailSend_PopBeforeSmtp.Use",
                    Values = "<value3>",
                }
            };

            var expected = new AdminSettingsResponse { SettingValues = settingValues };
            var requestItemList = new List<string> {"Current_Language", "Current_Language", "MailSend_PopBeforeSmtp.Use"};

            var mockSettingsOperator = new Mock<ISettingsOperator>();
            mockSettingsOperator.Setup(m => m.ObtainAdminSettingsAsync(requestItemList)).ReturnsAsync(settingValues);

            var testTargetController = new AdminSettingsController(_logger, mockSettingsOperator.Object, null);
            var response = await testTargetController.ObtainAdminSettings(new AdminSettingsRequest() { SettingsNames = requestItemList });

            Assert.Equal((int)HttpStatusCode.OK, ((ObjectResult)response).StatusCode);
            var actual = ((ObjectResult)response).Value as AdminSettingsResponse;
            Assert.NotNull(actual);
            Assert.Equal(expected.SettingValues, actual.SettingValues);

            mockSettingsOperator.VerifyAll();
        }
    }
}
