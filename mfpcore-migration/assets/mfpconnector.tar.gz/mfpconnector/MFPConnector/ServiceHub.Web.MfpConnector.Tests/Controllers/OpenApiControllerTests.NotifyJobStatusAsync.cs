using Moq;
using ServiceHub.Processors.Job;
using ServiceHub.Processors.Notify.Model;
using ServiceHub.Web.MfpConnector.Controllers;
using System;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;
using Xunit;

namespace ServiceHub.Web.MfpConnector.Tests.Controllers
{
    [Trait("OpenApiController", "Unit")]
    public partial class OpenApiControllerTests
    {
        private static string DevRptNotifyJobTraceStatus(int jobId, string jobStatus)
        {
            return
                "<e:Envelope xmlns:e='http://schemas.xmlsoap.org/soap/envelope/' e:encodingStyle='http://schemas.xmlsoap.org/soap/encoding/'><e:Header><me:DevRptHeader xmlns:me='http://www.konicaminolta.com/Header/OpenAPI-6-9'><ApplicationID>785</ApplicationID><Version><Major> 6 </Major><Minor> 9 </Minor></Version></me:DevRptHeader></e:Header><e:Body><m:DevRptNotifyJobTraceStatus xmlns:m ='http://www.konicaminolta.com/service/OpenAPI-6-9'>"
                + $"<JobID>{jobId}</JobID><DriverJobID/>"
                + $"<TraceStatus>{jobStatus}</TraceStatus>"
                + "</m:DevRptNotifyJobTraceStatus></e:Body></e:Envelope>";
        }

        [Theory]
        [InlineData("End")]
        [InlineData("Deleted")]
        [InlineData("TimeOut")]
        [InlineData("ErrorPrinting")]
        [InlineData("ErrorScanning")]
        public async void NotifyJobStatusAsync_ShouldExecuteProcessBusPublishAsyncOfBusSenderClassWhenJobIsOver(string jobStatus)
        {
            // Prepare
            var jobId = 1;
            var fakeStopToken = new CancellationTokenSource();

            _mockConvertNotification.Setup(m =>
                    m.ConvertToNotifyJobStatusAsync(It.IsAny<JobOperator>(), It.IsAny<string>()))
                .ReturnsAsync(GetNotifyJobStatus(jobId, jobStatus));
            _mockPushNotifier.Setup(m =>
                m.NotifyJobStatusAsync(It.IsAny<string>()))
                .Returns(Task.Run(() => { }, fakeStopToken.Token));
            _mockBusSender.Setup(m =>
                m.NotifyFromJobStatusAsync(It.IsAny<NotifyJobStatus>()))
                .Returns(Task.Run(() => { }, fakeStopToken.Token));

            // Execute
            var openApiController = new OpenApiController(
                _logger,
                MfpConnectorSetting,
                null,
                _mockPushNotifier.Object,
                null,
                null,
                _mockJobOperator.Object,
                _mockIwsThreadWorker.Object,
                _mockBusSender.Object);

            MethodInfo methodInfo =
                openApiController.GetType()
                    .GetMethod("NotifyJobStatusAsync", BindingFlags.NonPublic | BindingFlags.Instance);

            var task = Task.Run(async () =>
                    await (Task)methodInfo.Invoke(
                        openApiController,
                        new object[] { DevRptNotifyJobTraceStatus(jobId, jobStatus) }),
                fakeStopToken.Token);

            // Validate
            await Task.Delay(TimeSpan.FromMilliseconds(100), fakeStopToken.Token);
            await Task.WhenAll(task);

            Assert.Equal(TaskStatus.RanToCompletion, task.Status);
            _mockBusSender.VerifyAll();
        }

        [Theory]
        [InlineData("Create")]
        [InlineData("Scanning")]
        [InlineData("PauseScanning")]
        [InlineData("PauseDividedScanning")]
        [InlineData("Printing")]
        [InlineData("PausePrinting")]
        [InlineData("WaitPrinting")]
        [InlineData("PendPrinting")]
        [InlineData("MemorySaving")]
        [InlineData("Receiving")]
        [InlineData("Sending")]
        [InlineData("WaitSending")]
        [InlineData("Dialing")]
        [InlineData("TimerWaitSending")]
        [InlineData("Waiting")]
        [InlineData("Deleting")]
        [InlineData("Pending")]
        public async void NotifyJobStatusAsync_ShouldNotExecuteProcessBusPublishAsyncOfBusSenderClassWhenJobIsNotOver(string jobStatus)
        {
            // Prepare
            var jobId = 1;
            var fakeStopToken = new CancellationTokenSource();

            _mockConvertNotification.Setup(
                    m => m.ConvertToNotifyJobStatusAsync(It.IsAny<JobOperator>(), It.IsAny<string>()))
                .ReturnsAsync(GetNotifyJobStatus(jobId, jobStatus));
            _mockPushNotifier.Setup(
                    m => m.NotifyJobStatusAsync(It.IsAny<string>()))
                .Returns(Task.Run(() => { }, fakeStopToken.Token));
            _mockBusSender.Setup(
                    m => m.NotifyFromJobStatusAsync(It.IsAny<NotifyJobStatus>()))
                .Returns(Task.Run(() => { }, fakeStopToken.Token));

            // Execute
            var openApiController = new OpenApiController(
                _logger,
                MfpConnectorSetting,
                null,
                _mockPushNotifier.Object,
                null,
                _mockINotifySetter.Object,
                _mockJobOperator.Object,
                _mockIwsThreadWorker.Object,
                _mockBusSender.Object);

            MethodInfo methodInfo =
                openApiController.GetType()
                    .GetMethod("NotifyJobStatusAsync", BindingFlags.NonPublic | BindingFlags.Instance);

            var task = Task.Run(async () =>
                    await (Task)methodInfo.Invoke(
                        openApiController,
                        new object[] { DevRptNotifyJobTraceStatus(jobId, jobStatus) }),
                fakeStopToken.Token);

            // Validate
            await Task.Delay(TimeSpan.FromMilliseconds(100), fakeStopToken.Token);
            await Task.WhenAll(task);

            Assert.Equal(TaskStatus.RanToCompletion, task.Status);
            _mockBusSender.VerifyAll();
        }

        /// <summary>
        /// Get notifies the job status.
        /// </summary>
        /// <param name="jobId">The job identifier.</param>
        /// <param name="jobStatus">The job status.</param>
        /// <returns></returns>
        private NotifyJobStatus GetNotifyJobStatus(int jobId, string jobStatus)
        {
            return new NotifyJobStatus
            {
                JobId = jobId,
                Status = jobStatus
            };
        }
    }
}
