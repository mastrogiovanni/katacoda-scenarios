using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using ServiceHub.Connectors.IWS;
using ServiceHub.Connectors.OpenAPI.Model.ResponseXmlModel;
using ServiceHub.Processors.Bus;
using ServiceHub.Processors.DeviceInfo;
using ServiceHub.Processors.DeviceInfo.Model;
using ServiceHub.Processors.Job;
using ServiceHub.Processors.Notify;
using ServiceHub.Processors.PushNotification;
using ServiceHub.Web.MfpConnector.Controllers;
using ServiceHub.Web.MfpConnector.Tests.Controllers.Rest;
using System;
using System.Net;
using System.Threading.Tasks;
using Xunit;

namespace ServiceHub.Web.MfpConnector.Tests.Controllers
{
    [Trait("OpenApiController", "Unit")]
    public partial class OpenApiControllerTests : RestControllerTestsBase
    {
        private readonly string _devRptNotifyWarningChangeNormalMin = DevRptNotifyWarningChange("", "", "", "", "0", "0", "false");
        private readonly string _devRptNotifyWarningChangeNormalMax = DevRptNotifyWarningChange("", "", "", "", "65535", "18446744073709551615", "true");
        private readonly string _devRptNotifyWarningChangeAnimationIdOverMin = DevRptNotifyWarningChange("", "", "", "", "-1", "0", "false");
        private readonly string _devRptNotifyWarningChangeAnimationIdOverMax = DevRptNotifyWarningChange("", "", "", "", "65536", "0", "false");
        private readonly string _devRptNotifyWarningChangeAnimationIdNaN = DevRptNotifyWarningChange("", "", "", "", "abc", "0", "false");
        private readonly string _devRptNotifyWarningChangeAnimationIdEmpty = DevRptNotifyWarningChange("", "", "", "", "", "0", "false");
        private readonly string _devRptNotifyWarningChangeJobIdOverMin = DevRptNotifyWarningChange("", "", "", "", "0", "-1", "false");
        private readonly string _devRptNotifyWarningChangeJobIdOverMax = DevRptNotifyWarningChange("", "", "", "", "0", "18446744073709551616", "false");
        private readonly string _devRptNotifyWarningChangeJobIdNaN = DevRptNotifyWarningChange("", "", "", "", "0", "abc", "false");
        private readonly string _devRptNotifyWarningChangeJobIdEmpty = DevRptNotifyWarningChange("", "", "", "", "0", "", "false");
        private readonly string _devRptNotifyWarningChangeNextPageNotBool = DevRptNotifyWarningChange("", "", "", "", "0", "", "abc");
        private readonly string _devRptNotifyWarningChangeNextPageEmpty = DevRptNotifyWarningChange("", "", "", "", "0", "", "");

        private static string DevRptNotifyWarningChange(string warningName, string warningType, string messageData, string machihneImagePath, string animationId, string jobId, string nextPage)
        {
            return
            "<?xml version=\"1.0\" encoding=\"UTF-8\"?><e:Envelope xmlns:e=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:SOAP-ENC=\"http://schemas.xmlsoap.org/soap/encoding/\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\"><e:Header><me:AppReqHeader xmlns:me=\"http://www.konicaminolta.com/Header/OpenAPI-6-9\"><ApplicationID>0</ApplicationID><Version><Major>6</Major><Minor>9</Minor></Version><AppManagementID>28870</AppManagementID><ResendTime>3</ResendTime></me:AppReqHeader></e:Header><e:Body><m:DevRptNotifyWarningChange xmlns:m=\"http://www.konicaminolta.com/service/OpenAPI-6-9\"><Result><ResultInfo>Ack</ResultInfo></Result><WarningInformationList><ArraySize>1</ArraySize><WarningInformation><WarningInfo>"
             + $"<WarningName>{warningName}</WarningName>"
             + $"<WarningType>{warningType}</WarningType>"
             + "<WarningMessageInfoList><ArraySize>1</ArraySize><WarningMessageInfo>"
             + $"<MessageData>{messageData}</MessageData>"
             + "</WarningMessageInfo></WarningMessageInfoList></WarningInfo>"
             + $"<MachineImagePath>{machihneImagePath}</MachineImagePath>"
             + $"<AnimationID>{animationId}</AnimationID>"
             + $"<JobID>{jobId}</JobID>"
             + $"<NextPage>{nextPage}</NextPage>"
             + "</WarningInformation></WarningInformationList></m:DevRptNotifyWarningChange></e:Body></e:Envelope>";
        }

        private readonly Mock<IDeviceInfoOperator> _mockDeviceInfoOperator;
        private readonly Mock<IPushNotifier> _mockPushNotifier;
        private readonly ILogger<OpenApiController> _logger;
        private readonly Mock<IMfpCounterPublisher> _mockBusSender;
        private readonly Mock<IConvertNotification> _mockConvertNotification;
        private readonly Mock<IJobOperator> _mockJobOperator;
        private readonly Mock<IwsThreadWorker> _mockIwsThreadWorker;
        private readonly Mock<INotifySetter> _mockINotifySetter;

        public OpenApiControllerTests()
        {
            _logger = Mock.Of<ILogger<OpenApiController>>();
            _mockDeviceInfoOperator = new Mock<IDeviceInfoOperator>(MockBehavior.Strict);
            _mockPushNotifier = new Mock<IPushNotifier>(MockBehavior.Strict);
            _mockBusSender = new Mock<IMfpCounterPublisher>();
            _mockConvertNotification = new Mock<IConvertNotification>();
            _mockJobOperator = new Mock<IJobOperator>();
            _mockIwsThreadWorker = new Mock<IwsThreadWorker>();
            _mockINotifySetter = new Mock<INotifySetter>();
        }

        [Fact]
        public void Post_WhenDevRptNotifyWarningChange_ExpectSuccess()
        {
            // Prepare
            _mockDeviceInfoOperator.Setup(
                m => m.ConvertNotifyWarningChange(It.IsAny<string>()))
                .Returns<string>(
                    msg => XmlConverter.Deserialize<DevRptNotifyWarningChange>(msg, "m:DevRptNotifyWarningChange"));
            _mockPushNotifier.Setup(
                m => m.SendWarningInfoAsync(It.IsAny<string>())).Returns(Task.Factory.StartNew(() => { }));

            string[] messages = { _devRptNotifyWarningChangeNormalMin, _devRptNotifyWarningChangeNormalMax };
            foreach (var msg in messages)
            {
                // Execute
                var openApiController = new OpenApiController(
                    _logger,
                    MfpConnectorSetting,
                    _mockDeviceInfoOperator.Object,
                    _mockPushNotifier.Object,
                    null,
                    null,
                    null,
                    null,
                    null);

                var response = (StatusCodeResult)openApiController.Post(msg).Result;

                // Validate
                Assert.Equal((int)HttpStatusCode.OK, response.StatusCode);
                _mockDeviceInfoOperator.VerifyAll();
                _mockPushNotifier.VerifyAll();
            }
        }

        [Fact]
        public void Post_WhenDevRptNotifyWarningChange_ExpectBadRequestWithConvertFailed()
        {
            // Prepare
            _mockDeviceInfoOperator.Setup(
                m => m.ConvertNotifyWarningChange(It.IsAny<string>())).Throws(new Exception());

            // Execute
            var openApiController = new OpenApiController(
                _logger,
                MfpConnectorSetting,
                _mockDeviceInfoOperator.Object,
                null,
                null,
                null,
                null,
                null,
                null);

            var response = (StatusCodeResult)openApiController.Post(_devRptNotifyWarningChangeNormalMin).Result;

            // Validate
            Assert.Equal((int)HttpStatusCode.BadRequest, response.StatusCode);
            _mockDeviceInfoOperator.VerifyAll();
        }

        [Fact]
        public void Post_WhenDevRptNotifyWarningChange_ExpectBadRequestWithBadParam()
        {
            // Prepare
            _mockDeviceInfoOperator.Setup(
                m => m.ConvertNotifyWarningChange(It.IsAny<string>()))
                .Returns<string>(
                    msg => XmlConverter.Deserialize<DevRptNotifyWarningChange>(msg, "m:DevRptNotifyWarningChange"));

            string[] messages =
            {
                _devRptNotifyWarningChangeAnimationIdOverMin,
                _devRptNotifyWarningChangeAnimationIdOverMax,
                _devRptNotifyWarningChangeAnimationIdNaN,
                _devRptNotifyWarningChangeAnimationIdEmpty,

                _devRptNotifyWarningChangeJobIdOverMin,
                _devRptNotifyWarningChangeJobIdOverMax,
                _devRptNotifyWarningChangeJobIdNaN,
                _devRptNotifyWarningChangeJobIdEmpty,

                _devRptNotifyWarningChangeNextPageNotBool,
                _devRptNotifyWarningChangeNextPageEmpty
            };
            foreach (var msg in messages)
            {
                // Execute
                var openApiController = new OpenApiController(
                    _logger,
                    MfpConnectorSetting,
                    _mockDeviceInfoOperator.Object,
                    null,
                    null,
                    null,
                    null,
                    null,
                    null);

                var response = (StatusCodeResult)openApiController.Post(msg).Result; // We have also a different Xml exception while executing. We should look into it.

                // Validate
                Assert.Equal((int)HttpStatusCode.BadRequest, response.StatusCode);
                _mockDeviceInfoOperator.VerifyAll();
            }
        }
    }
}
