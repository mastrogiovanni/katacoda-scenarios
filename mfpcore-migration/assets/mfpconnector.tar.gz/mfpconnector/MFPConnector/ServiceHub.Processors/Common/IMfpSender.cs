using System.Threading.Tasks;

namespace ServiceHub.Processors.Common
{
    /// <summary>
    /// Send data to MFP interface
    /// </summary>
    /// <typeparam name="TI">Input data type.</typeparam>
    /// <typeparam name="TO">Output data type.</typeparam>
    public interface IMfpSender<in TI, TO>
        where TI : class, new()
        where TO : class
    {
        /// <summary>
        /// Send data to MFP.
        /// </summary>
        /// <param name="data">Processing data</param>
        /// <returns>Task that return output from MFP.</returns>
        Task<TO> SendToMfpAsync(TI data);
    }

    /// <summary>
    /// Send data to MFP interface
    /// </summary>
    public interface IMfpSender
    {
        /// <summary>
        /// Parameter
        /// </summary>
        string Parameter { get; set; }

        /// <summary>
        /// Send data to MFP.
        /// </summary>
        void SendToMfp();
    }
}
