using System.Xml.Serialization;
using ServiceHub.Connectors.OpenAPI.Model;

namespace ServiceHub.Processors.Common.Model
{
    /// <summary>
    /// AppResGetFileData model class
    /// </summary>
    public class AppResGetFileData
    {
        /// <summary>
        /// Request item type
        /// </summary>
        public AppRequestItemType ResuestItem { get; set; }

        /// <summary>
        /// Download file ID
        /// </summary>
        [XmlElement("DownloadFileID")]
        public ulong DownloadFileId { get; set; }
        
        /// <summary>
        /// File name
        /// </summary>
        public string FileName { get; set; }
    }
}
