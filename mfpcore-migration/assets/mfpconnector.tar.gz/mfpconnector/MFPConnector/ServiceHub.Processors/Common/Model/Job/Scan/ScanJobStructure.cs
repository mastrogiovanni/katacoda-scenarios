using Newtonsoft.Json;

namespace ServiceHub.Processors.Common.Model.Job.Scan
{
    public class ScanJobStructure : IJobStructure
    {
        [JsonProperty("mfpServicesJobid")]
        public string MfpServicesJobid { get; set; }

        [JsonProperty("ImageSavePath")]
        public string ImageSavePath { get; set; }

        [JsonProperty("setting")]
        public ScanJobSetting Setting { get; set; }

        [JsonProperty("URL")]
        public string Url { get; set; }

        [JsonProperty("DocumentName")]
        public string DocumentName { get; set; }

        [JsonProperty("previewNum")]
        public int PreviewNum { get; set; }

        [JsonProperty("preview")]
        public string Preview { get; set; }

        [JsonProperty("jobStatus")]
        public ScanJobStatus JobStatus { get; set; }

        [JsonProperty("parentID")]
        public string ParentId { get; set; }
    }
}