namespace ServiceHub.Processors.Common.Model.Job.Scan
{
    public class ScanSizeSettingStruct
    {
        public string Size { get; set; }

        public string FixedFormSize { get; set; }

        public string PhotoSize { get; set; }

        public int[] CustomSize { get; set; }
    }
}