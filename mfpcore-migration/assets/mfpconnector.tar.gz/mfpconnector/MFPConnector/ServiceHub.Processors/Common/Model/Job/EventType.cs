﻿namespace ServiceHub.Processors.Common.Model.Job
{
    /// <summary>
    /// MfpJobStructure eventType
    /// </summary>
    public enum EventType
    {
        Undefined,

        /// <summary>
        /// Scanning
        /// </summary>
        Scan
    }
}
