namespace ServiceHub.Processors.Common.Model.Job.Scan
{
    public class DensitySettingStruct
    {
        public string Density { get; set; }

        public string DensityLevel { get; set; }
    }
}