using Newtonsoft.Json;

namespace ServiceHub.Processors.Common.Model.Job
{
    public interface IJobStructure
    {
        [JsonProperty("mfpServicesJobid")]
        string MfpServicesJobid { get; set; }
    }
}
