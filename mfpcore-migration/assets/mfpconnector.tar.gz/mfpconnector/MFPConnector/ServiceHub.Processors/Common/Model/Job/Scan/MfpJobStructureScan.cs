using Newtonsoft.Json;

namespace ServiceHub.Processors.Common.Model.Job.Scan
{
    public class MfpJobStructureScan : IMfpJobStructure<ScanJobStructure>
    {
        [JsonProperty("eventType")]
        public EventType EventType => EventType.Scan;

        /// <summary>
        /// Job structure
        /// </summary>
        [JsonProperty("scanJobStructure")]
        public ScanJobStructure JobStructure { get; set; }
    }
}
