﻿namespace ServiceHub.Processors.Common.Model
{
    public enum OpenApiFaultErrorDetailsType
    {
        GeneralDuringDeviceLock
    }
}