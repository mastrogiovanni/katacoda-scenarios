namespace ServiceHub.Processors.Common.Model.Job.Scan
{
    public class ScanJobSetting
    {
        public FileTypeSettingStruct FileTypeSetting { get; set; }

        public string Resolution { get; set; }

        public string ColourSetting { get; set; }

        public ScanSizeSettingStruct ScanSizeSetting { get; set; }

        public string Direction { get; set; }

        public string DuplexMode { get; set; }

        public string BindingPosition { get; set; }

        public string SeparateScan { get; set; }

        public OriginalTypeSettingStruct OriginalTypeSetting { get; set; }

        public BackgroundRemovalSettingStruct BackgroundRemovalSetting { get; set; }

        public DensitySettingStruct DensitySetting { get; set; }

        public string ScanSide { get; set; }
    }
}