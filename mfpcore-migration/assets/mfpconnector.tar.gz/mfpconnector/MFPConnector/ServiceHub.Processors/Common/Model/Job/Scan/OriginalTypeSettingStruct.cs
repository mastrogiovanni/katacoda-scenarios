namespace ServiceHub.Processors.Common.Model.Job.Scan
{
    public class OriginalTypeSettingStruct
    {
        public string OriginalType { get; set; }

        public string PhotoType { get; set; }
    }
}