namespace ServiceHub.Processors.Common.Model.Job.Scan
{
    public class BackgroundRemovalSettingStruct
    {
        public string BackgroundRemoval { get; set; }

        public string BackgroundRemovalLevel { get; set; }
    }
}