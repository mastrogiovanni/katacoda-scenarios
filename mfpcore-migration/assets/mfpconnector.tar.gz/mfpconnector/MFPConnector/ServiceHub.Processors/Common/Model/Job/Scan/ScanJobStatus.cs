namespace ServiceHub.Processors.Common.Model.Job.Scan
{
    public class ScanJobStatus : JobStatus
    {
        public string ScanNum { get; set; }
    }
}