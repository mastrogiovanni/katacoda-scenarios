using Newtonsoft.Json;

namespace ServiceHub.Processors.Common.Model.Job
{
    public interface IMfpJobStructure<T> where T : IJobStructure, new()
    {
        /// <summary>
        /// Event type
        /// </summary>
        [JsonProperty("eventType")]
        EventType EventType { get; }

        /// <summary>
        /// Job structure
        /// </summary>
        [JsonProperty("jobStructure")]
        T JobStructure { get; set; }
    }
}
