namespace ServiceHub.Processors.Common.Model
{
    /// <summary>
    /// Attachment data
    /// </summary>
    public class AttachmentData
    {
        /// <summary>
        /// Name
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// File name
        /// </summary>
        public string FileName { get; set; }
        
        /// <summary>
        /// File binary data
        /// </summary>
        public byte[] Binary { get; set; }
    }
}