using Newtonsoft.Json;

namespace ServiceHub.Processors.Common.Model.Job
{
    public class JobStatus
    {
        [JsonProperty("ID")]
        public string Id { get; set; }

        public string Status { get; set; }

        public string ErrorCode { get; set; }
    }
}