namespace ServiceHub.Processors.Common.Model.Job.Scan
{
    public class FileTypeSettingStruct
    {
        public string FileType { get; set; }

        public string ScanPageSetting { get; set; }

        public int PageSeparationPages { get; set; }
    }
}