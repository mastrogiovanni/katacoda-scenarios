﻿namespace ServiceHub.Processors.Common
{
    public static class JobStatus
    {
        /// <summary>
        /// success job status.
        /// </summary>
        public static readonly string CREATE = "Create";

        /// <summary>
        /// end job status.
        /// </summary>
        public static readonly string END = "End";
    }
}
