﻿using System;
using System.Collections.Generic;

namespace ServiceHub.Processors.Common
{
    public static class SenderConfig
    {
        private static Dictionary<IwsCopyAction, string> _copyAction;
        private static Dictionary<IwsScanAction, string> _scanAction;

        /// <summary>
        /// Get copy action path (script/json).
        /// </summary>
        /// <param name="request">Type requested.</param>
        /// <returns>Requested action.</returns>
        public static string Get(IwsCopyAction request)
        {
            if (_copyAction == null)
            {
                _copyAction = new Dictionary<IwsCopyAction, string>
                {
                    {IwsCopyAction.Request, "/copyRequest.json"},
                    {IwsCopyAction.Response, "/copyResponse.json"},
                    {IwsCopyAction.Script, "/startCopy.py"}
                };
            }

            if (_copyAction.TryGetValue(request, out string action))
            {
                return action;
            }

            throw new NotSupportedException();
        }

        /// <summary>
        /// Get scan action path (script/json).
        /// </summary>
        /// <param name="request">Type requested.</param>
        /// <returns>Requested action.</returns>
        public static string Get(IwsScanAction request)
        {
            if (_scanAction == null)
            {
                _scanAction = new Dictionary<IwsScanAction, string>
                {
                    {IwsScanAction.Request, "/scanRequest.json"},
                    {IwsScanAction.Response, "/scanResponse.json"},
                    {IwsScanAction.Script, "/startScan.py"}
                };
            }

            if (_scanAction.TryGetValue(request, out var action))
            {
                return action;
            }

            throw new NotSupportedException();
        }

        /// <summary>
        /// Types of copy action.
        /// </summary>
        public enum IwsCopyAction
        {
            /// <summary>Copy request file path from IWS application data root.</summary>
            Request,
            /// <summary>Copy response file path from IWS application data root.</summary>
            Response,
            /// <summary>Copy script path from IWS application data root.</summary>
            Script
        }

        /// <summary>
        /// Types of scan action.
        /// </summary>
        public enum IwsScanAction
        {
            Request,
            Response,
            Script
        }

        /// <summary>
        /// Iws Result status.
        /// </summary>
        public enum IwsResultStatus
        {
            OK,
            NG
        }

        /// <summary>
        /// Types of Iws Errors.
        /// </summary>
        public enum IwsError
        {
            Timeout,
            Fatal
        }
    }
}
