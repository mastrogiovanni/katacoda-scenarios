using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;
using KonicaMinolta.OpenApi;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using ServiceHub.Common.Model;
using ServiceHub.Common.Model.DeviceInfo.NotifyToSh;
using ServiceHub.Common.Settings;
using ServiceHub.Connectors.OpenAPI;
using ServiceHub.Connectors.OpenAPI.Exceptions;
using ServiceHub.Connectors.OpenAPI.Model;
using ServiceHub.Connectors.OpenAPI.Model.ResponseXmlModel;
using ServiceHub.Processors.Common.Model;
using ServiceHub.Processors.DeviceInfo.Model;
using ServiceHub.Processors.Notify.Model;
using ServiceHub.Processors.PushNotification;
using ServiceHub.Processors.ReadyManage;
using OpenApiNackException = ServiceHub.Connectors.OpenAPI.Exceptions.OpenApiNackException;

namespace ServiceHub.Processors.DeviceInfo
{
    public class DeviceInfoOperator : OpenApiOperatable, IDeviceInfoOperator
    {
        /// <summary>
        /// Notify DevRptNotifyDevicePartsStatus EndPoint.
        /// </summary>
        private const string DevicePartsStatusEndpoint = "v1.1/device/notifystatuses";

        private const string BaseSupporFuncXPath = "/AppResGetDeviceInfo/SupportFunction/";
        private const string FileWithLicenseXpath = BaseSupporFuncXPath + "AppOption/FileTypeWithLicence";
        private const string StampNodeXpath = BaseSupporFuncXPath + "AppOption/Stamp";

        /// <summary>
        /// This semaphore represents a resource that must be synchronized
        /// so that only one thread at a time can enter.
        /// </summary>
        private static readonly SemaphoreSlim SemaphoreSync = new SemaphoreSlim(1, 1);

        private readonly IPushNotifier _pushNotifier;
        private readonly IMfpReadyManage _mfpReadyManage;
        private readonly IDeviceDescriptionOperator _descriptionOperator;
        private readonly ILogger<DeviceInfoOperator> _logger;
        private readonly ILockTaskManager _lockTaskManager;
        private readonly MfpCorePropertySettings _mfpCorePropertySettings;
        private bool _currentDeviceLock;

        /// <summary>
        /// Initializes a new instance of the <see cref="DeviceInfoOperator" /> class
        /// </summary>
        /// <param name="openApiRequestSettings">The open API request settings.</param>
        /// <param name="openApiOpenApiController">IOpenApiController</param>
        /// <param name="pushNotifier">IPushNotifier</param>
        /// <param name="mfpReadyManage">IMfpReadyManage</param>
        /// <param name="deviceDescriptionOperator">IDeviceDescriptionOperator</param>
        /// <param name="lockTaskManager">Lock task manager</param>
        /// <param name="logger">Logger</param>
        /// <param name="mfpCorePropertySettings">The MFP core property settings.</param>
        public DeviceInfoOperator(
            OpenApiRequestSettings openApiRequestSettings,
            IOpenApiController openApiOpenApiController,
            IPushNotifier pushNotifier,
            IMfpReadyManage mfpReadyManage,
            IDeviceDescriptionOperator deviceDescriptionOperator,
            ILockTaskManager lockTaskManager,
            ILogger<DeviceInfoOperator> logger,
            IOptions<MfpCorePropertySettings> mfpCorePropertySettings)
            : base(openApiRequestSettings, openApiOpenApiController)
        {
            _pushNotifier = pushNotifier;
            _mfpReadyManage = mfpReadyManage;
            _descriptionOperator = deviceDescriptionOperator;
            _lockTaskManager = lockTaskManager;
            _logger = logger;
            _mfpCorePropertySettings = mfpCorePropertySettings.Value;
        }

        /// <summary>
        /// Get printer encryption setting
        /// </summary>
        /// <returns>Result of AppResGetPrinterEncryptionSettingForDriver</returns>
        public async Task<PrinterEncryptionSetting> GetPrinterEncryptionSettingAsync()
        {
            try
            {
                _logger.LogInformation("GetPrinterEncryptionSetting");
                PrinterEncryptionSetting result;

                var content = await OpenApiController.GetPrinterEncryptionSettingAsync();
                if (content.GetElementsByTagName("ResultInfo")?[0].InnerText != ResponseStatus.Ack.ToString())
                {
                    throw new OpenApiNackException(content);
                }

                var type = (PrinterEncryptionType)Enum.Parse(
                    typeof(PrinterEncryptionType),
                    content.GetElementsByTagName("Type")?[0].InnerText);

                switch (type)
                {
                    case PrinterEncryptionType.FactoryDefault:
                        result = new PrinterEncryptionSetting
                        {
                            Type = PrinterEncryptionType.FactoryDefault
                        };
                        break;
                    case PrinterEncryptionType.UserDefined:
                        result = new PrinterEncryptionSetting
                        {
                            Type = PrinterEncryptionType.UserDefined,
                            EncryptionWord = content.GetElementsByTagName("EncryptionWord")?[0].InnerText
                        };
                        break;
                    default:
                        throw new OpenApiRequestException(OpenApiResultStatus.OtherError, "Type is unidentified");
                }

                return result;
            }
            catch (Exception ex)
            {
                var message = new ExceptionMessage(ex).ToString();
                _logger.LogWarning(default(EventId), ex, message);
                throw;
            }
        }

        /// <summary>
        /// Get serial number
        /// </summary>
        /// <returns>Serial number</returns>
        public async Task<string> GetSerialNumberAsync()
        {
            string result = null;

            try
            {
                _logger.LogInformation("GetSerialNumber");

                var content = await OpenApiController.GetDeviceInfoDetailAsync(DetailSettingsRequestItems.System);
                var response = content.SelectSingleNode("/AppResGetDeviceInfoDetail/System/SerialNumber");
                if (response != null)
                {
                    result = response.InnerText;
                }
                else
                {
                    throw new XmlException("Could not found AppResGetDeviceInfoDetail tag.");
                }
            }
            catch (Exception e)
            {
                _logger.LogError("[GetSerialNumber]", e);
            }

            return result;
        }

        /// <summary>
        /// Convert message data
        /// </summary>
        /// <param name="warningChangeMessage">DevRptNotifyWarningChange message</param>
        /// <returns>DevRptNotifyWarningChange</returns>
        public DevRptNotifyWarningChange ConvertNotifyWarningChange(string warningChangeMessage)
        {
            _logger.LogInformation("ConvertNotifyWarningChange");
            DevRptNotifyWarningChange content = XmlConverter.Deserialize<DevRptNotifyWarningChange>(warningChangeMessage, "m:DevRptNotifyWarningChange");

            // Add serial number to order
            List<DevRptNotifyWarningChange.WarningInformation> warningInformationList = content.WarningInformationList;
            if (warningInformationList != null)
            {
                foreach (DevRptNotifyWarningChange.WarningInformation warningInformation in warningInformationList)
                {
                    DevRptNotifyWarningChange.WarningInformation.WarningInfoStruct warningInfoStruct = warningInformation.WarningInfo;
                    if (warningInfoStruct != null)
                    {
                        int i = 1;
                        foreach (DevRptNotifyWarningChange.WarningInformation.WarningInfoStruct.WarningMessageInfo warningMessageInfo in warningInfoStruct.WarningMessageInfoList)
                        {
                            warningMessageInfo.Order = i;
                            i++;
                        }
                    }
                }
            }

            return content;
        }

        /// <summary>
        /// Get machine image file
        /// </summary>
        /// <param name="path">File path</param>
        /// <returns>Machine image file</returns>
        public async Task<AttachmentData> GetMachineImageFileAsync(string path)
        {
            _logger.LogInformation(nameof(GetMachineImageFileAsync));

            var rsp = await OpenApiController.RequestFileDataAsync(AppRequestItemType.ShMachineChart, path);
            if (rsp.Attachment == null)
            {
                _logger.LogWarning($"{nameof(GetMachineImageFileAsync)} failed {rsp.Message}");
                return null;
            }

            var fileData = XmlConverter.Deserialize<AppResGetFileData>(rsp.Message, "AppResGetFileData");
            var attach = new AttachmentData
            {
                Name = fileData.DownloadFileId.ToString(),
                FileName = fileData.FileName,
                Binary = rsp.Attachment
            };

            return attach;
        }

        /// <summary>
        /// Process DevRptEventOccurNotifyToSH message
        /// </summary>
        /// <param name="devRptEventOccurNotifyToSHmessage">DevRptEventOccurNotifyToSH message</param>
        public async Task NotifyDeviceEventAsync(string devRptEventOccurNotifyToSHmessage)
        {
            _logger.LogInformation(nameof(NotifyDeviceEventAsync));

            try
            {
                var content = new XmlDocument();
                content.LoadXml(devRptEventOccurNotifyToSHmessage);

                // select body element
                var rootNode = content.GetElementsByTagName("m:DevRptEventOccurNotifyToSH")?[0];

                // if event type is mfp poweroff, then stop wakeup timer.
                var eventOccurType = rootNode?.SelectSingleNode("EventOccurType")?.InnerText;
                if (eventOccurType == "MFP_PowerOFf")
                {
                    _mfpReadyManage.Pause();
                }
                else if (eventOccurType == "DeviceLock" || eventOccurType == "DeviceUnlock")
                {
                    // Since it may not be notified according to the specification of MFP,
                    // "DeviceLock" and "DeviceUnlock" of DevRptEventOccurNotifyToSH are not notified.
                    return;
                }

                await NotifyDeviceEventAsync(new EventState(eventOccurType));
            }
            catch (Exception e)
            {
                _logger.LogTrace(default(EventId), e, "[ProcessDeviceEventOccur]");
            }
        }

        /// <summary>
        /// Notify DevRptEventOccurNotifyToSH to MfpService
        /// </summary>
        /// <param name="eventState">Event state for notify</param>
        public async Task NotifyDeviceEventAsync(EventState eventState)
        {
            // push to service
            var pushResult = await _pushNotifier.PostAsync("v1.0/private/device/event", eventState);
            if (pushResult != null)
            {
                var statusCode = pushResult.StatusCode;
                if (!pushResult.IsSuccessStatusCode)
                {
                    _logger.LogWarning($"[NotifyDeviceEvent] Push to MFP Service failed. Code = {statusCode}");
                }
                else
                {
                    _logger.LogInformation($"[NotifyDeviceEvent] Push to MFP Service succeeded. Code = {statusCode}");
                }
            }
        }

        /// <summary>
        /// Notify device lock event.
        /// </summary>
        /// <param name="request">DevRptNotifyDeviceStatus2 message</param>
        public async Task NotifyDeviceLockEventAsync(string request)
        {
            // Could also be done using the task factory.
            await SemaphoreSync.WaitAsync().ConfigureAwait(false);

            try
            {
                var parser = new SoapXmlParser(request,
                    OpenApiOpenApiRequestSettings.MfpConnectorSetting.OpenApi.Version);
                var deviceStatusNode = parser.GetNode("/SOAP-ENV:Envelope/SOAP-ENV:Body").FirstChild;
                var deviceLockText = deviceStatusNode.SelectSingleNode("SystemStatus/DeviceLock")?.InnerText;
                
                bool.TryParse(deviceLockText, out var deviceLock);
                
                if (deviceLock)
                {   
                        var deviceStatus = await GetDeviceStatusAsync().ConfigureAwait(false);
                        deviceLock = deviceStatus.SystemStatus.DeviceLock;
                }

                if (deviceLock == _currentDeviceLock)
                {
                    return;
                }

                _currentDeviceLock = deviceLock;
                var wphLock = _lockTaskManager.TouchCurrentTaskForNotify();

                var eventOccurType = "DeviceUnlock";
                if (deviceLock)
                {
                    eventOccurType = wphLock ? "WPH_DeviceLock" : "DeviceLock";
                }

                await NotifyDeviceEventAsync(new EventState(eventOccurType)).ConfigureAwait(false);
            }
            catch (OpenApiRequestException e)
            {
                _logger.LogError(default(EventId), e, "[GetDeviceStatusAsync] Getting device Status failed.");
            }
            finally
            {
                SemaphoreSync.Release();
            }
        }

        /// <summary>
        /// Get MFP product info
        /// </summary>
        public async Task<MfpProductInfo> GetMfpProductInfoAsync()
        {
            MfpProductInfo mfpProductInfo = null;

            try
            {
                mfpProductInfo = new MfpProductInfo();
                _logger.LogDebug("GetMfpProductInfoAsync");
                var productId = GetMfpProductIdAsync();
                var marketArea = GetMfpMarketAreaAsync();

                await Task.WhenAll(productId, marketArea).ConfigureAwait(false);

                mfpProductInfo.ProductId = await productId.ConfigureAwait(false);
                mfpProductInfo.MarketArea = await marketArea.ConfigureAwait(false);
            }
            catch (Exception e)
            {
                _logger.LogError(default(EventId), e, "[GetMfpProductInfoAsync] Getting product infomation service failed.");
            }

            return mfpProductInfo;
        }

        /// <summary>
        /// Get MFP Product ID
        /// </summary>
        /// <returns>Product ID</returns>
        public async Task<string> GetMfpProductIdAsync()
        {
            try
            {
                _logger.LogDebug("GetMfpProductIdAsync");
                var contentSystem = await OpenApiController.GetDeviceInfoDetailAsync(DetailSettingsRequestItems.System);
                var resSystem = contentSystem.SelectSingleNode("/AppResGetDeviceInfoDetail/System/ProductID");
                if (resSystem != null)
                {
                    return resSystem.InnerText;
                }
            }
            catch (Exception e)
            {
                _logger.LogError(default(EventId), e, "[GetMfpProductIdAsync] Getting product ID service failed.");
            }

            return string.Empty;
        }

        /// <summary>
        /// AppReqGetDeviceInfoDetail(RequestItems.System)
        /// </summary>
        /// <returns>Product ID</returns>
        public Task<XmlDocument> GetMfpSystemAsync()
        {
            _logger.LogDebug("GetMfpProductIdAsync");
            return OpenApiController.GetDeviceInfoDetailAsync(DetailSettingsRequestItems.System);
        }

        /// <summary>
        /// Get MFP Market Area
        /// </summary>
        /// <returns>Market Area</returns>
        public async Task<string> GetMfpMarketAreaAsync()
        {
            try
            {
                _logger.LogDebug("GetMfpMarketAreaAsync");
                var contentArea = await OpenApiController
                    .GetDeviceInfoDetailAsync(DetailSettingsRequestItems.MarketArea)
                    .ConfigureAwait(false);
                var resArea = contentArea.SelectSingleNode("/AppResGetDeviceInfoDetail/MarketArea");
                if (resArea != null)
                {
                    return resArea.InnerText;
                }
            }
            catch (Exception e)
            {
                _logger.LogError(default(EventId), e, "[GetMfpMarketAreaAsync] Getting market area service failed.");
            }

            return string.Empty;
        }

        /// <summary>
        /// Get MFP device info
        /// </summary>
        public async Task<MfpDeviceInfo> GetMfpDeviceInfoAsync()
        {
            var mfpDeviceInfo = new MfpDeviceInfo();
            _logger.LogInformation("GetMfpDeviceInfo");

            try
            {
                var deviceDescription = _descriptionOperator.GetDeviceDescription();
                mfpDeviceInfo.ProductName = deviceDescription?.Configuration?.DeviceConfiguration?.ProductName;
                mfpDeviceInfo.CompanyName = deviceDescription?.Configuration?.DeviceConfiguration?.CompanyName;
                mfpDeviceInfo.Color = deviceDescription?.Configuration?.DeviceConfiguration?.Color.Printer ?? false;

                var contentOption = await OpenApiController.GetDeviceInfoAsync(GetDeviceInfoRequestItems.Option);
                var resDuplex = contentOption.SelectSingleNode("/AppResGetDeviceInfo/Option/Duplex/Installed");
                if (resDuplex != null)
                {
                    mfpDeviceInfo.Duplex = bool.Parse(resDuplex.InnerText);
                }

                var resCornerStaple = contentOption.SelectSingleNode("/AppResGetDeviceInfo/Option/Output/Function/CornerStaple");
                if (resCornerStaple != null)
                {
                    mfpDeviceInfo.CornerStaple = bool.Parse(resCornerStaple.InnerText);
                }

                var resSideStaple = contentOption.SelectSingleNode("/AppResGetDeviceInfo/Option/Output/Function/SideStaple");
                if (resSideStaple != null)
                {
                    mfpDeviceInfo.SideStaple = bool.Parse(resSideStaple.InnerText);
                }

                var resPunch2Point = contentOption.SelectSingleNode("/AppResGetDeviceInfo/Option/Output/Function/Punch2ServiceSetting");
                if (resPunch2Point != null)
                {
                    mfpDeviceInfo.Punch2Point = bool.Parse(resPunch2Point.InnerText);
                }

                var resPunch3Point = contentOption.SelectSingleNode("/AppResGetDeviceInfo/Option/Output/Function/Punch3ServiceSetting");
                if (resPunch3Point != null)
                {
                    mfpDeviceInfo.Punch3Point = bool.Parse(resPunch3Point.InnerText);
                }

                var resPunch4Point = contentOption.SelectSingleNode("/AppResGetDeviceInfo/Option/Output/Function/Punch4ServiceSetting");
                if (resPunch4Point != null)
                {
                    mfpDeviceInfo.Punch4Point = bool.Parse(resPunch4Point.InnerText);
                }

                var contentTray = await OpenApiController.GetDevicePartsStatusAsync("FeedTray");
                var resTrays = contentTray.SelectNodes("/AppResGetDevicePartsStatus/FeedTrayStatusList/FeedTrayStatus");

                if (resTrays != null)
                {
                    var trays = new List<Tray>();
                    foreach (XmlNode res in resTrays)
                    {
                        trays.Add(new Tray(res));
                    }
                    mfpDeviceInfo.Trays = trays;
                }
            }
            catch (Exception e)
            {
                _logger.LogTrace(default(EventId), e, "[GetMfpDeviceInfo]");
            }

            return mfpDeviceInfo;
        }

        /// <summary>
        /// Notify DevRptNotifyDevicePartsStatus to MfpService
        /// </summary>
        /// <param name="infoModel">Model of device parts status</param>
        public async Task NotifyDevicePartsStatusAsync(NotifyDevicePartsStatus infoModel)
        {
            var pushResult = await _pushNotifier.PostAsync(DevicePartsStatusEndpoint, infoModel);
            if (pushResult != null)
            {
                var statusCode = pushResult.StatusCode;
                if (pushResult.IsSuccessStatusCode)
                {
                    _logger.LogInformation($"[NotifyDevicePartsStatusEvent] Push to MFP Service succeeded. Code = {statusCode}");
                }
                else
                {
                    _logger.LogWarning($"[NotifyDevicePartsStatusEvent] Push to MFP Service failed. Code = {statusCode}");
                }
            }
            else
            {
                _logger.LogDebug($"There is nothing to notify device parts status. {GetType().Name}");
            }
        }

        /// <summary>
        /// Notify DevRptNotifyPowerStatus to MfpService
        /// </summary>
        /// <param name="powerStatus">Model of power status</param>
        /// <returns>A task</returns>
        public async Task NotifyPowerStatusAsync(NotifyPowerStatus powerStatus)
        {
            var pushResult = await _pushNotifier.PostAsync(_mfpCorePropertySettings.MfpServiceEndpoints.NotifyPowerStatusUri, powerStatus);
            if (pushResult != null)
            {
                var statusCode = pushResult.StatusCode;
                if (pushResult.IsSuccessStatusCode)
                {
                    _logger.LogInformation("[NotifyPowerStatusEvent] Push to MFP Service succeeded. Code = " + statusCode);
                }
                else
                {
                    _logger.LogWarning("[NotifyPowerStatusEvent] Push to MFP Service failed. Code = " + statusCode);
                }
            }
            else
            {
                _logger.LogDebug("There is nothing to notify power status.", GetType().Name);
            }
        }

        /// <summary>
        /// Get MFP device status
        /// </summary>
        public async Task<MfpDeviceStatus> GetDeviceStatusAsync()
        {
            MfpDeviceStatus deviceStatus;
            _logger.LogInformation("GetDeviceStatus");

            var content = await OpenApiController.GetDevicePowerStatusAsync();
            var appRes = content.SelectSingleNode("/AppResGetDeviceStatus2");
            var serializer = new XmlSerializer(typeof(MfpDeviceStatus));
            using (var tr = new StringReader(appRes.OuterXml))
            {
                deviceStatus = (MfpDeviceStatus)serializer.Deserialize(tr);
            }

            return deviceStatus;
        }

        /// <summary>
        /// Get MFP Fax Capability info
        /// </summary>
        public async Task<MfpFaxCapabilityInfo> GetMfpFaxCapabilityInfoAsync()
        {
            var mfpFaxCapabilityInfo = new MfpFaxCapabilityInfo();

            var contentOption = await OpenApiController.GetDeviceInfoAsync(GetDeviceInfoRequestItems.SupportFunction);
            var resFax = contentOption.SelectSingleNode($"{BaseSupporFuncXPath}Fax");

            mfpFaxCapabilityInfo.FaxEnabled = resFax != null && bool.TryParse(resFax.InnerText, out var faxEnabled) && faxEnabled;

            return mfpFaxCapabilityInfo;
        }

        /// <summary>
        /// Set MFP tray information
        /// </summary>
        /// <param name="trayInfoList">Tray setting value</param>
        /// <returns>Returns true if successfully updated.</returns>
        public async Task<bool> SetTrayInfoSettingAsync(List<TrayInfo> trayInfoList)
        {
            var responseXml = await OpenApiController.SetTrayInfoSettingAsync(trayInfoList);

            return responseXml.GetElementsByTagName("ResultInfo")?[0].InnerText == ResponseStatus.Ack.ToString();
        }

        /// <summary>
        /// Get MFP device version.
        /// </summary>
        /// <param name="name">MFP device version name value</param>
        /// <returns>Return the version with the name specified by the argument.</returns>
        public async Task<string> GetMfpDeviceVersionAsync(string name)
        {
            try
            {
                // Get MFP device version.
                var document = await OpenApiController.GetDeviceInfoDetailAsync(DetailSettingsRequestItems.Version);
                var response = new OpenApiMessage(document.OuterXml);

                if (!response.TryGetXmlNode($"/AppResGetDeviceInfoDetail/VersionList/Version[Name='{name}']/Code",
                    out var node))
                {
                    throw new OpenApiNackException(document, "Version not found.");
                }

                return node.InnerText;
            }
            catch (OpenApiFaultException e)
            {
                throw new OpenApiFaultException(e, e.FaultMessage);
            }
        }

        /// <summary>
        /// Get MFP application option.
        /// </summary>
        /// <returns>Return the license.(stamp, ooxml)</returns>
        public async Task<MfpApplicationOption> GetMfpApplicationOptionAsync()
        {
            _logger.LogDebug("GetMfpApplicationOptionAsync");

            var contentSupportFunction = await GetMfpSupportFunctionAsync().ConfigureAwait(false);

            var stampText = contentSupportFunction.SelectSingleNode(StampNodeXpath)?.InnerText;
            var ooxmlValue = contentSupportFunction.SelectSingleNode(FileWithLicenseXpath)?.InnerText;

            return new MfpApplicationOption
            {
                Stamp = (SwitchOption)Enum.Parse(typeof(SwitchOption), stampText ?? string.Empty),
                Ooxml = (SwitchOption)Enum.Parse(typeof(SwitchOption), ooxmlValue ?? string.Empty)
            };
        }

        /// <summary>
        /// AppReqGetDeviceInfo(RequestItems.SupportFunction)
        /// </summary>
        /// <returns>Return AppResGetDeviceInfo xml.</returns>
        public Task<XmlDocument> GetMfpSupportFunctionAsync()
        {
            _logger.LogDebug("GetMfpSupportFunctionAsync");
            return OpenApiController.GetDeviceInfoAsync(GetDeviceInfoRequestItems.SupportFunction);
        }

        /// <summary>
        /// Get the functions supported by the MFP.
        /// </summary>
        /// <returns>Return whether MFP functions is supported.</returns>
        public async Task<MfpSupportFunctions> GetMfpSupportFunctionsAsync()
        {
            _logger.LogDebug("GetMfpSupportFunctionsAsync");

            var supportFunctions = await GetMfpSupportFunctionAsync();

            return new MfpSupportFunctions
            {
                Copy = Convert.ToBoolean(GetNodeInnerTextToType(supportFunctions, $"{BaseSupporFuncXPath}Copy")),
                Print = Convert.ToBoolean(GetNodeInnerTextToType(supportFunctions, $"{BaseSupporFuncXPath}Print")),
                Scan = Convert.ToBoolean(GetNodeInnerTextToType(supportFunctions, $"{BaseSupporFuncXPath}Scan")),
                Fax = Convert.ToBoolean(GetNodeInnerTextToType(supportFunctions, $"{BaseSupporFuncXPath}Fax")),
                Fax2 = Convert.ToBoolean(GetNodeInnerTextToType(supportFunctions, $"{BaseSupporFuncXPath}Fax2")),
                Fax3 = (SwitchOption)Enum.Parse(typeof(SwitchOption),
                    GetNodeInnerTextToType(supportFunctions, $"{BaseSupporFuncXPath}Fax3")),
                Fax4 = (SwitchOption)Enum.Parse(typeof(SwitchOption),
                    GetNodeInnerTextToType(supportFunctions, $"{BaseSupporFuncXPath}Fax4"))
            };
        }

        /// <summary>
        /// Request to get whether mfp is envelope mode or not.
        /// </summary>
        /// <returns>Return whether mfp is envelope mode or not.</returns>
        public async Task<Envelope> GetEnvelopeModeStateAsync()
        {
            _logger.LogDebug("GetEnvelopeModeStateAsync");

            var supportFunctions = await GetMfpSupportFunctionAsync();

            return new Envelope
            {
                Mode = Convert.ToBoolean(GetNodeInnerTextToType(supportFunctions, $"{BaseSupporFuncXPath}FixingSeparationState"))
            };
        }

        /// <summary>
        /// Get mfp finisher function.
        /// </summary>
        /// <returns>Return whether MFP functions is supported.</returns>
        public async Task<MfpFinisher> GetMfpFinisherAsync()
        {
            _logger.LogDebug("GetMfpFinisherAsync");

            const string finisherXPath = "/AppResGetDeviceInfoDetail/Output/FinisherList/Finisher/ProductName";
            var content = await OpenApiController.GetDeviceInfoDetailAsync(DetailSettingsRequestItems.Output);

            return new MfpFinisher
            {
                ProductName = GetNodeInnerTextToType(content, finisherXPath)
            };
        }

        private string GetNodeInnerTextToType(XmlNode node, string xpath)
        {
            return node.SelectSingleNode(xpath)?.InnerText;
        }

        /// <summary>
        /// Get MFP ManualTrayPaperSizeUnmatch.
        /// </summary>
        /// <returns>ManualTrayPaperSizeUnmatch</returns>
        public async Task<Boolean> GetMfpManualTrayPaperSizeUnmatchAsync()
        {
            var contentTray = await OpenApiController.GetDevicePartsStatusAsync("FeedTray").ConfigureAwait(false);
            return System.Convert.ToBoolean(
                    contentTray.SelectSingleNode(
                        "/AppResGetDevicePartsStatus/FeedTrayStatusList/FeedTrayStatus/ManualTrayPaperSizeUnmatch")
                    .InnerText);
        }
    }
}
