﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System.Collections.Generic;

namespace ServiceHub.Processors.DeviceInfo.Model
{
    /// <summary>
    /// Mfp Fax Capability Info
    /// </summary>
    public class MfpFaxCapabilityInfo
    {
        /// <summary>
        /// Mfp Fax Capability Info
        /// </summary>
        [JsonProperty(PropertyName = "fax_enabled", Required = Required.Always)]
        public bool FaxEnabled { get; set; }
    }
}
