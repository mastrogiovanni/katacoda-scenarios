﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace ServiceHub.Processors.DeviceInfo.Model
{
    /// <summary>
    /// Mfp Lock Info
    /// </summary>
    public class LockInfo
    {
        /// <summary>
        /// Device Lock
        /// </summary>
        [JsonProperty(PropertyName = "device_lock", Required = Required.Always)]
        public bool DeviceLock { get; set; }
    }
}
