﻿using System.Xml.Serialization;

namespace ServiceHub.Processors.DeviceInfo.Model.OpenApi
{
    /// <summary>
    /// Scanner Status
    /// </summary>
    public class ScannerStatusModel
    {
        /// <summary>
        /// Status
        /// </summary>
        [XmlElement("Status")]
        public string Status { get; set; }

        /// <summary>
        /// Detail
        /// </summary>
        [XmlElement("Detail")]
        public string Detail { get; set; }

        /// <summary>
        /// Status
        /// </summary>
        [XmlElement("ErrorCode")]
        public int? ErrorCode { get; set; }
    }
}
