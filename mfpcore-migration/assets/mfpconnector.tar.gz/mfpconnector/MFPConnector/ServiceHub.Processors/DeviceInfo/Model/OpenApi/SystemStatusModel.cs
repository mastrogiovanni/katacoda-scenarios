﻿using System.Xml.Serialization;

namespace ServiceHub.Processors.DeviceInfo.Model.OpenApi
{
    /// <summary>
    /// System Status
    /// </summary>
    public class SystemStatusModel
    {
        /// <summary>
        /// ServiceMode
        /// </summary>
        [XmlElement("ServiceMode")]
        public bool ServiceMode { get; set; }

        /// <summary>
        /// AdminMode
        /// </summary>
        [XmlElement("AdminMode")]
        public bool AdminMode { get; set; }

        /// <summary>
        /// DeviceLock
        /// </summary>
        [XmlElement("DeviceLock")]
        public bool DeviceLock { get; set; }

        /// <summary>
        /// TwainLock
        /// </summary>
        [XmlElement("TwainLock")]
        public bool TwainLock { get; set; }

        /// <summary>
        /// ProgramUpdate
        /// </summary>
        [XmlElement("ProgramUpdate")]
        public bool ProgramUpdate { get; set; }

        /// <summary>
        /// Interrupt
        /// </summary>
        [XmlElement("Interrupt")]
        public bool Interrupt { get; set; }
    }
}
