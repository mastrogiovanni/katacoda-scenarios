﻿using System.Xml.Serialization;

namespace ServiceHub.Processors.DeviceInfo.Model.OpenApi
{
    /// <summary>
    /// Temporary Rescue
    /// </summary>
    public class TemporaryRescueModel
    {
        /// <summary>
        /// Tray1
        /// </summary>
        [XmlElement("Tray1")]
        public string Tray1 { get; set; }

        /// <summary>
        /// Tray2
        /// </summary>
        [XmlElement("Tray2")]
        public string Tray2 { get; set; }

        /// <summary>
        /// Tray3
        /// </summary>
        [XmlElement("Tray3")]
        public string Tray3 { get; set; }
        
        /// <summary>
        /// Tray4
        /// </summary>
        [XmlElement("Tray4")]
        public string Tray4 { get; set; }

        /// <summary>
        /// Lct
        /// </summary>
        [XmlElement("Lct")]
        public string Lct { get; set; }

        /// <summary>
        /// IrEdh
        /// </summary>
        [XmlElement("IrEdh")]
        public string IrEdh { get; set; }

        /// <summary>
        /// ManualTray
        /// </summary>
        [XmlElement("ManualTray")]
        public string ManualTray { get; set; }

        /// <summary>
        /// YMCUnit
        /// </summary>
        [XmlElement("YMCUnit")]
        public string YMCUnit { get; set; }

        /// <summary>
        /// Adf
        /// </summary>
        [XmlElement("Adf")]
        public string Adf { get; set; }

        /// <summary>
        /// PaperInputTray
        /// </summary>
        [XmlElement("PaperInputTray")]
        public string PaperInputTray { get; set; }

        /// <summary>
        /// Punch
        /// </summary>
        [XmlElement("Punch")]
        public string Punch { get; set; }

        /// <summary>
        /// PZFolder
        /// </summary>
        [XmlElement("PZFolder")]
        public string PZFolder { get; set; }

        /// <summary>
        /// Folder
        /// </summary>
        [XmlElement("Folder")]
        public string Folder { get; set; }

        /// <summary>
        /// Staple
        /// </summary>
        [XmlElement("Staple")]
        public string Staple { get; set; }
    }
}
