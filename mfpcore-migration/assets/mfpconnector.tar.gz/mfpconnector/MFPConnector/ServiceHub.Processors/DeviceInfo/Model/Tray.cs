using System.Xml;
using Newtonsoft.Json;

namespace ServiceHub.Processors.DeviceInfo.Model
{
    /// <summary>
    /// Trays info
    /// </summary>
    public class Tray
    {
        public Tray(XmlNode trayNode)
        {
            var resPaperDimensionX = string.Empty;
            var resPaperDimensionY = string.Empty;

            var resPaperDimension = trayNode.SelectSingleNode("PaperSize/Dimension2");
            if (resPaperDimension != null)
            {
                resPaperDimensionX = trayNode.SelectSingleNode("PaperSize/Dimension2/X")?.InnerText;
                resPaperDimensionY = trayNode.SelectSingleNode("PaperSize/Dimension2/Y")?.InnerText;
            }

            TrayId = trayNode.SelectSingleNode("Name")?.InnerText ?? string.Empty;
            SizeCode = trayNode.SelectSingleNode("PaperSize/SizeCode")?.InnerText ?? string.Empty;
            LevelState = trayNode.SelectSingleNode("PaperStatus")?.InnerText ?? string.Empty;
            MediaType = trayNode.SelectSingleNode("PaperType")?.InnerText ?? string.Empty;
            FeedDirection = trayNode.SelectSingleNode("PaperSize/FeedDirection")?.InnerText ?? string.Empty;
            PaperDimension = new PaperDimension
            {
                DimensionX = resPaperDimensionX,
                DimensionY = resPaperDimensionY
            };
            CustomPaperType = new CustomPaperType
            {
                Name = trayNode.SelectSingleNode("CustomPaperData/Name")?.InnerText ?? string.Empty,
                MediaType = trayNode.SelectSingleNode("CustomPaperData/MediaType")?.InnerText ?? string.Empty
            };
        }

        [JsonProperty(PropertyName = "tray_id", Required = Required.Always)]
        public string TrayId { get; set; }

        [JsonProperty(PropertyName = "size_code", Required = Required.Always)]
        public string SizeCode { get; set; }

        [JsonProperty(PropertyName = "level_state", Required = Required.Always)]
        public string LevelState { get; set; }

        [JsonProperty(PropertyName = "media_type", Required = Required.Always)]
        public string MediaType { get; set; }

        [JsonProperty(PropertyName = "feed_direction", Required = Required.Always)]
        public string FeedDirection { get; set; }

        [JsonProperty(PropertyName = "dimension", Required = Required.Always)]
        public PaperDimension PaperDimension { get; set; }

        [JsonProperty(PropertyName = "custom_paper_type", Required = Required.Always)]
        public CustomPaperType CustomPaperType { get; set; }
    }
}
