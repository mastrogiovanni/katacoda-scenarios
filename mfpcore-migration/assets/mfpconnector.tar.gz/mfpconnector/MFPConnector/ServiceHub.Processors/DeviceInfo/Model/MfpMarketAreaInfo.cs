﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace ServiceHub.Processors.DeviceInfo.Model
{
    /// <summary>
    /// Mfp Market Area Info
    /// </summary>
    public class MfpMarketAreaInfo
    {
        /// <summary>
        /// Mfp Market Area Info
        /// </summary>
        [JsonProperty(PropertyName = "market_area", Required = Required.Always)]
        [JsonConverter(typeof(StringEnumConverter))]
        public string MarketArea { get; set; }

        /// <summary>
        /// Verification of MFP market area for response
        /// </summary>
        /// <returns>Verification result</returns>
        public bool ValidateMfpMarketAreaResponse() => !string.IsNullOrEmpty(MarketArea);
    }
}
