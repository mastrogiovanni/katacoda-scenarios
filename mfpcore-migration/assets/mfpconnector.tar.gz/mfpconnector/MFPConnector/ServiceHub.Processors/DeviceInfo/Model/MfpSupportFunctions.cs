﻿using ServiceHub.Common.Model;

namespace ServiceHub.Processors.DeviceInfo.Model
{
    /// <summary>
    /// Mfp Support Functions
    /// </summary>
    public class MfpSupportFunctions
    {
        /// <summary>
        /// Copy function support
        /// </summary>
        public bool Copy { get; set; }

        /// <summary>
        /// Print function support
        /// </summary>
        public bool Print { get; set; }

        /// <summary>
        /// Scan function support
        /// </summary>
        public bool Scan { get; set; }

        /// <summary>
        /// Fax function support
        /// </summary>
        public bool Fax { get; set; }

        /// <summary>
        /// Fax2 function support
        /// </summary>
        public bool Fax2 { get; set; }

        /// <summary>
        /// Fax3 function support
        /// </summary>
        public SwitchOption Fax3 { get; set; }

        /// <summary>
        /// Fax4 function support
        /// </summary>
        public SwitchOption Fax4 { get; set; }
    }
}
