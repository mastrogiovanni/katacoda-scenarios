using ServiceHub.Processors.DeviceInfo.Model.OpenApi;

namespace ServiceHub.Processors.DeviceInfo.Model.DevRptNotifyDeviceStatus2
{
    /// <summary>
    /// DevRptNotifyDeviceStatus2 model class
    /// </summary>
    public class DevRptNotifyDeviceStatus2
    {
        /// <summary>
        /// System status
        /// </summary>
        public SystemStatusModel SystemStatus { get; set; }
    }
}
