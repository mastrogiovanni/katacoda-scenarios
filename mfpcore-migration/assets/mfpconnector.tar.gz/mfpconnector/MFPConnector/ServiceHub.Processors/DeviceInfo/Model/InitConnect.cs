﻿using Newtonsoft.Json;

namespace ServiceHub.Processors.DeviceInfo.Model
{
    /// <summary>
    /// Init connect
    /// </summary>
    public class InitConnect
    {
        /// <summary>
        /// Init connect result
        /// </summary>
        [JsonProperty(PropertyName = "result", Required = Required.Always)]
        public bool Result { get; set; }

    }
}
