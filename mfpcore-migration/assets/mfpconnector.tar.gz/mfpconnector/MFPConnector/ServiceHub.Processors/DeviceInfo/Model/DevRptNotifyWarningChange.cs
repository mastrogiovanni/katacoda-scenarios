using System.Collections.Generic;
using System.Xml.Serialization;
using Newtonsoft.Json;

namespace ServiceHub.Processors.DeviceInfo.Model
{
    /// <summary>
    /// DevRptNotifyWarningChange model class
    /// </summary>
    public class DevRptNotifyWarningChange
    {
        /// <summary>
        /// WarningMessageInfo class
        /// </summary>
        [JsonProperty(PropertyName = "warn_info_list", Required = Required.Always)]
        public List<WarningInformation> WarningInformationList { get; set; }

        /// <summary>
        /// WarningInformation class
        /// </summary>
        public class WarningInformation
        {
            /// <summary>
            /// WarningInfo class
            /// </summary>
            [JsonProperty(PropertyName = "warn_info_detail")]
            public WarningInfoStruct WarningInfo { get; set; }

            [JsonProperty(PropertyName = "warn_priority")]
            public int WarningPriority { get; set; }

            [JsonProperty(PropertyName = "machine_image_path")]
            public string MachineImagePath { get; set; }

            [XmlElement("AnimationID")]
            [JsonProperty(PropertyName = "animation_id")]
            public ushort AnimationId { get; set; }

            [JsonProperty(PropertyName = "animation_msg_list")]
            public List<AnimationMessageInfo> AnimationMessageInfoList { get; set; }

            /// <summary>
            /// AnimationMessageInfo class
            /// </summary>
            public class AnimationMessageInfo
            {
                [JsonProperty(PropertyName = "message_data")]
                public string MessageData { get; set; }
            }

            [XmlElement("JobID")]
            [JsonProperty(PropertyName = "job_id")]
            public ulong JobId { get; set; }

            [JsonProperty(PropertyName = "next_page")]
            public bool NextPage { get; set; }

            [JsonProperty(PropertyName = "warn_release_list")]
            public List<WarningRelease> WarningReleaseList { get; set; }

            /// <summary>
            /// WarningRelease class
            /// </summary>
            public class WarningRelease
            {
                [JsonProperty(PropertyName = "warn_cancel_type", Required = Required.Always)]
                public string WarningCancelType { get; set; }

                [JsonProperty(PropertyName = "warn_cancel_step", Required = Required.Always)]
                public bool? WarningCancelStep { get; set; }
            }

            /// <summary>
            /// WarningMessageInfo class
            /// </summary>
            public class WarningInfoStruct
            {
                [JsonProperty(PropertyName = "warn_disp_name")]
                public string WarningName { get; set; }

                [JsonProperty(PropertyName = "warn_disp_type")]
                public string WarningType { get; set; }

                [JsonProperty(PropertyName = "message_info_list")]
                public List<WarningMessageInfo> WarningMessageInfoList { get; set; }

                [JsonProperty(PropertyName = "manual_tray_flag")]
                public bool? ManualTrayPaperPresenceFlag { get; set; }

                /// <summary>
                /// WarningMessageInfo class
                /// </summary>
                public class WarningMessageInfo
                {
                    [JsonProperty(PropertyName = "order")]
                    public int Order { get; set; }

                    [JsonProperty(PropertyName = "schema_type")]
                    public string SchemaType { get; set; }

                    [JsonProperty(PropertyName = "message")]
                    public string MessageData { get; set; }

                    [JsonProperty(PropertyName = "manual_tray_info")]
                    public ManualTrayInfoDetail ManualTrayDetectedPaperSize { get; set; }
                }

                /// <summary>
                /// ManualTrayInfoDetail class
                /// </summary>
                public class ManualTrayInfoDetail
                {
                    [JsonProperty(PropertyName = "size_code")]
                    public string SizeCode { get; set; }

                    [JsonProperty(PropertyName = "feed_direction")]
                    public string FeedDirection { get; set; }
                }
            }
        }
    }
}