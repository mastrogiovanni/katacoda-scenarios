﻿using ServiceHub.Common.Constant;
using ServiceHub.Common.Model;

namespace ServiceHub.Processors.DeviceInfo.Model
{
    /// <summary>
    /// Mfp Application Option
    /// </summary>
    public class MfpApplicationOption
    {
        /// <summary>
        /// stamp license
        /// </summary>
        public SwitchOption Stamp { get; set; }

        /// <summary>
        /// ooxml license
        /// </summary>
        public SwitchOption Ooxml { get; set; }   
    }
}
