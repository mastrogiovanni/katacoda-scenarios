﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System.Collections.Generic;

namespace ServiceHub.Processors.DeviceInfo.Model
{
    /// <summary>
    /// Mfp Device Info
    /// </summary>
    public class MfpDeviceInfo
    {
        /// <summary>
        /// Mfp Device Info
        /// </summary>
        [JsonProperty(PropertyName = "product_name", Required = Required.Always)]
        public string ProductName { get; set; }

        [JsonProperty(PropertyName = "company_name", Required = Required.Always)]
        public string CompanyName { get; set; }

        [JsonProperty(PropertyName = "color", Required = Required.Always)]
        public bool Color { get; set; }

        [JsonProperty(PropertyName = "duplex", Required = Required.Always)]
        public bool Duplex { get; set; }

        [JsonProperty(PropertyName = "corner_staple", Required = Required.Always)]
        public bool CornerStaple { get; set; }

        [JsonProperty(PropertyName = "side_staple", Required = Required.Always)]
        public bool SideStaple { get; set; }

        [JsonProperty(PropertyName = "punch_2point", Required = Required.Always)]
        public bool Punch2Point { get; set; }

        [JsonProperty(PropertyName = "punch_3point", Required = Required.Always)]
        public bool Punch3Point { get; set; }

        [JsonProperty(PropertyName = "punch_4point", Required = Required.Always)]
        public bool Punch4Point { get; set; }

        [JsonProperty(PropertyName = "trays", Required = Required.Always)]
        public List<Tray> Trays { get; set; }

        /// <summary>
        /// Verification of MFP device information for response
        /// </summary>
        /// <returns>Verification result</returns>
        public bool ValidateMfpDeviceInfoResponse()
        {
            bool result = true;

            if (string.IsNullOrEmpty(this.ProductName))
            {
                result = false;
            }

            if (result && string.IsNullOrEmpty(this.CompanyName))
            {
                result = false;
            }

            return result;
        }
    }
}
