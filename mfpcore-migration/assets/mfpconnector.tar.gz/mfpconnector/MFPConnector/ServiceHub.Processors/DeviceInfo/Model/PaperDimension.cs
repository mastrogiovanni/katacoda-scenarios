﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace ServiceHub.Processors.DeviceInfo.Model
{
    /// <summary>
    /// Paper dmension
    /// </summary>
    public class PaperDimension
    {
        /// <summary>
        /// Trays Info
        /// </summary>
        [JsonProperty(PropertyName = "x", Required = Required.Always)]
        public string DimensionX { get; set; }

        [JsonProperty(PropertyName = "y", Required = Required.Always)]
        public string DimensionY { get; set; }

    }
}
