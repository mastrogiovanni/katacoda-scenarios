﻿using ServiceHub.Common.Model;

namespace ServiceHub.Processors.DeviceInfo.Model
{
    /// <summary>
    /// Get envelope mode state
    /// </summary>
    public class Envelope
    {
        /// <summary>
        /// Whether mfp is envelope mode or not.
        /// </summary>
        public bool Mode { get; set; }
    }
}
