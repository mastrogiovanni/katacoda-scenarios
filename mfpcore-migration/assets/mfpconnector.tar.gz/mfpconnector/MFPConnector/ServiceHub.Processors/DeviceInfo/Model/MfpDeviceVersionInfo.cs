﻿using Newtonsoft.Json;

namespace ServiceHub.Processors.DeviceInfo.Model
{
    public class MfpDeviceVersionInfo
    {
        /// <summary>
        /// Name to get version from Mfp.
        /// </summary>
        [JsonProperty(PropertyName = "target_name")]
        public string TargetName { get; set; }
    }
}
