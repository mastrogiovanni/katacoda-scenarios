﻿using Newtonsoft.Json;

namespace ServiceHub.Processors.DeviceInfo.Model
{
    /// <summary>
    /// Mfp Finisher Info
    /// </summary>
    public class MfpFinisher
    {
        /// <summary>
        /// Mfp Product Name
        /// </summary>
        [JsonProperty(PropertyName = "finisher_product_name", Required = Required.Always)]
        public string ProductName { get; set; }
    }
}
