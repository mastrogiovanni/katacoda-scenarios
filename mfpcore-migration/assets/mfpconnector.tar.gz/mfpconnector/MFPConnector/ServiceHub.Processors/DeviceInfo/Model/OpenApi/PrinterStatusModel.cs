﻿using System.Xml.Serialization;

namespace ServiceHub.Processors.DeviceInfo.Model.OpenApi
{
    /// <summary>
    /// Printer Status
    /// </summary>
    public class PrinterStatusModel
    {
        /// <summary>
        /// Status
        /// </summary>
        [XmlElement("Status")]
        public string Status { get; set; }

        /// <summary>
        /// Detail
        /// </summary>
        [XmlElement("Detail")]
        public string Detail { get; set; }

        /// <summary>
        /// Status
        /// </summary>
        [XmlElement("ErrorCode")]
        public int? ErrorCode { get; set; }
    }
}
