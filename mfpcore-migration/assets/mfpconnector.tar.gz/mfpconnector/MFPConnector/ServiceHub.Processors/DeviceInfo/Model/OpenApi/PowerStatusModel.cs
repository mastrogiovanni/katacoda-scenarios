﻿using System.Xml.Serialization;

namespace ServiceHub.Processors.DeviceInfo.Model.OpenApi
{
    /// <summary>
    /// Power Status
    /// </summary>
    public class PowerStatusModel
    {
        /// <summary>
        /// SubPower
        /// </summary>
        [XmlElement("SubPower")]
        public bool SubPower { get; set; }

        /// <summary>
        /// Sleep
        /// </summary>
        [XmlElement("Sleep")]
        public bool Sleep { get; set; }

        /// <summary>
        /// LowPower
        /// </summary>
        [XmlElement("LowPower")]
        public bool LowPower { get; set; }

        /// <summary>
        /// SuperWarp
        /// </summary>
        [XmlElement("SuperWarp")]
        public string SuperWarp { get; set; }
    }
}
