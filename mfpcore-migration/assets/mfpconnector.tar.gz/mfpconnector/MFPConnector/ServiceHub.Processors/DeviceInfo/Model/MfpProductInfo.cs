using Newtonsoft.Json;

namespace ServiceHub.Processors.DeviceInfo.Model
{
    /// <summary>
    /// Mfp Product Info
    /// </summary>
    public class MfpProductInfo : MfpMarketAreaInfo
    {
        /// <summary>
        /// Mfp Product Info
        /// </summary>
        [JsonProperty(PropertyName = "product_id", Required = Required.Always)]
        public string ProductId { get; set; }

        /// <summary>
        /// Verification of MFP product information for response
        /// </summary>
        /// <returns>Verification result</returns>
        public bool ValidateMfpProductInfoResponse() => !string.IsNullOrEmpty(ProductId) && !string.IsNullOrEmpty(MarketArea);
    }
}
