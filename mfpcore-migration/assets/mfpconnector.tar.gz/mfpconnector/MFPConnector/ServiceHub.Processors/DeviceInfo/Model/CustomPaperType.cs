﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace ServiceHub.Processors.DeviceInfo.Model
{
    /// <summary>
    /// Custom Paper Type
    /// </summary>
    public class CustomPaperType
    {
        /// <summary>
        /// Name
        /// </summary>
        [JsonProperty(PropertyName = "name")]
        public string Name { get; set; }

        /// <summary>
        /// MediaType
        /// </summary>
        [JsonProperty(PropertyName = "custom_media_type")]
        public string MediaType { get; set; }
    }
}