﻿using ServiceHub.Processors.DeviceInfo.Model.OpenApi;
using System.Xml.Serialization;

namespace ServiceHub.Processors.DeviceInfo.Model
{
    /// <summary>
    /// Mfp Device Status
    /// </summary>
    [XmlRoot("AppResGetDeviceStatus2")]
    public class MfpDeviceStatus
    {
        /// <summary>
        /// Result
        /// </summary>
        [XmlElement("Result")]
        public ResultModel Result { get; set; }

        /// <summary>
        /// PrinterStatus
        /// </summary>
        [XmlElement("PrinterStatus")]
        public PrinterStatusModel PrinterStatus { get; set; }

        /// <summary>
        /// ScannerStatus
        /// </summary>
        [XmlElement("ScannerStatus")]
        public ScannerStatusModel ScannerStatus { get; set; }

        /// <summary>
        /// SystemStatus
        /// </summary>
        [XmlElement("SystemStatus")]
        public SystemStatusModel SystemStatus { get; set; }

        /// <summary>
        /// PowerStatus
        /// </summary>
        [XmlElement("PowerStatus")]
        public PowerStatusModel PowerStatus { get; set; }

        /// <summary>
        /// TemporaryRescue
        /// </summary>
        [XmlElement("TemporaryRescue")]
        public TemporaryRescueModel TemporaryRescue { get; set; }
    }
}
