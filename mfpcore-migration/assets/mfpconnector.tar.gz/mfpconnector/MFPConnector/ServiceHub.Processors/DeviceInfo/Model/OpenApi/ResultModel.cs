﻿using System;
using System.Xml.Serialization;

namespace ServiceHub.Processors.DeviceInfo.Model.OpenApi
{
    /// <summary>
    /// Result Model
    /// </summary>
    public class ResultModel
    {
        [XmlElement("ResultInfo")]
        public String ResultInfo { get; set; }
    }
}
