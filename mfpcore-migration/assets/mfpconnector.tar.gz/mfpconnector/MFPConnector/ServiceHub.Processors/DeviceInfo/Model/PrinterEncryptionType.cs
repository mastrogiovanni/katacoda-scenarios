namespace ServiceHub.Processors.DeviceInfo.Model
{
    /// <summary>
    /// Printer encryption type
    /// </summary>
    public enum PrinterEncryptionType
    {
        FactoryDefault,
        UserDefined,
        Unidentified
    }
}
