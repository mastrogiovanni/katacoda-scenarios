using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace ServiceHub.Processors.DeviceInfo.Model
{
    /// <summary>
    /// Printer encryption setting
    /// </summary>
    public class PrinterEncryptionSetting
    {
        /// <summary>
        /// Printer encryption type
        /// </summary>
        public PrinterEncryptionType? Type { get; set; }

        /// <summary>
        /// Printer encryption word.
        /// </summary>
        public string EncryptionWord { get; set; }
    }
}
