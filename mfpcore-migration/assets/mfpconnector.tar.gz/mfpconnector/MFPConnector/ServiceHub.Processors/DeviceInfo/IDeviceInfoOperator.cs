using System;
using ServiceHub.Common.Model.DeviceInfo.NotifyToSh;
using ServiceHub.Connectors.OpenAPI.Model;
using ServiceHub.Processors.Common.Model;
using ServiceHub.Processors.DeviceInfo.Model;
using ServiceHub.Processors.Notify.Model;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Xml;

namespace ServiceHub.Processors.DeviceInfo
{
    /// <summary>
    /// Device information operator
    /// </summary>
    public interface IDeviceInfoOperator
    {
        /// <summary>
        /// Get printer encryption setting
        /// </summary>
        /// <returns>Result of AppResGetPrinterEncryptionSettingForDriver</returns>
        Task<PrinterEncryptionSetting> GetPrinterEncryptionSettingAsync();

        /// <summary>
        /// Get serial number
        /// </summary>
        /// <returns>Serial number</returns>
        Task<string> GetSerialNumberAsync();

        /// <summary>
        /// Convert message data
        /// </summary>
        /// <param name="warningChangeMessage">DevRptNotifyWarningChange message</param>
        /// <returns>DevRptNotifyWarningChange</returns>
        DevRptNotifyWarningChange ConvertNotifyWarningChange(string warningChangeMessage);

        /// <summary>
        /// Get machine image file
        /// </summary>
        /// <param name="path">File path</param>
        /// <returns>Machine image file</returns>
        Task<AttachmentData> GetMachineImageFileAsync(string path);

        /// <summary>
        /// Process DevRptEventOccurNotifyToSH message
        /// </summary>
        /// <param name="devRptEventOccurNotifyToSHmessage">DevRptEventOccurNotifyToSH message</param>
        Task NotifyDeviceEventAsync(string devRptEventOccurNotifyToSHmessage);

        /// <summary>
        /// Notify DevRptEventOccurNotifyToSH to MfpService
        /// </summary>
        /// <param name="eventState">Event state for notify</param>
        Task NotifyDeviceEventAsync(EventState eventState);

        /// <summary>
        /// Notify DevRptNotifyDevicePartsStatus to MfpService
        /// </summary>
        /// <param name="infoModel">Model of device parts status</param>
        Task NotifyDevicePartsStatusAsync(NotifyDevicePartsStatus infoModel);

        /// <summary>
        /// Notify device lock event.
        /// </summary>
        /// <param name="request">DevRptNotifyDeviceStatus2 message</param>
        Task NotifyDeviceLockEventAsync(string request);

        /// <summary>
        /// Get MFP product info
        /// </summary>
        Task<MfpProductInfo> GetMfpProductInfoAsync();

        /// <summary>
        /// Get MFP product id
        /// </summary>
        /// <returns>product id</returns>
        Task<string> GetMfpProductIdAsync();

        /// <summary>
        /// AppReqGetDeviceInfoDetail(RequestItems.System)
        /// </summary>
        /// <returns>product id</returns>
        Task<XmlDocument> GetMfpSystemAsync();

        /// <summary>
        /// Get MFP market area
        /// </summary>
        /// <returns>market area</returns>
        Task<string> GetMfpMarketAreaAsync();

        /// <summary>
        /// Get MFP device info
        /// </summary>
        Task<MfpDeviceInfo> GetMfpDeviceInfoAsync();

        /// <summary>
        /// Get MFP device status
        /// </summary>
        Task<MfpDeviceStatus> GetDeviceStatusAsync();

        /// <summary>
        /// Get MFP Fax Capability info
        /// </summary>
        Task<MfpFaxCapabilityInfo> GetMfpFaxCapabilityInfoAsync();

        /// <summary>
        /// Set MFP tray information
        /// </summary>
        /// <param name="trayInfoList">Tray setting value</param>
        /// <returns>Returns true if successfully updated.</returns>
        Task<bool> SetTrayInfoSettingAsync(List<TrayInfo> trayInfoList);

        /// <summary>
        /// Get MFP device version.
        /// </summary>
        /// <param name="name">MFP device version name value</param>
        /// <returns>Return the version with the name specified by the argument.</returns>
        Task<string> GetMfpDeviceVersionAsync(string name);

        /// <summary>
        /// Get MFP application option
        /// </summary>
        Task<MfpApplicationOption> GetMfpApplicationOptionAsync();

        /// <summary>
        /// AppReqGetDeviceInfo(RequestItems.SupportFunction)
        /// </summary>
        Task<XmlDocument> GetMfpSupportFunctionAsync();

        /// <summary>
        /// Get the functions supported by the MFP
        /// </summary>
        Task<MfpSupportFunctions> GetMfpSupportFunctionsAsync();

        /// <summary>
        /// Request to get whether mfp is envelope mode or not
        /// </summary>
        Task<Envelope> GetEnvelopeModeStateAsync();

        /// <summary>
        /// Get mfp finisher function
        /// </summary>
        Task<MfpFinisher> GetMfpFinisherAsync();

        /// <summary>
        /// Notify DevRptNotifyPowerStatus to MfpService
        /// </summary>
        /// <param name="powerStatus">Model of device parts status</param>
        Task NotifyPowerStatusAsync(NotifyPowerStatus powerStatus);

        /// <summary>
        /// Gets the MFP manual tray paper size unmatch asynchronous.
        /// </summary>
        Task<Boolean> GetMfpManualTrayPaperSizeUnmatchAsync();
    }
}