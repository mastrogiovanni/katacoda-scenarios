﻿using KonicaMinolta.OpenApi.DeviceDescriptions;

namespace ServiceHub.Processors.DeviceInfo
{
    /// <summary>
    /// Interface of device description operator.
    /// </summary>
    public interface IDeviceDescriptionOperator
    {
        /// <summary>
        /// Get device description.
        /// </summary>
        /// <returns>Device description</returns>
        DeviceDescription GetDeviceDescription();

        /// <summary>
        /// Clear cached device description.
        /// </summary>
        void ClearCachedDeviceDescription();
    }
}
