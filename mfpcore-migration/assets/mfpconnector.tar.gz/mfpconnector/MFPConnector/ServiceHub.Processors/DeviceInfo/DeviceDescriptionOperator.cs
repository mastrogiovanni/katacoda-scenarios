using System;
using KonicaMinolta.OpenApi.DeviceDescriptions;
using Microsoft.Extensions.Logging;
using ServiceHub.Connectors.OpenAPI;
using ServiceHub.Connectors.OpenAPI.Model;

namespace ServiceHub.Processors.DeviceInfo
{
    /// <summary>
    /// Device description operator.
    /// </summary>
    public class DeviceDescriptionOperator : IDeviceDescriptionOperator
    {
        private readonly IOpenApiController _openApiController;
        private readonly object _lockObj = new object();
        private readonly ILogger<DeviceDescriptionOperator> _logger;

        private DeviceDescription _cachedDeviceDescription;

        /// <summary>
        /// Initializes a new instance of the <see cref="DeviceDescriptionOperator"/> class
        /// </summary>
        /// <param name="openApiController">OpenAPI controller</param>
        /// <param name="logger">Logger</param>
        public DeviceDescriptionOperator(IOpenApiController openApiController, ILogger<DeviceDescriptionOperator> logger)
        {
            _logger = logger;
            _openApiController = openApiController;
        }

        /// <summary>
        /// Get device description.
        /// </summary>
        /// <returns>Device description</returns>
        public DeviceDescription GetDeviceDescription()
        {
            lock (_lockObj)
            {
                if (_cachedDeviceDescription != null)
                {
                    return _cachedDeviceDescription;
                }

                _cachedDeviceDescription = GetDeviceDescriptionFromOpenApi();
                if (_logger.IsEnabled(LogLevel.Information))
                {
                    _logger.LogInformation($"XML of device description: {_cachedDeviceDescription.Serialize().Replace(Environment.NewLine, string.Empty)}");
                }

                return _cachedDeviceDescription;
            }
        }

        /// <summary>
        /// Clear cached device description.
        /// </summary>
        public void ClearCachedDeviceDescription()
        {
            lock (_lockObj)
            {
                _cachedDeviceDescription = null;
            }
        }

        private DeviceDescription GetDeviceDescriptionFromOpenApi()
        {
            try
            {
                return _openApiController.GetDeviceDescription();
            }
            catch (Exception e)
            {
                _logger.LogDebug($"Error occurred to get device descrption.:{e.Message}", e);
                throw;
            }
        }
    }
}
