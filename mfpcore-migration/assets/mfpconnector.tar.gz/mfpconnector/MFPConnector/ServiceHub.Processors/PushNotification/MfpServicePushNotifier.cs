using Microsoft.Extensions.Logging;
using ServiceHub.Common.Settings;
using ServiceHub.Common.Settings.PushNotification;
using ServiceHub.Connectors.MfpService;

namespace ServiceHub.Processors.PushNotification
{
    /// <summary>
    /// Push notification to MFP service
    /// </summary>
    public class MfpServicePushNotifier : AbstractPushNotifier
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MfpServicePushNotifier"/> class
        /// </summary>
        /// <param name="logger">Logger</param>
        /// <param name="service">MFP Service</param>
        /// <param name="setting">MfpConnectorSetting</param>
        public MfpServicePushNotifier(ILogger<AbstractPushNotifier> logger, IMfpService service, MfpConnectorSetting setting)
            : base(logger, service)
        {
            Setting = setting;
        }

        /// <summary>
        /// Push notification ID
        /// </summary>
        public override PushNotificationType PushNotificationId => PushNotificationType.MfpService;
    }
}
