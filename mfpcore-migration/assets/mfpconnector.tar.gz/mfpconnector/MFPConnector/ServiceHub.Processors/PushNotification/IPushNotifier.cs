using ServiceHub.Common.Settings;
using ServiceHub.Common.Settings.PushNotification;
using System.Net.Http;
using System.Threading.Tasks;

namespace ServiceHub.Processors.PushNotification
{
    /// <summary>
    /// Push notifications to somewhere
    /// </summary>
    public interface IPushNotifier
    {
        /// <summary>
        /// Push notification ID (defines in Setting.json "push_notification"'s child object key)
        /// </summary>
        PushNotificationType PushNotificationId { get; }

        /// <summary>
        /// MFP Connector setting
        /// </summary>
        MfpConnectorSetting Setting { get; set; }

        /// <summary>
        /// GET method
        /// </summary>
        /// <param name="path">URL path to push (protocol, domain, port are not specifiable, just only path and query)</param>
        /// <returns>HTTP response</returns>
        Task<HttpResponseMessage> GetAsync(string path);

        /// <summary>
        /// POST method
        /// </summary>
        /// <typeparam name="T">Posting data type</typeparam>
        /// <param name="path">URL path to push (protocol, domain, port are not specifiable, just only path and query)</param>
        /// <param name="data">Posting data</param>
        /// <returns>HTTP response</returns>
        Task<HttpResponseMessage> PostAsync<T>(string path, T data = null) where T : class, new();

        /// <summary>
        /// Send warning info list
        /// </summary>
        /// <param name="infoListJson">Json of warning info list</param>
        Task SendWarningInfoAsync(string infoListJson);

        /// <summary>
        /// Notify job status
        /// </summary>
        /// <param name="infoJson">Json of job status</param>
        Task NotifyJobStatusAsync(string infoJson);

        /// <summary>
        /// Notify init connect
        /// </summary>
        /// <param name="infoJson">Json of init connect</param>
        Task NotifyInitConnectAsync(string infoJson);
    }
}
