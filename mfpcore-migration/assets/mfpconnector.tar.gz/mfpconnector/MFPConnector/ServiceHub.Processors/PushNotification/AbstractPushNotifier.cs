using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using ServiceHub.Common.Settings;
using ServiceHub.Common.Settings.PushNotification;
using ServiceHub.Connectors.MfpService;

namespace ServiceHub.Processors.PushNotification
{
    /// <summary>
    /// Abstract push notifier
    /// </summary>
    public abstract class AbstractPushNotifier : IPushNotifier
    {
        /// <summary>
        /// Logger
        /// </summary>
        private readonly ILogger<AbstractPushNotifier> _logger;

        /// <summary>
        /// MediaType: JSON
        /// </summary>
        private const string MediaTypeJson = "application/json";

        /// <summary>
        /// Initializes a new instance of the <see cref="AbstractPushNotifier"/> class
        /// </summary>
        /// <param name="logger">Logger</param>
        /// <param name="service">MFP Service</param>
        protected AbstractPushNotifier(ILogger<AbstractPushNotifier> logger, IMfpService service)
        {
            _logger = logger;
            Service = service;
        }

        /// <summary>
        /// Push notification ID (defines in Setting.json "push_notification"'s child object key)
        /// </summary>
        public abstract PushNotificationType PushNotificationId { get; }

        /// <summary>
        /// MFP Connector setting
        /// </summary>
        public MfpConnectorSetting Setting { get; set; }

        /// <summary>
        /// Connector for MFP service
        /// </summary>
        private IMfpService Service { get; }

        /// <summary>
        /// Send warning data list path
        /// </summary>
        private string SendWarningDataListPath => Setting.PushNotification[PushNotificationId].CurrentSetting.SendWarningDataListPath;

        /// <summary>
        /// Send job status path
        /// </summary>
        private string SendJobStatusPath => Setting.PushNotification[PushNotificationId].CurrentSetting.SendJobStatusPath;

        /// <summary>
        /// Send init connect path
        /// </summary>
        private string SendInitConnectPath => Setting.PushNotification[PushNotificationId].CurrentSetting.SendInitConnectPath;

        /// <summary>
        /// GET method
        /// </summary>
        /// <param name="path">URL path to push (protocol, domain, port are not specifiable, just only path and query)</param>
        /// <returns>HTTP response</returns>
        public async Task<HttpResponseMessage> GetAsync(string path)
        {
            return await Service.GetAsync(path);
        }

        /// <summary>
        /// POST method
        /// </summary>
        /// <typeparam name="T">Posting data type</typeparam>
        /// <param name="path">URL path to push (protocol, domain, port are not specifiable, just only path and query)</param>
        /// <param name="data">Posting data</param>
        /// <returns>HTTP response</returns>
        public async Task<HttpResponseMessage> PostAsync<T>(string path, T data = null) where T : class, new()
        {
            HttpResponseMessage result;
            var count = 0;
            do
            {
                result = await Service.PostAsync(path, new StringContent(JsonConvert.SerializeObject(data), Encoding.UTF8, MediaTypeJson));
                count++;
            } while (count < 3 && result.StatusCode == HttpStatusCode.GatewayTimeout);

            return result;
        }

        /// <summary>
        /// Send warning info list
        /// </summary>
        /// <param name="infoListJson">Json of warning info list</param>
        public async Task SendWarningInfoAsync(string infoListJson)
        {
            _logger.LogDebug($"Notify warning data to MFPService. request : {infoListJson}");

            HttpResponseMessage result;
            var count = 0;
            do
            {
                result = await Service.PostAsync(SendWarningDataListPath, new StringContent(infoListJson, Encoding.UTF8, MediaTypeJson));
                count++;
            } while (count < 3 && result.StatusCode == HttpStatusCode.GatewayTimeout);

            if (!result.IsSuccessStatusCode)
            {
                _logger.LogWarning($"PostWarningDataList failed : {result.StatusCode}");
            }
        }

        /// <summary>
        /// Notify job status
        /// </summary>
        /// <param name="infoJson">Json of job status</param>
        public async Task NotifyJobStatusAsync(string infoJson)
        {
            _logger.LogDebug($"Notify job trace to MFPService. request : {infoJson}");

            HttpResponseMessage result;
            var count = 0;
            do
            {
                result = await Service.PostAsync(SendJobStatusPath, new StringContent(infoJson, Encoding.UTF8, MediaTypeJson));
                count++;
            } while (count < 3 && result.StatusCode == HttpStatusCode.GatewayTimeout);

            if (!result.IsSuccessStatusCode)
            {
                _logger.LogWarning($"PostNotifyJobStatus failed : {result.StatusCode}");
            }
        }

        /// <summary>
        /// Notify init connect
        /// </summary>
        /// <param name="infoJson">Json of init connect</param>
        public async Task NotifyInitConnectAsync(string infoJson)
        {
            HttpResponseMessage result;
            var count = 0;
            do
            {
                result = await Service.PostAsync(SendInitConnectPath, new StringContent(infoJson, Encoding.UTF8, MediaTypeJson));
                count++;
            } while (count < 3 && result.StatusCode == HttpStatusCode.GatewayTimeout);

            if (!result.IsSuccessStatusCode)
            {
                _logger.LogWarning($"PostNotifyInitConnect failed : {result.StatusCode}");
            }
        }
    }
}
