using KonicaMinolta.OpenApi;
using Microsoft.Extensions.Logging;
using ServiceHub.Connectors.OpenAPI;
using ServiceHub.Connectors.OpenAPI.Model;
using ServiceHub.Processors.Job.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Xml;

namespace ServiceHub.Processors.Job
{
    /// <summary>
    /// Operation Job
    /// </summary>
    public class JobOperator : OpenApiOperatable, IJobOperator
    {
        private readonly ILogger<JobOperator> _logger;
        private readonly IConvertJobs _convertJobs;

        /// <summary>
        /// Initializes a new instance of the <see cref="JobOperator" /> class
        /// </summary>
        /// <param name="openApiRequestSettings">OpenApiRequestSettings</param>
        /// <param name="openApiController">IOpenApiController</param>
        /// <param name="convertJobs">ConvertJobs</param>
        /// <param name="logger">The logger.</param>
        public JobOperator(
            OpenApiRequestSettings openApiRequestSettings,
            IOpenApiController openApiController,
            IConvertJobs convertJobs,
            ILogger<JobOperator> logger)
            : base(openApiRequestSettings, openApiController)
        {
            _convertJobs = convertJobs;
            _logger = logger;
        }

        /// <summary>
        /// Delete job.
        /// </summary>
        /// <param name="jobId">Job id</param>
        /// <param name="enhancedAuthParameterCode">Enhanced auth parameter code</param>
        /// <returns>Result to delete</returns>
        /// <remarks>
        /// In V1.0, enhancedAuthParameterCode param is unnecessary,
        /// There is a possibility to use it in v1.2 It is left behind.
        /// </remarks>
        public async Task<bool> DeleteJobAsync(string jobId, string enhancedAuthParameterCode)
        {
            var res = true;
            var content = await OpenApiController.DeleteJobAsync(jobId, enhancedAuthParameterCode);

            if (content.GetElementsByTagName("ResultInfo")[0].InnerText != ResponseStatus.Ack.ToString())
            {
                res = false;
            }

            return res;
        }

        /// <summary>
        /// Delete all active jobs.
        /// </summary>
        /// <returns>Result to delete</returns>
        public async Task<bool> DeleteAllActiveJobsAsync()
        {
            var res = true;
            var content = await OpenApiController.GetJobActiveListAsync(null);
            var jobList = _convertJobs.ConvertToJobs(content, null);

            foreach (var job in jobList)
            {
                if (job.JobType != JobType.FaxReceive.ToString())
                {
                    try
                    {
                        await DeleteJobAsync(job.MfpJobId.ToString(), null);
                    }
                    catch (Exception e)
                    {
                        _logger.LogTrace(default(EventId), e, $"Exception occurred during delete job, Mfp job id:{job.MfpJobId}");
                        res = false;
                    }
                }
            }

            return res;
        }

        /// <summary>
        /// Get jobs.
        /// </summary>
        /// <param name="mfpJobId">Mfp job id</param>
        /// <returns>Job list</returns>
        /// <exception cref="XmlException">Invalid response</exception>
        public async Task<IEnumerable<MfpJobResponse>> GetJobsAsync(ulong? mfpJobId)
        {
            try
            {
                // get xml content to active job list.
                var content = await OpenApiController.GetJobActiveListAsync(mfpJobId);
                var contentStatus = await OpenApiController.GetJobStatusListAsync(mfpJobId);
                _convertJobs.JobActiveStatus = true;

                return _convertJobs.ConvertToJobs(content, contentStatus, mfpJobId);
            }
            catch (OpenApiFaultException ex)
            {
                // Continue processing if job is non-active
                _logger.LogTrace(default(EventId), ex,
                    "ConvertToJobs - Non active. Continue processing using default list.");
            }

            try
            {
                // get xml content to static job list.
                var content = await OpenApiController.GetJobListAsync(mfpJobId);
                _convertJobs.JobActiveStatus = false;

                return _convertJobs.ConvertToJobs(content, mfpJobId);
            }
            catch (OpenApiFaultException ex)
            {
                _logger.LogInformation(default(EventId), ex,
                    "ConvertToJobs - JobList Not Found. Continue processing using default list.");

                return new List<MfpJobResponse>();
            }
        }

        /// <summary>
        /// Get active jobs.
        /// </summary>
        /// <param name="mfpJobId">Mfp job id</param>
        /// <returns>Job list</returns>
        /// <exception cref="OpenApiFaultException">Open api fault</exception>
        /// <exception cref="XmlException">Invalid response</exception>
        public async Task<IEnumerable<MfpJobResponse>> GetActiveJobsAsync(ulong? mfpJobId)
        {
            try
            {
                var content = await OpenApiController.GetJobActiveListAsync(mfpJobId);
                _convertJobs.JobActiveStatus = true;

                return _convertJobs.ConvertToActiveJobs(content, mfpJobId).ToList();
            }
            catch (Exception e) when (e is OpenApiFaultException || e is XmlException)
            {
                _logger.LogTrace(default(EventId), e, "Exception occurred(ConvertToJobs) non active.");
            }

            return await GetInactiveJobsAsync(mfpJobId);
        }

        /// <summary>
        /// Get inactive jobs.
        /// </summary>
        /// <param name="mfpJobId">Mfp job id</param>
        /// <param name="doNotThrow">Do not throw when no job found</param>
        /// <returns>Job list</returns>
        /// <exception cref="OpenApiFaultException">Open api fault</exception>
        public async Task<IEnumerable<MfpJobResponse>> GetInactiveJobsAsync(ulong? mfpJobId, bool doNotThrow = true)
        {
            try
            {
                var content = await OpenApiController.GetJobListAsync(mfpJobId);

                return _convertJobs.ConvertToJobs(content, mfpJobId);
            }
            catch (OpenApiFaultException ex) when (
                ex.FaultMessage.FaultCode.Equals(SoapFaultCode.Server) &&
                ex.FaultMessage.FaultString.Equals("Server Error") &&
                ex.FaultMessage.FaultRequest.Equals("AppReqGetJobList") &&
                ex.FaultMessage.ErrorDetails.Equals("JobInfoNotFoundJobID") &&
                ex.FaultMessage.ErrorDescription.Equals("SpecifiedNo") &&
                !doNotThrow)
            {
                throw;
            }
            catch (OpenApiFaultException ex)
            {
                _logger.LogTrace(default(EventId), ex, "Exception occurred(ConvertToJobs) Not Found JobList.");
                return new List<MfpJobResponse>();
            }
        }

        /// <summary>
        /// Get jobs.
        /// </summary>
        /// <returns>Job history</returns>
        /// <exception cref="XmlException">Invalid response</exception>
        public async Task<IEnumerable<MfpJobResponse>> GetJobHistoryAsync()
        {
            var content = await OpenApiController.GetJobHistoryAsync();

            try
            {
                return _convertJobs.ConvertToJobsForGetJobHistory(content);
            }
            catch (XmlException ex)
            {
                _logger.LogTrace("Exception occurred(ConvertToJobs). Returning empty list.", ex);
                return new List<MfpJobResponse>();
            }
        }

        /// <summary>
        /// Restart job.
        /// </summary>
        /// <param name="jobId">Job id</param>
        /// <param name="enhancedAuthParameterCode">Enhanced auth parameter code</param>
        /// <returns>Result to restart</returns>
        public async Task<bool> RestartJobAsync(string jobId, string enhancedAuthParameterCode)
        {
            var res = true;
            var content = await OpenApiController.RestartJobAsync(jobId, enhancedAuthParameterCode, true);

            if (content.GetElementsByTagName("ResultInfo")[0].InnerText != ResponseStatus.Ack.ToString())
            {
                res = false;
            }

            return res;
        }
    }
}