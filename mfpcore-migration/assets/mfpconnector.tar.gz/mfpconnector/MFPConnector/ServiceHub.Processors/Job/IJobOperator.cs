using System.Collections.Generic;
using System.Threading.Tasks;

using ServiceHub.Processors.Job.Model;

namespace ServiceHub.Processors.Job
{
    /// <summary>
    /// Operation job interface.
    /// </summary>
    public interface IJobOperator
    {
        /// <summary>
        /// Delete job
        /// </summary>
        /// <param name="jobId">Job id</param>
        /// <param name="enhancedAuthParameterCode">Enhanced auth parameter code</param>
        /// <returns>Result to delete</returns>
        Task<bool> DeleteJobAsync(string jobId, string enhancedAuthParameterCode);

        /// <summary>
        /// Delete all active jobs.
        /// </summary>
        /// <returns>Result to delete</returns>
        Task<bool> DeleteAllActiveJobsAsync();

        /// <summary>
        /// Get jobs
        /// </summary>
        /// <param name="mfpJobId">Mfp job id</param>
        /// <returns>Job list</returns>
        /// <exception cref="System.Xml.XmlException">Invalid response</exception>
        Task<IEnumerable<MfpJobResponse>> GetJobsAsync(ulong? mfpJobId);

        /// <summary>
        /// Get active jobs.
        /// </summary>
        /// <param name="mfpJobId">Mfp job id</param>
        /// <returns>Job list</returns>
        /// <exception cref="KonicaMinolta.OpenApi.OpenApiFaultException">Open api fault</exception>
        /// <exception cref="System.Xml.XmlException">Invalid response</exception>
        Task<IEnumerable<MfpJobResponse>> GetActiveJobsAsync(ulong? mfpJobId);

        /// <summary>
        /// Get inactive jobs.
        /// </summary>
        /// <param name="mfpJobId">Mfp job id</param>
        /// <param name="doNotThrow">Do not throw when no job found</param>
        /// <returns>Job list</returns>
        /// <exception cref="KonicaMinolta.OpenApi.OpenApiFaultException">Open api fault</exception>
        Task<IEnumerable<MfpJobResponse>> GetInactiveJobsAsync(ulong? mfpJobId, bool doNotThrow = true);

        /// <summary>
        /// Get jobs
        /// </summary>
        /// <returns>Job history</returns>
        /// <exception cref="System.Xml.XmlException">Invalid response</exception>
        Task<IEnumerable<MfpJobResponse>> GetJobHistoryAsync();

        /// <summary>
        /// Restart job
        /// </summary>
        /// <param name="jobId">Job id</param>
        /// <param name="enhancedAuthParameterCode">Enhanced auth parameter code</param>
        /// <returns>Result to restart</returns>
        Task<bool> RestartJobAsync(string jobId, string enhancedAuthParameterCode);
    }
}
