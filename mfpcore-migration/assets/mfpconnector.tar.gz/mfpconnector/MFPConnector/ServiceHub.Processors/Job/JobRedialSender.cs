using Microsoft.Extensions.Logging;
using ServiceHub.Connectors.IWS;

namespace ServiceHub.Processors.Job
{
    /// <summary>
    /// Job redial sender
    /// </summary>
    public class JobRedialSender : AbstractJobSender<JobRedialSender>, IJobRedialSender
    {
        /// <summary>
        public override string FilePath { get; } = string.Empty;

        public override string Data { get; } = string.Empty;

        /// Initializes a new instance of the <see cref="JobRedialSender" /> class.
        /// </summary>
        /// <param name="logger">Logger</param>
        /// <param name="iwsConnectorUser">The iws connector user.</param>
        public JobRedialSender(ILogger<JobRedialSender> logger, IIwsConnectorUser iwsConnectorUser)
            : base(logger, iwsConnectorUser)
        {
        }

        protected override string ScriptPath { get; } = "/jobRedial.py";
    }
}