using Newtonsoft.Json;

namespace ServiceHub.Processors.Job.Model
{
    /// <summary>
    /// IWS job result(script callback)
    /// </summary>
    public class CallBackJobResult
    {
        /// <summary>
        /// Gets or sets results for job.
        /// </summary>
        [JsonProperty(PropertyName = "result", NullValueHandling = NullValueHandling.Ignore)]
        public string Result { get; set; }

        /// <summary>
        /// Gets or sets mfp_job_id for job.
        /// </summary>
        [JsonProperty(PropertyName = "job_id", NullValueHandling = NullValueHandling.Ignore)]
        public ulong JobId { get; set; }

        /// <summary>
        /// Gets or sets error for job.
        /// </summary>
        [JsonProperty(PropertyName = "error", NullValueHandling = NullValueHandling.Ignore)]
        public string Error { get; set; }

        /// <summary>
        /// Gets or sets errorMsg for job.
        /// </summary>
        [JsonProperty(PropertyName = "errorMsg", NullValueHandling = NullValueHandling.Ignore)]
        public string ErrorMsg { get; set; }
    }
}
