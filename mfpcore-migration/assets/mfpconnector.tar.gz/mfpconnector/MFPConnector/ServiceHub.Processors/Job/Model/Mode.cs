﻿namespace ServiceHub.Processors.Job.Model
{
    /// <summary>
    /// Job mode
    /// </summary>
    public enum Mode
    {
        REDIAL,
        RESTART
    }
}
