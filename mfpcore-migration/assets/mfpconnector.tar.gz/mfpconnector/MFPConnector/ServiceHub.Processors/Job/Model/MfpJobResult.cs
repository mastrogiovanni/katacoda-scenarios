using Newtonsoft.Json;

namespace ServiceHub.Processors.Job.Model
{
    /// <summary>
    /// ActiveJobResult
    /// </summary>
    public class MfpJobResult
    {
        /// <summary>
        /// Result
        /// </summary>
        [JsonProperty(PropertyName = "result")]
        public string Result { get; set; }

        /// <summary>
        /// Delete cause
        /// </summary>
        [JsonProperty(PropertyName = "delete_cause")]
        public string DeleteCause { get; set; }

        /// <summary>
        /// Force end (mode cancellation) cause
        /// </summary>
        [JsonProperty(PropertyName = "force_end_cause")]
        public string ForceEndCause { get; set; }

        /// <summary>
        /// Trouble code
        /// </summary>
        [JsonProperty(PropertyName = "trouble_code")]
        public long? TroubleCode { get; set; }
    }
}
