using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using ServiceHub.Common.Settings;

namespace ServiceHub.Processors.Job.Model
{
    /// <summary>
    /// IWS Job request body
    /// </summary>
    public class JobsManipulateRequest
    {
        /// <summary>
        /// Gets or sets Job Mode
        /// </summary>
        [JsonProperty(PropertyName = "mode", NullValueHandling = NullValueHandling.Ignore)]
        [JsonConverter(typeof(StringEnumConverter))]
        public Mode Mode { get; set; }

        /// <summary>
        /// Gets or sets Job Auth
        /// </summary>
        [JsonProperty(PropertyName = "auth_parameter", NullValueHandling = NullValueHandling.Ignore)]
        public AuthParameter AuthParameter { get; set; }
    }
}
