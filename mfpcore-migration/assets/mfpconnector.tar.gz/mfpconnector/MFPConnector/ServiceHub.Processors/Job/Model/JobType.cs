﻿namespace ServiceHub.Processors.Job.Model
{
    /// <summary>
    /// Job type enum.
    /// </summary>
    public enum JobType
    {
        /// <summary>
        /// Print.
        /// </summary>
        Print,

        /// <summary>
        /// Copy.
        /// </summary>
        Copy,

        /// <summary>
        /// Scan.
        /// </summary>
        Scan,

        /// <summary>
        /// Fax send.
        /// </summary>
        FaxSend,

        /// <summary>
        /// Fax receive.
        /// </summary>
        FaxReceive
    }
}
