using Newtonsoft.Json;

namespace ServiceHub.Processors.Job.Model
{
    /// <summary>
    /// ActiveJobResponse
    /// </summary>
    public class MfpJobResponse
    {
        /// <summary>
        /// MfpJobId
        /// </summary>
        [JsonProperty(PropertyName = "mfp_job_id")]
        public ulong? MfpJobId { get; set; }

        /// <summary>
        /// JobType
        /// </summary>
        [JsonProperty(PropertyName = "job_type")]
        public string JobType { get; set; }

        /// <summary>
        /// DriverJobId
        /// </summary>
        [JsonProperty(PropertyName = "driver_job_id")]
        public string DriverJobId { get; set; }

        /// <summary>
        /// Status
        /// </summary>
        [JsonProperty(PropertyName = "status")]
        public string Status { get; set; }

        /// <summary>
        /// NumberOfOriginals
        /// </summary>
        [JsonProperty(PropertyName = "number_of_originals")]
        public int? NumberOfOriginals { get; set; }

        /// <summary>
        /// Job name(File name).
        /// </summary>
        [JsonProperty(PropertyName = "file_name")]
        public string FileName { get; set; }

        /// <summary>
        /// Job transaction number.
        /// Enabled by only Fax jobs.
        /// </summary>
        [JsonProperty(PropertyName = "transaction_no")]
        public ulong? TransactionNo { get; set; }

        /// <summary>
        /// Send mode
        /// </summary>
        [JsonProperty(PropertyName = "send_mode")]
        public string SendMode { get; set; }

        /// <summary>
        /// Number of copies
        /// </summary>
        [JsonProperty(PropertyName = "number_of_copies")]
        public int? NumberOfCopies { get; set; }

        /// <summary>
        /// Input (scanning) status
        /// </summary>
        [JsonProperty(PropertyName = "input_status")]
        public string InputStatus { get; set; }

        /// <summary>
        /// Output (printing) status
        /// </summary>
        [JsonProperty(PropertyName = "output_status")]
        public string OutputStatus { get; set; }

        /// <summary>
        /// Fax status
        /// </summary>
        [JsonProperty(PropertyName = "fax_status")]
        public string FaxStatus { get; set; }

        /// <summary>
        /// Total number of print pages
        /// </summary>
        [JsonProperty(PropertyName = "total_number_of_print_pages")]
        public int? TotalNumberOfPrintPages { get; set; }

        /// <summary>
        /// Number of printed pages before now
        /// </summary>
        [JsonProperty(PropertyName = "printed_number_of_print_pages")]
        public int? PrintedNumberOfPrintPages { get; set; }

        /// <summary>
        /// Output tray type
        /// </summary>
        [JsonProperty(PropertyName = "output_tray_type")]
        public string OutputTrayType { get; set; }

        /// <summary>
        /// Job finished time
        /// </summary>
        [JsonProperty(PropertyName = "end_time")]
        public string EndTime { get; set; }

        /// <summary>
        /// Job result
        /// </summary>
        [JsonProperty(PropertyName = "job_result")]
        public MfpJobResult JobResult { get; set; }

        /// <summary>
        /// Sent target address
        /// </summary>
        [JsonProperty(PropertyName = "send_address")]
        public string SendAddress { get; set; }
    }
}
