using System;
using ServiceHub.Common.Settings;
using ServiceHub.Connectors.IWS;
using ServiceHub.Processors.Common;
using Microsoft.Extensions.Logging;

namespace ServiceHub.Processors.Job
{
    /// <summary>
    /// IWS Job sender (Only ExecAppScript)
    /// </summary>
    public abstract class AbstractJobSender<TJobSender> : IMfpSender
    {
        private readonly ILogger<TJobSender> _logger;

        /// <summary>
        /// Initializes a new instance of the <see cref="AbstractJobSender{TJobSender}"/> class.
        /// </summary>
        /// <param name="logger">The logger.</param>
        /// <param name="iwsConnectorUser">The iws connector user.</param>
        protected AbstractJobSender(ILogger<TJobSender> logger, IIwsConnectorUser iwsConnectorUser)
        {
            _logger = logger;
            IwsConnectorUser = iwsConnectorUser;
        }

        public string Parameter { get; set; }
        public AuthParameter AuthParameter { get; set; }
        public abstract string FilePath { get; }
        public abstract string Data { get; }
        
        protected abstract string ScriptPath { get; }
        protected IIwsConnector IwsConnectorUser { get; }

        /// <summary>
        /// Send data to MFP.
        /// </summary>
        public void SendToMfp()
        {
            _logger.LogInformation("SendToMfp Started.");

            try
            {
                IwsConnectorUser.ExecAppScriptExParamAsync(ScriptPath, AuthParameter, FilePath, Data);
            }
            catch (IwsException e)
            {
                _logger.LogWarning(default(EventId), e, e.Message);
                throw;
            }
        }
    }
}