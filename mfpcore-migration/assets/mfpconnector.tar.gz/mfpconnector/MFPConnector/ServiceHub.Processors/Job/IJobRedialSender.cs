﻿using ServiceHub.Processors.Common;

namespace ServiceHub.Processors.Job
{
    public interface IJobRedialSender : IMfpSender
    {
    }
}
