using Microsoft.Extensions.Logging;
using ServiceHub.Connectors.IWS;

namespace ServiceHub.Processors.Job
{
    /// <summary>
    /// Job pause sender
    /// </summary>
    public class JobPauseSender : AbstractJobSender<JobPauseSender>, IJobPauseSender
    {
        public override string FilePath { get; } = string.Empty;

        public override string Data { get; } = string.Empty;

        /// <summary>
        /// Initializes a new instance of the <see cref="JobPauseSender" /> class.
        /// </summary>
        /// <param name="logger">Logger</param>
        /// <param name="iwsConnectorUser">The iws connector user.</param>
        public JobPauseSender(ILogger<JobPauseSender> logger, IIwsConnectorUser iwsConnectorUser)
            : base(logger, iwsConnectorUser)
        {
        }

        protected override string ScriptPath => "/jobStop.py";
    }
}