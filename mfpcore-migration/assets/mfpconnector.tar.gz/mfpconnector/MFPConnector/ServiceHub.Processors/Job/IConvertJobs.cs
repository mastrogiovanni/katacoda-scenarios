﻿using System.Collections.Generic;
using System.Xml;
using ServiceHub.Processors.Job.Model;

namespace ServiceHub.Processors.Job
{
    /// <summary>
    /// Convert jobs interface.
    /// </summary>
    public interface IConvertJobs
    {
        /// <summary>
        /// Job is activated?
        /// </summary>
        bool JobActiveStatus { get; set; }

        /// <summary>
        /// Convert xml to model.
        /// </summary>
        /// <param name="xml">Xml</param>
        /// <param name="mfpJobId">MfpJobId</param>
        /// <returns>Response</returns>
        IEnumerable<MfpJobResponse> ConvertToJobs(XmlDocument xml, ulong? mfpJobId);

        /// <summary>
        /// Convert xml to model for active status.
        /// </summary>
        /// <param name="xml">Xml</param>
        /// <param name="xmlStatus">Xml</param>
        /// <param name="mfpJobId">MfpJobId</param>
        /// <returns>Response</returns>
        /// <remarks>
        /// If element can not be found, empty list is returned.
        /// </remarks>
        IEnumerable<MfpJobResponse> ConvertToJobs(XmlDocument xml, XmlDocument xmlStatus, ulong? mfpJobId);

        /// <summary>
        /// Convert xml to model for active status.
        /// </summary>
        /// <param name="xml">Xml</param>
        /// <param name="mfpJobId">MfpJobId</param>
        /// <returns>Response</returns>
        /// <remarks>
        /// If element can not be found, empty list is returned.
        /// </remarks>
        IReadOnlyCollection<MfpJobResponse> ConvertToActiveJobs(XmlDocument xml, ulong? mfpJobId);

        /// <summary>
        /// Convert xml to model for active GetAppResGetJobList - "JobHistory"
        /// </summary>
        /// <param name="xml">Xml</param>
        /// <returns>Response</returns>
        /// <exception cref="XmlException">Invalid response</exception>
        IEnumerable<MfpJobResponse> ConvertToJobsForGetJobHistory(XmlNode xml);

        /// <summary>
        /// Get job status whether it is active or not
        /// </summary>
        /// <param name="node">XmlNode</param>
        /// <returns>bool</returns>
        bool IsActiveJob(XmlNode node);
    }
}
