using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Xml;
using Microsoft.Extensions.Logging;
using ServiceHub.Connectors.OpenAPI.Model;
using ServiceHub.Processors.Job.Model;

namespace ServiceHub.Processors.Job
{
    /// <summary>
    /// ConvertJobs
    /// </summary>
    public class ConvertJobs : IConvertJobs
    {
        private const string AppResGetJobList = "AppResGetJobList";
        private const string AppResGetJobStatus = "AppResGetJobStatus";
        private const string Result = "./Result";
        private const string RequestItem = "./RequestItem";
        private const string ActiveJob = "./JobList/Job";
        private const string SpecifiedJob = "./JobHistoryList/JobHistory";
        private const string JobId = "./JobID";
        private const string ActiveJobType = "./KindOfJob/JobTypeEach";
        private const string SpecifiedJobType = "./KindOfJob/JobType";
        private const string DriverJobId = "./KindOfJob/JobDetail/DriverJobID";
        private const string ActiveStatus = "./JobStatus/Status";
        private const string SpecifiedStatus = "./JobResult/Result";
        private const string DocumentNumber = "./JobNumber/DocumentNumber";
        private const string JobName = "./JobCommonMode/JobName";
        private const string JobTransactionId = "./JobCommonMode/TransactionNo";
        private const string NumberOfCopies = "./JobNumber/CopyNumber";
        private const string JobStatus = "./JobStatus";
        private const string ScanStatus = "./JobStatus/InputStatus";
        private const string PrintStatus = "./JobStatus/OutputStatus";
        private const string ForwardStatus = "./JobStatus/FaxStatus";
        private const string TotalNumberOfPrintPages = "./JobNumber/TotalNumber";
        private const string NumberOfPrintedPagesBeforeNow = "./JobNumber/PrintNumber";
        private const string OutputTrayType = "./PaperOutput2";
        private const string TimeWhenTheJobFinishedYear = "./JobTime/EndTime/Year";
        private const string TimeWhenTheJobFinishedMongh = "./JobTime/EndTime/Month";
        private const string TimeWhenTheJobFinishedDay = "./JobTime/EndTime/Day";
        private const string TimeWhenTheJobFinishedHour = "./JobTime/EndTime/Hour";
        private const string TimeWhenTheJobFinishedMinute = "./JobTime/EndTime/Minute";
        private const string JobEndStatus = "./JobResult";
        private const string JobResultResult = "./JobResult/Result";
        private const string JobResultDeleteCause = "./JobResult/DeleteCause";
        private const string JobResultForceEndCause = "./JobResult/ForceEndCause";
        private const string JobResultTroubleCode = "./JobResult/TroubleCode";
        private const string SendAddressTempInfo = "./SendDestination/TempInfo";
        private const string SendAddressDirectAddress = "SendDestination/DirectAddress";
        private const string MessageResultNotFound = "not found Result";
        private const string MessageResultNotAck = "Result is not Ack";

        private readonly ILogger<ConvertJobs> _logger;
        private readonly string _oapNamespace;

        /// <summary>
        /// Initializes a new instance of the <see cref="ConvertJobs"/> class
        /// </summary>
        /// <param name="settings"></param>
        /// <param name="logger">Logger</param>
        public ConvertJobs(OpenApiRequestSettings settings, ILogger<ConvertJobs> logger)
        {
            _oapNamespace = settings?.Namespace;
            _logger = logger;
        }

        /// <summary>
        /// Job is activated?
        /// </summary>
        public bool JobActiveStatus { get; set; }

        /// <summary>
        /// Convert xml to model.
        /// </summary>
        /// <param name="xml">Xml</param>
        /// <param name="mfpJobId">MfpJobId</param>
        /// <returns>Response</returns>
        public IEnumerable<MfpJobResponse> ConvertToJobs(XmlDocument xml, ulong? mfpJobId)
        {
            // non active
            JobActiveStatus = false;

            return ConvertToJobs(xml, null, mfpJobId);
        }

        /// <summary>
        /// Convert xml to model for active status.
        /// </summary>
        /// <param name="xml">Xml</param>
        /// <param name="xmlStatus">Xml</param>
        /// <param name="mfpJobId">MfpJobId</param>
        /// <returns>Response</returns>
        /// <remarks>
        /// If element can not be found, empty list is returned.
        /// </remarks>
        public IEnumerable<MfpJobResponse> ConvertToJobs(XmlDocument xml, XmlDocument xmlStatus, ulong? mfpJobId)
        {
            if (!JobActiveStatus)
            {
                return ConvertJobFromNonActiveStatus(xml, mfpJobId);
            }

            if (xml?.DocumentElement?.LocalName == AppResGetJobList)
            {
                return ConvertJobFromJobListResult(xml, xmlStatus, mfpJobId);
            }

            _logger.LogTrace(xml?.OuterXml);
            _logger.LogInformation($"Not found elementName:{xml?.DocumentElement?.LocalName}. " +
                                   "Returning an empty response.");

            return new List<MfpJobResponse>();
        }

        /// <summary>
        /// Convert xml to model for active status.
        /// </summary>
        /// <param name="xml">Xml</param>
        /// <param name="mfpJobId">MfpJobId</param>
        /// <returns>Response</returns>
        /// <remarks>
        /// If element can not be found, empty list is returned.
        /// </remarks>
        public IReadOnlyCollection<MfpJobResponse> ConvertToActiveJobs(XmlDocument xml, ulong? mfpJobId)
        {
            if (xml?.DocumentElement?.LocalName == AppResGetJobList)
            {
                return ConvertToJobsForGetJobActiveList(xml, mfpJobId);
            }

            return new List<MfpJobResponse>();
        }

        /// <summary>
        /// Check document name of xml.
        /// </summary>
        /// <param name="xml">Xml</param>
        /// <returns>active or nonactive</returns>
        [Obsolete("Does not seems to be called, to be removed in the future if nobody still calls it.")]
        public bool IsActiveJobs(XmlDocument xml)
        {
            JobActiveStatus = false;
            var documentElementName = xml.DocumentElement?.Name;
            if (documentElementName != null && documentElementName.Contains(AppResGetJobList))
            {
                JobActiveStatus = true;
            }

            return JobActiveStatus;
        }

        /// <summary>
        /// CreateMfpJob
        /// </summary>
        /// <param name="node">XmlNode</param>
        /// <param name="mfpJobId">Mfp job id</param>
        /// <param name="isSpecified">Specified job flag</param>
        /// <returns>Response</returns>
        private MfpJobResponse CreateMfpJob(XmlNode node, ulong? mfpJobId, bool isSpecified)
        {
            var jobType = node.SelectSingleNode(ActiveJobType);
            var status = node.SelectSingleNode(ActiveStatus);
            if (!JobActiveStatus)
            {
                if (node.LocalName == AppResGetJobStatus)
                {
                    jobType = node.SelectSingleNode(SpecifiedJobType);
                    status = node.SelectSingleNode(ActiveStatus);
                }
                else
                {
                    jobType = node.SelectSingleNode(isSpecified ? SpecifiedJobType : ActiveJobType);
                    status = node.SelectSingleNode(isSpecified ? SpecifiedStatus : ActiveStatus);
                }
            }

            if (jobType == null)
            {
                _logger.LogDebug(node.OuterXml);
                throw new XmlException("not found JobType");
            }

            if (status == null)
            {
                _logger.LogDebug(node.OuterXml);
                throw new XmlException("not found Status");
            }

            var job = new MfpJobResponse
            {
                MfpJobId = mfpJobId,
                JobType = jobType.InnerText,
                DriverJobId = node.SelectSingleNode(DriverJobId)?.InnerText,
                Status = status.InnerText,
                NumberOfOriginals = ConvertNodeToInteger(node.SelectSingleNode(DocumentNumber)),
                FileName = node.SelectSingleNode(JobName)?.InnerText,
                TransactionNo = ConvertNodeToUlong(node.SelectSingleNode(JobTransactionId)),
                NumberOfCopies = ConvertNodeToInteger(node.SelectSingleNode(NumberOfCopies)),
                InputStatus = node.SelectSingleNode(ScanStatus)?.InnerText,
                OutputStatus = node.SelectSingleNode(PrintStatus)?.InnerText,
                FaxStatus = node.SelectSingleNode(ForwardStatus)?.InnerText,
                TotalNumberOfPrintPages = ConvertNodeToInteger(node.SelectSingleNode(TotalNumberOfPrintPages)),
                PrintedNumberOfPrintPages = ConvertNodeToInteger(node.SelectSingleNode(NumberOfPrintedPagesBeforeNow)),
                OutputTrayType = node.SelectSingleNode(OutputTrayType)?.InnerText,
                EndTime = FormattingTimeWhenTheJobFinished(node),
                SendAddress = (node.SelectSingleNode(SendAddressTempInfo) ??
                               node.SelectSingleNode(SendAddressDirectAddress))?.InnerText
            };

            // JobEndStatus
            if (node.SelectSingleNode(JobEndStatus) == null)
            {
                return job;
            }

            // Result
            var result = node.SelectSingleNode(JobResultResult);
            if (result == null)
            {
                _logger.LogDebug(node.OuterXml);
                throw new XmlException(MessageResultNotFound);
            }

            var jobResult = new MfpJobResult
            {
                Result = result.InnerText,
                DeleteCause = node.SelectSingleNode(JobResultDeleteCause)?.InnerText,
                ForceEndCause = node.SelectSingleNode(JobResultForceEndCause)?.InnerText,
                TroubleCode = ConvertNodeToInteger(node.SelectSingleNode(JobResultTroubleCode))
            };

            job.JobResult = jobResult;

            return job;
        }

        /// <summary>
        /// CreateMfpJob
        /// </summary>
        /// <param name="node">XmlNode</param>
        /// <returns>Response</returns>
        [Obsolete("Does not seems to be called, to be removed in the future if nobody still calls it.")]
        public MfpJobResponse CreateMfpJobStatus(XmlNode node)
        {
            // We just want to validate, but we don't keep the root.
            GetValidRoot(node, AppResGetJobStatus);

            return new MfpJobResponse
            {
                InputStatus = node.SelectSingleNode(ScanStatus)?.InnerText,
                OutputStatus = node.SelectSingleNode(PrintStatus)?.InnerText,
                FaxStatus = node.SelectSingleNode(ForwardStatus)?.InnerText
            };
        }

        /// <summary>
        /// Convert xml to model for GetAppResGetJobList - "JobHistory" : "JobList"
        /// </summary>
        /// <param name="xml">Xml</param>
        /// <param name="mfpJobId">MfpJobId</param>
        /// <returns>Response</returns>
        /// <exception cref="XmlException">Invalid response</exception>
        private List<MfpJobResponse> ConvertToJobsForGetJobList(XmlNode xml, ulong? mfpJobId)
        {
            var root = GetValidRoot(xml, AppResGetJobList);

            // check request
            var request = root.SelectSingleNode(RequestItem);
            if (request == null)
            {
                _logger.LogDebug(xml.OuterXml);
                throw new XmlException("not found RequestItem");
            }

            if (request.InnerText != (mfpJobId.HasValue ? "JobHistory" : "JobList"))
            {
                _logger.LogDebug(xml.OuterXml);
                throw new XmlException($"RequestItem is not {(mfpJobId.HasValue ? "JobHistory" : "JobList")}");
            }

            // create MfpJobResponse
            var nodeList = root.SelectNodes(mfpJobId.HasValue ? SpecifiedJob : ActiveJob);
            if (nodeList == null)
            {
                _logger.LogDebug(xml.OuterXml);
                throw new XmlException($"{(mfpJobId.HasValue ? SpecifiedJob : ActiveJob)} is not found");
            }

            return ConvertToJobsCreateResponse(xml, mfpJobId, nodeList);
        }

        /// <summary>
        /// Convert xml to model for active GetAppResGetJobList - "JobList"
        /// </summary>
        /// <param name="xml">Xml</param>
        /// <param name="mfpJobId">MfpJobId</param>
        /// <returns>Response</returns>
        /// <exception cref="XmlException">Invalid response</exception>
        private List<MfpJobResponse> ConvertToJobsForGetJobActiveList(XmlNode xml, ulong? mfpJobId)
        {
            var root = GetValidRoot(xml, AppResGetJobList);

            // check request
            var request = root.SelectSingleNode(RequestItem);
            if (request == null)
            {
                _logger.LogDebug(xml.OuterXml);
                throw new XmlException("not found RequestItem");
            }

            if (request.InnerText != "JobList")
            {
                _logger.LogDebug(xml.OuterXml);
                throw new XmlException("RequestItem is not JobList");
            }

            // create MfpJobResponse
            var nodeList = root.SelectNodes(ActiveJob);
            if (nodeList == null)
            {
                _logger.LogDebug(xml.OuterXml);
                throw new XmlException("ActiveJob is not found");
            }

            return ConvertToJobsCreateResponse(xml, mfpJobId, nodeList);
        }

        /// <summary>
        /// Convert xml to model for active GetAppResGetJobList - "JobHistory"
        /// </summary>
        /// <param name="xml">Xml</param>
        /// <returns>Response</returns>
        /// <exception cref="XmlException">Invalid response</exception>
        public IEnumerable<MfpJobResponse> ConvertToJobsForGetJobHistory(XmlNode xml)
        {
            var response = new List<MfpJobResponse>();
            var root = GetValidRoot(xml, AppResGetJobList);

            // check request
            var request = root.SelectSingleNode(RequestItem);
            if (request == null)
            {
                _logger.LogDebug(xml?.OuterXml);
                throw new XmlException("not found RequestItem");
            }

            if (request.InnerText != "JobHistory")
            {
                _logger.LogDebug(xml.OuterXml);
                throw new XmlException("RequestItem is not JobHistory");
            }

            // create MfpJobResponse
            var nodeList = root.SelectNodes(SpecifiedJob);
            if (nodeList == null)
            {
                _logger.LogDebug(xml.OuterXml);
                throw new XmlException("ActiveJob is not found");
            }

            foreach (XmlNode node in nodeList)
            {
                // MfpJobId
                var element = node.SelectSingleNode(JobId);
                var jobId = ConvertNodeToUlong(element);
                if (jobId == null)
                {
                    _logger.LogDebug(xml.OuterXml);
                    continue;
                }

                // exepect non-active
                JobActiveStatus = IsActiveJob(node);
                response.Add(CreateMfpJob(node, jobId, true));
            }

            return response;
        }

        /// <summary>
        /// Convert xml to model for active GetAppResGetJobStatus - "JobList"
        /// </summary>
        /// <param name="xml">Xml</param>
        /// <param name="mfpJobId">MfpJobId</param>
        /// <param name="response">The response.</param>
        /// <returns>
        /// Response
        /// </returns>
        /// <exception cref="XmlException">Invalid response</exception>
        private List<MfpJobResponse> ConvertToJobsForGetJobStatus(
            XmlNode xml,
            ulong? mfpJobId,
            IReadOnlyCollection<MfpJobResponse> response)
        {
            var root = GetValidRoot(xml, AppResGetJobStatus);
            var element = root.SelectSingleNode(JobId);
            var jobId = ConvertNodeToUlong(element);
            if (jobId == null)
            {
                _logger.LogDebug(xml.OuterXml);
                throw new XmlException("not found jobId");
            }

            // create MfpJobResponse
            var node = root.SelectSingleNode(JobStatus);
            if (node == null)
            {
                _logger.LogDebug(xml.OuterXml);
                throw new XmlException($"{JobStatus} is not found");
            }

            if (response == null)
            {
                return new List<MfpJobResponse>();
            }

            return response.Select(r =>
            {
                // MfpJobId
                if (mfpJobId.HasValue && mfpJobId.Value.Equals(jobId))
                {
                    // when jobid has value and equal with node, create mfpjob and add to response 
                    // update to response
                    // ScanStatus
                    var scanStatus = root.SelectSingleNode(ScanStatus);
                    r.InputStatus = scanStatus?.InnerText;

                    // PrintStatus
                    var printStatus = root.SelectSingleNode(PrintStatus);
                    r.OutputStatus = printStatus?.InnerText;

                    // ForwardStatus
                    var forwardStatus = root.SelectSingleNode(ForwardStatus);
                    r.FaxStatus = forwardStatus?.InnerText;
                }

                return r;
            }).ToList();
        }

        private XmlNode GetValidRoot(XmlNode xml, string baseNodeName)
        {
            var root = xml?.SelectSingleNode(baseNodeName);
            if (root == null)
            {
                _logger.LogDebug(xml?.OuterXml);
                throw new XmlException($"not found namespace: {_oapNamespace}");
            }

            // check result
            var result = root.SelectSingleNode(Result);
            if (result == null)
            {
                _logger.LogDebug(xml.OuterXml);
                throw new XmlException(MessageResultNotFound);
            }

            if (result.InnerText != ResponseStatus.Ack.ToString())
            {
                _logger.LogDebug(xml.OuterXml);
                throw new XmlException(MessageResultNotAck);
            }

            return root;
        }

        /// <summary>
        /// Convert XmlNode to Integer value
        /// </summary>
        /// <param name="node">Node</param>
        /// <returns>Value</returns>
        private int? ConvertNodeToInteger(XmlNode node)
        {
            if (node != null && int.TryParse(
                    node.InnerText, NumberStyles.Any, CultureInfo.InvariantCulture, out var num))
            {
                return num;
            }

            return null;
        }

        /// <summary>
        /// Convert XmlNode to Ulong value
        /// </summary>
        /// <param name="node">Node</param>
        /// <returns>Value</returns>
        private ulong? ConvertNodeToUlong(XmlNode node)
        {
            if (node != null && ulong.TryParse(
                    node.InnerText, NumberStyles.Any, CultureInfo.InvariantCulture, out var num))
            {
                return num;
            }

            return null;
        }

        /// <summary>
        /// Formatting TimeWhenTheJobFinished
        /// </summary>
        /// <param name="node">Node</param>
        /// <returns>Value</returns>
        private string FormattingTimeWhenTheJobFinished(XmlNode node)
        {
            var timeWhenTheJobFinishedYear = node.SelectSingleNode(TimeWhenTheJobFinishedYear);
            var timeWhenTheJobFinishedMonth = node.SelectSingleNode(TimeWhenTheJobFinishedMongh);
            var timeWhenTheJobFinishedDay = node.SelectSingleNode(TimeWhenTheJobFinishedDay);
            var timeWhenTheJobFinishedHour = node.SelectSingleNode(TimeWhenTheJobFinishedHour);
            var timeWhenTheJobFinishedMinute = node.SelectSingleNode(TimeWhenTheJobFinishedMinute);

            if (timeWhenTheJobFinishedYear == null
                || timeWhenTheJobFinishedMonth == null
                || timeWhenTheJobFinishedDay == null
                || timeWhenTheJobFinishedHour == null
                || timeWhenTheJobFinishedMinute == null)
            {
                return null;
            }

            return $"{timeWhenTheJobFinishedYear.InnerText}-{timeWhenTheJobFinishedMonth.InnerText}-" +
                $"{timeWhenTheJobFinishedDay.InnerText} {timeWhenTheJobFinishedHour.InnerText}:" +
                $"{timeWhenTheJobFinishedMinute.InnerText}";
        }

        private IList<MfpJobResponse> ConvertJobFromJobListResult(XmlNode xml, XmlDocument xmlStatus, ulong? mfpJobId)
        {
            var response = ConvertToJobsForGetJobActiveList(xml, mfpJobId);
            if (xmlStatus?.DocumentElement?.LocalName == AppResGetJobStatus)
            {
                return ConvertToJobsForGetJobStatus(xmlStatus, mfpJobId, response);
            }

            return response;
        }

        private IList<MfpJobResponse> ConvertJobFromNonActiveStatus(XmlDocument xml, ulong? mfpJobId)
        {
            if (xml?.DocumentElement?.LocalName == AppResGetJobList)
            {
                return ConvertToJobsForGetJobList(xml, mfpJobId);
            }

            _logger.LogTrace(xml?.OuterXml);
            _logger.LogWarning($"Not found elementName: {xml?.DocumentElement?.LocalName}.");

            return new List<MfpJobResponse>();
        }

        private List<MfpJobResponse> ConvertToJobsCreateResponse(XmlNode xml, ulong? mfpJobId, XmlNodeList nodeList)
        {
            var response = new List<MfpJobResponse>();

            foreach (XmlNode node in nodeList)
            {
                // MfpJobId
                var element = node.SelectSingleNode(JobId);
                var jobId = ConvertNodeToUlong(element);
                if (jobId == null)
                {
                    _logger.LogDebug(xml.OuterXml);
                    throw new XmlException("not found jobId");
                }

                if (mfpJobId.HasValue && mfpJobId.Value.Equals(jobId))
                {
                    // when jobid has value and equal with node, create mfpjob and add to response 
                    // add to response
                    response.Add(CreateMfpJob(node, jobId, true));

                    return response;
                }

                if (!mfpJobId.HasValue)
                {
                    // when jobid has not value, all node will be added to response  
                    // add to response
                    response.Add(CreateMfpJob(node, jobId, false));
                }
            }

            return response;
        }

        /// <summary>
        /// Get job status whether it is active or not
        /// </summary>
        /// <param name="node">XmlNode</param>
        /// <returns>bool</returns>
        public bool IsActiveJob(XmlNode node)
        {
            return node.SelectSingleNode(ActiveJobType) != null &&
                    node.SelectSingleNode(ActiveStatus) != null;
        }
    }
}
