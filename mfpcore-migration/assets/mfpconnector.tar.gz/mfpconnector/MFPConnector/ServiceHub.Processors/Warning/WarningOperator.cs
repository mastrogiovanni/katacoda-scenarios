using System;
using System.Threading.Tasks;
using System.Xml;
using ServiceHub.Common.Constant;
using ServiceHub.Connectors.OpenAPI;
using ServiceHub.Connectors.OpenAPI.Model;
using ServiceHub.Processors.Warning.Model;

namespace ServiceHub.Processors.Warning
{
    /// <summary>
    /// Cancel Warning.
    /// </summary>
    public class WarningOperator : OpenApiOperatable, IWarningOperator
    {
        private static readonly string None = Enum.GetName(typeof(WarningOperatorStatus), WarningOperatorStatus.None);
        private static readonly string NextWarning = Enum.GetName(typeof(WarningOperatorStatus), WarningOperatorStatus.NextWarning);

        /// <summary>
        /// Initializes a new instance of the <see cref="WarningOperator"/> class.  
        /// </summary>
        /// <param name="openApiRequestSettings">OpenApiRequestSettings</param>
        /// <param name="controller">OpenApiController</param>
        public WarningOperator(
            OpenApiRequestSettings openApiRequestSettings,
            IOpenApiController controller)
            : base(openApiRequestSettings, controller)
        {
        }

        /// <summary>
        /// Cancel Warning.
        /// </summary>
        /// <returns>true/false</returns>
        public async Task<bool> CancelWarningAsync(WarningServiceSetting request)
        {
            if (request.Type != None && request.Type != NextWarning)
            {
                return false;
            }

            if (request.Type == None)
            {
                return await CancelAsync(request);
            }

            return await NextAsync();
        }

        /// <summary>
        /// Cancel warning.
        /// </summary>
        /// <param name="request">Request</param>
        private async Task<bool> CancelAsync(WarningServiceSetting request)
        {
            var resultWarning = await OpenApiController.CancelWarningAsync(request);
            var resultCancel = resultWarning.GetElementsByTagName("ResultInfo")[0].InnerText == ResponseStatus.Ack.ToString();

            // Restart job.
            if (resultCancel)
            {
                var jobId = request.JobId.ToString();
                var name = request.Name;
                string acceptableType = request.ApsAcceptable?.AcceptableType ?? string.Empty;
                string paperEmptyCautionType = request.PaperEmptyCaution?.PaperEmptyCautionType ?? string.Empty;
                if (name == GeneralConstant.MANUSCRIPT_SIZE_DETECT_ERROR
                    || name == GeneralConstant.AMS_MAGNIFICATION_INCOMPATIBLE
                    || name == GeneralConstant.MANUSCRIPT_ADF1
                    || name == GeneralConstant.MEMORY_OVERFLOW
                    || acceptableType == GeneralConstant.FORCE_START
                    || paperEmptyCautionType == GeneralConstant.FORCE_START)
                {
                    RestartJobAsync(jobId);
                }
            }

            return resultCancel;
        }

        /// <summary>
        /// Next warning.
        /// </summary>
        private async Task<bool> NextAsync()
        {
            var resultWarning = await OpenApiController.NextWarningAsync();

            var isAck = resultWarning.GetElementsByTagName("ResultInfo")[0].InnerText == ResponseStatus.Ack.ToString();

            return isAck;
        }

        /// <summary>
        /// Restart job.
        /// </summary>
        /// <param name="jobId">JobId</param>
        /// <returns>Returns a task</returns>
        private async Task RestartJobAsync(string jobId)
        {
            XmlDocument resultRestart = await OpenApiController.RestartJobAsync(jobId);
        }
    }
}