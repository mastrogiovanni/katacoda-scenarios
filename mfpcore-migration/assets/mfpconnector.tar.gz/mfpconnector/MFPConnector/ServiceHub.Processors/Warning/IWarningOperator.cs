﻿using ServiceHub.Connectors.OpenAPI.Model;
using System.Threading.Tasks;

namespace ServiceHub.Processors.Warning
{
    /// <summary>
    /// Cancel Warning Interface.
    /// </summary>
    public interface IWarningOperator
    {
        /// <summary>
        /// Cancel Warning.
        /// </summary>
        /// <returns>Result</returns>
        Task<bool> CancelWarningAsync(WarningServiceSetting request);

    }
}