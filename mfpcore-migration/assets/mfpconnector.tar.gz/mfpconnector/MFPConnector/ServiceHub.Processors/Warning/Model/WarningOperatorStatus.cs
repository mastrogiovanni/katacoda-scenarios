namespace ServiceHub.Processors.Warning.Model
{
    /// <summary>
    /// Warning operator status
    /// </summary>
    public enum WarningOperatorStatus
    {
        None,
        NextWarning 
    }
}
