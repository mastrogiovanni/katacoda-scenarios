﻿using Newtonsoft.Json;
using System.Collections.Generic;
using Newtonsoft.Json.Converters;

namespace ServiceHub.Processors.Notify.Model
{
    public class NotifyDeviceTonerStatus
    {
        /// <summary>
        /// Number of toner
        /// </summary>
        public int ArraySize { get; set; }
        
        public List<TonerStatus> TonerStatuses { get; set; }
        
        public class TonerStatus
        {
            /// <summary>
            /// Color
            /// </summary>
            [JsonProperty(PropertyName = "color")]
            public string Color { get; set; }

            /// <summary>
            /// Toner exist
            /// </summary>
            [JsonProperty(PropertyName = "exist")]
            public string Exist { get; set; }

            /// <summary>
            /// Toner state
            /// </summary>
            [JsonConverter(typeof(StringEnumConverter))]
            public DeviceTonerStatus Status { get; set; }

            /// <summary>
            /// Wear level
            /// </summary>
            [JsonProperty(PropertyName = "level_per")]
            public int LevelPer { get; set; }

            /// <summary>
            /// Temporarily disconnected state
            /// </summary>
            [JsonProperty(PropertyName = "temporary_rescue")]
            public string TemporaryRescue { get; set; }
        }

        public enum DeviceTonerStatus
        {
            Empty,
            NearLifeEnd,
            NearEmpty,
            Enough,
            Ready
        }
    }
}
