using Newtonsoft.Json;
using System.Collections.Generic;

namespace ServiceHub.Processors.Notify.Model
{
    /// <summary>
    /// Notify device status
    /// </summary>
    public class NotifyDevicePartsStatus
    {
        /// <summary>
        /// Type
        /// </summary>
        [JsonProperty(PropertyName = "type")]
        public string Type { get; set; }

        /// <summary>
        /// Open
        /// </summary>
        [JsonProperty(PropertyName = "open")]
        public bool Open { get; set; }

        /// <summary>
        /// PaperExist
        /// </summary>
        [JsonProperty(PropertyName = "paper_exist")]
        public bool PaperExist { get; set; }

        /// <summary>
        /// FreeTrayInfoList
        /// </summary>
        [JsonProperty(PropertyName = "free_tray_info_list")]
        public List<FeedTrayStatus> FreeTrayInfoList { get; set; }

        /// <summary>
        /// FeedTrayStatus class
        /// </summary>
        public class FeedTrayStatus
        {
            /// <summary>
            /// Name
            /// </summary>
            [JsonProperty(PropertyName = "name")]
            public string Name { get; set; }

            /// <summary>
            /// PaperStatus
            /// </summary>
            [JsonProperty(PropertyName = "paper_status")]
            public string PaperStatus { get; set; }

            /// <summary>
            /// SizeCode
            /// </summary>
            [JsonProperty(PropertyName = "size_code")]
            public string SizeCode { get; set; }

            /// <summary>
            /// FeedDirection
            /// </summary>
            [JsonProperty(PropertyName = "feed_direction")]
            public string FeedDirection { get; set; }

            /// <summary>
            /// TrayOpenStatus
            /// </summary>
            [JsonProperty(PropertyName = "tray_open_status")]
            public string TrayOpenStatus { get; set; }
        }
    }
}
