using Newtonsoft.Json;

namespace ServiceHub.Processors.Notify.Model
{
    /// <summary>
    /// Notify of power status (text)
    /// </summary>
    /// <remarks>
    /// TODO This should be using the enum instead of using this poco class.
    /// </remarks>
    public class NotifyPowerStatus
    {
        /// <summary>
        /// SubPower
        /// </summary>
        [JsonProperty(PropertyName = "sub_power")]
        public bool SubPower { get; set; }

        /// <summary>
        /// Sleep
        /// </summary>
        [JsonProperty(PropertyName = "sleep")]
        public bool Sleep { get; set; }

        /// <summary>
        /// LowPower
        /// </summary>
        [JsonProperty(PropertyName = "low_power")]
        public bool LowPower { get; set; }
    }
}
