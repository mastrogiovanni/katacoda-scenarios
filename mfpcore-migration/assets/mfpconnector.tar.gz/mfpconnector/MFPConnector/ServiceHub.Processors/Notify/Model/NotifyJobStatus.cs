using Newtonsoft.Json;

namespace ServiceHub.Processors.Notify.Model
{
    /// <summary>
    /// Notify status.
    /// </summary>
    public class NotifyJobStatus
    {
        /// <summary>
        /// JobId
        /// </summary>
        [JsonProperty(PropertyName = "job_id")]
        public int JobId { get; set; }

        /// <summary>
        /// DriverJobId
        /// </summary>
        [JsonProperty(PropertyName = "driver_job_id")]
        public string DriverJobId { get; set; }

        /// <summary>
        /// JobType
        /// </summary>
        [JsonProperty(PropertyName = "job_type")]
        public string JobType { get; set; }

        /// <summary>
        /// Status
        /// </summary>
        [JsonProperty(PropertyName = "status")]
        public string Status { get; set; }

        /// <summary>
        /// UserName
        /// </summary>
        [JsonProperty(PropertyName = "user_name")]
        public string UserName { get; set; }

        /// <summary>
        /// NumberOfOriginals
        /// </summary>
        [JsonProperty(PropertyName = "number_of_originals")]
        public int NumberOfOriginals { get; set; }

        /// <summary>
        /// TotalNumberOfPrintPages
        /// </summary>
        [JsonProperty(PropertyName = "total_number_of_print_pages")]
        public int TotalNumberOfPrintPages { get; set; }

        /// <summary>
        /// PrintedNumberOfPrintPages
        /// </summary>
        [JsonProperty(PropertyName = "printed_number_of_print_pages")]
        public long PrintedNumberOfPrintPages { get; set; }

        /// <summary>
        /// NumberOfCopies
        /// </summary>
        [JsonProperty(PropertyName = "number_of_copies")]
        public long NumberOfCopies{ get; set; }

        /// <summary>
        /// ErrorDetails
        /// </summary>
        [JsonProperty(PropertyName = "error_details")]
        public string ErrorDetails { get; set; }

        /// <summary>
        /// Job name(File name).
        /// </summary>
        [JsonProperty(PropertyName = "file_name")]
        public string FileName { get; set; }

        /// <summary>
        /// SendMode
        /// </summary>
        [JsonProperty(PropertyName = "send_mode")]
        public string SendMode { get; set; }
    }
}
