using ServiceHub.Connectors.OpenAPI.Model;

namespace ServiceHub.Processors.Notify.Model
{
    /// <summary>
    /// Result of AppReqSetJobTrace
    /// </summary>
    public class AppResSetJobTrace : AppResBase
    {
        /// <summary>
        /// Driver job ID
        /// </summary>
        public string DriverJobId { get; set; }

        /// <summary>
        /// JobID
        /// </summary>
        public string JobId { get; set; }
    }
}
