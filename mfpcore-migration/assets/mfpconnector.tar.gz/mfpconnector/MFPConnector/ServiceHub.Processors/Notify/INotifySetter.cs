using ServiceHub.Processors.Notify.Model;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ServiceHub.Processors.Notify
{
    /// <summary>
    /// Notify setter instance.
    /// </summary>
    public interface INotifySetter
    {
        /// <summary>
        /// Get device list status.
        /// </summary>
        /// <returns>JSON string</returns>
        Task<List<NotifyDeviceStatus>> GetDeviceListStatusAsync();

        /// <summary>
        /// Get device Parts status.
        /// </summary>
        /// <returns>Response</returns>
        Task<List<NotifyDevicePartsStatus>> GetDevicePartsStatusAsync();

        /// <summary>
        /// Get device tonner status.
        /// </summary>
        /// <returns>Response</returns>
        Task<NotifyDeviceTonerStatus> GetDeviceTonerStatusAsync();

        /// <summary>
        /// Set event notification.
        /// </summary>
        Task SetEventNotificationAsync();

        /// <summary>
        /// Set job trace.
        /// </summary>
        /// <param name="jobId">Job id</param>
        /// <returns>Result</returns>
        Task<AppResSetJobTrace> SetJobTraceAsync(int jobId);

        /// <summary>
        /// Notify MFP init connect.
        /// </summary>
        Task NotifyMfpInitConnectAsync();
    }
}
