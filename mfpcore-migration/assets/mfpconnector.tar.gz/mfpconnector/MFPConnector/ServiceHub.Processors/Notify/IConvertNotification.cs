using System.Collections.Generic;
using System.Threading.Tasks;
using ServiceHub.Processors.Job;
using ServiceHub.Processors.Notify.Model;

namespace ServiceHub.Processors.Notify
{
    /// <summary>
    /// Convert Notification.
    /// </summary>
    public interface IConvertNotification
    {
        /// <summary>
        /// Converts to notify job status asynchronous.
        /// </summary>
        /// <param name="jobOperator">The job operator.</param>
        /// <param name="xml">The XML.</param>
        /// <returns>NotifyJobStatus</returns>
        Task<NotifyJobStatus> ConvertToNotifyJobStatusAsync(IJobOperator jobOperator, string xml);

        /// <summary>
        /// Converts to notify job status copy error asynchronous.
        /// </summary>
        /// <param name="jobOperator">The job operator.</param>
        /// <param name="jobStatus">The job status.</param>
        /// <returns>NotifyJobStatus</returns>
        Task<NotifyJobStatus> ConvertToNotifyJobStatusCopyErrAsync(IJobOperator jobOperator,
            NotifyJobStatus jobStatus);

        /// <summary>
        /// Converts to notify device status.
        /// </summary>
        /// <param name="xml">The XML.</param>
        /// <returns>NotifyDeviceStatus</returns>
        List<NotifyDeviceStatus> ConvertToNotifyDeviceStatus(string xml);

        /// <summary>
        /// Converts to notify device parts status.
        /// </summary>
        /// <param name="xml">The XML.</param>
        /// <returns>NotifyDevicePartsStatus</returns>
        NotifyDevicePartsStatus ConvertToNotifyDevicePartsStatus(string xml);

        /// <summary>
        /// Converts to notify device toner status.
        /// </summary>
        /// <param name="xml">The XML.</param>
        /// <returns>NotifyDeviceTonerStatus</returns>
        NotifyDeviceTonerStatus ConvertToNotifyDeviceTonerStatus(string xml);

        /// <summary>
        /// Converts to finisher door status.
        /// </summary>
        /// <param name="xml">The XML.</param>
        /// <returns>NotifyDevicePartsStatus</returns>
        NotifyDevicePartsStatus ConvertToFinisherDoorStatus(string xml);

        /// <summary>
        /// Converts to notify power status.
        /// </summary>
        /// <param name="xml">The XML.</param>
        /// <returns>NotifyPowerStatus</returns>
        NotifyPowerStatus ConvertToNotifyPowerStatus(string xml);

        /// <summary>
        /// Converts to push device parts status.
        /// </summary>
        /// <param name="xml">The XML.</param>
        /// <returns>NotifyDevicePartsStatus</returns>
        NotifyDevicePartsStatus ConvertToPushDevicePartsStatus(string xml);
    }
}