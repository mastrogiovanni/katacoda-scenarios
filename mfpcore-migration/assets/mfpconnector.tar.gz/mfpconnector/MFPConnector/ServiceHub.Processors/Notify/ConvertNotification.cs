using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

using ServiceHub.Common.Settings.OpenApi;
using ServiceHub.Connectors.OpenAPI;
using ServiceHub.Processors.Common;
using ServiceHub.Processors.Extensions;
using ServiceHub.Processors.Extensions.Model;
using ServiceHub.Processors.Job;
using ServiceHub.Processors.Notify.Model;
using static ServiceHub.Processors.Notify.Model.NotifyDeviceTonerStatus;

namespace ServiceHub.Processors.Notify
{
    /// <summary>
    /// Convert Notification.
    /// </summary>
    public class ConvertNotification: IConvertNotification
    {
        private const string XmlTagNameBody = "/SOAP-ENV:Envelope/SOAP-ENV:Body";
        private const string XmlTagNameRequestItem = "./RequestItem";

        private const string AppResGetDeviceListStatus = "/AppResGetDeviceListStatus";
        private const string AppResGetDevicePartsStatus = "/AppResGetDevicePartsStatus";
        private const string StatusList = "/{0}StatusList";
        private const string Status = "/{0}Status";

        // Todo create an enum for the statuses
        private const string PrinterStatus = "Printer";
        private const string ScannerStatus = "Scanner";
        private const string AdfStatus = "Adf";
        private const string PlatenStatus = "Platen";
        private const string FeedTrayStatus = "FeedTray";
        private const string FinisherDoorStatus = "FinisherDoorStatus";
        private const string PowerStatusNode = "PowerStatus";

        private const string Public = "Public";
        private const string Print = "PRINT";
        private const string JobStatusDeleted = "Deleted";
        private const string ErrorDetailsNoMfpJobHistoryError = "NoMfpJobHistoryError";
        private const string ErrorDetailsNonActiveJobError = "NonActiveJobError";

        private readonly OpenApiVersion _openApiVersion;
        private readonly List<string> _printStatuses = new List<string>
        {
            "End",
            "Printing",
            "PausePrinting",
            "WaitPrinting",
            "ErrorPrinting",
            "PendPrinting",
            "Deleting"
        };

        /// <summary>
        /// Initializes a new instance of the <see cref="ConvertNotification"/> class.
        /// </summary>
        /// <param name="openApiVersion">The open API version.</param>
        public ConvertNotification(OpenApiVersion openApiVersion)
        {
            _openApiVersion = openApiVersion;
        }

        /// <summary>
        /// Convert to notify job status.
        /// </summary>
        /// <param name="jobOperator">The job operator.</param>
        /// <param name="xml">XML from OpenAPI</param>
        /// <returns>
        /// NotifyStatus object
        /// </returns>
        public async Task<NotifyJobStatus> ConvertToNotifyJobStatusAsync(IJobOperator jobOperator, string xml)
        {
            //An alternative value to null
            const int alternativeValueForNull = -1;

            // In the case of ServiceMan, since notification fails, the initial value is set to 0
            var status = new NotifyJobStatus();
            var parser = new SoapXmlParser(xml, _openApiVersion);

            var nodeJobId = parser.GetNode($"{XmlTagNameBody}/OpenAPI:DevRptNotifyJobStatus");

            if (nodeJobId != null)
            {
                status.JobId = int.Parse(parser.GetValue(nodeJobId, "JobID/text()"));
                var nodeJobType = parser.GetNode($"{XmlTagNameBody}/OpenAPI:DevRptNotifyJobStatus/KindOfJob");
                status.JobType = parser.GetValue(nodeJobType, "JobType/text()");
                var nodeJobDetail = parser.GetNode($"{XmlTagNameBody}/OpenAPI:DevRptNotifyJobStatus/KindOfJob/JobDetail");
                status.DriverJobId = parser.GetValue(nodeJobDetail, "DriverJobID/text()");
                var nodeUserName = parser.GetNode($"{XmlTagNameBody}/OpenAPI:DevRptNotifyJobStatus/JobCommonMode");
                var foundUserName = parser.GetValue(nodeUserName, "UserName/text()");
                status.UserName = ConvertUserName(foundUserName);
                var nodeStatus = parser.GetNode($"{XmlTagNameBody}/OpenAPI:DevRptNotifyJobStatus/JobStatus");
                status.Status = parser.GetValue(nodeStatus, "Status/text()");
                var nodeSendMode = parser.GetNode($"{XmlTagNameBody}/OpenAPI:DevRptNotifyJobStatus/KindOfJob/JobDetail");
                status.SendMode = parser.GetValue(nodeSendMode, "SendMode/text()");
            }
            else
            {
                nodeJobId = parser.GetNode($"{XmlTagNameBody}/OpenAPI:DevRptNotifyJobTraceStatus");
                status.JobId = int.Parse(parser.GetValue(nodeJobId, "JobID/text()"));
                status.Status = parser.GetValue(nodeJobId, "TraceStatus/text()");
            }

            if (_printStatuses.Contains(status.Status))
            {
                var jobs = await jobOperator.GetActiveJobsAsync((ulong)status.JobId);
                var job = jobs.FirstOrDefault();
                if (job != null)
                {
                    status.FileName = job.FileName;

                    if (status.Status == "End")
                    {
                        status.PrintedNumberOfPrintPages = (job.NumberOfOriginals ?? 0) * (job.NumberOfCopies ?? 0);
                        status.TotalNumberOfPrintPages = (job.NumberOfOriginals ?? 0) * (job.NumberOfCopies ?? 0);
                        status.NumberOfOriginals = (job.NumberOfOriginals ?? 0);
                        status.NumberOfCopies = (job.NumberOfCopies ?? 0);
                    }
                    else
                    {
                        status.PrintedNumberOfPrintPages = job.PrintedNumberOfPrintPages ?? alternativeValueForNull;
                        status.TotalNumberOfPrintPages = job.TotalNumberOfPrintPages ?? alternativeValueForNull;
                        status.NumberOfOriginals = (job.NumberOfOriginals ?? alternativeValueForNull);
                        status.NumberOfCopies = (job.NumberOfCopies ?? alternativeValueForNull);
                    }
                }
            }
            else
            {
                status.PrintedNumberOfPrintPages = alternativeValueForNull;
                status.TotalNumberOfPrintPages = alternativeValueForNull;
                status.NumberOfOriginals = alternativeValueForNull;
                status.NumberOfCopies = alternativeValueForNull;
            }

            return status;

        }

        /// <summary>
        /// Convert to notify job status(copy error).
        /// </summary>
        /// <param name="jobOperator">Job operator interface</param>
        /// <param name="jobStatus">NotifyStatus object</param>
        /// <returns>NotifyStatus object</returns>
        public async Task<NotifyJobStatus> ConvertToNotifyJobStatusCopyErrAsync(IJobOperator jobOperator, NotifyJobStatus jobStatus)
        {
            bool isEnd = false;
            string fileName = null;
            string errorDetails = ErrorDetailsNonActiveJobError;
            try
            {
                var contents = await jobOperator.GetInactiveJobsAsync((ulong)jobStatus.JobId, false);
                isEnd = contents.Any(c =>
                    c.MfpJobId.HasValue && jobStatus.JobId == (int)c.MfpJobId && JobStatus.END == c.Status);
                fileName = contents.FirstOrDefault(c => c.MfpJobId.HasValue && jobStatus.JobId == (int)c.MfpJobId)
                    ?.FileName;
            }
            catch (KonicaMinolta.OpenApi.OpenApiFaultException)
            {
                errorDetails = ErrorDetailsNoMfpJobHistoryError;
            }

            var notificationStatus = new NotifyJobStatus
            {
                JobId = jobStatus.JobId,
                ErrorDetails = ErrorDetailsNonActiveJobError,
                JobType = jobStatus.JobType,
                Status = JobStatus.END,
                FileName = fileName,
                DriverJobId = jobStatus.DriverJobId
            };

            if (!isEnd)
            {
                notificationStatus.Status = JobStatusDeleted;
                notificationStatus.ErrorDetails = errorDetails;
            }

            return notificationStatus;
        }

        /// <summary>
        /// Convert to notify device status.
        /// </summary>
        /// <param name="xml">XML from OpenAPI</param>
        /// <returns>NotifyDeviceStatus object</returns>
        public List<NotifyDeviceStatus> ConvertToNotifyDeviceStatus(string xml)
        {
            try
            {
                List<NotifyDeviceStatus> status = null;

                var parser = new SoapXmlParser(xml, _openApiVersion);
                var node = parser.GetNode(AppResGetDeviceListStatus);

                if (node != null)
                {
                    status = new List<NotifyDeviceStatus>();
                    status.AddRange(GetDeviceDetailStatus(parser, PrinterStatus));
                    status.AddRange(GetDeviceDetailStatus(parser, ScannerStatus));
                }

                return status;
            }
            catch
            {
                return null;
            }
        }

        /// <summary>
        /// Convert to notify device parts status.
        /// </summary>
        /// <param name="xml">XML from OpenAPI</param>
        /// <returns>NotifyDeviceStatus object</returns>
        public NotifyDevicePartsStatus ConvertToNotifyDevicePartsStatus(string xml)
        {
            try
            {
                NotifyDevicePartsStatus status = null;
                var parser = new SoapXmlParser(xml, _openApiVersion);
                var node = parser.GetNode(AppResGetDevicePartsStatus);

                if (node != null)
                {
                    status = GetDevicePartsDetailStatus(parser, AdfStatus) ?? GetDevicePartsDetailStatus(parser, PlatenStatus);
                }

                return status;
            }
            catch
            {
                return null;
            }
        }

        /// <summary>
        /// Convert to notify toner status.
        /// </summary>
        /// <param name="xml">XML from OpenAPI</param>
        /// <returns>NotifyDeviceStatus object</returns>
        public NotifyDeviceTonerStatus ConvertToNotifyDeviceTonerStatus(string xml)
        {
            NotifyDeviceTonerStatus status = null;

            var parser = new SoapXmlParser(xml, _openApiVersion);

            var node = parser.GetNode(AppResGetDevicePartsStatus);

            if (node != null)
            {
                status = GetDeviceTonerStatus(parser);
            }

            return status;
        }

        /// <summary>
        /// Convert to finisher door status.
        /// </summary>
        /// <param name="xml">XML from OpenAPI</param>
        /// <returns>PushDevicePartsStatus object</returns>
        public NotifyDevicePartsStatus ConvertToFinisherDoorStatus(string xml)
        {
            var parser = new SoapXmlParser(xml, _openApiVersion);
            var node = parser.GetNode(XmlTagNameBody)?.FirstChild;
            var open = node?.SelectSingleNode(FinisherDoorStatus)?.InnerText;

            if (!string.IsNullOrEmpty(open))
            {
                return new NotifyDevicePartsStatus
                {
                    Type = "Finisher",
                    Open = open == "Open"
                };
            }

            return null;
        }

        /// <summary>
        /// Convert to power status.
        /// </summary>
        /// <param name="xml">XML from OpenAPI</param>
        /// <returns>NotifyPowerStatus object</returns>
        public NotifyPowerStatus ConvertToNotifyPowerStatus(string xml)
        {
            try
            {
                return new NotifyPowerStatus
                {
                    SubPower = PowerStatus.SubPower.GetPowerStatus(xml, PowerStatusNode, _openApiVersion),
                    Sleep = PowerStatus.Sleep.GetPowerStatus(xml, PowerStatusNode, _openApiVersion),
                    LowPower = PowerStatus.LowPower.GetPowerStatus(xml, PowerStatusNode, _openApiVersion),
                };
            }
            catch
            {
                // There are default values for these status from MfpService.
                return null;
            }
        }

        /// <summary>
        /// Convert to push device parts status.
        /// </summary>
        /// <param name="xml">XML from OpenAPI</param>
        /// <returns>PushDevicePartsStatus object</returns>
        public NotifyDevicePartsStatus ConvertToPushDevicePartsStatus(string xml)
        {
            try
            {
                var parser = new SoapXmlParser(xml, _openApiVersion);
                var node = parser.GetNode(XmlTagNameBody).FirstChild;
                var type = node.SelectSingleNode(XmlTagNameRequestItem)?.InnerText;

                NotifyDevicePartsStatus status = null;

                if (type != string.Empty)
                {
                    status = GetDevicePartsDetailStatus(node, type);
                }

                return status;
            }
            catch
            {
                return null;
            }
        }

        /// <summary>
        /// Get device detailstatus
        /// </summary>
        /// <param name="parser">Soqp parser</param>
        /// <param name="type">Type</param>
        /// <returns>Device status</returns>
        private List<NotifyDeviceStatus> GetDeviceDetailStatus(SoapXmlParser parser, string type)
        {
            var statusName = new StringBuilder(AppResGetDeviceListStatus)
                .AppendFormat(StatusList, type)
                .AppendFormat(Status, type)
                .ToString();

            var nodeStatusListParent = parser.GetNodes(statusName);

            var result = new List<NotifyDeviceStatus>();
            foreach (XmlNode nodeStatus in nodeStatusListParent)
            {
                result.Add(new NotifyDeviceStatus
                {
                    Type = type,
                    Status = parser.GetValue(nodeStatus, "Status/text()"),
                    Detail = parser.GetValue(nodeStatus, "Detail/text()"),
                    ErrorCode = parser.GetInteger(nodeStatus, "ErrorCode/text()")
                });
            }

            return result;
        }

        /// <summary>
        /// Get device parts detail status
        /// </summary>
        /// <param name="parser">Soqp parser</param>
        /// <param name="type">Type</param>
        /// <returns>Device parts status</returns>
        private NotifyDevicePartsStatus GetDevicePartsDetailStatus(SoapXmlParser parser, string type)
        {
            var node = new StringBuilder().Append(AppResGetDevicePartsStatus).AppendFormat("/{0}", type).ToString();
            if (!parser.ExistNode(node))
            {
                return null;
            }

            var status = new NotifyDevicePartsStatus();
            var nodeStatus = parser.GetNode(node);
            status.Type = type;

            // get paper exist status.
            bool.TryParse(parser.GetValue(nodeStatus, "PaperExist/text()"), out var paperExist);
            status.PaperExist = paperExist;

            bool.TryParse(parser.GetValue(nodeStatus, "Open/text()"), out var open);
            status.Open = open;

            return status;
        }

        /// <summary>
        /// Get device toner status
        /// </summary>
        /// <param name="parser">Soqp parser</param>
        /// <returns>
        /// Device parts status
        /// </returns>
        private NotifyDeviceTonerStatus GetDeviceTonerStatus(SoapXmlParser parser)
        {
            if (!parser.ExistNode(AppResGetDevicePartsStatus))
            {
                return null;
            }

            var nodeStatus = parser.GetNode(AppResGetDevicePartsStatus);
            var statuses = nodeStatus.SelectNodes("Toner/TonerStatusList/TonerStatus").OfType<XmlNode>().Select(n =>
                new TonerStatus
                {
                    Color = n.SelectSingleNode("Color")?.InnerText,
                    Exist = n.SelectSingleNode("Exist")?.InnerText,
                    Status = (DeviceTonerStatus)Enum.Parse(typeof(DeviceTonerStatus), n.SelectSingleNode("Status")?.InnerText),
                    LevelPer = int.Parse(n.SelectSingleNode("LevelPer")?.InnerText),
                    TemporaryRescue = n.SelectSingleNode("TemporaryRescue")?.InnerText,
                }).ToList();

            var arraySize = nodeStatus.SelectSingleNode("Toner/TonerStatusList/ArraySize")?.InnerText;
            return new NotifyDeviceTonerStatus
            {
                ArraySize = int.Parse(arraySize),
                TonerStatuses = statuses
            };
        }

        /// <summary>
        /// Get device parts detail status
        /// </summary>
        /// <param name="node">The node.</param>
        /// <param name="type">Type</param>
        /// <returns>
        /// Device parts status
        /// </returns>
        private NotifyDevicePartsStatus GetDevicePartsDetailStatus(XmlNode node, string type)
        {
            var childNodes = node.ChildNodes.Item(1);
            var status = new NotifyDevicePartsStatus { Type = type };

            switch (type)
            {
                case AdfStatus:
                case PlatenStatus:
                    bool.TryParse(childNodes.SelectSingleNode("./PaperExist")?.InnerText, out var paperExist);
                    status.PaperExist = paperExist;
                    bool.TryParse(childNodes.SelectSingleNode("./Open")?.InnerText, out var open);
                    status.Open = open;

                    break;
                case FeedTrayStatus:
                    var trayResList = new List<NotifyDevicePartsStatus.FeedTrayStatus>();
                    var trayReqList = childNodes.SelectNodes("./FeedTrayStatus");
                    if (trayReqList != null)
                    {
                        foreach (XmlNode trayReq in trayReqList)
                        {
                            if (trayReq == null)
                            {
                                continue;
                            }

                            var trayRes = new NotifyDevicePartsStatus.FeedTrayStatus
                            {
                                Name = trayReq.SelectSingleNode("./Name")?.InnerText,
                                PaperStatus = trayReq.SelectSingleNode("./PaperStatus")?.InnerText,
                                SizeCode = trayReq.SelectSingleNode("./PaperSize")?.SelectSingleNode("./SizeCode")
                                    .InnerText,
                                FeedDirection = trayReq.SelectSingleNode("./PaperSize")
                                    ?.SelectSingleNode("./FeedDirection")?.InnerText,
                                TrayOpenStatus = trayReq.SelectSingleNode("./TrayOpenStatus")?.InnerText
                            };

                            trayResList.Add(trayRes);
                        }

                        status.FreeTrayInfoList = trayResList;
                    }

                    break;
            }

            return status;
        }

        /// <summary>
        /// Check username
        /// </summary>
        /// <param name="username">username</param>
        /// <returns>username</returns>
        private static string ConvertUserName(string username)
        {
            // When the user name is "PRINT", it is treated as "Public"
            return Print.Equals(username) ? Public : username;
        }
    }
}