using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using ServiceHub.Common.Settings.OpenApi;
using ServiceHub.Connectors.OpenAPI;
using ServiceHub.Connectors.OpenAPI.Exceptions;
using ServiceHub.Connectors.OpenAPI.Model;
using ServiceHub.Processors.DeviceInfo.Model;
using ServiceHub.Processors.Notify.Model;
using ServiceHub.Processors.PushNotification;

namespace ServiceHub.Processors.Notify
{
    /// <summary>
    /// Notify Setter.
    /// </summary>
    public class NotifySetter : OpenApiOperatable, INotifySetter
    {
        private enum DeviceType
        {
            Adf,
            Platen,
            Toner
        }

        private readonly IPushNotifier _pushNotifier;
        private readonly ILogger<NotifySetter> _logger;
        private readonly IConvertNotification _convertNotification;

        /// <summary>
        /// Initializes a new instance of the NotifySetter class
        /// </summary>
        /// <param name="logger">Logger</param>
        /// <param name="openApiRequestSettings">OpenApiRequestSettings</param>
        /// <param name="openApiController">IOpenApiController</param>
        /// <param name="pushNotifier">IPushNotifier</param>
        public NotifySetter(
            ILogger<NotifySetter> logger,
            OpenApiRequestSettings openApiRequestSettings,
            IOpenApiController openApiController,
            IPushNotifier pushNotifier) 
            : base(openApiRequestSettings, openApiController)
        {
            _logger = logger;
            _pushNotifier = pushNotifier;

            var version = new OpenApiVersion
            {
                Major = OpenApiOpenApiRequestSettings.MfpConnectorSetting.OpenApi.Version.Major,
                Minor = OpenApiOpenApiRequestSettings.MfpConnectorSetting.OpenApi.Version.Minor
            };
            _convertNotification = new ConvertNotification(version);
        }

        /// <summary>
        /// Get device list status.
        /// </summary>
        /// <returns>Response</returns>
        public async Task<List<NotifyDeviceStatus>> GetDeviceListStatusAsync()
        {
            var xml = await OpenApiController.GetDeviceListStatusAsync();
            return _convertNotification.ConvertToNotifyDeviceStatus(xml.OuterXml);
        }

        /// <summary>
        /// Get device Parts status.
        /// </summary>
        /// <returns>Response</returns>
        public async Task<List<NotifyDevicePartsStatus>> GetDevicePartsStatusAsync()
        {
            var devicePartsList = new List<NotifyDevicePartsStatus>();

            // Call ADF Status
            var xml = await OpenApiController.GetDevicePartsStatusAsync(DeviceType.Adf.ToString());
            var adf = _convertNotification.ConvertToNotifyDevicePartsStatus(xml.OuterXml);
            if (adf != null)
            {
                devicePartsList.Add(adf);
            }

            // Get Platen Status
            xml = await OpenApiController.GetDevicePartsStatusAsync(DeviceType.Platen.ToString());
            var platen = _convertNotification.ConvertToNotifyDevicePartsStatus(xml.OuterXml);
            if (platen != null)
            {
                devicePartsList.Add(platen);
            }

            return devicePartsList;
        }

        /// <summary>
        /// Get device toner status.
        /// </summary>
        /// <returns>Response</returns>
        public async Task<NotifyDeviceTonerStatus> GetDeviceTonerStatusAsync()
        {
            // Call Toner Status
            var xml = await OpenApiController.GetDevicePartsStatusAsync(DeviceType.Toner.ToString());

            try
            {
                return _convertNotification.ConvertToNotifyDeviceTonerStatus(xml.OuterXml);
            }
            catch (Exception e)
            {
                _logger.LogError(default(EventId), e, "Exception occurred to convert to NotifyDeviceTonerStatus.");
                return null;
            }
        }

        /// <summary>
        /// Set event notification.
        /// </summary>
        public async Task SetEventNotificationAsync()
        {
            try
            {
                _logger.LogInformation("SetEventNotification");

                var setNotification = await OpenApiController.SetEventNotificationAsync(
                    OpenApiOpenApiRequestSettings.MfpConnectorSetting.OpenApi.Devices.CurrentSetting.NotifyIp,
                    OpenApiOpenApiRequestSettings.MfpConnectorSetting.OpenApi.Devices.CurrentSetting.NotifyPort);
                if (setNotification.GetElementsByTagName("ResultInfo")[0].InnerText != ResponseStatus.Ack.ToString())
                {
                    throw new OpenApiNackException(setNotification, "AppReqSetEventNotification is Nack");
                }
            }
            catch (Exception ex)
            {
                _logger.LogTrace(default(EventId), ex, "Failed to connect MFP");
                throw;
            }
        }

        /// <summary>
        /// Set job trace.
        /// </summary>
        /// <param name="jobId">Job id</param>
        /// <returns>Result</returns>
        public async Task<AppResSetJobTrace> SetJobTraceAsync(int jobId)
        {
            try
            {
                _logger.LogInformation("SetJobTrace");
                var result = await OpenApiController.SetJobTraceAsync(
                    string.Empty,
                    jobId.ToString(),
                    OpenApiOpenApiRequestSettings.MfpConnectorSetting.OpenApi.Devices.CurrentSetting.NotifyIp,
                    OpenApiOpenApiRequestSettings.MfpConnectorSetting.OpenApi.Devices.CurrentSetting.NotifyPort);
                return new AppResSetJobTrace
                {
                    Result = new OpenApiResult
                    {
                        ResultInfo = result.SelectSingleNode("./Result/ResultInfo")?.InnerText
                    },
                    DriverJobId = result.SelectSingleNode("./DriverJobID")?.InnerText,
                    JobId = result.SelectSingleNode("./JobID")?.InnerText
                };
            }
            catch (Exception ex)
            {
                _logger.LogTrace(default(EventId), ex, "Failed to job trace ");
                throw;
            }
        }

        /// <summary>
        /// Notify MFP init connect.
        /// </summary>
        public Task NotifyMfpInitConnectAsync()
        {
            var result = new InitConnect
            {
                Result = true
            };

            var infoJson = JsonConvert.SerializeObject(result);
            return _pushNotifier.NotifyInitConnectAsync(infoJson);
        }
    }
}
