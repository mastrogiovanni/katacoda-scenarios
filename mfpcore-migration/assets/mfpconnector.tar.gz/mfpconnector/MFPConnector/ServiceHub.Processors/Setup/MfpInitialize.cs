using System;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using ServiceHub.Common.Settings;
using ServiceHub.Connectors.OpenAPI;
using ServiceHub.Connectors.OpenAPI.Model;
using ServiceHub.Connectors.OpenAPI.Model.PermanentSettings.Security;
using ServiceHub.Processors.DeviceInfo;
using ServiceHub.Processors.Fax;
using ServiceHub.Processors.Notify;
using ServiceHub.Processors.Power;
using ServiceHub.Processors.ReadyManage;
using ServiceHub.Processors.Screen;

namespace ServiceHub.Processors.Setup
{
    /// <summary>
    /// Mfp initialize setup class.
    /// </summary>
    public class MfpInitialize : IMfpInitialize
    {
        private readonly MfpConnectorSetting _mfpConnectorSetting;
        private readonly ILogger<MfpInitialize> _logger;
        private readonly IDeviceDescriptionOperator _deviceDescriptionOperator;
        private readonly IPowerOperator _powerOperator;
        private readonly IScreenOperator _screenOperator;
        private readonly IMfpReadyManage _mfpReadyManage;
        private readonly INotifySetter _notifySetter;
        private readonly IFaxReceiveSetter _faxReceiveSetter;
        private readonly IOpenApiController _openApiController;
        private readonly IFirmwareOperator _firmwareOperator;
        private readonly PersonalInfoProtect _personalInfoProtect;

        /// <summary>
        /// Initializes a new instance of the <see cref="MfpInitialize"/> class
        /// </summary>
        /// <param name="mfpConnectorSetting">MFP Connector's Setting</param>
        /// <param name="logger">Logger</param>
        /// <param name="deviceDescriptionOperator">Device description operator</param>
        /// <param name="powerOperator">Power operator</param>
        /// <param name="screenOperator">Screnn operator</param>
        /// <param name="mfpReadyManage">MFP's ready state manage</param>
        /// <param name="notifySetter">Notify setter</param>
        /// <param name="faxReceiveSetter">Fax receive setter</param>
        /// <param name="openApiController">OpenAPI controller</param>
        /// <param name="firmwareOperator">MFP's FW operator</param>
        public MfpInitialize(MfpConnectorSetting mfpConnectorSetting, ILogger<MfpInitialize> logger,
            IDeviceDescriptionOperator deviceDescriptionOperator, IPowerOperator powerOperator,
            IScreenOperator screenOperator, IMfpReadyManage mfpReadyManage, INotifySetter notifySetter,
            IFaxReceiveSetter faxReceiveSetter, IOpenApiController openApiController,
            IFirmwareOperator firmwareOperator)
        {
            _mfpConnectorSetting = mfpConnectorSetting;
            _logger = logger;
            _deviceDescriptionOperator = deviceDescriptionOperator;
            _powerOperator = powerOperator;
            _screenOperator = screenOperator;
            _mfpReadyManage = mfpReadyManage;
            _notifySetter = notifySetter;
            _faxReceiveSetter = faxReceiveSetter;
            _openApiController = openApiController;
            _firmwareOperator = firmwareOperator;
            _personalInfoProtect = new PersonalInfoProtect(
                new JobHistory(
                PermanentSettingsEnable.On.ToString(),
                PermanentSettingsDisplayMode.Mode2.ToString(),
                PermanentSettingsPublicUser.Mode3.ToString()), 
                new ExecutingJob(
                PermanentSettingsEnable.On.ToString(),
                PermanentSettingsDisplayMode.Mode2.ToString(),
                PermanentSettingsPublicUser.Mode3.ToString()));
        }

        /// <summary>
        /// Mfp initialize setup.
        /// </summary>
        public async Task SetupAsync()
        {
            _logger.LogInformation("Initial setup to MFP Device");

            try
            {
                _logger.LogInformation("Wake up to MFP");
                try
                {
                    await _powerOperator.WakeUpToMfpAsync(true);
                }
                catch (Exception ex)
                {
                    // Continuable
                    _logger.LogWarning(default(EventId), ex, "Failed to wake up MFP");
                }

                try
                {
                    _logger.LogInformation("Screen change to WPH panel");
                    await _screenOperator.ScreenChangeAsync(SwitchType.WPH, ScreenType.None, null);
                }
                catch (Exception ex)
                {
                    // Continuable
                    _logger.LogWarning(default(EventId), ex, "Failed to screen change to WPH panel");
                }

                _logger.LogDebug("MfpReadyManage resume");
                _mfpReadyManage.Resume();
                _logger.LogDebug("Set event notification");
                await _notifySetter.SetEventNotificationAsync();
                await _notifySetter.NotifyMfpInitConnectAsync();
                _logger.LogInformation("Get Mac address of mfp.");
                await _powerOperator.MfpMacAddressSettingAsync();
                await _faxReceiveSetter.SetAbbreviationAddressbookAsync(_mfpConnectorSetting.Fax);
                _logger.LogDebug("Set device lock");
                await _openApiController.EnterDeviceLockAsync();
                try
                {
                    _logger.LogDebug("Set Personal Information Protect Setting.");
                    await _openApiController.SetDevicePermanentSettingSecurityAsync(_personalInfoProtect)
                        .ConfigureAwait(false);
                    _logger.LogDebug("Set panel's installed mode");
                    await _screenOperator.SetInstalledAsync();
                    _logger.LogDebug("Set FTP server settings for firmware update");
                    await _firmwareOperator.SetFtpServerSettingsAsync();
                }
                finally
                {
                    _logger.LogDebug("Exit device lock");
                    await _openApiController.ExitDeviceLockAsync();
                }
            }
            catch (Exception e)
            {
                _logger.LogError(default(EventId), e, "Failed to initial setup to MFP Device");
                throw;
            }
        }
    }
}
