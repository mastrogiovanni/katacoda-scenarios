﻿using System.Threading.Tasks;

namespace ServiceHub.Processors.Setup
{
    /// <summary>
    /// Mfp initialize setup interface.
    /// </summary>
    public interface IMfpInitialize
    {
        /// <summary>
        /// Mfp initialize setup.
        /// </summary>
        Task SetupAsync();
    }
}
