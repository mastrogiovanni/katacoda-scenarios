using System.Threading.Tasks;

namespace ServiceHub.Processors.Setup
{
    /// <summary>
    /// FW install.
    /// </summary>
    public interface IFirmwareOperator
    {
        /// <summary>
        /// Set ftp client
        /// </summary>
        Task SetFtpServerSettingsAsync(string fileName = null);

        /// <summary>
        /// Let MFP download MFP firmware.
        /// </summary>
        /// <returns>Success</returns>
        Task<bool> LetDownloadMfpFirmwareAsync(string fileName);

        /// <summary>
        /// Update MFP.
        /// </summary>
        /// <returns>Success</returns>
        Task<bool> UpdateFirmwareAsync();
    }
}
