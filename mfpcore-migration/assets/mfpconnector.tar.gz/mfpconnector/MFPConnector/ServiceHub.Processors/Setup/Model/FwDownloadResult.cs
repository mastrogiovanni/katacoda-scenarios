using Newtonsoft.Json;

namespace ServiceHub.Processors.Setup.Model
{
    /// <summary>
    /// Firmware download result.
    /// </summary>
    public class FwDownloadResult
    {
        /// <summary>
        /// Firmware download result.
        /// </summary>
        [JsonProperty(PropertyName = "download_result", Required = Required.DisallowNull)]
        public bool DownloadResult{ get; set; }
    }
}
