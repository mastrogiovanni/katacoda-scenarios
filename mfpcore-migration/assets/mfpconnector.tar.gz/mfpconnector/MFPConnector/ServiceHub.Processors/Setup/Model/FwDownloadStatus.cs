namespace ServiceHub.Processors.Setup.Model
{
    /// <summary>
    /// FwDownload status
    /// </summary>
    public enum FwDownloadStatus
    {
        Initial,
        Right,
        Download,
        Cancel,
        Deletion,
        Error,
        Unidentified
    }
}