using System;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using ServiceHub.Common.Settings;
using ServiceHub.Common.Settings.Ftp;
using ServiceHub.Connectors.MfpService;
using ServiceHub.Connectors.OpenAPI;
using ServiceHub.Connectors.OpenAPI.Model;
using ServiceHub.Connectors.OpenAPI.Model.DeviceInfoDetail;
using ServiceHub.Processors.Setup.Model;

namespace ServiceHub.Processors.Setup
{
    /// <summary>
    /// Firmware operator.
    /// </summary>
    public class FirmwareOperator : OpenApiOperatable, IFirmwareOperator
    {
        private const string MediaTypeJson = "application/json";

        private readonly ILogger<FirmwareOperator> _logger;
        private readonly MfpConnectorSetting _connectorSetting;
        private readonly IMfpService _mfpService;

        /// <summary>
        /// Initializes a new instance of the <see cref="FirmwareOperator"/> class
        /// </summary>
        /// <param name="logger">Logger</param>
        /// <param name="openApiRequestSettings">Settings</param>
        /// <param name="controller">OpenAPI controller</param>
        /// <param name="connectorSettings">MfpConnectorSetting</param>
        /// <param name="mfpService">MfpService</param>
        public FirmwareOperator(
            ILogger<FirmwareOperator> logger,
            OpenApiRequestSettings openApiRequestSettings,
            IOpenApiController controller,
            MfpConnectorSetting connectorSettings,
            IMfpService mfpService)
            : base(openApiRequestSettings, controller)
        {
            _logger = logger;
            _mfpService = mfpService;
            _connectorSetting = connectorSettings;
        }

        private FtpDefinition FtpSettings => OpenApiOpenApiRequestSettings.MfpConnectorSetting.Ftp.CurrentSetting;

        /// <summary>
        /// Set ftp server settings
        /// </summary>
        public async Task SetFtpServerSettingsAsync(string fileName = null)
        {
            _logger.LogInformation("SetFtpServerSettings");

            var ftpSettings = OpenApiOpenApiRequestSettings.MfpConnectorSetting.Ftp.CurrentSetting;
            DeviceInfoDetail info;

            if (fileName != null)
            {
                info = new DeviceInfoDetail
                {
                    Item = new DeviceInfoDetailIisw
                    {
                        TransferAccessSetting = new DeviceInfoDetailIisw.TransferAccessSettingStuct
                        {
                            User = ftpSettings.Iisw.UserName,
                            Password = ftpSettings.Iisw.Password,
                            DownLoadUrl = ftpSettings.Iisw.DownloadUrl,
                            FwFileName = fileName
                        },
                        FtpEnable = ftpSettings.Iisw.Enable
                    }
                };
            }
            else
            {
                info = new DeviceInfoDetail
                {
                    Item = new DeviceInfoDetailIisw
                    {
                        TransferAccessSetting = new DeviceInfoDetailIisw.TransferAccessSettingStuct
                        {
                            User = ftpSettings.Iisw.UserName,
                            Password = ftpSettings.Iisw.Password,
                            DownLoadUrl = ftpSettings.Iisw.DownloadUrl,
                            FwFileName = ftpSettings.Iisw.FwFileName
                        },
                        FtpEnable = ftpSettings.Iisw.Enable
                    }
                };
            }

            var count = 0;
            var retrySettings = OpenApiOpenApiRequestSettings.MfpConnectorSetting.OpenApi.Devices.CurrentSetting.Retry.SetDeviceInfoDetail;
            while (true)
            {
                var result = await OpenApiController.SetDeviceInfoDetailAdminAsync(info);
                if (result != null)
                {
                    if (result.GetElementsByTagName("ResultInfo")[0].InnerText == ResponseStatus.Ack.ToString())
                    {
                        _logger.LogDebug("Success to set FTP Service URL.");
                        break; // success
                    }

                    _logger.LogWarning("Fail to set FTP Service URL.");
                    break; // fail
                }

                if (retrySettings.Count <= count)
                {
                    _logger.LogWarning("Over retry to set FTP Service URL.");
                    break; // over retry count
                }

                await Task.Delay(retrySettings.Interval);
                count++;
            }
        }

        /// <summary>
        /// Let MFP download MFP firmware.
        /// </summary>
        /// <returns>Success</returns>
        public async Task<bool> LetDownloadMfpFirmwareAsync(string fileName)
        {
            _logger.LogInformation("LetDownloadMfpFirmware");

            var success = await CheckDownloadUrlAsync();
            if (!success)
            {
                _logger.LogWarning("FTP Server URL is invalid");
                return false;
            }

            _logger.LogDebug("Success CheckDownloadUrl");
            success = await CheckDownloadFileAsync(fileName);
            if (!success)
            {
                try
                {
                    await OpenApiController.EnterDeviceLockAsync();
                    _logger.LogDebug("EnterDeviceLock is Done!");
                    await SetFtpServerSettingsAsync(fileName);
                    _logger.LogDebug("SetFtpServerSettings is Done!");
                }
                finally
                {
                    await OpenApiController.ExitDeviceLockAsync();
                    _logger.LogDebug("ExitDeviceLock is Done!");
                }
            }

            _logger.LogDebug("Success CheckDownloadFile");

            var rsp = await OpenApiController.LetBeginDownloadFirmwareAsync();
            if (rsp.GetElementsByTagName("ResultInfo")[0].InnerText != ResponseStatus.Ack.ToString())
            {
                return false;
            }

            _logger.LogDebug("Success LetBeginDownloadFirmware");

            // Todo, we don't wait to finish downloading before returning true? Should'nt we return the result instead?
            var result = FirmwareDownloadAsync();
            _logger.LogDebug("Called waitDownLoad and return true.");

            return true;
        }

        /// <summary>
        /// Wait for the firmware download to complete.
        /// </summary>
        /// <returns></returns>
        public async Task<bool> FirmwareDownloadAsync()
        {
            var downloadResult = new FwDownloadResult
            {
                DownloadResult = await WaitForDownloadCompleteAsync()
            };

            if (downloadResult.DownloadResult)
            {
                _logger.LogInformation("Download status is success.");
            }
            else
            {
                _logger.LogWarning("Download status is invalid.");
            }

            //Call API of MfpService.
            var infoJson = JsonConvert.SerializeObject(downloadResult);
            _logger.LogTrace($"infoJson: {infoJson}{Environment.NewLine}" +
                             $"Url: {_connectorSetting.Firmware.Url}");

            HttpResponseMessage result;
            var count = 0;
            do
            {
                result = await _mfpService.PostAsync(_connectorSetting.Firmware.Url, new StringContent(infoJson, Encoding.UTF8, MediaTypeJson));
                count++;
            } while (count < 3 && result.StatusCode == HttpStatusCode.GatewayTimeout);

            return downloadResult.DownloadResult;
        }

        /// <summary>
        /// Update MFP.
        /// </summary>
        /// <returns>Success</returns>
        public async Task<bool> UpdateFirmwareAsync()
        {
            _logger.LogInformation("UpdateFirmware");

            var rsp = await OpenApiController.UpdateFirmwareAsync();
            return rsp.GetElementsByTagName("ResultInfo")[0].InnerText == "Ack";
        }

        private async Task<bool> CheckDownloadUrlAsync()
        {
            var rspXml = await OpenApiController.GetDeviceInfoDetailAsync(DetailSettingsRequestItems.Iisw);
            var result = rspXml.GetElementsByTagName("DownLoadUrl")[0].InnerText;

            _logger.LogDebug("MFP URL:" + result);
            _logger.LogDebug("MFPConnector URL:" + FtpSettings.Iisw.DownloadUrl);
            return result == FtpSettings.Iisw.DownloadUrl;
        }

        private async Task<bool> CheckDownloadFileAsync(string fileName)
        {
            var rspXml = await OpenApiController.GetDeviceInfoDetailAsync(DetailSettingsRequestItems.Iisw);
            var result = rspXml.GetElementsByTagName("FwFileName")[0].InnerText;

            _logger.LogDebug($"MFP FwFileName: {result}");
            _logger.LogDebug($"Recieved fileName : {fileName}");
            return result == fileName;
        }

        private async Task<bool> WaitForDownloadCompleteAsync()
        {
            _logger.LogInformation("WaitForDownloadComplete");

            var ftpSettings = OpenApiOpenApiRequestSettings.MfpConnectorSetting.Ftp.CurrentSetting;
            var status = FwDownloadStatus.Download;
            while ((status == FwDownloadStatus.Download) || (status == FwDownloadStatus.Initial))
            {
                await Task.Delay(ftpSettings.Iisw.PollingWaitTime);
                var rspXml = await OpenApiController.GetFirmwareDownloadStatusAsync();
                var statusText = rspXml.GetElementsByTagName("Status")[0].InnerText;

                status = (FwDownloadStatus)Enum.Parse(typeof(FwDownloadStatus), statusText, false);
                _logger.LogTrace($"Download status : {status}");
            }

            _logger.LogInformation($"Last download status : {status}");
            return status == FwDownloadStatus.Right;
        }
    }
}
