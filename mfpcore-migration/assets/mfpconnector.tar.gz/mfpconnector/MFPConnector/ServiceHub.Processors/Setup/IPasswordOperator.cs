﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace ServiceHub.Processors.Setup
{
    /// <summary>
    /// Password manage.
    /// </summary>
    public interface IPasswordOperator
    {
        /// <summary>
        /// Change password.
        /// </summary>
        /// <param name="passwordPairs">Key and value pairs of password</param>
        /// <returns>Key of login success</returns>
        Task<string> ChangePasswordAsync(Dictionary<string, string> passwordPairs);
    }
}
