using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using ServiceHub.Common.DeviceState;
using ServiceHub.Common.Settings;
using ServiceHub.Connectors.OpenAPI;

namespace ServiceHub.Processors.Setup
{
    /// <summary>
    /// Password manage.
    /// </summary>
    public class PasswordOperator : IPasswordOperator
    {
        private readonly MfpConnectorSetting _connectorSetting;
        private readonly IDeviceStateContext _deviceStateContext;
        private readonly IDeviceState<IdleState> _idleState;
        private readonly ILogger<PasswordOperator> _logger;
        private readonly IOpenApiController _openApiController;

        /// <summary>
        /// Initializes a new instance of the <see cref="PasswordOperator" /> class.
        /// </summary>
        /// <param name="logger">Logger</param>
        /// <param name="openApiController">OpenAPI controller</param>
        /// <param name="connectorSetting">MFP Connector setting</param>
        /// <param name="deviceStateContext">Context of MFP device state</param>
        /// <param name="idleState">Idle device state</param>
        public PasswordOperator(
            ILogger<PasswordOperator> logger,
            IOpenApiController openApiController,
            MfpConnectorSetting connectorSetting,
            IDeviceStateContext deviceStateContext,
            IDeviceState<IdleState> idleState)
        {
            _logger = logger;
            _openApiController = openApiController;
            _connectorSetting = connectorSetting;
            _deviceStateContext = deviceStateContext;
            _idleState = idleState;
        }

        /// <summary>
        /// Change password.
        /// </summary>
        /// <param name="passwordPairs">Key and value pair of password</param>
        /// <returns>Key of login success</returns>
        public async Task<string> ChangePasswordAsync(Dictionary<string, string> passwordPairs)
        {
            var logPrefix = $"[{nameof(PasswordOperator)}.{nameof(ChangePasswordAsync)}]";
            if (_logger.IsEnabled(LogLevel.Information))
            {
                var keysInfo = new StringBuilder();
                foreach (var pair in passwordPairs)
                {
                    keysInfo.Append($"[{pair.Key}]");
                }

                _logger.LogInformation($"{logPrefix} Started. Keys : {keysInfo}");
            }

            var result = string.Empty;

            foreach (var passwordPair in passwordPairs)
            {
                if (await _openApiController.ConfirmAdminLoginAsync(passwordPair.Value).ConfigureAwait(false))
                {
                    result = passwordPair.Key;

                    // reset password to config file
                    _connectorSetting.OpenApi.Devices.CurrentSetting.Password = passwordPair.Value;
                    _connectorSetting.Save();

                    _deviceStateContext.ChangeState(_idleState);
                }
            }

            return result;
        }
    }
}
