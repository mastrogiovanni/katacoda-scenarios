using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using KonicaMinolta.OpenApi;
using Microsoft.Extensions.Logging;
using ServiceHub.Common.Extensions;
using ServiceHub.Common.Settings;
using ServiceHub.Common.Settings.Mfp;
using ServiceHub.Connectors.OpenAPI;
using ServiceHub.Connectors.OpenAPI.Exceptions;
using ServiceHub.Connectors.OpenAPI.Model;
using ServiceHub.Processors.Common.Model;
using ServiceHub.Processors.MfpSetting.Model;
using ServiceHub.Processors.Power;

namespace ServiceHub.Processors.MfpSetting
{
    public class MfpSettingsOperator : OpenApiOperatable, IMfpSettingsOperator
    {
        private const string AdminPasswordCategoryName = "administrator_password.wph_administrator_password"; //NOSONAR

        private Dictionary<string, MfpSettingCategoryValue> _settingCategory;
        private Dictionary<string, MfpSettingItemValue> _mfpSettings;
        private IPowerOperator _powerOperator;

        private readonly MfpConnectorSetting _mfpConnectorSettings;
        private readonly ILogger<MfpSettingsOperator> _logger;

        /// <summary>
        /// Initializes a new instance of the <see cref="MfpSettingsOperator"/> class.  
        /// </summary>
        /// <param name="openApiRequestSettings">OpenApiRequestSettings</param>
        /// <param name="openApiController">IOpenApiController</param>
        /// <param name="logger">ILogger</param>
        public MfpSettingsOperator(
            OpenApiRequestSettings openApiRequestSettings,
            MfpConnectorSetting mfpConnectorSettings,
            IOpenApiController openApiController,
            ILogger<MfpSettingsOperator> logger)
            : base(openApiRequestSettings, openApiController)
        {
            _mfpConnectorSettings = mfpConnectorSettings;
            _logger = logger;
        }

        /// <summary>
        /// Initialize.
        /// </summary>
        /// <param name="settingCategory">Setting category</param>
        /// <param name="mfpSettings">Mfp setting</param>
        /// <param name="powerController">PowerController</param>
        public void Init(
            Dictionary<string, MfpSettingCategoryValue> settingCategory,
            Dictionary<string, MfpSettingItemValue> mfpSettings,
            IPowerOperator powerOperator)
        {
            _settingCategory = settingCategory;
            _mfpSettings = mfpSettings;
            _powerOperator = powerOperator;
        }

        /// <summary>
        /// Get Mfp settings.
        /// </summary>
        /// <param name="settingNames">Setting names</param>
        /// <returns>
        /// Json string
        /// </returns>
        /// <exception cref="OpenApiRequestException">WakeUp failed.</exception>
        public async Task<List<GetSettingValue>> GetMfpSettingsAsync(
            List<string> settingNames)
        {
            var settings = new List<string>();

            if (settingNames.Count == 0)
            {
                _logger.LogInformation("Create all setting names.");
                settings = new List<string>();
                // All the settings available
                foreach (var settingName in _mfpSettings.Keys)
                {
                    settings.Add(settingName);
                }
            }
            else
            {
                // validate settingNames
                foreach (var settingName in settingNames)
                {
                    if (!_mfpSettings.ContainsKey(settingName))
                    {
                        // Bad Request
                        return null;
                    }
                    settings.Add(settingName);
                }
            }

            // key:OAP_message  value:RequestItem
            var oapMsgDic = new Dictionary<string, List<string>>();

            // Combine OAP messages.
            CombineGetOapMsg(settings, ref oapMsgDic);

            // Wake up
            if (!await WakeUpAsync())
            {
                throw new OpenApiRequestException(OpenApiResultStatus.OtherError, "WakeUp failed.");
            }

            // Execute OAP messages.
            var resultXmlDic = await ExecuteGetOapMsgAsync(oapMsgDic);

            // Get result OAP messages.
            return ResultOapGetMsg(settings, resultXmlDic);
        }

        /// <summary>
        /// Set Mfp settings.
        /// </summary>
        /// <param name="settingNames">Setting names</param>
        /// <returns>Json string</returns>
        public async Task<List<SetSettingResult>> SetMfpSettingsAsync(List<SetSettingValue> settingNamesModels)
        {
            // key:RequestItem  value:xml
            var oapMsgDic = new Dictionary<string, XmlDocument>();

            // Combine OAP messages.
            CombineSetOapMsg(settingNamesModels, oapMsgDic);

            try
            {
                // Wake up
                if (!await WakeUpAsync())
                {
                    throw new OpenApiRequestException(OpenApiResultStatus.OtherError, "WakeUp failed.");
                }
            }
            catch (OpenApiFaultException e)
            {
                // Convert error code.
                var result = new OapResponseXmlResult();
                var errorResultString = result.ConvertErrorCode(e.FaultMessage.ErrorDetails);

                _logger.LogTrace(default(EventId), e, $"OpenAPI Request failed. Complete convert error string : [{errorResultString}]");
                return GetAllErrorResult(settingNamesModels, errorResultString);
            }
            catch (HttpRequestException e)
            {
                _logger.LogTrace(default(EventId), e, "OpenAPI Request failed time out error.");
                return GetAllErrorResult(settingNamesModels, ErrorType.TimeOut.ModelValue());
            }
        
            // Execute OAP messages.
            var resultXmlDic = await ExecuteSetOapMsgAsync(oapMsgDic);

            // Get result OAP messages.
            return ResultOapSetMsg(settingNamesModels, resultXmlDic);
        }

        /// <summary>
        /// Get all error result
        /// </summary>
        /// <param name="settingNamesModels">All setting value</param>
        /// <param name="errorReason">Error reason</param>
        /// <returns>Failed result</returns>
        public List<SetSettingResult> GetAllErrorResult(
            IEnumerable<SetSettingValue> settingNamesModels,
            string errorReason)
        {
            var listResult = new List<SetSettingResult>();
            foreach (var settingValue in settingNamesModels)
            {
                var result = new SetSettingResult
                {
                    Name = settingValue.Name,
                    Result = false,
                    ErrorCode = errorReason,
                };
                listResult.Add(result);
            }

            return listResult;
        }

        /// <summary>
        /// Combine Get OAP Message.
        /// </summary>
        /// <param name="settingNames">Setting name list</param>
        /// <param name="oapMsgDic">OAP Message by RequestItem</param>
        private void CombineGetOapMsg(IEnumerable<string> settingNames, ref Dictionary<string, List<string>> oapMsgDic)
        {
            foreach (var settingName in settingNames)
            {
                try
                {
                    if (!_mfpSettings.TryGetValue(settingName, out var mfpSettingItemValue))
                    {
                        throw new KeyNotFoundException($"SettingName:{settingName} is not key value from Settings.json.");
                    }

                    if (!_settingCategory.TryGetValue(mfpSettingItemValue.RequestMsgItem, out var mfpSettingCategoryValue))
                    {
                        throw new KeyNotFoundException($"RequestMsgItem:{mfpSettingItemValue.RequestMsgItem} is not key value from SettingCategory.json.");
                    }

                    var oapMsg = mfpSettingCategoryValue.GetMessage;
                    if (!oapMsgDic.ContainsKey(oapMsg))
                    {
                        var requestItems = new List<string>
                        {
                            mfpSettingItemValue.RequestMsgItem
                        };
                        oapMsgDic.Add(oapMsg, requestItems);
                    }
                    else
                    {
                        var requestItems = oapMsgDic[oapMsg];
                        if (!requestItems.Contains(mfpSettingItemValue.RequestMsgItem))
                        {
                            requestItems.Add(mfpSettingItemValue.RequestMsgItem);
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw new OpenApiRequestException(OpenApiResultStatus.OtherError, $"OAP message create failed. {ex.Message}");
                }
            }
        }

        /// <summary>
        /// Combine Set OAP Message.
        /// </summary>
        /// <param name="settingNamesModels">List of setting name and value</param>
        /// <param name="oapMsgDic">OAP Message by RequestItem</param>
        private void CombineSetOapMsg(IEnumerable<SetSettingValue> settingNamesModels, IDictionary<string, XmlDocument> oapMsgDic)
        {
            var arraySizeCounters = new Dictionary<string, int>();

            var logPadding = $"{Environment.NewLine}\t\t";

            _logger.LogInformation("Combine set oap message. SettingName :" +
                                   $"{logPadding}{string.Join(logPadding, settingNamesModels.Select(f => f.Name))}");
            var sb = new StringBuilder();
            foreach (var settingNamesModel in settingNamesModels)
            {
                try
                {
                    if (!_mfpSettings.TryGetValue(settingNamesModel.Name, out var mfpSettingItemValue))
                    {
                        throw new KeyNotFoundException($"SettingName:{settingNamesModel.Name} is not key value from Settings.json.");
                    }

                    if (!_settingCategory.TryGetValue(mfpSettingItemValue.RequestMsgItem, out var mfpSettingCategoryValue))
                    {
                        throw new KeyNotFoundException($"RequestMsgItem:{mfpSettingItemValue.RequestMsgItem} is not key value from SettingCategory.json.");
                    }

                    if (!oapMsgDic.ContainsKey(mfpSettingItemValue.RequestMsgItem))
                    {
                        sb.AppendLine($"{settingNamesModel.Name} Combine set oap message. OapMsgDic Exists.");
                        var xml = new XmlDocument();
                        xml.LoadXml(mfpSettingCategoryValue.SetMessageTag);
                        SetOapMsgValues(ref xml, settingNamesModel, mfpSettingItemValue, arraySizeCounters);
                        oapMsgDic.Add(mfpSettingItemValue.RequestMsgItem, xml);
                    }
                    else
                    {
                        sb.AppendLine($"{settingNamesModel.Name} Combine set oap message. OapMsgDic does not Exists.");
                        var xml = oapMsgDic[mfpSettingItemValue.RequestMsgItem];
                        SetOapMsgValues(ref xml, settingNamesModel, mfpSettingItemValue, arraySizeCounters);
                    }
                }
                catch (XmlException e)
                {
                    _logger.LogTrace(default(EventId), e, $"Load xml error. Check SetMessageTag. [{settingNamesModel.Name}]");
                    throw;
                }
                catch (Exception e)
                {
                    throw new OpenApiRequestException(
                        OpenApiResultStatus.OtherError,
                        $"OpenApi message create failed [{settingNamesModel.Name}]. ${e.Message}");
                }
            }

            _logger.LogInformation(sb.ToString());
        }

        private void SetOapMsgValues(ref XmlDocument xml, SetSettingValue settingNamesModel, MfpSettingItemValue mfpSettingItemValue, Dictionary<string, int> arraySizeCounters)
        {
            var itemNode = xml.SelectSingleNode(mfpSettingItemValue.SetTag);
            if (itemNode != null && settingNamesModel.Value != null)
            {
                itemNode.InnerText = settingNamesModel.Value;
                if (string.IsNullOrEmpty(settingNamesModel.Value) && !string.IsNullOrEmpty(mfpSettingItemValue.Value))
                {
                    itemNode.InnerText = mfpSettingItemValue.Value;
                }
            }

            // extra values
            foreach (var extra in (mfpSettingItemValue.SetTagExtra ?? new List<MfpSettingItemValueExtra>()))
            {
                var extraItemNode = xml.SelectSingleNode(extra.Path);
                if (extraItemNode != null)
                {
                    switch (extra.Type)
                    {
                        case MfpSettingItemValueExtraType.FixedValue:
                            extraItemNode.InnerText = extra.Value;
                            break;
                        case MfpSettingItemValueExtraType.ArraySize:
                            if (mfpSettingItemValue.SetTag.StartsWith(extra.Value))
                            {
                                if (!arraySizeCounters.ContainsKey(extra.Value))
                                {
                                    arraySizeCounters.Add(extra.Value, 0);
                                }

                                extraItemNode.InnerText = (++arraySizeCounters[extra.Value]).ToString();
                            }

                            break;
                        default:
                            throw new ArgumentOutOfRangeException(nameof(MfpSettingItemValueExtra.Type));
                    }
                }
            }
        }

        /// <summary>
        /// Execute Get OAP Message.
        /// </summary>
        /// <param name="oapMsgDic">OAP Message by RequestItem</param>
        /// <returns>Result</returns>
        private async Task<Dictionary<string, XmlDocument>> ExecuteGetOapMsgAsync(Dictionary<string, List<string>> oapMsgDic)
        {
            var resultXmlDic = new Dictionary<string, XmlDocument>();

            foreach (var oapMsg in oapMsgDic.Keys)
            {
                var requestItems = oapMsgDic[oapMsg];

                foreach (var requestItem in requestItems)
                {
                    var mfpSettingCategoryValue = _settingCategory[requestItem];
                    var xml = new XmlDocument();
                    xml.LoadXml(mfpSettingCategoryValue.GetMessageTag);

                    try
                    {
                        var response = await OpenApiController.MfpSettingsAsync(xml, mfpSettingCategoryValue.IsAdmin, false);
                        resultXmlDic.Add(requestItem, response);
                    }
                    catch (Exception ex)
                    {
                        _logger.LogWarning(
                            default(EventId),
                            ex,
                            $"Mfp settings response is empty. RequestItem:[{requestItem}] " +
                            $"TagName:[{mfpSettingCategoryValue.GetMessageTag}]");
                        var response = new XmlDocument();
                        resultXmlDic.Add(requestItem, response);
                    }
                }
            }

            return resultXmlDic;
        }

        /// <summary>
        /// Execute Set OAP Message.
        /// </summary>
        /// <param name="oapMsgDic">OAP Message by RequestItem</param>
        /// <returns>Result</returns>
        private async Task<List<OapResponseXmlResult>> ExecuteSetOapMsgAsync(Dictionary<string, XmlDocument> oapMsgDic)
        {
            var resultList = new List<OapResponseXmlResult>();


            var requiredDeviceLock = false;
            try
            {
                if (oapMsgDic.Keys.Any(oapMsg => _settingCategory[oapMsg].IsAdmin))
                {
                    requiredDeviceLock = true;
                }

                if (requiredDeviceLock)
                {
                    await OpenApiController.EnterDeviceLockAsync(_mfpConnectorSettings.OpenApi.Devices.CurrentSetting
                        .MfpSettingLockTimeoutMin);
                }

                foreach (var oapMsg in oapMsgDic.Keys)
                {
                    _logger.LogInformation($"Excute:OAPMessage:[{oapMsg}]");

                    var result = new OapResponseXmlResult
                    {
                        Key = oapMsg
                    };

                    var xml = oapMsgDic[oapMsg];

                    DeleteEmptyTag(xml.DocumentElement);
                    ReplaceEmptyTag(xml.DocumentElement);

                    XmlDocument response;
                    try
                    {
                        response = await OpenApiController.MfpSettingsAsync(xml, _settingCategory[oapMsg].IsAdmin,
                            true);
                    }
                    catch (OpenApiFaultException e)
                    {
                        result.ErrorCode = e.FaultMessage.ErrorDetails;
                        response = null;
                    }
                    catch (HttpRequestException e)
                    {
                        _logger.LogTrace(default(EventId), e, "OpenAPI Request failed time out error.");
                        result.ErrorCode = ErrorType.TimeOut.ModelValue();
                        response = null;
                    }
                    catch (Exception e)
                    {
                        _logger.LogTrace(default(EventId), e, "OpenAPI Request failed response error.");
                        response = null;
                    }

                    result.Xml = response;
                    resultList.Add(result);
                }
            }
            catch (OpenApiFaultException e) 
                when(e.FaultMessage.ErrorDetails== OpenApiFaultErrorDetailsType.GeneralDuringDeviceLock.ToString())
            {
                requiredDeviceLock = false;
                throw;
            }
            finally
            {
                if (requiredDeviceLock)
                {
                    await OpenApiController.ExitDeviceLockAsync();
                }
            }

            return resultList;
        }

        /// <summary>
        /// Delete empty tag for Set OAP Message.
        /// </summary>
        /// <param name="node">Xml</param>
        /// <returns>ParentNode of empty tag</returns>
        private XmlNode DeleteEmptyTag(XmlNode node)
        {
            XmlNode ret = null;

            if (node.HasChildNodes)
            {
                var tmpNode = node.FirstChild;
                while (tmpNode != null)
                {
                    var parentNode = DeleteEmptyTag(tmpNode);
                    tmpNode = parentNode ?? tmpNode.NextSibling;
                }
            }
            else if (node.InnerText.Equals(string.Empty))
            {
                ret = node.ParentNode;
                node.ParentNode?.RemoveChild(node);
            }

            return ret;
        }

        /// <summary>
        /// Replace text * to  for Set OAP Message.
        /// </summary>
        /// <param name="node">Xml</param>
        /// <returns>ParentNode of replace tag</returns>
        private XmlNode ReplaceEmptyTag(XmlNode node)
        {
            XmlNode ret = null;

            if (node.HasChildNodes)
            {
                var tmpNode = node.FirstChild;
                while (tmpNode != null)
                {
                    var parentNode = ReplaceEmptyTag(tmpNode);
                    tmpNode = parentNode ?? tmpNode.NextSibling;
                }
            }
            else if (node.InnerText.Equals(OpenApiOpenApiRequestSettings.MfpConnectorSetting.OpenApi.Devices.CurrentSetting.EmptyText))
            {
                ret = node.ParentNode;
                node.InnerText = string.Empty;
            }

            return ret;
        }


        /// <summary>
        /// Result Get OAP Message.
        /// </summary>
        /// <param name="settingNames">Setting names</param>
        /// <param name="resultXmlDic">OAP Message result</param>
        /// <returns>Result</returns>
        private List<GetSettingValue> ResultOapGetMsg(List<string> settingNames, Dictionary<string, XmlDocument> resultXmlDic)
        {
            var res = new List<GetSettingValue>();

            try
            {
                foreach (var settingName in settingNames)
                {
                    var mfpSettingItemValue = _mfpSettings[settingName];
                    if (resultXmlDic.ContainsKey(mfpSettingItemValue.RequestMsgItem))
                    {
                        var xml = resultXmlDic[mfpSettingItemValue.RequestMsgItem];
                        if (xml == null || SelectSingleNode(xml, mfpSettingItemValue.GetTag) == null)
                        {
                            _logger.LogWarning($"Response is empty or tag not found. SettingName:[{settingName}] TagName:[{mfpSettingItemValue.GetTag}]");
                            var settingValue = SetDefaultSettingValue(settingName, mfpSettingItemValue);
                            res.Add(settingValue);
                            continue;
                        }

                        if (xml.GetElementsByTagName("ResultInfo")[0].InnerText == ResponseStatus.Ack.ToString())
                        {
                            var settingValue = SetDefaultSettingValue(settingName, mfpSettingItemValue);
                            settingValue.Result = true;
                            settingValue.Values = SelectSingleNode(xml, mfpSettingItemValue.GetTag)?.InnerText;
                            settingValue.Range = _mfpSettings[settingName].Range;
                            res.Add(settingValue);
                        }
                        else
                        {
                            var settingValue = SetDefaultSettingValue(settingName, mfpSettingItemValue);
                            res.Add(settingValue);
                        }
                    }
                    else
                    {
                        var settingValue = SetDefaultSettingValue(settingName, mfpSettingItemValue);
                        res.Add(settingValue);
                    }
                }
            }
            catch (Exception ex)
            {
                throw new OpenApiRequestException(OpenApiResultStatus.OtherError, $"OAP response failed. {ex.Message}");
            }

            return res;
        }

        /// <summary>
        /// Result Set OAP Message.
        /// </summary>
        /// <param name="settingNamesModels">Setting names and value</param>
        /// <param name="oapResponseXmlResult">OAP Message result</param>
        /// <returns>Result</returns>
        private List<SetSettingResult> ResultOapSetMsg(List<SetSettingValue> settingNamesModels, List<OapResponseXmlResult> oapResponseXmlResult)
        {
            var res = new List<SetSettingResult>();

            try
            {
                foreach (var settingNamesModel in settingNamesModels)
                {
                    var setSettingResult = new SetSettingResult
                    {
                        Name = settingNamesModel.Name,
                        Result = false
                    };

                    var mfpSettingItemValue = _mfpSettings[settingNamesModel.Name];
                    var xmlResult = oapResponseXmlResult.First(t => t.Key == mfpSettingItemValue.RequestMsgItem);

                    if (xmlResult.Xml == null)
                    {
                        _logger.LogWarning($"Response is empty. SettingName:[{settingNamesModel.Name}]\n" +
                                           $"TagName:[{mfpSettingItemValue.SetTag}]\n" +
                                           $"Convert error code : [{xmlResult.ErrorCode}]\n" +
                                           $"Complete convert error string : [{setSettingResult.ErrorCode}]");

                        setSettingResult.ErrorCode = xmlResult.ErrorCode;
                        setSettingResult.ErrorCode = xmlResult.ConvertErrorCode(xmlResult.ErrorCode);

                        res.Add(setSettingResult);
                        continue;
                    }

                    if (xmlResult.Xml.GetElementsByTagName("ResultInfo")[0].InnerText == ResponseStatus.Ack.ToString())
                    {
                        setSettingResult.Result = true;
                        if (IsChangeAdminPassword(settingNamesModel.Name))
                        {
                            OpenApiOpenApiRequestSettings.MfpConnectorSetting.OpenApi.Devices.CurrentSetting.Password =
                                settingNamesModel.Value == OpenApiOpenApiRequestSettings.MfpConnectorSetting.OpenApi.Devices.CurrentSetting
                                    .EmptyText
                                    ? string.Empty
                                    : settingNamesModel.Value;
                            try
                            {
                                OpenApiOpenApiRequestSettings.MfpConnectorSetting.Save();
                            }
                            catch (Exception ex)
                            {
                                // continuable warning
                                _logger.LogTrace(default(EventId), ex, $"Error occurred of save connector setting.");
                            }
                        }
                    }

                    res.Add(setSettingResult);
                }
            }
            catch (Exception)
            {
                throw new OpenApiRequestException(OpenApiResultStatus.OtherError, "OAP response failed.");
            }

            return res;
        }

        private static bool IsChangeAdminPassword(string name)
        {
            return name == AdminPasswordCategoryName;
        }

        /// <summary>
        /// Defalut Set GetSettingValue model.
        /// </summary>
        /// <param name="settingName">Setting names</param>
        /// <param name="mfpSettingItemValue">SettingItem</param>
        /// <returns>GetSettingValue</returns>
        private static GetSettingValue SetDefaultSettingValue(string settingName, MfpSettingItemValue mfpSettingItemValue)
        {
            var settingValue = new GetSettingValue
            {
                Result = false,
                Key = settingName,
                Values = null,
                Datatype = mfpSettingItemValue.Datatype,
                Range = string.Empty,
            };

            return settingValue;
        }

        /// <summary>
        /// Mfp wake up.
        /// </summary>
        /// <returns>Result</returns>
        private async Task<bool> WakeUpAsync()
        {
            var ret = true;
            if (!await GetDevicePowerStatusInfoAsync())
            {
                try
                {
                    ret = await _powerOperator.WakeUpToMfpAsync();
                }
                catch (Exception)
                {
                    ret = false;
                }
            }

            return ret;
        }

        /// <summary>
        /// Get device power status Infomation.
        /// </summary>
        /// <returns>Result</returns>
        private async Task<bool> GetDevicePowerStatusInfoAsync()
        {
            var ret = true;

            try
            {
                var xml = await OpenApiController.GetDevicePowerStatusAsync();
                if (xml.GetElementsByTagName("ResultInfo")[0].InnerText != ResponseStatus.Ack.ToString())
                {
                    ret = false;
                }
            }
            catch (OpenApiRequestException)
            {
                ret = false;
            }

            return ret;
        }

        /// <summary>
        /// Get node by XPath
        /// </summary>
        /// <param name="doc">XML document</param>
        /// <param name="tag">Target tag path</param>
        /// <returns>XmlNode</returns>
        private static XmlNode SelectSingleNode(XmlNode doc, string tag)
        {
            return doc?.SelectSingleNode(tag);
        }
    }
}
