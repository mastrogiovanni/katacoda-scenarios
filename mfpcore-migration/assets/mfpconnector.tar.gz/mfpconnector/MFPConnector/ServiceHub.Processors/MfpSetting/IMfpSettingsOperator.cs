using ServiceHub.Common.Settings.Mfp;
using ServiceHub.Processors.MfpSetting.Model;
using ServiceHub.Processors.Power;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ServiceHub.Processors.MfpSetting
{
    /// <summary>
    /// Interface of MFP settings operator
    /// </summary>
    public interface IMfpSettingsOperator
    {
        /// <summary>
        /// Initialize.
        /// </summary>
        /// <param name="settingCategory">Setting category</param>
        /// <param name="mfpSettings">Mfp setting</param>
        /// <param name="powerController">PowerController</param>
        void Init(
            Dictionary<string, MfpSettingCategoryValue> settingCategory,
            Dictionary<string, MfpSettingItemValue> mfpSettings,
            IPowerOperator powerController);

        /// <summary>
        /// Get Mfp settings.
        /// </summary>
        /// <param name="settingNames">Setting names</param>
        /// <returns>Json string</returns>
        Task<List<GetSettingValue>> GetMfpSettingsAsync(
            List<string> settingNames);

        /// <summary>
        /// Set Mfp settings.
        /// </summary>
        /// <param name="settingNames">Setting names</param>
        /// <returns>Json string</returns>
        Task<List<SetSettingResult>> SetMfpSettingsAsync(
            List<SetSettingValue> settingNames);

        /// <summary>
        /// Gets all error result.
        /// </summary>
        /// <param name="settingNamesModels">The setting names models.</param>
        /// <param name="errorReason">The error reason.</param>
        /// <returns></returns>
        List<SetSettingResult> GetAllErrorResult(
            IEnumerable<SetSettingValue> settingNamesModels,
            string errorReason);
    }
}
