using Newtonsoft.Json;

namespace ServiceHub.Processors.MfpSetting.Model
{
    /// <summary>
    /// Set setting result.
    /// </summary>
    public class SetSettingResult
    {
        /// <summary>
        /// Result.
        /// </summary>
        [JsonProperty("result")]
        public bool Result { get; set; }

        /// <summary>
        /// Name.
        /// </summary>
        [JsonProperty("name")]
        public string Name { get; set; }

        /// <summary>
        /// Error code.
        /// </summary>
        [JsonProperty("error_code", NullValueHandling= NullValueHandling.Ignore)]
        public string ErrorCode { get; set; }
    }
}
