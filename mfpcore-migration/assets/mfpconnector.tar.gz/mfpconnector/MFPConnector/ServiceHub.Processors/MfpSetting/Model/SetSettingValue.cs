using Newtonsoft.Json;

namespace ServiceHub.Processors.MfpSetting.Model
{
    /// <summary>
    /// Set setting value.
    /// </summary>
    public class SetSettingValue
    {
        /// <summary>
        /// Name.
        /// </summary>
        [JsonProperty("name")]
        public string Name { get; set; }

        /// <summary>
        /// Value.
        /// </summary>
        [JsonProperty("value")]
        public string Value { get; set; }
    }
}
