﻿using ServiceHub.Common.Extensions;
using System.Xml;

namespace ServiceHub.Processors.MfpSetting.Model
{
    /// <summary>
    /// Mfp setting error type
    /// </summary>
    public enum ErrorType
    {
        /// <summary>
        /// Undefined.
        /// </summary>
        Undefined,

        /// <summary>
        /// TimeOut.
        /// </summary>
        TimeOut,

        /// <summary>
        /// Authenticaiton.
        /// </summary>
        Auth,

        /// <summary>
        /// DeviceLock.
        /// </summary>
        DeviceLock,

        /// <summary>
        /// Internal Server error.
        /// </summary>
        Internal,

        /// <summary>
        /// Request error.
        /// </summary>
        Request,
    }

    /// <summary>
    /// Open api response xml result.
    /// </summary>
    public class OapResponseXmlResult
    {
        /// <summary>
        /// Open api message key.
        /// </summary>
        public string Key { get; set; }

        /// <summary>
        /// Open api result xml.
        /// </summary>
        public XmlDocument Xml { get; set; }

        /// <summary>
        /// Open api error result code.
        /// </summary>
        public string ErrorCode { get; set; }

        /// <summary>
        /// Convert error code
        /// </summary>
        /// <param name="oapReqErrorCode"></param>
        /// <returns>Error code string</returns>
        public string ConvertErrorCode(string oapReqErrorCode)
        {
            var errorStr = ErrorType.Undefined.ModelValue();
            switch (oapReqErrorCode)
            {
                //TimeOut
                case "DeviceSettingTimeOut":
                case "TimeOut":
                    errorStr = ErrorType.TimeOut.ModelValue();
                    break;

                //Authentication
                case "GeneralIllegalPassword":
                case "GeneralNotFoundSpecifiedUser":
                case "GeneralPasswordMismatch":
                case "GeneralPasswordMissing":
                case "GeneralOutOfAuthority":
                case "GeneralNotAllowedPublic":
                case "GeneralNotAllowedBoxAdmin":
                case "AuthNotAllowedAuthSetting":
                case "AuthIllegalAccount":
                case "AuthAlreadyExist":
                case "AuthIllegalPassword":
                case "AuthLackOfCharacter":
                case "AuthOverAuthLimit":
                case "AuthIllegalUserNo":
                case "AuthIllegalParameter":
                case "AuthServerSettingError":
                case "AuthDnsServerError":
                case "AuthServerNotFound":
                case "AuthServerAuthFailure":
                case "AuthServerBusy":
                case "AuthServerError":
                case "JobInfoNotSupportedItem":
                case "JobInfoIllegalValue":
                case "AuthNotSupportedAuthMode":
                case "AuthNotFoundAuthNo":
                case "AuthIllegalTrackID":
                case "AuthNotFoundTrack":
                case "AuthNotTrackMode":
                case "AuthIllegalTrackPassword":
                case "AuthIllegalTrackName":
                case "AuthAccessDenied":
                case "AuthTrackAlreadyExist_Password":
                case "AuthTrackAlreadyExist_Name":
                case "AuthUserAlreadyExist":
                case "AuthNotAllowedFunction":
                case "AuthNotFoundAuthKey":
                case "AuthOverAccessLimit":
                case "AuthNotFoundUserAuthData":
                case "AuthAccessDeniedTrack":
                case "AuthIllegalPasswordTrack":
                case "AuthNotAllowedFunctionTrack":
                case "AuthServerErrorTrack":
                case "AuthOverBoxLimit":
                case "AuthIllegalToken":
                case "AuthIllegalIntegrationTimeout":
                case "AuthIllegalIntegrationBusy":

                case "DeviceSerrtingOutOfAuth":
                case "DeviceSettingNotAllowed":

                case "Auth":
                    errorStr = ErrorType.Auth.ModelValue();
                    break;

                //DeviceLock
                case "GeneralDuringServiceMode":
                case "GeneralDuringAdminMode":
                case "GeneralDuringUserChoice":
                case "GeneralDuringFatal":
                case "GeneralDuringError":
                case "GeneralDuringBusy":
                case "GeneralDuringJobExist":
                case "GeneralDuringDeviceLock":
                case "GeneralDuringJobExistFaxTrans":
                case "GeneralOutOfTiming":
                case "GeneralDuringLongPrint":
                case "GeneralDuringUserLogin":
                case "GeneralDuringWarmUp":
                case "GeneralDuringSubPowerOff":
                case "GeneralDuringWeeklyTimer":
                case "GeneralDuringHddDisable":

                case "DeviceOperationIllegalLockKey":

                case "DeviceLock":
                    errorStr = ErrorType.DeviceLock.ModelValue();
                    break;

                // Request
                case "GeneralUnkownRequest":
                case "GeneralNotSupportedRequest":
                case "GeneralTagMissing":
                case "GeneralParserError":
                case "GeneralNameSpaceOver":
                case "GeneralNameSpaceStringOver":
                case "GeneralIllegalEncoding":
                case "GeneralIllegalTag":
                case "GeneralIllegalValue":
                case "GeneralPrefixStirngOver":
                case "GeneralXmlError":
                case "GeneralNotSupportedValue":

                case "DeviceInfoIllegalValue":
                case "DeviceInfoOtherError":
                case "DeviceSettingNotSupportedItem":
                case "DeviceSettingIllegalValue":

                case "DeviceOerationOutOfSupportItem":

                case "Request":
                    errorStr = ErrorType.Request.ModelValue();
                    break;

                //InternalServer
                case "GeneralReceiveMemoryOver":
                case "GeneralSendMemoryOver":
                case "GeneralReceiveMemoryBusy":
                case "GeneralSendMemoryBusy":
                case "GeneralAllocateBufferFull":
                case "GeneralAttachedFileMissing":
                case "GeneralRangeIllegal":
                case "GeneralArrayIllegal":
                case "GeneralPartsNotInstalled":
                case "GeneralAlreadyExistData":
                case "GeneralIllegalLockKey":
                case "GeneralNotFoundSpecifiedID":
                case "GeneralRegistOver":
                case "GeneralCombinationUnmatch":
                case "GeneralAlreadyExist":
                case "GeneralOverInspectLogLimit":
                case "GeneralExecuteFailure":
                case "GeneralBreachPasswordRules":
                case "GeneralWaitRebootConflict":
                case "GeneralNotFoundData":
                case "GeneralDuringMemoryDisable":
                case "GeneralServerConnectError":
                case "GeneralServerError":
                case "GeneralInvalidityCertificate":
                case "GeneralIllegalSignature":
                case "GeneralSerialNumberError":
                case "GeneralRequestcodeCodeError":
                case "GeneralDuringPowerSave":
                case "GeneralNotAllowedAddressSetting":
                case "OpenApiVersionMismatch":
                case "OpenApiNoApplicationID":
                case "OpenApiPasswordMismatch":
                case "OpenApiIllegalManagementID":
                case "OpenApiIllegalApplicationID":
                case "OpenApiConnectionTypeOver":
                case "OpenApiNotAuthMode":
                case "OpenApiIllegalSequence":
                case "OpenApiNotSupportWsdl":
                case "OpenApiNotPermittedRequest":

                case "DeviceSettingCannotSetPortNo":
                case "DeviceSettingDuplicateNetBIOS":
                case "DeviceSettingNotInstalledCertificate":
                case "DeviceSettingOverRegistLimit":
                case "DeviceSettingOtherError":

                case "Internal":
                    errorStr = ErrorType.Internal.ModelValue();
                    break;
            }

            return errorStr;
        }
    }
}
