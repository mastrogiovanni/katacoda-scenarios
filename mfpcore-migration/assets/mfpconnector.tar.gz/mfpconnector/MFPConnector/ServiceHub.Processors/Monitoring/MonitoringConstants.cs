﻿namespace ServiceHub.Processors.Monitoring
{
    internal static class MonitoringConstants
    {
        public const int RetryIntervalSeconds  = 5;
    }
}