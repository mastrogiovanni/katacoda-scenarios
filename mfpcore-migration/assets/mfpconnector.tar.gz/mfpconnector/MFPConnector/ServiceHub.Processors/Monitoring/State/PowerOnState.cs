using System;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using ServiceHub.Common.DeviceState;
using ServiceHub.Connectors.OpenAPI;
using ServiceHub.Processors.PushNotification;
using ServiceHub.Processors.Setup;

namespace ServiceHub.Processors.Monitoring.State
{
    /// <summary>
    /// MFP device state (Power On).
    /// </summary>
    public class PowerOnState : AbstractPowerState<PowerOnState>
    {
        private readonly IMfpInitialize _mfpInitialize;
        private readonly ILogger<PowerOnState> _logger;

        private bool _hasQueuedTask;

        /// <summary>
        /// Initializes a new instance of the <see cref="PowerOnState" /> class
        /// </summary>
        /// <param name="mfpInitialize">Mfp initialize setup</param>
        /// <param name="notifier">Push notifications to somewhere</param>
        /// <param name="stateContext">Device state context</param>
        /// <param name="openApiController">The open API controller.</param>
        /// <param name="logger">Logger</param>
        public PowerOnState(
            IMfpInitialize mfpInitialize,
            IPushNotifier notifier,
            IDeviceStateContext stateContext,
            IOpenApiController openApiController,
            ILogger<PowerOnState> logger)
            : base(notifier, stateContext, openApiController,logger)
        {
            _mfpInitialize = mfpInitialize;
            _logger = logger;
        }

        /// <summary>
        /// Gets a value indicating whether this <see cref="PowerOnState"/> is usable.
        /// </summary>
        public override bool Usable => true;

        /// <summary>
        /// Event handler for after change state.
        /// </summary>
        /// <param name="previousState">Previous state</param>
        /// <returns>change result</returns>
        protected override void ChangeState(IDeviceState previousState)
        {
            base.ChangeState(previousState);
            if (previousState?.GetType() == GetType() || _hasQueuedTask)
            {
                return;
            }
            
            _hasQueuedTask = true;
            StateContext.QueueTask(GetType().Name, InitializeProcessAsync, DefaultRetryIntervalAsync);
        }

        private async Task InitializeProcessAsync()
        {
            _logger.LogInformation("Because turned on MFP device, initialize process.");

            try
            {
                await _mfpInitialize.SetupAsync();
                _hasQueuedTask = false;
            }
            catch (Exception ex)
            {
                _logger.LogError(default(EventId), ex, "Exception occurred to initialize process.");
                throw;
            }
        }
    }
}
