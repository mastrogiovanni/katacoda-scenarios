using Microsoft.Extensions.Logging;
using ServiceHub.Common.DeviceState;
using ServiceHub.Connectors.OpenAPI;
using ServiceHub.Processors.Monitoring.Model;
using ServiceHub.Processors.PushNotification;
using System;
using System.Threading.Tasks;

namespace ServiceHub.Processors.Monitoring.State
{
    public abstract class AbstractPowerState<TState> : IDeviceState<TState>
    {
        private const string NotifyPath = "v1.0/alive";

        private readonly ILogger<TState> _logger;
        private readonly IPushNotifier _notifier;
        private readonly IOpenApiController _openApiController;

        protected readonly IDeviceStateContext StateContext;
        /// <summary>
        /// Initializes a new instance of sub class.
        /// </summary>
        /// <param name="notifier">Push notifications to somewhere</param>
        /// <param name="stateContext">Device state context</param>
        /// <param name="openApiController">The open API controller.</param>
        /// <param name="logger">Logger</param>
        protected AbstractPowerState(
            IPushNotifier notifier,
            IDeviceStateContext stateContext,
            IOpenApiController openApiController,
            ILogger<TState> logger)
        {
            _notifier = notifier;
            StateContext = stateContext;
            _logger = logger;
            _openApiController = openApiController;
        }

        public abstract bool Usable { get; }
        public bool Environment => true;

        /// <summary>
        /// Called when [change state].
        /// </summary>
        /// <param name="previousState">State of the previous.</param>
        public void OnChangeState(IDeviceState previousState)
        {
            try
            {
                ChangeState(previousState);
            }
            catch (Exception e)
            {
                // Swallow the exception
                _logger.LogError(default(EventId), e, "Error occurred to notify device state.");
            }
        }

        protected virtual void ChangeState(IDeviceState previousState)
        {
            if (previousState?.GetType() == GetType())
            {
                return;
            }

            StateContext.QueueTask(GetType().Name, NotifyStateToListenerAsync, DefaultRetryIntervalAsync);
        }

        private async Task NotifyStateToListenerAsync()
        {
            _logger.LogInformation("MFP's State Change. Notify to state listener. state : [{0}]", Usable);

            try
            {
                if (!Usable)
                {
                    _openApiController.RemoveCurrentAuthKeys();
                }

                await _notifier.PostAsync(NotifyPath, new MfpStateResult { Alive = Usable });
            }
            catch (Exception ex)
            {
                _logger.LogError(default(EventId), ex, "Exception occurred to notify to state listener");
                throw;
            }
        }

        protected static async Task DefaultRetryIntervalAsync()
        {
            await Task.Delay(TimeSpan.FromSeconds(MonitoringConstants.RetryIntervalSeconds));
        }
    }
}
