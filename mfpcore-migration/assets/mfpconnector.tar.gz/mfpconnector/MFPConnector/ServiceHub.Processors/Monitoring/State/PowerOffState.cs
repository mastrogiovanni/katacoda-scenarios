using Microsoft.CodeAnalysis.CSharp;
using Microsoft.Extensions.Logging;
using ServiceHub.Common.DeviceState;
using ServiceHub.Connectors.OpenAPI;
using ServiceHub.Processors.PushNotification;

namespace ServiceHub.Processors.Monitoring.State
{
    /// <summary>
    /// MFP device state (Power Off).
    /// </summary>
    public class PowerOffState : AbstractPowerState<PowerOffState>
    {
        /// <summary>
        /// Gets a value indicating whether this <see cref="PowerOffState"/> is usable.
        /// </summary>
        public override bool Usable => false;

        /// <summary>
        /// Initializes a new instance of the <see cref="PowerOffState" /> class
        /// </summary>
        /// <param name="notifier">Push notifications to somewhere</param>
        /// <param name="stateContext">Device state context</param>
        /// <param name="openApiController">The open API controller.</param>
        /// <param name="logger">Logger</param>
        public PowerOffState(
            IPushNotifier notifier,
            IDeviceStateContext stateContext,
            IOpenApiController openApiController,
            ILogger<PowerOffState> logger)
            : base(notifier, stateContext, openApiController,logger)
        {
        }
    }
}
