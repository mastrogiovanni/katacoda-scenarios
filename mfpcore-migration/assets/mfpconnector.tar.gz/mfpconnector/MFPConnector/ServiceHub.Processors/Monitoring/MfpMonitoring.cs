using AutoMapper;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using ServiceHub.Common.Constant;
using ServiceHub.Common.DeviceState;
using ServiceHub.Common.Settings.Iws;
using ServiceHub.Common.Settings.OpenApi;
using ServiceHub.Connectors.IWS.Actions;
using ServiceHub.Connectors.IWS.Model;
using ServiceHub.Connectors.IWS.Util;
using ServiceHub.Connectors.OpenAPI;
using ServiceHub.Connectors.OpenAPI.Model;
using ServiceHub.Processors.Common;
using ServiceHub.Processors.Monitoring.State;
using ServiceHub.Processors.Power;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Threading;
using System.Threading.Tasks;

namespace ServiceHub.Processors.Monitoring
{
    /// <summary>
    /// Mfp starutup monitoring class.
    /// </summary>
    public class MfpMonitoring : BackgroundService
    {
        private readonly TimeSpan _waitTimeForExecAppScript = TimeSpan.FromMilliseconds(600);
        private readonly IDeviceStateContext _stateContext;
        private readonly Ping _ping = new Ping();
        private readonly IOpenApiController _openApiController;
        private readonly OpenApiDeviceDetailSetting _deviceSettings;
        private readonly OpenApiAliveMonitorSetting _settings;
        private readonly IwsWebApiSetting _iwsWebApiSetting;
        private readonly IDeviceState<PowerOnState> _powerOnState;
        private readonly IDeviceState<PowerOffState> _powerOffState;
        private readonly ILogger<MfpMonitoring> _logger;
        private readonly IMapper _mapper;
        private readonly string _mfpCoreServiceId;
        private readonly IPowerOperator _powerOperator;

        private int _curOapConfirmPeriod;
        private int _pingErrorCount;
        private bool _dnsAvailable;
        private bool _init;

        /// <summary>
        /// Initializes a new instance of the <see cref="MfpMonitoring" /> class
        /// </summary>
        /// <param name="stateContext">Device state context</param>
        /// <param name="deviceSettings">OpenAPI request settings</param>
        /// <param name="logger">Logger</param>
        /// <param name="openApiController">OpenAPi controller</param>
        /// <param name="powerOnState">MFP device state (power on).</param>
        /// <param name="powerOffState">MFP device state (power off).</param>
        public MfpMonitoring(
            IDeviceStateContext stateContext,
            OpenApiRequestSettings deviceSettings,
            ILogger<MfpMonitoring> logger,
            IOpenApiController openApiController,
            IDeviceState<PowerOnState> powerOnState,
            IDeviceState<PowerOffState> powerOffState,
            IPowerOperator powerOperator)
        {
            _stateContext = stateContext;
            _deviceSettings = deviceSettings.MfpConnectorSetting.OpenApi.Devices.CurrentSetting;
            _iwsWebApiSetting = deviceSettings.MfpConnectorSetting.Iws.CurrentSetting;
            _settings = _deviceSettings.AliveMonitor;
            _logger = logger;
            _openApiController = openApiController;
            _powerOnState = powerOnState;
            _powerOffState = powerOffState;
            _mfpCoreServiceId = deviceSettings.MfpConnectorSetting.MfpCoreSettings.ServiceId;
            _mapper = GetMapperConfig();
            _powerOperator = powerOperator;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            _logger.LogInformation("MfpMonitoring background task is starting.");
            stoppingToken.Register(() => _logger.LogInformation("MfpMonitoring background task is stopping."));

            _logger.LogInformation("MfpCore Restart Wake up mfp.");
            await _powerOperator.WakeUpToMfpAsync(true).ConfigureAwait(false);

            while (!stoppingToken.IsCancellationRequested)
            {
                try
                {
                    var mfpDiscoveryInProgress = await ShouldContinueDiscoveryAsync().ConfigureAwait(false);
                    if (!mfpDiscoveryInProgress)
                    {
                        return;
                    }

                    var startupState = await GetStartupStateAsync().ConfigureAwait(false);

                    if (startupState != null)
                    {
                        _stateContext.ChangeState(startupState);

                        if (!_init && startupState.Usable)
                        {
                            await RemoveReqResScriptAsync();
                            _init = true;
                        }
                    }
                }
                catch (Exception ex)
                {
                    if (ex.InnerException?.InnerException != null &&
                        ex.InnerException.GetType() == typeof(PingException))
                    {
                        _logger.LogError(default(EventId), ex, $"{ex.InnerException.Message} " +
                                                               $"{ex.InnerException.InnerException.Message} " +
                                                               $"(Device IP: {_deviceSettings.DeviceIp}, " +
                                                               $"Ping Timeout: {_settings.PingTimeout})");
                    }
                    else
                    {
                        _logger.LogError(default(EventId), ex, "Exception occurred while trying to connect to " +
                                                               $"the MFP: [{ex.Message}]. " +
                                                               $"Retry in {_settings.PingInterval}ms.");
                    }
                }

                await Task.Delay(_settings.PingInterval, stoppingToken).ConfigureAwait(false);
            }

            _logger.LogInformation("MfpMonitoring background task is stopping.");
        }

        /// <summary>
        /// Check the availability of the dns by looking at the nicIp and dnsIp which should be the same.
        /// </summary>
        /// <returns>Returns true when NIC +DNS found.</returns>
        internal async Task<bool> GetDnsAvailabilityAsync()
        {
            var nicIp = _deviceSettings.NotifyIp;
            if (nicIp != null)
            {
                string dnsIp = null;
                var hostIpAddressList = await Dns.GetHostAddressesAsync(_mfpCoreServiceId).ConfigureAwait(false);
                var hostIpAddress =
                    hostIpAddressList.FirstOrDefault(f => f.AddressFamily.Equals(AddressFamily.InterNetwork));

                if (hostIpAddress != null)
                {
                    dnsIp = hostIpAddress.ToString();

                    if (dnsIp.Equals(nicIp))
                    {
                        _logger.LogInformation($"DNS setting completed. NIC_IP: {nicIp}, DNS_IP: {dnsIp}");
                        return true;
                    }
                }

                _logger.LogWarning($"Wait for DNS setting. NIC_IP: {nicIp}, DNS_IP: {dnsIp}");
            }
            else
            {
                _logger.LogWarning("Wait for DNS setting. NIC_IP: NULL");
            }

            return false;
        }

        private IMapper GetMapperConfig()
        {
            var config = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<IwsWebApiSetting, IwsWebApiUriData>()
                    .ForMember(d => d.IwsProtocol, o => o.MapFrom(s => s.Protocol))
                    .ForMember(d => d.IwsHostName, o => o.MapFrom(s => s.IpAddress))
                    .ForMember(d => d.PortNo, o => o.MapFrom(s => s.Port))
                    .ForMember(d => d.IwsWebApiPath, o => o.MapFrom(s => $"{GeneralConstant.IwsWebApiPath}"))
                    .ForMember(d => d.IwsWebApiUriFront, o => o.MapFrom(s => $"{s.Protocol}://{s.IpAddress}:{s.Port}"))
                    .ForMember(d => d.IwsWebApiUri,
                        o => o.MapFrom(s => $"{s.Protocol}://{s.IpAddress}:{s.Port}{GeneralConstant.IwsWebApiPath}"));
                cfg.CreateMap<IwsWebApiSetting, IwsWebApiReqCommon>()
                    .ForMember(d => d.EnhancedServerAuthInfo,
                        o => o.MapFrom(s => EnhancedServerAuthInfo.Convert(s.EnhancedServerAuth)))
                    .ForMember(d => d.MfpPassword, o => o.MapFrom(s => string.Empty));
            });

            return config.CreateMapper();
        }

        private async Task<bool> ShouldContinueDiscoveryAsync()
        {
            if (_dnsAvailable)
            {
                return _stateContext.Environment;
            }

            _dnsAvailable = await GetDnsAvailabilityAsync().ConfigureAwait(false);

            if (!_dnsAvailable)
            {
                _logger.LogError("Retry check for DNS setting. Therefore, checking the mfp state is pending.");
                return false;
            }

            return _stateContext.Environment;
        }

        private async Task<IDeviceState> GetStartupStateAsync()
        {
            IDeviceState startupState = null;

            var canConnectToMfp = await ConfirmConnectByPingAsync();
            if (!canConnectToMfp)
            {
                SetPowerOffStateOnTooManyPingErrors(ref startupState);
                _curOapConfirmPeriod = 0;
            }
            else if (++_curOapConfirmPeriod >= _settings.OapConfirmPeriod)
            {
                _pingErrorCount = 0;
                _curOapConfirmPeriod = 0;

                canConnectToMfp = await _openApiController.ConfirmConnectAsync(_settings.OapConfirmTimeout)
                    .ConfigureAwait(false);

                startupState = SetPowerState(canConnectToMfp);
            }
            else
            {
                _pingErrorCount = 0;
            }

            return startupState;
        }

        private IDeviceState SetPowerState(bool canConnectToMfp)
        {
            IDeviceState startupState;
            if (canConnectToMfp)
            {
                _logger.LogInformation("Success to confirm connect.");
                startupState = _powerOnState;
            }
            else
            {
                _curOapConfirmPeriod = _settings.OapConfirmPeriod - 1;
                _logger.LogError("Failed to confirm connect by oap.");
                startupState = _powerOffState;
            }

            return startupState;
        }

        private void SetPowerOffStateOnTooManyPingErrors(ref IDeviceState startupState)
        {
            if (++_pingErrorCount >= _settings.PingErrorMax)
            {
                _pingErrorCount--;
                // MFP is down
                startupState = _powerOffState;
                _logger.LogInformation("Failed to confirm connect using ping. Setting state to [PowerOffState]");
            }
        }

        private async Task<bool> ConfirmConnectByPingAsync()
        {
            var buffer = new byte[32];

            // Do an ICMP ping to the MFP
            var reply = await _ping
                .SendPingAsync(_deviceSettings.DeviceIp, _settings.PingTimeout, buffer)
                .ConfigureAwait(false);

            return reply.Status == IPStatus.Success;
        }

        /// <summary>
        /// Exec IWS application script to remove json files.
        /// </summary>
        private async Task RemoveReqResScriptAsync()
        {
            var deleteItemRequestList = new List<DeleteItemRequest>
            {
                new DeleteItemRequest
                {
                    DeletionPattern = DeletionPattern.File,
                    FileName = SenderConfig.Get(SenderConfig.IwsCopyAction.Response)
                },
                new DeleteItemRequest
                {
                    DeletionPattern = DeletionPattern.File,
                    FileName = SenderConfig.Get(SenderConfig.IwsScanAction.Response)
                }
            };

            _logger.LogDebug($"scriptPath = {GeneralConstant.RemoveFileScriptPath}");

            var action = new ExecAppScript(
                _mapper.Map<IwsWebApiSetting, IwsWebApiUriData>(_iwsWebApiSetting),
                _mapper.Map<IwsWebApiSetting, IwsWebApiReqCommon>(_iwsWebApiSetting));

            action.SetRequestParameter(
                null, 
                GeneralConstant.RemoveFileScriptPath, 
                JsonConvert.SerializeObject(deleteItemRequestList));

            await action.InvokeAsync();
            await Task.Delay(_waitTimeForExecAppScript);
        }
    }
}
