using Newtonsoft.Json;

namespace ServiceHub.Processors.Monitoring.Model
{
    /// <summary>
    /// MFP State result class.
    /// </summary>
    public class MfpStateResult
    {
        /// <summary>
        /// Result
        /// </summary>
        [JsonProperty(PropertyName = "alive")]
        public bool Alive { get; set; }

        /// <summary>
        /// ToString
        /// </summary>
        public override string ToString() {
            return $"{{ Alive = {Alive} }}";
        }
    }
}
