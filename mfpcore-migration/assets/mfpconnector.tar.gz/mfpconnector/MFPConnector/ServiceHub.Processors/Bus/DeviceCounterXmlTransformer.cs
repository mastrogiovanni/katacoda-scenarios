﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Xml;
using ServiceHub.Processors.Bus.Models;
using ServiceHub.Processors.Bus.Models.Attributes;

namespace ServiceHub.Processors.Bus
{
    /// <summary>
    /// This class is converting XmlDocument.
    /// </summary>
    internal class DeviceCounterXmlTransformer
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="DeviceCounterXmlTransformer"/> class.
        /// </summary>
        protected DeviceCounterXmlTransformer()
        {
        }

        /// <summary>
        /// Transforms the specified document.
        /// </summary>
        /// <param name="doc">The document.</param>
        /// <returns></returns>
        public static DeviceCounters Transform(XmlDocument doc)
        {
            var xmlRootNode = doc.DocumentElement;
            var mfpCountersDto = (DeviceCounters)ConvertMfpCounters(xmlRootNode, typeof(DeviceCounters));

            return mfpCountersDto;
        }

        /// <summary>
        /// Converts the MFP counters.
        /// </summary>
        /// <param name="currentNode">The current node to deserialize.</param>
        /// <param name="objectType">The type.</param>
        /// <returns></returns>
        private static object ConvertMfpCounters(XmlNode currentNode, Type objectType)
        {
            var result = Activator.CreateInstance(objectType);
            foreach (var propertyInfo in objectType.GetProperties())
            {
                var isUsingXPathDictionary = ManageXPathDictionary(currentNode, propertyInfo, result);
                var isUsingXPathKvp = false;
                if (!isUsingXPathDictionary)
                {
                    isUsingXPathKvp = ManageXPathKeyValuePair(currentNode, propertyInfo, result);
                }

                if (!isUsingXPathKvp && !isUsingXPathDictionary)
                {
                    var value = propertyInfo.GetValue(result, null);

                    if (value == null)
                    {
                        try
                        {
                            var subTreeResult = ConvertMfpCounters(currentNode, propertyInfo.PropertyType);
                            propertyInfo.SetValue(result, subTreeResult);
                        }
                        catch (Exception)
                        {
                            // List of defined exception: https://bit.ly/2HiqTgD
                            // Swallow the exception, no instance can be created.
                        }
                    }
                }
            }

            return result;
        }

        /// <summary>
        /// Manages the x path key value pair.
        /// </summary>
        /// <param name="root">The root.</param>
        /// <param name="propertyInfo">The property information.</param>
        /// <param name="result">The result.</param>
        /// <returns></returns>
        private static bool ManageXPathKeyValuePair(XmlNode root, PropertyInfo propertyInfo, object result)
        {
            var attributes = propertyInfo.GetCustomAttributes<XPathKeyValuePairAttribute>()?.ToList();
            if (attributes != null && attributes.Any())
            {
                var content = Activator.CreateInstance(propertyInfo.PropertyType);
                var data = (Dictionary<string, decimal>)content; 
                foreach (var attribute in attributes)
                {
                    var node = root.SelectSingleNode(attribute.XPath);
                    if (node != null)
                    {
                        AssignCounterElement(node, data);
                    }
                }

                propertyInfo.SetValue(result, data);
            }

            return attributes != null && attributes.Any();
        }

        /// <summary>
        /// Manages the x path dictionary.
        /// </summary>
        /// <param name="root">The root.</param>
        /// <param name="propertyInfo">The property information.</param>
        /// <param name="result">The result.</param>
        /// <returns></returns>
        private static bool ManageXPathDictionary(XmlNode root, PropertyInfo propertyInfo, object result)
        {
            var attribute = propertyInfo.GetCustomAttribute<XPathDictionaryAttribute>();
            if (attribute != null)
            {
                var nodes = root.SelectNodes(attribute.XPath);
                var data = new Dictionary<string, long>();
                if(nodes!= null)
                {
                    AssignCounterNodes(nodes, data);
                }

                propertyInfo.SetValue(result, data);
            }

            return attribute != null;
        }

        private static void AssignCounterNodes(IEnumerable counterNodes, IDictionary<string, long> counters)
        {
            foreach (XmlNode node in counterNodes)
            {
                var name = node.SelectSingleNode("./Type").InnerText;
                var totalCount = long.Parse(node.SelectSingleNode("./Count").InnerText);
                counters.Add(name, totalCount);
            }
        }

        private static void AssignCounterElement(XmlNode counterElement, IDictionary<string, decimal> counters)
        {
            var name = counterElement.Name;
            var totalCount = decimal.Parse(counterElement.InnerText);
            counters.Add(name, totalCount);
        }
    }
}
