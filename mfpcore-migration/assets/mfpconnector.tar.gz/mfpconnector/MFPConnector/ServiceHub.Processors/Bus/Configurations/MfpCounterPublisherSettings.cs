﻿namespace ServiceHub.Processors.Bus.Configurations
{
    internal class MfpCounterPublisherSettings
    {
        /// <summary>
        /// Gets or sets the maximum retry count.
        /// </summary>
        public int MaxRetryCount { get; set; }

        /// <summary>
        /// Gets or sets the retry wait seconds.
        /// </summary>
        public int RetryWaitSeconds { get; set; }
    }
}