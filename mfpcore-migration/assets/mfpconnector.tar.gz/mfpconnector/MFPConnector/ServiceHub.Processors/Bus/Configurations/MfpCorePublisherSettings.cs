﻿namespace ServiceHub.Processors.Bus.Configurations
{
    internal class MfpCorePublisherSettings
    {
        public static readonly string SectionName = "MfpCorePublisherSettings";

        public int TimeoutDelayMs { get; set; }
        public MfpCounterPublisherSettings MfpCounter { get; set; }
    }
}
