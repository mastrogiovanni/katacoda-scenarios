﻿using System;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using ServiceHub.CommonTools.Bus.Bus;
using ServiceHub.CommonTools.Bus.Infrastructure;
using ServiceHub.CommonTools.Bus.Messages.MfpCore;
using ServiceHub.Connectors.OpenAPI;
using ServiceHub.Connectors.OpenAPI.Model;
using ServiceHub.Processors.Exceptions;
using ServiceHub.Processors.Notify.Model;
using Formatting = Newtonsoft.Json.Formatting;

namespace ServiceHub.Processors.Bus
{
    /// <summary>
    /// This class counter information of MFP to RabbitMQ.
    /// </summary>
    internal class MfpCounterPublisher : OpenApiOperatable, IMfpCounterPublisher
    {
        private enum BusSenderJobStatusType
        {
            End,
            Deleted, 
            TimeOut,
            ErrorPrinting,
            ErrorScanning
        }

        private const string XPATH_RESULT_INFO = "ResultInfo";

        private readonly ILogger<MfpCounterPublisher> _logger;
        private readonly IShBusPublisher _publisher;
        private readonly Configurations.MfpCorePublisherSettings _mfpCorePublisherSettings;
        private readonly JsonSerializerSettings _jsonSettings;

        /// <summary>
        /// Initializes a new instance of the <see cref="MfpCounterPublisher" /> class.
        /// </summary>
        /// <param name="logger">The logger.</param>
        /// <param name="openApiRequestSettings">The open API request settings.</param>
        /// <param name="openApiController">The open API controller.</param>
        /// <param name="publisher">The publisher.</param>
        /// <param name="publisherSettings">The publisher settings.</param>
        public MfpCounterPublisher(
            ILogger<MfpCounterPublisher> logger,
            OpenApiRequestSettings openApiRequestSettings,
            IOpenApiController openApiController,
            IShBusPublisher publisher,
            IOptions<Configurations.MfpCorePublisherSettings> publisherSettings)
            : base(openApiRequestSettings, openApiController)
        {
            _logger = logger;
            _publisher = publisher;
            _mfpCorePublisherSettings = publisherSettings.Value;

            var contractResolver = new DefaultContractResolver
            {
                NamingStrategy = new CamelCaseNamingStrategy()
            };

            _jsonSettings = new JsonSerializerSettings { ContractResolver = contractResolver };
        }

        /// <summary>
        /// Notifies the MFP counters only if the .
        /// </summary>
        /// <param name="jobStatus">The job status.</param>
        /// <returns></returns>
        public async Task NotifyFromJobStatusAsync(NotifyJobStatus jobStatus)
        {
            if (Enum.TryParse(jobStatus.Status, true, out BusSenderJobStatusType statusType)
                && Enum.IsDefined(typeof(BusSenderJobStatusType), statusType))
            {
                _logger.LogTrace($"Sending a notification for counter after: [JobStatus={statusType.ToString()}]");
                try
                {
                    await PublishMfpCounterAsync().ConfigureAwait(false);
                }
                catch (MfpCorePublisherException ex)
                {
                    _logger.LogError(default(EventId), ex, "Error while sending while publishing mfp counters:\n" +
                                                           $"{ex.Message}");
                }
            }
        }

        /// <summary>
        /// Processes the bus publish asynchronous.
        /// </summary>
        /// <returns></returns>
        /// <exception cref="MfpCorePublisherException">Max amount of retry ({MaxRetryCount})</exception>
        internal async Task PublishMfpCounterAsync()
        {
            var stoppingToken =
                new CancellationTokenSource(TimeSpan.FromMilliseconds(_mfpCorePublisherSettings.TimeoutDelayMs));
            var tryCount = 0;

            while (!await BusPublishCounterInfoAsync() && !stoppingToken.IsCancellationRequested)
            {
                tryCount++;
                if (tryCount == _mfpCorePublisherSettings.MfpCounter.MaxRetryCount)
                {
                    throw new MfpCorePublisherException(
                        $"Max retry count ({_mfpCorePublisherSettings.MfpCounter.MaxRetryCount}) " +
                        "to publish to RabbitMQ have been reached.");
                }

                await Task.Delay(
                    TimeSpan.FromSeconds(_mfpCorePublisherSettings.MfpCounter.RetryWaitSeconds), 
                    stoppingToken.Token);
            }
        }

        /// <summary>
        /// Publishes the bus asynchronous.
        /// </summary>
        /// <returns>Returns true if publish succeed.</returns>
        private async Task<bool> BusPublishCounterInfoAsync()
        {
            _logger.LogTrace("BusPublishCounterInfoAsync start");
            var xml = await OpenApiController.GetCounterInfoAsync(MfpCounterType.Total);
            if (xml != null 
                && xml.GetElementsByTagName(XPATH_RESULT_INFO)[0].InnerText == ResponseStatus.Ack.ToString())
            {
                _logger.LogTrace("Counter information acquisition succeeded.");
                try
                {
                    var payload = new ShPayloadGeneric(
                        JsonConvert.SerializeObject(
                            DeviceCounterXmlTransformer.Transform(xml), 
                            Formatting.Indented, 
                            _jsonSettings));

                    _publisher.Publish<MfpCoreCounterUpdated, ShPayloadGeneric>(payload);
                    return true;
                }
                catch (Exception ex)
                {
                    // Swallow the exception.
                    _logger.LogError(default(EventId), ex, $"Exception happened bus publish.\n {ex.Message}");
                    return false;
                }
            }

            _logger.LogTrace("Failed Counter information acquisition.");
            return false;
        }
    }
}
