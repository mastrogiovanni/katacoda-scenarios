﻿using System;
using System.Collections.Generic;
using ServiceHub.Processors.Bus.Models.Attributes;

namespace ServiceHub.Processors.Bus.Models
{
    /// <summary>
    /// This class is the model of bus sender information.
    /// </summary>
    public class DeviceCounters
    {
        /// <summary>
        /// Gets the counter date creation under the RFC-3339 format.
        /// </summary>
        public long UtcUnixTimeStamp => 
            new DateTimeOffset(DateTime.UtcNow).ToUnixTimeMilliseconds();
        
        public string RequestItemType => "Total";

        [XPathKeyValuePair("//UserCounterInfo/TotalCounterData/Nin1TotalRate")]
        [XPathKeyValuePair("//UserCounterInfo/TotalCounterData/DuplexTotalRate")]
        public Dictionary<string, decimal> TotalCounterData { get; set; }

        [XPathDictionary("//UserCounterInfo/TotalCounterList//TotalCounter")]
        public Dictionary<string, long> TotalCounters { get; set; }

        public PaperSheetCounters PaperSheetCounters { get; set; }

        [XPathDictionary("//UserCounterInfo/CopyCounterList//CopyCounter")]
        public Dictionary<string, long> CopyCounters { get; set; }

        [XPathDictionary("//UserCounterInfo/PrintCounterList//PrintCounter")]
        public Dictionary<string, long> PrintCounters { get; set; }

        [XPathDictionary("//UserCounterInfo/ScanFaxCounterList//ScanFaxCounter")]
        public Dictionary<string, long> ScanFaxCounters { get; set; }
    }
}
