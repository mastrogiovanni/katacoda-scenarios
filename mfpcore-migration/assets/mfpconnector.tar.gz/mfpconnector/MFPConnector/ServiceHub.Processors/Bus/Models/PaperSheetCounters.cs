﻿using System.Collections.Generic;
using ServiceHub.Processors.Bus.Models.Attributes;

namespace ServiceHub.Processors.Bus.Models
{
    public class PaperSheetCounters
    {
        [XPathDictionary("//UserCounterInfo/PaperSheetCounter/FullColorCounterList//FullColorCounter")]
        public Dictionary<string, long> FullColorCounters { get; set; }

        [XPathDictionary("//UserCounterInfo/PaperSheetCounter/BlackCounterList//BlackCounter")]
        public Dictionary<string, long> BlackCounters { get; set; }

        [XPathDictionary("//UserCounterInfo/PaperSheetCounter/DoubleColorCounterList//DoubleColorCounter")]
        public Dictionary<string, long> DoubleColorCounters { get; set; }
    }
}