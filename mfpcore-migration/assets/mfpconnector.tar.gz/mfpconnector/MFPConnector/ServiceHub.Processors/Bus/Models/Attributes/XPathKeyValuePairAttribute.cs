﻿using System;

namespace ServiceHub.Processors.Bus.Models.Attributes
{
    [AttributeUsage(AttributeTargets.Property, AllowMultiple = true)]
    internal class XPathKeyValuePairAttribute : Attribute
    {
        /// <summary>
        /// Gets the x path.
        /// </summary>
        public string XPath { get; }

        /// <summary>
        /// Initializes a new instance of the <see cref="XPathKeyValuePairAttribute"/> class.
        /// </summary>
        /// <param name="xpath">The xpath.</param>
        public XPathKeyValuePairAttribute(string xpath)
        {
            XPath = xpath;
        }
    }
}
