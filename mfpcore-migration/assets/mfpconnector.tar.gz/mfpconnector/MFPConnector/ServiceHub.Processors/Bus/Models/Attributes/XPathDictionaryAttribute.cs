﻿using System;

namespace ServiceHub.Processors.Bus.Models.Attributes
{
    [AttributeUsage(AttributeTargets.Property)]
    internal class XPathDictionaryAttribute : Attribute
    {
        /// <summary>
        /// Gets the x path.
        /// </summary>
        public string XPath { get; }

        /// <summary>
        /// Initializes a new instance of the <see cref="XPathDictionaryAttribute"/> class.
        /// </summary>
        /// <param name="xpath">The xpath.</param>
        public XPathDictionaryAttribute(string xpath)
        {
            XPath = xpath;
        }
    }
}
