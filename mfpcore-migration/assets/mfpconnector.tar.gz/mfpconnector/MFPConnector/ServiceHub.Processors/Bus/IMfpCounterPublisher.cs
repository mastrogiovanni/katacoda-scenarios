﻿using System.Threading.Tasks;
using ServiceHub.Processors.Notify.Model;

namespace ServiceHub.Processors.Bus
{
    /// <summary>
    /// Define the Bus Sender interface.
    /// </summary>
    public interface IMfpCounterPublisher
    {
        Task NotifyFromJobStatusAsync(NotifyJobStatus jobStatus);
    }
}
