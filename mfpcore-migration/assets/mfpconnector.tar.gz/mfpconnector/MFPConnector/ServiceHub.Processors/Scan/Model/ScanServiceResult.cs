using Newtonsoft.Json;

namespace ServiceHub.Processors.Scan.Model
{
    /// <summary>
    /// Scan result from IWS
    /// </summary>
    public class ScanServiceResult
    {
        /// <summary>Result type string.</summary>
        [JsonProperty(PropertyName = "result")]
        public string Result { get; set; }

        /// <summary>Error detail string.</summary>
        [JsonProperty(PropertyName = "error")]
        public string Error { get; set; }

        /// <summary>Job ID.</summary>
        [JsonProperty(PropertyName = "job_id")]
        public int? JobId { get; set; }
    }
}
