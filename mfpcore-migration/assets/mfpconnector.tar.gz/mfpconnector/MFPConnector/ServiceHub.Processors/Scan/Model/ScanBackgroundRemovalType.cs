﻿namespace ServiceHub.Processors.Scan.Model
{
    /// <summary>
    /// back ground type.
    /// </summary>
    public enum ScanBackgroundRemovalType
    {
        AUTO,
        MANUAL
    }
}
