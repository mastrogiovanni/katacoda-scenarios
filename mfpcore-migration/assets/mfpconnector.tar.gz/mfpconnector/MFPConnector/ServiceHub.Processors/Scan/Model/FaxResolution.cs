﻿namespace ServiceHub.Processors.Scan.Model
{
    /// <summary>
    /// Resolution for Fax scanning.
    /// </summary>
    public enum FaxResolution
    {
        NORMAL,
        FINE,
        SUPER_FINE,
        ULTRA_FINE
    }
}
