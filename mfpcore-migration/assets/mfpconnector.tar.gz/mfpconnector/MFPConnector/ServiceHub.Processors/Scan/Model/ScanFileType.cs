﻿namespace ServiceHub.Processors.Scan.Model
{
    public enum ScanFileType
    {
        PDF,
        CompactPDF,
        TIFF,
        JPEG,
        XPS,
        CompactXPS,
        DOCX,
        XLSX,
        PPTX
    }
}
