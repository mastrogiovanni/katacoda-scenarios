using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using ServiceHub.Common.Settings;

namespace ServiceHub.Processors.Scan.Model
{
    public class ScanServiceSetting
    {
        [JsonProperty(PropertyName = "file_name", NullValueHandling = NullValueHandling.Ignore)]
        public string FileName { get; set; }

        [JsonProperty(PropertyName = "resolution", NullValueHandling = NullValueHandling.Ignore)]
        [RegularExpression("200X200|300X300|400X400|600X600")]
        public string Resolution { get; set; }

        [JsonProperty(PropertyName = "file_type", NullValueHandling = NullValueHandling.Ignore)]
        [JsonConverter(typeof(StringEnumConverter))]
        public ScanFileType FileType { get; set; }

        [JsonProperty(PropertyName = "color", NullValueHandling = NullValueHandling.Ignore)]
        public ScanColor Color { get; set; }

        [JsonProperty(PropertyName = "webdav_settings", NullValueHandling = NullValueHandling.Ignore)]
        public WebDavSetting? WebdavSettings { get; set; }

        [JsonProperty(PropertyName = "in_duplex", NullValueHandling = NullValueHandling.Ignore)]
        [JsonConverter(typeof(StringEnumConverter))]
        public ScanSide ScanSide { get; set; }

        [JsonProperty(PropertyName = "auth_parameter", NullValueHandling = NullValueHandling.Ignore)]
        public AuthParameter AuthParameter { get; set; }

        [JsonProperty(PropertyName = "in_paper_size", NullValueHandling = NullValueHandling.Ignore)]
        public ScanInPaperSize InPaperSize { get; set; }

        [JsonProperty(PropertyName = "fax_resolution", NullValueHandling = NullValueHandling.Ignore)]
        [JsonConverter(typeof(StringEnumConverter))]
        public FaxResolution? FaxResolution { get; set; }

        [JsonProperty(PropertyName = "txfax", NullValueHandling = NullValueHandling.Ignore)]
        public FaxSendSetting? FaxSendSettings { get; set; }

        /// <summary>
        /// Gets or sets density.
        /// </summary>
        [JsonProperty(PropertyName = "density", NullValueHandling = NullValueHandling.Ignore)]
        [Range(-4, 4)]
        public int Density { get; set; }

        /// <summary>
        /// Gets or sets class of background removal.
        /// </summary> 
        [JsonProperty(PropertyName = "background_removal", NullValueHandling = NullValueHandling.Ignore)]
        public ScanBackgroundRemoval BackgroundRemoval { get; set; }
    }
}