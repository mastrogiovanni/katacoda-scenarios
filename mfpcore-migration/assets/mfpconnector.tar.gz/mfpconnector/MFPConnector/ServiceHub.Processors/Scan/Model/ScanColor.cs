using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace ServiceHub.Processors.Scan.Model
{
    /// <summary>
    /// Color model on IWS.
    /// </summary>
    public class ScanColor
    {
        /// <summary>
        /// Gets or sets class of color mode choices.
        /// </summary>
        [JsonProperty(PropertyName = "mode", Required = Required.Always)]
        [JsonConverter(typeof(StringEnumConverter))]
        public ScanColorMode Mode { get; set; }

        /// <summary>
        /// Gets or sets class of color choices.
        /// </summary>
        [JsonProperty(PropertyName = "color")]
        [JsonConverter(typeof(StringEnumConverter))]
        public ScanColorSelectColor SelectColor { get; set; }
    }
}
