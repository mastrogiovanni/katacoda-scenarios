using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System.ComponentModel.DataAnnotations;

namespace ServiceHub.Processors.Scan.Model
{
    /// <summary>
    /// BackgroundRemoval model on IWS.
    /// </summary>
    public class ScanBackgroundRemoval
    {
        /// <summary>
        /// Gets or sets type of background removal.
        /// </summary>
        [JsonProperty(PropertyName = "type", Required = Required.Always)]
        [JsonConverter(typeof(StringEnumConverter))]
        public ScanBackgroundRemovalType Type { get; set; }

        /// <summary>
        /// Gets or sets level of background removal.
        /// </summary>
        [JsonProperty(PropertyName = "level", Required = Required.Default)]
        [Range(-6, 2)]
        public int? Level { get; set; }
    }
}
