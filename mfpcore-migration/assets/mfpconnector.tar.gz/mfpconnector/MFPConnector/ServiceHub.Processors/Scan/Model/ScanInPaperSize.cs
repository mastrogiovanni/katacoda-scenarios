using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace ServiceHub.Processors.Scan.Model
{
    /// <summary>
    /// InPaperSize model on IWS.
    /// </summary>
    public class ScanInPaperSize
    {
        /// <summary>
        /// Gets or sets class of paper size type choices.
        /// </summary>
        [JsonProperty(PropertyName = "type", Required = Required.Always)]
        [JsonConverter(typeof(StringEnumConverter))]
        public ScanPaperSizeType Type { get; set; }

        /// <summary>
        /// Gets or sets class of data.
        /// </summary>
        [JsonProperty(PropertyName = "data")]
        public string Data { get; set; }
    }
}
