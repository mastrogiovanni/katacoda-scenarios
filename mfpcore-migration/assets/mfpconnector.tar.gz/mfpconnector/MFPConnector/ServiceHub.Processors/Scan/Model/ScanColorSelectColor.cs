﻿namespace ServiceHub.Processors.Scan.Model
{
    /// <summary>
    /// Color choices.
    /// </summary>
    public enum ScanColorSelectColor
    {
        NOT_SELECTED,
        BLACK
    }
}
