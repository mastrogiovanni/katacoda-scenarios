using Newtonsoft.Json;

namespace ServiceHub.Processors.Scan.Model
{
    /// <summary>
    /// Fax Send Setting.
    /// </summary>
    public struct FaxSendSetting
    {
        /// <summary>
        /// Gets or sets class of address for fax sending.
        /// </summary>
        [JsonProperty(PropertyName = "address")]
        public string FaxAddress { get; set; }

        /// <summary>
        /// Gets or sets class of faxing overseas.
        /// </summary>
        [JsonProperty(PropertyName = "use_overseas_tx")]
        public bool? UseOverseasTx { get; set; }

        /// <summary>
        /// Gets or sets class of canceling ECM mode.
        /// </summary>
        [JsonProperty(PropertyName = "use_ecm")]
        public bool? CancelEcm { get; set; }

        /// <summary>
        /// Gets or sets class of confirm destination before sending.
        /// </summary>
        [JsonProperty(PropertyName = "use_check_dest_and_send")]
        public bool? UseCheckDestAndSend { get; set; }

        /// <summary>
        /// Gets or sets class of password.
        /// </summary>
        [JsonProperty(PropertyName = "password")]
        public string Password { get; set; }
    }
}
