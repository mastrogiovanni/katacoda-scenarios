﻿namespace ServiceHub.Processors.Scan.Model
{
    /// <summary>
    /// Color mode choices.
    /// </summary>
    public enum ScanColorMode
    {
        AUTO,
        FULL_COLOR,
        SINGLE_COLOR,
        GRAY_SCALE
    }
}
