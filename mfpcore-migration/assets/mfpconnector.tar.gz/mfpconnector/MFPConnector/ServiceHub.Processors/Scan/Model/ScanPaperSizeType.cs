﻿namespace ServiceHub.Processors.Scan.Model
{
    /// <summary>
    /// Paper size type choices.
    /// </summary>
    public enum ScanPaperSizeType
    {
        AUTO,
        STANDARD
    }
}
