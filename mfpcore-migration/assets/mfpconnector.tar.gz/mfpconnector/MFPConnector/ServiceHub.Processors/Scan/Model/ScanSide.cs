﻿namespace ServiceHub.Processors.Scan.Model
{
    /// <summary>
    /// Scanning side for Scan.
    /// </summary>
    public enum ScanSide
    {
        SIMPLEX,
        DUPLEX
    }
}
