using System;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using ServiceHub.Connectors.IWS;
using ServiceHub.Processors.Common;
using ServiceHub.Processors.Scan.Model;

namespace ServiceHub.Processors.Scan
{
    /// <summary>
    /// Scan Sender
    /// </summary>
    public class ScanSender : IMfpSender<ScanServiceSetting, ScanServiceResult>
    {
        private readonly ILogger<ScanSender> _logger;
        private readonly IIwsConnector _connector;

        private static readonly JsonSerializerSettings SerializerSettings = new JsonSerializerSettings
        {
            NullValueHandling = NullValueHandling.Ignore
        };

        /// <summary>
        /// Initializes a new instance of the <see cref="ScanSender" /> class.
        /// </summary>
        /// <param name="logger">Logger</param>
        /// <param name="iwsConnectorUser">The iws connector user.</param>
        public ScanSender(ILogger<ScanSender> logger, IIwsConnectorUser iwsConnectorUser)
        {
            _logger = logger;
            _connector = iwsConnectorUser;
        }

        /// <summary>
        /// Send data to MFP.
        /// </summary>
        /// <param name="data">Processing data</param>
        /// <returns>Task that return output from MFP.</returns>
        public async Task<ScanServiceResult> SendToMfpAsync(ScanServiceSetting data)
        {
            _logger.LogInformation("SendToMfp Started.");
            return await ExecScanAsync(data);
        }

        /// <summary>
        /// Exec scan.
        /// </summary>
        /// <param name="data">Scan request information.</param>
        /// <returns>Scan response information.</returns>
        private async Task<ScanServiceResult> ExecScanAsync(ScanServiceSetting data)
        {
            if (data == null)
            {
                throw new ArgumentNullException(nameof(data));
            }

            try
            {
                _logger.LogInformation("ExecScan Started.");

                var result = await _connector.ExecuteAsync(
                    SenderConfig.Get(SenderConfig.IwsScanAction.Script),
                    data.AuthParameter,
                    JsonConvert.SerializeObject(
                        data,
                        Formatting.None,
                        SerializerSettings),
                    SenderConfig.Get(SenderConfig.IwsScanAction.Response),
                    SenderConfig.Get(SenderConfig.IwsScanAction.Request));

                return result != null ?
                    JsonConvert.DeserializeObject<ScanServiceResult>(result)
                    : new ScanServiceResult
                    {
                        Result = SenderConfig.IwsResultStatus.NG.ToString(),
                        Error = SenderConfig.IwsError.Timeout.ToString()
                    };
            }
            catch (IwsException e)
            {
                return new ScanServiceResult
                {
                    Result = SenderConfig.IwsResultStatus.NG.ToString(),
                    Error = e.IwsErrorMessage
                };
            }
        }
    }
}
