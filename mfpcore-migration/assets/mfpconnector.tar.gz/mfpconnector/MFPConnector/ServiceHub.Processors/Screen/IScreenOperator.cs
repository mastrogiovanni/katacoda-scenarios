using System.Threading.Tasks;
using ServiceHub.Connectors.OpenAPI.Model;

namespace ServiceHub.Processors.Screen
{
    public interface IScreenOperator
    {
        /// <summary>
        /// Change to Legacy
        /// </summary>
        /// <returns>Success/Fail</returns>
        Task ScreenChangeAsync(SwitchType switchType, ScreenType? screenType, int? appNo);

        /// <summary>
        /// Set the installed mode to WPH installed mode.
        /// </summary>
        /// <returns>Xml document</returns>
        Task SetInstalledAsync();
    }
}
