using Newtonsoft.Json;
using ServiceHub.Connectors.OpenAPI.Model;

namespace ServiceHub.Processors.Screen.Model
{
    /// <summary>
    /// Screen setting model.
    /// </summary>
    public class ScreenSetting
    {
        /// <summary>
        /// Switch type.
        /// </summary>
        [JsonProperty(PropertyName = "switching_type", NullValueHandling = NullValueHandling.Ignore)]
        public SwitchType SwitchType { get; set; }

        /// <summary>
        /// Screen Type.
        /// </summary>
        [JsonProperty(PropertyName = "screen_type", NullValueHandling = NullValueHandling.Ignore)]
        public ScreenType? ScreenType { get; set; }

        /// <summary>
        /// Application number.
        /// </summary>
        [JsonProperty(PropertyName = "app_no", NullValueHandling = NullValueHandling.Ignore)]
        public int? AppNo { get; set; }
    }
}
