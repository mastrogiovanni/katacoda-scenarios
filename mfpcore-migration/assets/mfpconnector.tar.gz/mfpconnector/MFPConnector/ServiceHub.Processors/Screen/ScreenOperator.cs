using System.Threading.Tasks;
using ServiceHub.Connectors.OpenAPI;
using ServiceHub.Connectors.OpenAPI.Model;

namespace ServiceHub.Processors.Screen
{
    /// <summary>
    /// Screen switching operator
    /// </summary>
    public class ScreenOperator : OpenApiOperatable, IScreenOperator
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ScreenOperator" /> class
        /// </summary>
        /// <param name="openApiRequestSettings">The open API request settings.</param>
        /// <param name="openApiController">The open API controller.</param>
        public ScreenOperator(OpenApiRequestSettings openApiRequestSettings, IOpenApiController openApiController)
            :base(openApiRequestSettings, openApiController)
        {
        }

        /// <summary>
        /// Switch to Legacy screen
        /// </summary>
        /// <param name="switchType">SwitchType</param>
        /// <param name="screenType">ScreenType</param>
        /// <param name="appNo">AppNumber</param>
        /// <returns>Success/Fail</returns>
        public async Task ScreenChangeAsync(SwitchType switchType, ScreenType? screenType, int? appNo)
        {
            await OpenApiController.ChangeDeviceScreenAsync(switchType, screenType, appNo);
        }

        /// <summary>
        /// Set the installed mode to WPH installed mode.
        /// </summary>
        /// <returns>Success/Fail</returns>
        public async Task SetInstalledAsync()
        {
            await OpenApiController.SetInstalledAsync();
        }
    }
}
