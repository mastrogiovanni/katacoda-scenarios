using System;
using System.Threading.Tasks;
using ServiceHub.Common.Model;
using ServiceHub.Common.Settings.Fax;
using ServiceHub.Connectors.OpenAPI;
using ServiceHub.Connectors.OpenAPI.Model;
using Microsoft.Extensions.Logging;

namespace ServiceHub.Processors.Fax
{
    /// <summary>
    /// Fax Receive Setter.
    /// </summary>
    public class FaxReceiveSetter : OpenApiOperatable, IFaxReceiveSetter
    {
        private readonly ILogger<FaxReceiveSetter> _logger;

        /// <summary>
        /// Initializes a new instance of the FaxReceiveSetter class
        /// </summary>
        /// <param name="logger">Logger</param>
        /// <param name="openApiRequestSettings">OpenApiRequestSettings</param>
        /// <param name="openApiController">IOpenApiController</param>
        public FaxReceiveSetter(
            ILogger<FaxReceiveSetter> logger,
            OpenApiRequestSettings openApiRequestSettings,
            IOpenApiController openApiController)
            : base(openApiRequestSettings, openApiController)
        {
            _logger = logger;
        }

        /// <summary>
        /// Set Abbreviation Addressbook
        /// </summary>
        /// <param name="faxReceiveSetting">Fax receive setting</param>
        public Task SetAbbreviationAddressbookAsync(FaxReceiveSetting faxReceiveSetting)
        {
            try
            {
                _logger.LogInformation("SetAbbreviationAddressbook");
                return OpenApiController.SetAbbreviationAddressbookAsync(faxReceiveSetting);
            }
            catch (Exception ex)
            {
                var message = new ExceptionMessage(ex).ToString();
                _logger.LogWarning(default(EventId), ex, message);
                throw;
            }
        }
    }
}
