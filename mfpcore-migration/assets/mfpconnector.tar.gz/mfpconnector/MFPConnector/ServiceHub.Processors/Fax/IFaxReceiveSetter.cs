using System.Threading.Tasks;
using ServiceHub.Common.Settings.Fax;

namespace ServiceHub.Processors.Fax
{
    /// <summary>
    /// Fax Receive Setter.
    /// </summary>
    public interface IFaxReceiveSetter
    {
        /// <summary>
        /// Set Abbreviation Addressbook
        /// </summary>
        /// <param name="faxReceiveSetting">Fax receive setting</param>
        Task SetAbbreviationAddressbookAsync(FaxReceiveSetting faxReceiveSetting);
    }
}