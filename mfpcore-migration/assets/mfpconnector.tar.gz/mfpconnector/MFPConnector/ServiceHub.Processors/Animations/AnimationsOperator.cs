using KonicaMinolta.OpenApi;
using ServiceHub.Connectors.OpenAPI;
using ServiceHub.Connectors.OpenAPI.Model;
using ServiceHub.Connectors.OpenAPI.Model.ResponseXmlModel;
using ServiceHub.Connectors.OpenAPI.Model.ResponseXmlModel.Animations;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Xml;
using OpenApiNackException = ServiceHub.Connectors.OpenAPI.Exceptions.OpenApiNackException;
using Microsoft.Extensions.Logging;

namespace ServiceHub.Processors.Animations
{
    /// <summary>
    /// Animatinon operator class.
    /// </summary>
    public class AnimationsOperator : OpenApiOperatable, IAnimationsOperator
    {
        private readonly ILogger<AnimationsOperator> _logger;

        /// <summary>
        /// Initializes a new instance of the <see cref="AnimationsOperator"/> class.  
        /// </summary>
        /// <param name="logger">Logger</param>
        /// <param name="openApiRequestSettings">OpenApiRequestSettings</param>
        /// <param name="openApiController">IOpenApiController</param>
        public AnimationsOperator(
            ILogger<AnimationsOperator> logger,
            OpenApiRequestSettings openApiRequestSettings,
            IOpenApiController openApiController)
            : base(openApiRequestSettings, openApiController)
        {
            _logger = logger;
        }

        /// <summary>
        /// Get animation rom version.
        /// </summary>
        /// <returns>animation rom version</returns>
        public async Task<string> GetAnimationRomVersionAsync()
        {
            _logger.LogInformation($"{nameof(AnimationsOperator)}.{nameof(GetAnimationRomVersionAsync)} START");

            const string targetDataName = "Movie Data";
            string version;

            // Get animation rom version.
            var document = await OpenApiController.GetDeviceInfoDetailAsync(DetailSettingsRequestItems.Version);
            var response = new OpenApiMessage(document.OuterXml);

            var nodeXpath = $"/AppResGetDeviceInfoDetail/VersionList/Version[Name='{targetDataName}']";
            var nodeResult = response.TryGetXmlNode(nodeXpath, out var node);
            if (nodeResult)
            {
                version = node.SelectSingleNode("./Code")?.InnerText;
            }
            else
            {
                // error
                throw new OpenApiNackException(document, "Version not found.");
            }

            return version;
        }

        /// <summary>
        /// Get XML of animation file list.
        /// </summary>
        /// <returns>JSON of animation file list</returns>
        public async Task<List<Model.AnimationFile>> GetAnimationFileListAsync()
        {
            _logger.LogInformation($"{nameof(AnimationsOperator)}.{nameof(GetAnimationFileListAsync)} START");

            // Get animation file list.
            var document = await OpenApiController.GetAnimationFileListAsync();

            _logger.LogInformation($"XML : {document.OuterXml}");
            var docResult = XmlConverter.Deserialize<AppResGetAnimationFileList>(document);
            var jsonResult = new List<Model.AnimationFile>();
            foreach (var animationFile in docResult.AnimationFiles.AnimationFiles) {
                var jsonAnimationFile = new Model.AnimationFile
                {
                    AnimationId = animationFile.AnimationId,
                    AnimationSteps = new List<Model.AnimationStep>(),
                };
                jsonResult.Add(jsonAnimationFile);

                foreach (var stepLists in animationFile.AnimationStepList)
                {
                    foreach (var stepList in stepLists.AnimationStep)
                    {
                        var jsonStepList = new Model.AnimationStep
                        {
                            StepId = stepList.StepId,
                            FilePathList = new List<string>(),
                        };
                        jsonAnimationFile.AnimationSteps.Add(jsonStepList);

                        foreach(var filePathList in stepList.AnimationFilePathList)
                        {
                            foreach (var filePath in filePathList.AnimationFilePath)
                            {
                                jsonStepList.FilePathList.Add(filePath.FilePath);
                            }
                        }
                    }
                }
            }

            return jsonResult;
        }
    }
}