﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace ServiceHub.Processors.Animations.Model
{

    public class AnimationFile
    {
        [JsonProperty(PropertyName = "animation_id")]
        public int AnimationId { get; set; }

        [JsonProperty(PropertyName = "animation_steps")]
        public List<AnimationStep> AnimationSteps { get; set; }
    }

    public class AnimationStep
    {
        [JsonProperty(PropertyName = "step_id")]
        public int StepId { get; set; }
        [JsonProperty(PropertyName = "file_path_list")]
        public List<string> FilePathList { get; set; }
    }

}
