namespace ServiceHub.Processors.Animations.Model
{
    /// <summary>
    /// Animation data
    /// </summary>
    public class AnimationData
    {
        /// <summary>
        /// Animation id
        /// </summary>
        public int AnimationId { get; set; }

        /// <summary>
        /// Animation file path
        /// </summary>
        public string AnimationFilePath { get; set; }

        /// <summary>
        /// Animation file name
        /// </summary>
        public string AnimationFileName { get; set; }

        /// <summary>
        /// Animation step id
        /// </summary>
        public string AnimationStepId { get; set; }

        /// <summary>
        /// Animation file number
        /// </summary>
        public string AnimationFileNumber { get; set; }

        /// <summary>
        /// Animation byte data
        /// </summary>
        public byte[] AnimationByteData { get; set; }
    }
}
