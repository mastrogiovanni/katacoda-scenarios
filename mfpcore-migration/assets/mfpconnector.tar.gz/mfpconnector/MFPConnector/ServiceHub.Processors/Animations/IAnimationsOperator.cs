using System.Collections.Generic;
using System.Threading.Tasks;
using ServiceHub.Processors.Animations.Model;

namespace ServiceHub.Processors.Animations
{
    /// <summary>
    /// Animations interface.
    /// </summary>
    public interface IAnimationsOperator
    {
        /// <summary>
        /// Get animation rom version.
        /// </summary>
        /// <returns>Animation rom version.</returns>
        Task<string> GetAnimationRomVersionAsync();

        /// <summary>
        /// Get file of animation data list.
        /// </summary>
        /// <returns>tar file of animation data list</returns>
        Task<List<AnimationFile>> GetAnimationFileListAsync();
    }
}
