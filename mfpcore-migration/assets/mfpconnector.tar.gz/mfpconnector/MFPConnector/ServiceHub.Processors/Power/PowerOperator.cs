using KonicaMinolta.OpenApi;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using ServiceHub.Common.Settings.MfpSettings;
using ServiceHub.Connectors.OpenAPI;
using ServiceHub.Connectors.OpenAPI.Exceptions;
using ServiceHub.Connectors.OpenAPI.Model;
using System;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Threading.Tasks;
using System.Xml;
using OpenApiNackException = KonicaMinolta.OpenApi.OpenApiNackException;

namespace ServiceHub.Processors.Power
{
    /// <summary>
    /// Power operator
    /// </summary>
    public class PowerOperator : OpenApiOperatable, IPowerOperator
    {
        private readonly TimeSpan _delayRetryRequest = TimeSpan.FromSeconds(1);
        private readonly ILogger<PowerOperator> _logger;
        private readonly MfpWakeupSetting _mfpWakeupSetting;

        private string _macAddress;

        /// <inheritdoc />
        public PowerOperator(
            ILogger<PowerOperator> logger, 
            OpenApiRequestSettings openApiRequestSettings, 
            IOpenApiController openApiController,
            MfpWakeupSetting mfpWakeupSetting)
            : base(openApiRequestSettings, openApiController)
        {
            _logger = logger;
            _mfpWakeupSetting = mfpWakeupSetting;
        }

        /// <inheritdoc />
        public async Task<string> ChangePowerModeAsync(PowerMode powerMode)
        {
            var xml = await OpenApiController.ChangePowerModeAsync(powerMode);
            return xml.GetElementsByTagName("ResultInfo")[0].InnerText;
        }

        /// <inheritdoc />
        public async Task<bool> WakeUpToMfpAsync(bool mpfCoreStart = false)
        {
            if (!mpfCoreStart)
            {
                await MfpMacAddressSettingAsync();
            }

            if (string.IsNullOrEmpty(_mfpWakeupSetting.MacAddress))
            {
                return false;
            }

            return await StartMfpUsingOpenApiAsync() || await StartMfpUsingMacAddress();
        }

        /// <summary>MFPs the wakeup setting save asynchronous.</summary>
        /// <returns></returns>
        public async Task MfpMacAddressSettingAsync()
        {
            try
            {
                var response =
                    await OpenApiController.GetDeviceInfoDetailAsync(DetailSettingsRequestItems.PhysicalInterface);
                var macAddress = response.GetElementsByTagName("MacAddress")[0].InnerText;

                _macAddress = string.IsNullOrEmpty(macAddress) ? _mfpWakeupSetting.MacAddress : macAddress;
                
                if (_mfpWakeupSetting.MacAddress != _macAddress)
                {
                    _mfpWakeupSetting.MacAddress = _macAddress;

                    using (StreamWriter file =
                        File.CreateText(Directory.GetCurrentDirectory() + _mfpWakeupSetting.FilePath))
                    {
                        JsonSerializer serializer = new JsonSerializer();
                        serializer.Serialize(file, _mfpWakeupSetting);
                    }
                }
            }
            catch (OpenApiNackException ex)
            {
                _logger.LogInformation(default(EventId), ex, "OpenApi Nack exception has occurred.");
            }
            catch (OpenApiFaultException ex)
            {
                _logger.LogInformation(default(EventId), ex, "OpenApi Fault exception has occurred.");
            }
            catch (OpenApiRequestException ex)
            {
                _logger.LogInformation(default(EventId), ex, "OpenApi Request exception has occurred.");
            }
            catch (AggregateException ex)
            {
                _logger.LogInformation(default(EventId), ex, "Aggregate exception has occurred.");
            }
            catch (IOException ex)
            {
                _logger.LogInformation(default(EventId), ex, $"Exception occurred during file operation. {ex.Message}");
            }
        }

        /// <inheritdoc />
        public bool IsDevicePowersToSleep(XmlDocument xml)
        {
            var isResult = ResponseStatus.Ack.ToString() == xml.GetElementsByTagName("ResultInfo")[0].InnerText;
            var isStandby = IsStandby(xml);
            return isResult && isStandby;
        }

        /// <inheritdoc />
        public bool IsStandby(XmlDocument xml)
        {
            var isSubPower = Convert.ToBoolean(xml.GetElementsByTagName(PowerStatus.SubPower.ToString())[0].InnerText);
            var isSleep = !Convert.ToBoolean(xml.GetElementsByTagName(PowerStatus.Sleep.ToString())[0].InnerText);
            var isLowPower = !Convert.ToBoolean(xml.GetElementsByTagName(PowerStatus.LowPower.ToString())[0].InnerText);

            return isSubPower && isSleep && isLowPower;
        }

        /// <summary>
        /// Send command for wake up.
        /// </summary>
        /// <param name="deviceIp">Device Ip Address</param>
        private static async Task SendShWakeUpAsync(string deviceIp)
        {
            var packet = "KMSHWAKEUP";
            var packetData = packet.ToCharArray().Select(s => (byte)s).ToArray();
            using (var udpClient = new UdpClient(AddressFamily.InterNetwork))
            {
                await udpClient.SendAsync(packetData, packetData.Length, deviceIp, 60050);
            }
        }

        /// <inheritdoc />
        public async Task SendMagicPacketAsync()
        {
            var packet = $"FF:FF:FF:FF:FF:FF:{ string.Join(":", Enumerable.Repeat(_mfpWakeupSetting.MacAddress, 16)) }";

            var packetData = packet.Split(':').Select(s => byte.Parse(s, NumberStyles.AllowHexSpecifier)).ToArray();
            using (var udpClient = new UdpClient(AddressFamily.InterNetwork))
            {
                udpClient.EnableBroadcast = true;
                
                await udpClient.SendAsync(packetData, packetData.Length, new IPEndPoint(IPAddress.Broadcast, 9));
            }
        }

        /// <summary>
        /// Starts the MFP using open API asynchronous.
        /// </summary>
        /// <returns></returns>
        private async Task<bool> StartMfpUsingOpenApiAsync()
        {
            await SendShWakeUpAsync(OpenApiOpenApiRequestSettings.MfpConnectorSetting.OpenApi.Devices.CurrentSetting.DeviceIp);
            await SendMagicPacketAsync();

            return await IsWakeUpAsync();
        }

        /// <summary>
        /// Starts the MFP using mac address.
        /// </summary>
        /// <returns></returns>
        private async Task<bool> StartMfpUsingMacAddress()
        {
            await MfpMacAddressSettingAsync();
            await SendMagicPacketAsync();

            return await IsWakeUpAsync();
        }

        /// <summary>
        /// Confirm whether MFP has started-up.
        /// </summary>
        /// <returns>IsWakeUpAsync</returns>
        private async Task<bool> IsWakeUpAsync()
        {
            // 5 tries
            for(var i = 0; i < 5; i++)
            {
                try
                {
                    if (IsDevicePowersToSleep(await OpenApiController.GetDevicePowerStatusAsync()))
                    {
                        return true;
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError(default(EventId), ex, "AppReqGetDeviceStatus2 failed.");
                }

                await Task.Delay(_delayRetryRequest);
            }

            return false;
        }

        private enum PowerStatus
        {
            SubPower,
            Sleep,
            LowPower
        }
    }
}