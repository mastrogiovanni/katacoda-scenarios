using System.Threading.Tasks;
using System.Xml;
using ServiceHub.Connectors.OpenAPI.Model;

namespace ServiceHub.Processors.Power
{
    public interface IPowerOperator
    {
        /// <summary>
        /// Wake up to Mfp
        /// </summary>
        /// <returns>Result</returns>
        Task<bool> WakeUpToMfpAsync(bool mfpCoreStart = false);

        /// <summary>
        /// Change power mode to erp.
        /// </summary>
        /// <param name="powerMode">Power mode.</param>
        /// <returns>Ack/Nack</returns>
        Task<string> ChangePowerModeAsync(PowerMode powerMode);

        /// <summary>
        /// Check whether the power state of the device is in standby state.
        /// </summary>
        /// <param name="xml">Xml for Device power status.</param>
        /// <returns>IsStandby</returns>
        bool IsDevicePowersToSleep(XmlDocument xml);

        /// <summary>
        /// Check whether the power state of the device is in standby state.
        /// </summary>
        /// <param name="xml">Xml for Device power status.</param>
        /// <returns>IsStandby</returns>
        bool IsStandby(XmlDocument xml);

        /// <summary>
        /// Send command for magic packet.
        /// </summary>
        /// <returns>Task</returns>
        Task SendMagicPacketAsync();

        /// <summary>
        /// MFPs the mac address setting asynchronous.
        /// </summary>
        /// <returns></returns>
        Task MfpMacAddressSettingAsync();
    }
}