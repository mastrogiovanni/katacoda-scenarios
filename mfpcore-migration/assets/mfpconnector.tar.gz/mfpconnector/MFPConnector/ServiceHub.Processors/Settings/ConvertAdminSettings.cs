using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Xml;
using System.Xml.Serialization;
using System.Xml.XPath;
using Microsoft.Extensions.Logging;
using ServiceHub.Common.Settings;
using ServiceHub.Connectors.OpenAPI.Model;
using ServiceHub.Processors.Settings.Model;

namespace ServiceHub.Processors.Settings
{
    /// <summary>
    /// Convert admin settings
    /// </summary>
    public class ConvertAdminSettings:IConvertAdminSettings
    {
        /// <summary>
        /// FunctionCode
        /// </summary>
        /// <remarks>1-based</remarks>
        private enum FuncCodes
        {
            /// <summary>
            /// Searchable PDF
            /// </summary>
            SearchablePdf = 6,

            /// <summary>
            /// PDF/A
            /// </summary>
            PdfA = 7,

            /// <summary>
            /// Web Optimized (Linearized PDF)
            /// </summary>
            LinearizedPdf = 8
        }

        /// <summary>
        /// OpenApi NameSpace
        /// </summary>
        private readonly string _oapNamespace;

        /// <summary>
        /// Logger
        /// </summary>
        private readonly ILogger<ConvertAdminSettings> _logger;

        /// <summary>
        /// Initializes a new instance of the <see cref="ConvertAdminSettings"/> class.  
        /// </summary>
        /// <param name="logger">Logger</param>
        /// <param name="settings">OpenApiRequestSettings</param>
        public ConvertAdminSettings(ILogger<ConvertAdminSettings> logger, OpenApiRequestSettings settings)
        {
            _logger = logger;
            _oapNamespace = settings.Namespace;
        }

        /// <summary>
        /// Convert xml to model.
        /// </summary>
        /// <param name="xml">Xml</param>
        /// <param name="settingName">Setting name</param>
        /// <returns>Response</returns>
        /// <exception cref="XmlException">Invalid response</exception>
        public SettingValue ConvertToAdminSettings(XmlDocument xml, string settingName)
        {
            SettingValue settingValue;

            var documentElementName = xml.DocumentElement?.Name;

            if (documentElementName != null && documentElementName.Contains(ConvertAdminSettingsConst.AppResGetDevicePermanentSetting))
            {
                settingValue = ConvertToForSettingNameXml(xml, ConvertAdminSettingsConst.AppResGetDevicePermanentSetting, settingName);   
            }
            else if (documentElementName != null && documentElementName.Contains(ConvertAdminSettingsConst.AppResGetDeviceInfoDetail))
            {
                settingValue = ConvertToForSettingNameXml(xml, ConvertAdminSettingsConst.AppResGetDeviceInfoDetail, settingName);
            }
            else
            {
                throw new XmlException("not found elementName:" + documentElementName);
            }

            return settingValue;
        }

        /// <summary>
        /// ConvertToAdminSettingsForEnableOcrScan.
        /// </summary>
        /// <param name="deviceInfoExFuncXml">Device info ex func xml</param>
        /// <param name="enableFuncXml">Enable func xml</param> 
        /// <param name="settingName">Setting name</param>
        /// <returns>Response</returns>
        /// <exception cref="XmlException">Invalid response</exception>
        public SettingValue ConvertToAdminSettingsForEnableOcrScan(XmlDocument deviceInfoExFuncXml, XmlDocument enableFuncXml, string settingName)
        {
            SettingValue settingValue;
            
            var documentElementNameExFunc = deviceInfoExFuncXml.DocumentElement?.Name;
            var documentElementNameEnableFunc = enableFuncXml.DocumentElement?.Name;

            if (documentElementNameExFunc != null && documentElementNameExFunc.Contains(ConvertAdminSettingsConst.AppResGetDeviceInfo))
            {
                if (documentElementNameEnableFunc != null && documentElementNameEnableFunc.Contains(ConvertAdminSettingsConst.AppResGetEnableFunctionInfo2))
                {
                    settingValue = ConvertToEnableOcr(deviceInfoExFuncXml, enableFuncXml, settingName);
                    settingValue.Name = settingName;
                }
                else
                {
                    throw new XmlException("not found elementName:" + documentElementNameExFunc);
                }
            }
            else
            {
                throw new XmlException("not found elementName:" + documentElementNameExFunc);
            }

            return settingValue;
        }

        /// <summary>
        /// IsLicenseCheck.
        /// </summary>
        /// <param name="enableFuncXml">Enable func xml</param> 
        /// <param name="settingName">Setting name</param>
        /// <returns>Response</returns>
        /// <exception cref="XmlException">Invalid response</exception>
        public bool IsLicenseCheck(XmlDocument enableFuncXml, string settingName)
        {
            // Enable func xml
            var root = enableFuncXml.SelectSingleNode(ConvertAdminSettingsConst.AppResGetEnableFunctionInfo2);

            // 1-based
            int bitNumber;
            switch (settingName) {
                case AdminSettingNamesConst.ScanPdfA:
                case AdminSettingNamesConst.ScanIsEnablePdfA:
                    bitNumber = (int)FuncCodes.PdfA;
                    break;

                case AdminSettingNamesConst.ScanLinearizedPdfg:
                case AdminSettingNamesConst.ScanIsEnableLinearizedPdf:
                    bitNumber = (int)FuncCodes.LinearizedPdf;
                    break;

                case AdminSettingNamesConst.ScanOcrLanguage:
                    bitNumber = (int)FuncCodes.SearchablePdf;
                    break;

                default:
                    bitNumber = -1;
                    break;
            }

            return IsEnableFuncBit(enableFuncXml, root, bitNumber);
        }

        /// <summary>
        /// ConvertToAdminSettingsForScanFileNameAddString
        /// </summary>
        /// <param name="deviceParmanentSettingScanxml">Device Parmanent Setting Scan xml</param>
        /// <param name="deviceXml">Device xml</param>
        /// <param name="settingName">Setting name</param>
        /// <returns>Response</returns>
        /// <exception cref="XmlException">Invalid response</exception>
        public SettingValue ConvertToAdminSettingsForScanFileNameAddString(XmlDocument deviceParmanentSettingScanxml, XmlDocument deviceXml, string settingName)
        {
            var settingValue = new SettingValue { Name = settingName, Success = false, Values = false };
            var documentElementName = deviceParmanentSettingScanxml.DocumentElement?.Name;

            if (documentElementName != null && documentElementName.Contains(ConvertAdminSettingsConst.AppResGetDevicePermanentSetting))
            {
                if (documentElementName.Contains(ConvertAdminSettingsConst.AppResGetDevicePermanentSetting))
                {
                    var root = deviceParmanentSettingScanxml.SelectSingleNode(ConvertAdminSettingsConst.AppResGetDevicePermanentSetting);

                    if (IsCheckXml(deviceParmanentSettingScanxml, root) && root != null)
                    {
                        // Get scan filename setting
                        var addStringNode = root.SelectSingleNode(ConvertAdminSettingsConst.ScanFileNameSetting);
                        var addSetting = addStringNode != null ? addStringNode.InnerText : string.Empty;

                        if (addSetting == "DeviceName")
                        {
                            var deviceName = ConvertToDevicePermanentSettingSystemForDeivceName(deviceXml);
                            settingValue.Values = deviceName;
                        }
                        else
                        {
                            // Get scan filename setting any string
                            var anyStringNode = root.SelectSingleNode(ConvertAdminSettingsConst.ScanFileNameSettingAnyString);
                            var anyString = anyStringNode != null ? anyStringNode.InnerText : string.Empty;
                            settingValue.Values = anyString;
                        }

                        settingValue.Success = true;
                    }
                }
                else
                {
                    throw new XmlException("not found elementName:" + deviceParmanentSettingScanxml);
                }
            }
            else
            {
                throw new XmlException("not found elementName:" + deviceParmanentSettingScanxml);
            }

            return settingValue;
        }

        /// <summary>
        /// Convert to device permanent setting system for device name.
        /// </summary>
        /// <param name="devicePermanentSettingSystemXml">Device permanent setting system xml</param>
        /// <returns>Device name</returns>
        /// <exception cref="XmlException">Invalid response</exception>
        public string ConvertToDevicePermanentSettingSystemForDeivceName(XmlDocument devicePermanentSettingSystemXml)
        {
            var documentElementName = devicePermanentSettingSystemXml.DocumentElement?.Name;

            if (documentElementName != null && documentElementName.Contains(ConvertAdminSettingsConst.AppResGetDevicePermanentSetting))
            {
                var root = devicePermanentSettingSystemXml.SelectSingleNode(ConvertAdminSettingsConst.AppResGetDevicePermanentSetting);

                if (IsCheckXml(devicePermanentSettingSystemXml, root) && root != null)
                {
                    // Get device name
                    var deviceName = root.SelectSingleNode(ConvertAdminSettingsConst.SystemDeviceNameAddrSettingName);
                    return deviceName != null ? deviceName.InnerText : string.Empty;
                }
            }
            else
            {
                throw new XmlException("not found elementName:" + devicePermanentSettingSystemXml);
            }

            return string.Empty;
        }

        /// <summary>
        /// Convert to device info detail system for serialNumber.
        /// </summary>
        /// <param name="deviceInfoDetailSystemXml">Device info detail system xml</param>
        /// <returns>Serial number</returns>
        /// <exception cref="XmlException">Invalid response</exception>
        public string ConvertToDeviceInfoDetailSystemForSerialNumber(XmlDocument deviceInfoDetailSystemXml)
        {
            var documentElementName = deviceInfoDetailSystemXml.DocumentElement?.Name;

            if (documentElementName != null && documentElementName.Contains(ConvertAdminSettingsConst.AppResGetDeviceInfoDetail))
            {
                if (documentElementName.Contains(ConvertAdminSettingsConst.AppResGetDeviceInfoDetail))
                {
                    var root = deviceInfoDetailSystemXml.SelectSingleNode(ConvertAdminSettingsConst.AppResGetDeviceInfoDetail);

                    if (IsCheckXml(deviceInfoDetailSystemXml, root) && root != null)
                    {
                        // Get serial number
                        var serialNumber = root.SelectSingleNode(ConvertAdminSettingsConst.SerialNo);
                        return serialNumber != null ? serialNumber.InnerText : string.Empty;
                    }
                }
                else
                {
                    throw new XmlException("not found elementName:" + deviceInfoDetailSystemXml);
                }
            }
            else
            {
                throw new XmlException("not found elementName:" + deviceInfoDetailSystemXml);
            }

            return string.Empty;
        }

        /// <summary>
        /// Is enable function bit
        /// </summary>
        /// <param name="enableFuncXml">Enable function xml</param>
        /// <param name="root">Xml node</param>
        /// <param name="checkBitNumber">Check bit number (1-based)</param>
        /// <returns>Result license true or false</returns>
        public bool IsEnableFuncBit(XmlDocument enableFuncXml, XmlNode root, int checkBitNumber)
        {
            if (IsCheckXml(enableFuncXml, root, false))
            {
                // Searchable pdf dictionary result
                var functionCode = root.SelectSingleNode(ConvertAdminSettingsConst.FunctionCode);
                var result = functionCode?.InnerText;

                try
                {
                    if (!string.IsNullOrWhiteSpace(result) && checkBitNumber >= 0)
                    {
                        // Sort lisence bit.
                        var reverseBit = result.ToCharArray();
                        Array.Reverse(reverseBit);

                        // Check bit result
                        if (reverseBit?[checkBitNumber - 1] == '1')
                        {
                            return true;
                        }
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogTrace(default(EventId), ex, $"Get failed enable func bit {checkBitNumber.ToString()}.");
                    throw;
                }
            }

            return false;
        }

        /// <summary>
        /// Convert to for settingname xml
        /// </summary>
        /// <param name="xml">Xml document</param>
        /// <param name="nameSpaceSetting">Name space setting</param>
        /// <param name="settingName">Setting name</param>
        /// <returns>Setting value</returns>
        private SettingValue ConvertToForSettingNameXml(XmlDocument xml, string nameSpaceSetting, string settingName)
        {
            var root = xml.SelectSingleNode(nameSpaceSetting);

            // Set check string
            var stringToBooleanList = new Dictionary<string, object>
            {
                { "On", true }, { "Off", false }
            };

            var checkStrToBooleanList = new Dictionary<string, object>
            {
                { "On", true }, { "Off", false }, { "Unidentified", false }
            };

            var receiveOnSettinsList = new List<string>
            {
                "ReceiveOn", "ReceiveOn2", "ReceiveOn3", "ReceiveOn3"
            };

            var detaProtectTypeList = new Dictionary<string, object>
            {
                { "NotProtect", "Off" }, { "PasswordProtect", "PASSWORD_DELETION" }, { "BoxAdminProtect", "ADMINISTRATOR_USER_BOX_DELETION" }, { "Unidentified", "OFF" }
            };
            
            var scanIsEnablePdfAtoBooleanList = new Dictionary<string, object>
            {
                { "Pdf_A_1a", true }, { "Pdf_A_1b", true }, { "Off", false }, { "Unidentified", false }
            };

            var mailSendEncryptionSettingList = new Dictionary<string, object>
            {
                { "UserSslTsl", "SSL" }, { "StartTls", "STARTTLS" }, { "Off", "DISABLE" }
            };

            var dic = new Dictionary<string, Func<SettingValue>>
            {
                { AdminSettingNamesConst.AuthColorManage, () => ConvertToForTargetNode(xml, root, ConvertAdminSettingsConst.ColorManage) },
                { AdminSettingNamesConst.AuthNoAuthPrintOn, () => ConvertToForTargetNode(xml, root, ConvertAdminSettingsConst.NoAuthPrintOn) },
                { AdminSettingNamesConst.AuthSendAddressLimit, () => ConvertToForTargetNode(xml, root, ConvertAdminSettingsConst.SendAddressLimit, checkStrToBooleanList) },
                { AdminSettingNamesConst.AuthAuthType, () => ConvertToForTargetNode(xml, root, ConvertAdminSettingsConst.AuthType) },
                { AdminSettingNamesConst.FaxDefaultSenders, () => ConvertToForFaxSenderName(xml, root, ConvertAdminSettingsConst.FaxSender) },
                { AdminSettingNamesConst.FaxDialType, () => ConvertToForTargetNode(xml, root, ConvertAdminSettingsConst.DialType) },
                { AdminSettingNamesConst.FaxReceiveOnSettings, () => ConvertToForTargetNodeList(xml, root, ConvertAdminSettingsConst.MemoryReceive, receiveOnSettinsList) },
                { AdminSettingNamesConst.FaxDataProtectType, () => ConvertToForTargetNode(xml, root, ConvertAdminSettingsConst.DataProtectType, detaProtectTypeList) },
                { AdminSettingNamesConst.FaxSendAuthPassword, () => ConvertToForTargetNode(xml, root, ConvertAdminSettingsConst.SendAuthPasswordEnable) },
                { AdminSettingNamesConst.SecuritySendProhibit, () => ConvertToForTargetNode(xml, root, ConvertAdminSettingsConst.SecuritySendProhibit, checkStrToBooleanList) },
                { AdminSettingNamesConst.SysConnPrefixSuffix, () => ConvertToForTargetNode(xml, root, ConvertAdminSettingsConst.PrefixSuffix) },
                { AdminSettingNamesConst.OplevelOriginalSizeAutoDetectByUser, () => ConvertToForTargetNode(xml, root, ConvertAdminSettingsConst.OriginalSizeAutoDetectByUser) },
                { AdminSettingNamesConst.IfaxIsEnable, () => ConvertToForTargetNode(xml, root, ConvertAdminSettingsConst.IfaxEnable, stringToBooleanList) },
                { AdminSettingNamesConst.ScanOcrLanguage, () => ConvertToForTargetNodeMulti(xml, root, ConvertAdminSettingsConst.SearchablePdfLanguageListLanguage) },
                { AdminSettingNamesConst.ScanPdfA, () => ConvertToForScanPdfA(xml, root, ConvertAdminSettingsConst.ScanPdfA) },
                { AdminSettingNamesConst.ScanLinearizedPdfg, () => ConvertToForTargetNode(xml, root, ConvertAdminSettingsConst.ScanLinearizedPdf, checkStrToBooleanList) },
                { AdminSettingNamesConst.ScanIsEnablePdfA, () => ConvertToForTargetNode(xml, root, ConvertAdminSettingsConst.ScanPdfA, scanIsEnablePdfAtoBooleanList) },
                { AdminSettingNamesConst.ScanIsEnableLinearizedPdf, () => ConvertToForTargetNode(xml, root, ConvertAdminSettingsConst.ScanLinearizedPdf, checkStrToBooleanList) },

                // { "Scan_FileNameAddString", () => ConvertToForTargetNode(xml, root, ScanLinearizedPdf, checkStrToBooleanList) },
                { AdminSettingNamesConst.ScanFunctionInitial, () => ConvertToForTargetNode(xml, root, ConvertAdminSettingsConst.ScanFileNameFunctionInitial) },
                { AdminSettingNamesConst.WinNwkIsEnable, () => ConvertToForTargetNode(xml, root, ConvertAdminSettingsConst.WinnetworkScanFunctionEnable, stringToBooleanList) },
                { AdminSettingNamesConst.MailSendAuth, () => ConvertToForMailSendAuth(xml, root, ConvertAdminSettingsConst.MailSend) },
                { AdminSettingNamesConst.MailSendBinaryDivisionSize, () => ConvertToForMailSendBinary(xml, root, ConvertAdminSettingsConst.MailSend) },
                { AdminSettingNamesConst.MailSendVerification, () => ConvertToForMailSendVerification(xml, root, ConvertAdminSettingsConst.MailSend) },
                { AdminSettingNamesConst.MailSendPopBeforeSmtp, () => ConvertToForMailSendPopBeforeSmtp(xml, root, ConvertAdminSettingsConst.MailSend) },
                { AdminSettingNamesConst.MailSendPortNo, () => ConvertToForTargetNode(xml, root, ConvertAdminSettingsConst.MailSendPortNo, convertInt: true) },
                { AdminSettingNamesConst.MailSendSslTslPortNo, () => ConvertToForTargetNode(xml, root, ConvertAdminSettingsConst.MailSendSslTslPortNo, convertInt: true) },
                { AdminSettingNamesConst.MailSendServerLimit, () => ConvertToForMailSendLimitSize(xml, root, ConvertAdminSettingsConst.MailSendServerLimitSize) },
                { AdminSettingNamesConst.MailSendServerAddress, () => ConvertToForTargetNode(xml, root, ConvertAdminSettingsConst.MailSendServerAddress) },
                { AdminSettingNamesConst.MailSendEncryptionSetting, () => ConvertToForTargetNode(xml, root, ConvertAdminSettingsConst.MailSendEncryptionSetting, mailSendEncryptionSettingList) },
                { AdminSettingNamesConst.MailSendTimeOut, () => ConvertToForTargetNode(xml, root, ConvertAdminSettingsConst.MailSendTimeOut, convertInt: true) },
                { AdminSettingNamesConst.MailSendIsEnable, () => ConvertToForTargetNode(xml, root, ConvertAdminSettingsConst.MailSendEnable, stringToBooleanList) },
                { AdminSettingNamesConst.MailSendStatusNotify, () => ConvertToForTargetNode(xml, root, ConvertAdminSettingsConst.MailSendStatusNotify, stringToBooleanList) },
                { AdminSettingNamesConst.MailSendScanSending, () => ConvertToForTargetNode(xml, root, ConvertAdminSettingsConst.MailSendScanSending, stringToBooleanList) },
                { AdminSettingNamesConst.MailSendTotalCounterNotify, () => ConvertToForTargetNode(xml, root, ConvertAdminSettingsConst.MailSendTotalCounterNotify, stringToBooleanList) }
            };

            var settingValue = new SettingValue { Name = settingName, Success = false, Values = null };
            if (dic.ContainsKey(settingName))
            {
                settingValue = dic[settingName]();
            }

            settingValue.Name = settingName;
            return settingValue;
        }

        /// <summary>
        /// Convert enable ocr
        /// </summary>
        /// <param name="deviceInfoExFuncXml">Device info exFunc xml</param>
        /// <param name="enableFuncXml">Enable func xml</param>
        /// <param name="settingName">Setting name</param>
        /// <returns>Setting value</returns>
        private SettingValue ConvertToEnableOcr(XmlDocument deviceInfoExFuncXml, XmlDocument enableFuncXml, string settingName)
        {
            var settingValue = new SettingValue { Name = settingName, Success = false, Values = null };

            // Enable ocr
            var enableOcrflg = true;

            // Device info xml
            var root = deviceInfoExFuncXml.SelectSingleNode(ConvertAdminSettingsConst.AppResGetDeviceInfo);
            if (!IsDeviceInfoExFuncSearchablePdf(deviceInfoExFuncXml, root))
            {
                enableOcrflg = false;
            }

            // Enable func xml
            root = enableFuncXml.SelectSingleNode(ConvertAdminSettingsConst.AppResGetEnableFunctionInfo2);

            if (!IsEnableFuncBit(enableFuncXml, root, (int)FuncCodes.SearchablePdf))
            {
                enableOcrflg = false;
            }

            settingValue.Success = true;
            settingValue.Values = enableOcrflg;

            return settingValue;
        }

        /// <summary>
        /// Is device info extention function serchable pdf
        /// </summary>
        /// <param name="deviceInfoExFuncXml">Device info extention function xml</param>
        /// <param name="root">Xml node</param>
        /// <returns>Result serchable pdf on/off</returns>
        private bool IsDeviceInfoExFuncSearchablePdf(XmlDocument deviceInfoExFuncXml, XmlNode root)
        {
            if (IsCheckXml(deviceInfoExFuncXml, root))
            {
                // Searchable pdf dictionary result
                var searchablePdfDictionary = root.SelectSingleNode(ConvertAdminSettingsConst.SearchablePdfDictionary);
                var result = searchablePdfDictionary?.InnerText;
                if (result == "On")
                {
                    return true;
                }
            }

            return false;
        }

        /// <summary>
        /// ConvertToForTargetNode
        /// </summary>
        /// <param name="xml">Enable function xml</param>
        /// <param name="root">Xml node</param>
        /// <param name="targetNodePath">Target node path</param>
        /// <param name="returnBoolCheckString">Return bool check string</param>
        /// <param name="convertInt">ConvertInt</param>
        /// <returns>Setting value</returns>
        private SettingValue ConvertToForTargetNode(XmlDocument xml, XmlNode root, string targetNodePath, Dictionary<string, object> returnBoolCheckString = null, bool convertInt = false)
        {
            var settingValue = new SettingValue { Name = string.Empty, Success = true, Values = false };

            if (IsCheckXml(xml, root))
            {
                var targetNode = root.SelectSingleNode(targetNodePath);
                var valueStr = targetNode?.InnerText;
                settingValue.Values = valueStr;

                if (returnBoolCheckString != null && valueStr != null)
                {
                    foreach (var checkKey in returnBoolCheckString.Keys)
                    {
                        if (checkKey == valueStr)
                        {
                            settingValue.Values = returnBoolCheckString[checkKey];
                            break;
                        }
                    }
                }

                if (string.IsNullOrEmpty(valueStr))
                {
                    // When targetNode?.InnerText is null
                    settingValue.Values = false;
                }

                if (convertInt && valueStr != null)
                {
                    if (int.TryParse(valueStr, out var value))
                    {
                        settingValue.Values = value;
                    }
                    else
                    {
                        _logger.LogWarning($"Value is not a integer. [Value = \"{valueStr}\"");
                        settingValue.Success = false;
                    }
                }
            }
            else
            {
                settingValue.Success = false;
            }

            return settingValue;
        }

        /// <summary>
        /// ConvertToForTargetNodeList
        /// </summary>
        /// <param name="xml">Enable function xml</param>
        /// <param name="root">Xml node</param>
        /// <param name="targetNodePath">Target node path</param>
        /// <param name="targetStringList">Target string list</param>
        /// <returns>Setting value</returns>
        private SettingValue ConvertToForTargetNodeList(XmlDocument xml, XmlNode root, string targetNodePath, List<string> targetStringList = null)
        {
            var settingValue = new SettingValue { Name = string.Empty, Success = true, Values = false };

            if (IsCheckXml(xml, root))
            {
                if (targetStringList != null)
                {
                    var valueList = new List<string>();
                    foreach (var targetString in targetStringList)
                    {
                        var path = string.Format("{0}/{1}", targetNodePath, targetString);
                        var targetNode = root.SelectSingleNode(path);
                        var target = targetNode?.InnerText;
                        if (!string.IsNullOrEmpty(target))
                        {
                            valueList.Add(target);
                        }
                    }

                    settingValue.Values = valueList;
                }
            }
            else
            {
                settingValue.Success = false;
            }

            return settingValue;
        }

        /// <summary>
        /// ConvertToForAuthPrintOn
        /// </summary>
        /// <param name="xml">Enable function xml</param>
        /// <param name="root">Xml node</param>
        /// <param name="targetNodePath">Target node path</param>
        /// <returns>Setting value</returns>
        private SettingValue ConvertToForTargetNodeMulti(XmlDocument xml, XmlNode root, string targetNodePath)
        {
            var settingValue = new SettingValue { Name = string.Empty, Success = true, Values = false };

            try
            {
                if (IsCheckXml(xml, root))
                {
                    var targetNodes = root.SelectNodes(targetNodePath);
                    if (targetNodes != null)
                    {
                        var listValue = new List<string>();
                        foreach (XmlNode node in targetNodes)
                        {
                            var value = node?.InnerText;
                            if (!string.IsNullOrWhiteSpace(value))
                            {
                                listValue.Add(value);
                            }
                        }
                        settingValue.Values = listValue;
                    }
                    else
                    {
                        settingValue.Success = false;
                    }
                }
                else
                {
                    settingValue.Success = false;
                }
            }
            catch (XPathException ex)
            {
                _logger.LogError("Target node path nothing:" + targetNodePath,ex);
                settingValue.Success = false;
            }

            return settingValue;
        }

        /// <summary>
        /// ConvertToForMailSendAuth
        /// </summary>
        /// <param name="xml">Enable function xml</param>
        /// <param name="root">Xml node</param>
        /// <param name="targetNodePath">Target node path</param>
        /// <returns>Setting value</returns>
        private SettingValue ConvertToForMailSendAuth(XmlDocument xml, XmlNode root, string targetNodePath)
        {
            var settingValue = new SettingValue { Name = string.Empty, Success = true, Values = false };
            var mailSendAuth = new MailSendAuth();

            if (IsCheckXml(xml, root))
            {
                var path = "/Authentication/Type";

                // Type
                var targetNode = root.SelectSingleNode(targetNodePath + path);
                var type = targetNode?.InnerText;
                mailSendAuth.Use = type == "SmtpAuthentication" || type == "Both";
                
                path = "/Authentication/SmtpAuthSetting";

                // User
                targetNode = root.SelectSingleNode(targetNodePath + path + "/User");
                mailSendAuth.UserId = targetNode.InnerText ?? string.Empty;

                // Password
                targetNode = root.SelectSingleNode(targetNodePath + path + "/Password");
                mailSendAuth.Password = targetNode.InnerText ?? string.Empty;

                // DomainName
                targetNode = root.SelectSingleNode(targetNodePath + path + "/Realm");
                mailSendAuth.DomainName = targetNode?.InnerText;

                // UseUserAuthentication
                targetNode = root.SelectSingleNode(targetNodePath + path + "/UseUserAuthentication");
                var authType = targetNode?.InnerText;
                mailSendAuth.Type = authType == "On" ? "USE_LOGIN_USER_AUTH"
                    : authType == "Off" ? "USE_SETTING_VALUE"
                    : authType == "Unidentified" ? "USE_SETTING_VALUE"
                    : null;

                var mailSendAuthSystemSetting = new MailSendAuthSystemSetting();
                path = "/Authentication/SmtpAuthSetting/AuthSystemSetting";

                // Kerberos
                targetNode = root.SelectSingleNode(targetNodePath + path + "/Kerberos");
                mailSendAuthSystemSetting.Kerberos = targetNode?.InnerText;

                // NtlmV1
                targetNode = root.SelectSingleNode(targetNodePath + path + "/Ntlm_v1");
                mailSendAuthSystemSetting.Ntlmv1 = targetNode?.InnerText;

                // DigestMd5
                targetNode = root.SelectSingleNode(targetNodePath + path + "/Digest_Md5");
                mailSendAuthSystemSetting.DigestMd5 = targetNode?.InnerText;

                // CramMd5
                targetNode = root.SelectSingleNode(targetNodePath + path + "/Cram_Md5");
                mailSendAuthSystemSetting.CramMd5 = targetNode?.InnerText;

                // Login
                targetNode = root.SelectSingleNode(targetNodePath + path + "/Login");
                mailSendAuthSystemSetting.Login = targetNode?.InnerText;

                // Plain
                targetNode = root.SelectSingleNode(targetNodePath + path + "/Plain");
                mailSendAuthSystemSetting.Plain = targetNode?.InnerText;

                // Add auth system setting
                mailSendAuth.Method = mailSendAuthSystemSetting;

                settingValue.Values = mailSendAuth;
            }
            else
            {
                settingValue.Success = false;
            }

            return settingValue;
        }

        /// <summary>
        /// ConvertToForMailSendBinary
        /// </summary>
        /// <param name="xml">Enable function xml</param>
        /// <param name="root">Xml node</param>
        /// <param name="targetNodePath">Target node path</param>
        /// <returns>Setting value</returns>
        private SettingValue ConvertToForMailSendBinary(XmlDocument xml, XmlNode root, string targetNodePath)
        {
            var settingValue = new SettingValue { Name = string.Empty, Success = true, Values = false };

            if (IsCheckXml(xml, root))
            {
                var path = "/BinaryDivision";

                // Type
                var targetNode = root.SelectSingleNode(targetNodePath + path + "/Enable");
                var enable = targetNode?.InnerText;

                if (enable == "false")
                {
                    settingValue.Values = 0;
                }
                else
                {
                    targetNode = root.SelectSingleNode(targetNodePath + path + "/DivisionSize");
                    var sizeStr = targetNode?.InnerText;
                    if (int.TryParse(sizeStr, out var size))
                    {
                        settingValue.Values = size;
                    }
                    else
                    {
                        _logger.LogWarning($"Size is not integer. [Value = \"{sizeStr}\"");
                    }
                }
            }
            else
            {
                settingValue.Success = false;
            }

            return settingValue;
        }

        /// <summary>
        /// ConvertToForMailSendLimitSize
        /// </summary>
        /// <param name="xml">Enable function xml</param>
        /// <param name="root">Xml node</param>
        /// <param name="targetNodePath">Target node path</param>
        /// <returns>Setting value</returns>
        private SettingValue ConvertToForMailSendLimitSize(XmlDocument xml, XmlNode root, string targetNodePath)
        {
            var settingValue = new SettingValue { Name = string.Empty, Success = true, Values = false };

            if (IsCheckXml(xml, root))
            {
                // Type
                var targetNode = root.SelectSingleNode(targetNodePath + "/Enable");
                var enable = targetNode?.InnerText;
                var limit = new MailSendServerLimit { Enable = false, LimitSize = 0 };

                if (enable == "true")
                {
                    limit.Enable = true;
                    targetNode = root.SelectSingleNode(targetNodePath + "/LimitSize");
                    var sizeStr = targetNode?.InnerText;
                    if (int.TryParse(sizeStr, out var size))
                    {
                        limit.LimitSize = size;
                    }
                    else
                    {
                        _logger.LogWarning($"Size is not integer. [Value = \"{sizeStr}\"]");
                    }
                }

                settingValue.Values = limit;
            }
            else
            {
                settingValue.Success = false;
            }

            return settingValue;
        }

        /// <summary>
        /// ConvertToForMailSendVerification
        /// </summary>
        /// <param name="xml">Enable function xml</param>
        /// <param name="root">Xml node</param>
        /// <param name="targetNodePath">Target node path</param>
        /// <returns>Setting value</returns>
        private SettingValue ConvertToForMailSendVerification(XmlDocument xml, XmlNode root, string targetNodePath)
        {
            var settingValue = new SettingValue { Name = string.Empty, Success = true, Values = false };
            var mailSendVerify = new MailSendVerificationResponse();

            if (IsCheckXml(xml, root))
            {
                var path = "/VerificationStrength";

                var targetNode = root.SelectSingleNode(targetNodePath + path + "/ExpirationDate");
                mailSendVerify.ExpirationDate = targetNode?.InnerText;

                targetNode = root.SelectSingleNode(targetNodePath + path + "/CN");
                mailSendVerify.CommonName = targetNode?.InnerText;

                targetNode = root.SelectSingleNode(targetNodePath + path + "/KeyDirections");
                mailSendVerify.KeyUsage = targetNode?.InnerText;

                targetNode = root.SelectSingleNode(targetNodePath + path + "/Chain");
                mailSendVerify.Chain = targetNode?.InnerText;

                targetNode = root.SelectSingleNode(targetNodePath + path + "/LapseConfirmation");
                mailSendVerify.ExpirationDateConfirmation = targetNode?.InnerText;

                // Add auth system setting
                settingValue.Values = mailSendVerify;
            }
            else
            {
                settingValue.Success = false;
            }

            return settingValue;
        }

        /// <summary>
        /// ConvertToForMailSendPopBeforeSmtp
        /// </summary>
        /// <param name="xml">Enable function xml</param>
        /// <param name="root">Xml node</param>
        /// <param name="targetNodePath">Target node path</param>
        /// <returns>Setting value</returns>
        private SettingValue ConvertToForMailSendPopBeforeSmtp(XmlDocument xml, XmlNode root, string targetNodePath)
        {
            var settingValue = new SettingValue { Name = string.Empty, Success = true, Values = false };
            var mailSendPopBeforeSmtp = new MailSendPopBeforeSmtp();

            if (IsCheckXml(xml, root))
            {
                var path = "/Authentication";

                // Type
                var targetNode = root.SelectSingleNode(targetNodePath + path + "/Type");
                var type = targetNode?.InnerText;
                mailSendPopBeforeSmtp.Use = type == "SmtpAuthentication" || type == "Both";

                // User
                targetNode = root.SelectSingleNode(targetNodePath + path + "/PopBeforeSmtpSetting");
                    
                var intervaltext = targetNode?.InnerText;
                if (int.TryParse(intervaltext, out var interval))
                {
                    mailSendPopBeforeSmtp.Interval = interval;
                }
                else
                {
                    _logger.LogWarning($"interval is not a figure. [Value = \"{intervaltext}\"");
                }

                // Add mail send pop before smtp
                settingValue.Values = mailSendPopBeforeSmtp;
            }
            else
            {
                settingValue.Success = false;
            }

            return settingValue;
        }

        /// <summary>
        /// ConvertToForFaxSenderName
        /// </summary>
        /// <param name="xml">Enable function xml</param>
        /// <param name="root">Xml node</param>
        /// <param name="targetNodePath">Target node path</param>
        /// <returns>Setting value</returns>
        private SettingValue ConvertToForFaxSenderName(XmlDocument xml, XmlNode root, string targetNodePath)
        {
            var settingValue = new SettingValue { Name = string.Empty, Success = true, Values = false };

            if (IsCheckXml(xml, root))
            {
                // Type
                var targetNode = root.SelectSingleNode(targetNodePath + "/Default");
                var defaultIndexValue = targetNode?.InnerText;

                if (!int.TryParse(defaultIndexValue, out var defaultIndex))
                {
                    _logger.LogWarning($"Default index value try parse error. [Value = \"{defaultIndexValue}\"]");
                    return settingValue;
                }

                // Select FaxSenderInfoList
                targetNode = root.SelectSingleNode(targetNodePath + "/FaxSenderInfoList");

                if (targetNode == null)
                {
                    return settingValue;
                }

                // Load xml
                FaxSenderInfoList faxSenderInfoList;
                var serializer = new XmlSerializer(typeof(FaxSenderInfoList));
                using (var ms = new MemoryStream(Encoding.UTF8.GetBytes(targetNode.OuterXml)))
                {
                    using (var reader = XmlReader.Create(ms))
                    {
                        faxSenderInfoList = (FaxSenderInfoList)serializer.Deserialize(reader);
                    }
                }

                // Search for index name
                foreach (var info in faxSenderInfoList.FaxSenderInfos)
                {
                    if (info.Index == defaultIndex && info.Entry)
                    {
                        settingValue.Values = info.Name;
                        break;
                    }
                }
            }

            return settingValue;
        }

        /// <summary>
        /// Is check xml
        /// </summary>
        /// <param name="xml">Xml</param>
        /// <param name="root">Xml node</param>
        /// <param name="isRequestItemCheck">IsRequestItemCheck</param>
        /// <returns>Result</returns>
        private bool IsCheckXml(XmlDocument xml, XmlNode root, bool isRequestItemCheck = true)
        {
            if (root == null)
            {
                _logger.LogWarning(xml.OuterXml);

                throw new XmlException($"not found namespace: {_oapNamespace}");
            }

            // check result
            var result = root.SelectSingleNode(ConvertAdminSettingsConst.Result);
            if (result == null)
            {
                throw new XmlException("not found Result");
            }

            if (result.InnerText != ResponseStatus.Ack.ToString())
            {
                throw new XmlException("Result is not Ack");
            }

            if (isRequestItemCheck)
            {
                // check request
                var request = root.SelectSingleNode(ConvertAdminSettingsConst.RequestItem);
                if (request == null)
                {
                    throw new XmlException("not found RequestItem");
                }

            }

            return true;
        }

        /// <summary>
        /// Convert to setting value for ScanPdfA.
        /// </summary>
        /// <param name="xml">Enable function xml</param>
        /// <param name="root">Xml node</param>
        /// <param name="targetNodePath">Target node path</param>
        /// <returns>Setting value</returns>
        private SettingValue ConvertToForScanPdfA(XmlDocument xml, XmlNode root, string targetNodePath)
        {
            // Todo Use a constant instead of hardcoded Unidentified and scan pdf a (few lines after)
            var settingValue = new SettingValue { Name = AdminSettingNamesConst.ScanPdfA, Success = true, Values = "Unidentified" };

            if (!IsCheckXml(xml, root))
            {
                settingValue.Success = false;
                return settingValue;
            }

            var path = "/Scan/Pdf_A";

            // Type
            var targetNode = root.SelectSingleNode(targetNodePath + path);
            var type = targetNode?.InnerText;
            if (!string.IsNullOrEmpty(type))
            {
                settingValue.Values = type;
            }

            return settingValue;
        }
    }
}
