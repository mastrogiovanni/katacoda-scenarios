using System.Xml;
using ServiceHub.Processors.Settings.Model;

namespace ServiceHub.Processors.Settings
{
    /// <summary>
    /// Convert admin settings
    /// </summary>
    public interface IConvertAdminSettings
    {
        /// <summary>
        /// Convert xml to model.
        /// </summary>
        /// <param name="xml">Xml</param>
        /// <param name="settingName">Setting name</param>
        /// <returns>Response</returns>
        /// <exception cref="XmlException">Invalid response</exception>
        SettingValue ConvertToAdminSettings(XmlDocument xml, string settingName);

        /// <summary>
        /// ConvertToAdminSettingsForEnableOcrScan.
        /// </summary>
        /// <param name="deviceInfoExFuncXml">Device info ex func xml</param>
        /// <param name="enableFuncXml">Enable func xml</param> 
        /// <param name="settingName">Setting name</param>
        /// <returns>Response</returns>
        /// <exception cref="XmlException">Invalid response</exception>
        SettingValue ConvertToAdminSettingsForEnableOcrScan(XmlDocument deviceInfoExFuncXml, XmlDocument enableFuncXml,
            string settingName);

        /// <summary>
        /// IsLicenseCheck.
        /// </summary>
        /// <param name="enableFuncXml">Enable func xml</param> 
        /// <param name="settingName">Setting name</param>
        /// <returns>Response</returns>
        /// <exception cref="XmlException">Invalid response</exception>
        bool IsLicenseCheck(XmlDocument enableFuncXml, string settingName);

        /// <summary>
        /// ConvertToAdminSettingsForScanFileNameAddString
        /// </summary>
        /// <param name="deviceParmanentSettingScanxml">Device Parmanent Setting Scan xml</param>
        /// <param name="deviceXml">Device xml</param>
        /// <param name="settingName">Setting name</param>
        /// <returns>Response</returns>
        /// <exception cref="XmlException">Invalid response</exception>
        SettingValue ConvertToAdminSettingsForScanFileNameAddString(XmlDocument deviceParmanentSettingScanxml,
            XmlDocument deviceXml, string settingName);

        /// <summary>
        /// Convert to device permanent setting system for device name.
        /// </summary>
        /// <param name="devicePermanentSettingSystemXml">Device permanent setting system xml</param>
        /// <returns>Device name</returns>
        /// <exception cref="XmlException">Invalid response</exception>
        string ConvertToDevicePermanentSettingSystemForDeivceName(XmlDocument devicePermanentSettingSystemXml);

        /// <summary>
        /// Convert to device info detail system for serialNumber.
        /// </summary>
        /// <param name="deviceInfoDetailSystemXml">Device info detail system xml</param>
        /// <returns>Serial number</returns>
        /// <exception cref="XmlException">Invalid response</exception>
        string ConvertToDeviceInfoDetailSystemForSerialNumber(XmlDocument deviceInfoDetailSystemXml);

        /// <summary>
        /// Is enable function bit
        /// </summary>
        /// <param name="enableFuncXml">Enable function xml</param>
        /// <param name="root">Xml node</param>
        /// <param name="checkBitNumber">Check bit number (1-based)</param>
        /// <returns>Result license true or false</returns>
        bool IsEnableFuncBit(XmlDocument enableFuncXml, XmlNode root, int checkBitNumber);
    }
}
