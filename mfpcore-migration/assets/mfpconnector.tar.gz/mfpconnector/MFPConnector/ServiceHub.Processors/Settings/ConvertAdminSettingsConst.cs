namespace ServiceHub.Processors.Settings
{
    /// <summary>
    /// ConvertAdminSettingsConst
    /// </summary>
    public static class ConvertAdminSettingsConst
    {
        /// <summary>
        /// AppResGetDevicePermanentSetting
        /// </summary>
        public static readonly string AppResGetDevicePermanentSetting = "AppResGetDevicePermanentSetting";

        /// <summary>
        /// AppResGetDeviceDetailSetting
        /// </summary>
        public static readonly string AppResGetDeviceInfoDetail = "AppResGetDeviceInfoDetail";

        /// <summary>
        /// AppResGetDeviceDetailSetting
        /// </summary>
        public static readonly string AppResGetDeviceInfo = "AppResGetDeviceInfo";

        /// <summary>
        /// AppResGetDeviceDetailSetting
        /// </summary>
        public static readonly string AppResGetEnableFunctionInfo2 = "AppResGetEnableFunctionInfo2";

        /// <summary>
        /// Result
        /// </summary>
        public static readonly string Result = "./Result";

        /// <summary>
        /// RequestItem
        /// </summary>
        public static readonly string RequestItem = "./RequestItem";

        /// <summary>
        /// ColorManage
        /// </summary>
        public static readonly string ColorManage = "./AuthSetting/UserAndTrack/ColorManage";

        /// <summary>
        /// NoAuthPrintOn
        /// </summary>
        public static readonly string NoAuthPrintOn = "./AuthSetting/CommonMode/NoAuthPrintOn";

        /// <summary>
        /// SendAddressLimit
        /// </summary>
        public static readonly string SendAddressLimit = "./AuthSetting/AuthMode/SendAddressLimit";

        /// <summary>
        /// AuthType
        /// </summary>
        public static readonly string AuthType = "./AuthSetting/AuthMode/AuthType";

        /// <summary>
        /// FaxSender
        /// </summary>
        public static readonly string FaxSender = "./Fax/FaxSender";

        /// <summary>
        /// DialType
        /// </summary>
        public static readonly string DialType = "./Fax/CircuitParameter/DialType";

        /// <summary>
        /// MemoryReceive
        /// </summary>
        public static readonly string MemoryReceive = "./Fax/MemoryReceive";

        /// <summary>
        /// DataProtectType
        /// </summary>
        public static readonly string DataProtectType = "./Fax/ReceiveDataProtectSetting/DataProtectType";

        /// <summary>
        /// SendAuthPasswordEnable
        /// </summary>
        public static readonly string SendAuthPasswordEnable = "./Fax/Function/SendAuthPassword/Enable"; //NOSONAR

        /// <summary>
        /// SecuritySendProhibit
        /// </summary>
        public static readonly string SecuritySendProhibit = "./Security/FaxSendProhibit";

        /// <summary>
        /// PrefixSuffix
        /// </summary>
        public static readonly string PrefixSuffix = "./SystemConnection/PrefixSuffix";

        /// <summary>
        /// OriginalSizeAutoDetectByUser
        /// </summary>
        public static readonly string OriginalSizeAutoDetectByUser = "./OperationLevel/OriginalSizeAutoDetectByUser";

        /// <summary>
        /// IfaxEnable
        /// </summary>
        public static readonly string IfaxEnable = "./Ifax/Enable";

        /// <summary>
        /// ScanPdfA
        /// </summary>
        public static readonly string ScanPdfA = "./Scan/Pdf_A";

        /// <summary>
        /// ScanLinearizedPdf
        /// </summary>
        public static readonly string ScanLinearizedPdf = "./Scan/LinearizedPdf";

        /// <summary>
        /// ScanFileNameFunctionInitial
        /// </summary>
        public static readonly string ScanFileNameFunctionInitial = "./Scan/ScanFileNameSetting/FunctionInitial";

        /// <summary>
        /// WinnetworkScanFunctionEnable
        /// </summary>
        public static readonly string WinnetworkScanFunctionEnable = "./WindowsNetwork/ScanFunction/Enable";

        /// <summary>
        /// SearchablePdfLanguageListLanguage
        /// </summary>
        public static readonly string SearchablePdfLanguageListLanguage = "./Scan/SearchablePdfLanguageList/SearchablePdfLanguage/Language";

        /// <summary>
        /// MailSend
        /// </summary>
        public static readonly string MailSend = "./MailSend";

        /// <summary>
        /// MailSendPortNo
        /// </summary>
        public static readonly string MailSendPortNo = "./MailSend/PortNo";

        /// <summary>
        /// MailSendSslTslPortNo
        /// </summary>
        public static readonly string MailSendSslTslPortNo = "./MailSend/SslTslPortNo";

        /// <summary>
        /// MailSendServerLimitSize
        /// </summary>
        public static readonly string MailSendServerLimitSize = "./MailSend/ServerLimit";

        /// <summary>
        /// MailSendServerAddress
        /// </summary>
        public static readonly string MailSendServerAddress = "./MailSend/ServerAddress";

        /// <summary>
        /// MailSendEncryptionSetting
        /// </summary>
        public static readonly string MailSendEncryptionSetting = "./MailSend/EncryptionSetting";

        /// <summary>
        /// MailSendTimeOut
        /// </summary>
        public static readonly string MailSendTimeOut = "./MailSend/TimeOut";

        /// <summary>
        /// MailSendEnable
        /// </summary>
        public static readonly string MailSendEnable = "./MailSend/Enable";

        /// <summary>
        /// MailSendStatusNotify
        /// </summary>
        public static readonly string MailSendStatusNotify = "./MailSend/StatusNotify";

        /// <summary>
        /// MailSendScanSending
        /// </summary>
        public static readonly string MailSendScanSending = "./MailSend/ScanSending";

        /// <summary>
        /// MailSendTotalCounterNotify
        /// </summary>
        public static readonly string MailSendTotalCounterNotify = "./MailSend/TotalCounterNotify";

        /// <summary>
        /// SerialNumber
        /// </summary>
        public static readonly string SerialNo = "./System/SerialNumber";

        /// <summary>
        /// ScanFileNameSetting
        /// </summary>
        public static readonly string ScanFileNameSetting = "./Scan/ScanFileNameSetting/AddString";

        /// <summary>
        /// ScanFileNameSettingAnyString
        /// </summary>
        public static readonly string ScanFileNameSettingAnyString = "./Scan/ScanFileNameSetting/AnyString";

        /// <summary>
        /// SystemDeviceNameAddrSettingName
        /// </summary>
        public static readonly string SystemDeviceNameAddrSettingName = "./System/DeviceNameAddrSetting/Name";

        /// <summary>
        /// Serchable pdf dictionary
        /// </summary>
        public static readonly string SearchablePdfDictionary = "./ExtensionFunction/SearchablePdfDictionary";

        /// <summary>
        /// Function bit status 
        /// </summary>
        public static readonly string FunctionCode = "./FunctionBitStatus/FunctionCode";
    }
}
