using Newtonsoft.Json;

namespace ServiceHub.Processors.Settings.Model
{
    /// <summary>
    /// Mail send auth response
    /// </summary>
    public class MailSendServerLimit
    {
        /// <summary>
        /// Mail send auth use
        /// </summary>
        [JsonProperty(PropertyName = "Enable")]
        public bool Enable { get; set; }

        /// <summary>
        /// Mail send auth interval
        /// </summary>
        [JsonProperty(PropertyName = "LimitSize")]
        public int LimitSize { get; set; }
    }
}
