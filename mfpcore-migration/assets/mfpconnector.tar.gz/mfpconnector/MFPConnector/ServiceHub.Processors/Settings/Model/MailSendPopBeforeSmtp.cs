using Newtonsoft.Json;

namespace ServiceHub.Processors.Settings.Model
{
    /// <summary>
    /// Mail send auth response
    /// </summary>
    public class MailSendPopBeforeSmtp
    {
        /// <summary>
        /// Mail send auth use
        /// </summary>
        [JsonProperty(PropertyName = "use")]
        public bool Use { get; set; }

        /// <summary>
        /// Mail send auth interval
        /// </summary>
        [JsonProperty(PropertyName = "interval")]
        public int Interval { get; set; }
    }
}
