using System.Collections.Generic;
using Newtonsoft.Json;

namespace ServiceHub.Processors.Settings.Model
{
    /// <summary>
    /// IWS Job request body
    /// </summary>
    public class AdminSettingsRequest
    {
        /// <summary>
        /// Admin settings names
        /// </summary>
        [JsonProperty(PropertyName = "setting_names", Required = Required.DisallowNull)]
        public List<string> SettingsNames { get; set; }
    }
}
