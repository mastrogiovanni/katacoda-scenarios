using Newtonsoft.Json;

namespace ServiceHub.Processors.Settings.Model
{
    /// <summary>
    /// Mail send auth system setting
    /// </summary>
    public class MailSendAuthSystemSetting
    {
        /// <summary>
        /// Kerberos
        /// </summary>
        [JsonProperty(PropertyName = "kerberos")]
        public string Kerberos { get; set; }

        /// <summary>
        /// Ntlmv1
        /// </summary>
        [JsonProperty(PropertyName = "ntlmv1")]
        public string Ntlmv1 { get; set; }

        /// <summary>
        /// Digest md5
        /// </summary>
        [JsonProperty(PropertyName = "digest_md5")]
        public string DigestMd5 { get; set; }

        /// <summary>
        /// Cram md5
        /// </summary>
        [JsonProperty(PropertyName = "cram_md5")]
        public string CramMd5 { get; set; }

        /// <summary>
        /// Cram_md5
        /// </summary>
        [JsonProperty(PropertyName = "login")]
        public string Login { get; set; }

        /// <summary>
        /// Plain
        /// </summary>
        [JsonProperty(PropertyName = "plain")]
        public string Plain { get; set; }
    }
}
