using System.Collections.Generic;
using System.Xml.Serialization;

namespace ServiceHub.Processors.Settings.Model
{
    /// <summary>
    /// FaxSenderInfoList
    /// </summary>
    [XmlRoot("FaxSenderInfoList")]
    public class FaxSenderInfoList
    {
        /// <summary>
        /// Array size
        /// </summary>
        [XmlElement("ArraySize")]
        public int ArraySize { get; set; }

        /// <summary>
        /// Fax sender info list
        /// </summary>
        [XmlElement("FaxSenderInfo")]
        public List<FaxSenderInfo> FaxSenderInfos { get; set; }
    }
}
