using System.Xml.Serialization;

namespace ServiceHub.Processors.Settings.Model
{
    /// <summary>
    /// FaxSenderInfo
    /// </summary>
    [XmlRoot("FaxSenderInfo")]
    public class FaxSenderInfo
    {
        /// <summary>
        /// Index
        /// </summary>
        [XmlElement("Index")]
        public int Index { get; set; }

        /// <summary>
        /// Entry
        /// </summary>
        [XmlElement("Entry")]
        public bool Entry { get; set; }

        /// <summary>
        /// Entry
        /// </summary>
        [XmlElement("Name")]
        public string Name { get; set; }
    }
}
