using Newtonsoft.Json;

namespace ServiceHub.Processors.Settings.Model
{
    /// <summary>
    /// Mail send verification response
    /// </summary>
    public class MailSendVerificationResponse
    {
        /// <summary>
        /// Mail send verification expiration_date
        /// </summary>
        [JsonProperty(PropertyName = "expiration_date")]
        public string ExpirationDate { get; set; }

        /// <summary>
        /// Mail send verification cn
        /// </summary>
        [JsonProperty(PropertyName = "cn")]
        public string CommonName { get; set; }

        /// <summary>
        /// Mail send verification key_usage
        /// </summary>
        [JsonProperty(PropertyName = "key_usage")]
        public string KeyUsage { get; set; }

        /// <summary>
        /// Mail send verification chain
        /// </summary>
        [JsonProperty(PropertyName = "chain")]
        public string Chain { get; set; }

        /// <summary>
        /// Mail send verification expiration_date_confirmation
        /// </summary>
        [JsonProperty(PropertyName = "expiration_date_confirmation")]
        public string ExpirationDateConfirmation { get; set; }
    }
}
