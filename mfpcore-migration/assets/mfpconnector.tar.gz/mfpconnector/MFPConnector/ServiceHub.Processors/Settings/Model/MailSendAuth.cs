using Newtonsoft.Json;

namespace ServiceHub.Processors.Settings.Model
{
    /// <summary>
    /// Mail send auth response
    /// </summary>
    public class MailSendAuth
    {
        /// <summary>
        /// Mail send auth use
        /// </summary>
        [JsonProperty(PropertyName = "use")]
        public bool Use { get; set; }

        /// <summary>
        /// Mail send auth user_id
        /// </summary>
        [JsonProperty(PropertyName = "user_id")]
        public string UserId { get; set; }

        /// <summary>
        /// Mail send auth password
        /// </summary>
        [JsonProperty(PropertyName = "password")]
        public string Password { get; set; }

        /// <summary>
        /// Mail send auth domain_name
        /// </summary>
        [JsonProperty(PropertyName = "domain_name")]
        public string DomainName { get; set; }

        /// <summary>
        /// Mail send auth type
        /// </summary>
        [JsonProperty(PropertyName = "type")]
        public string Type { get; set; }

        /// <summary>
        /// Mail send auth method
        /// </summary>
        [JsonProperty(PropertyName = "method")]
        public MailSendAuthSystemSetting Method { get; set; }
    }
}
