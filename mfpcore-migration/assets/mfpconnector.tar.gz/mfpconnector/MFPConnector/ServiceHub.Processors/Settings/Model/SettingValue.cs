using Newtonsoft.Json;

namespace ServiceHub.Processors.Settings.Model
{
    /// <summary>
    /// Setting values
    /// </summary>
    public class SettingValue
    {
        /// <summary>
        /// Success
        /// </summary>
        [JsonProperty(PropertyName = "success")]
        public bool Success { get; set; }

        /// <summary>
        /// Name
        /// </summary>
        [JsonProperty(PropertyName = "name")]
        public string Name { get; set; }

        /// <summary>
        /// Values
        /// </summary>
        [JsonProperty(PropertyName = "value")]
        public object Values { get; set; }
    }
}
