using ServiceHub.Connectors.OpenAPI.Model;

namespace ServiceHub.Processors.Settings.Model
{
    /// <summary>
    /// AppResSetSHIPAddress
    /// </summary>
    public class AppResSetSHIPAddress : AppResBase
    {
        public AppResSetSHIPAddress()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="AppResSetSHIPAddress"/> class.
        /// </summary>
        /// <param name="resultInfo">The result information.</param>
        /// <param name="status">The status.</param>
        public AppResSetSHIPAddress(string resultInfo, string status)
        {
            Result = new OpenApiResult(resultInfo);
            Status = status;
        }

        /// <summary>
        /// Status (original parameter used by <see cref="Connectors.OpenAPI.OpenApiController"/>.
        /// </summary>
        public string Status { get; set; }
    }
}
