using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Xml;
using Microsoft.Extensions.Logging;
using ServiceHub.Connectors.OpenAPI;
using ServiceHub.Connectors.OpenAPI.Model;
using ServiceHub.Processors.Settings.Model;

namespace ServiceHub.Processors.Settings
{
    /// <summary>
    /// Admin settings operator
    /// </summary>
    public class AdminSettingsOperator : OpenApiOperatable, ISettingsOperator
    {
        // Todo Refactor use an enum instead.
        private const string DicKeyPermanentAuth = "PermanentAuth";
        private const string DicKeyPermanentScan = "PermanentScan";
        private const string DicKeyPermanentFax = "PermanentFax";
        private const string DicKeyPermanentIfax = "PermanentIfax";
        private const string DicKeyPermanentOplevel = "PermanentOplevel";
        private const string DicKeyPermanentSecurity = "PermanentSecurity";
        private const string DicKeyPermanentSystem = "PermanentSystem";
        private const string DicKeyDetailSystemConnection = "DetailSystemConnection";
        private const string DicKeyDetailWindowsNetwork = "DetailWindowsNetwork";
        private const string DicKeyUbiquitous = "Ubiquitous";
        private const string DicKeyUser = "User";
        private const string DicKeyDetailMailSend = "DetailMailSend";
        private const string DicKeyDeviceInfoExFunc = "DeviceInfoExFunc";
        private const string DicKeyEnableFunctionInfo2 = "EnableFunctionInfo2";
        private const string PrefixNameAuth = "Auth";
        private const string PrefixNameScan = "Scan";
        private const string PrefixNameFax = "Fax";
        private const string PrefixNameIfax = "IFax";
        private const string PrefixNameOplevel = "Oplevel";
        private const string PrefixNameSecurity = "Security";
        private const string PrefixNameSystemConnection = "SysConn";
        private const string PrefixNameWinNwk = "WinNwk";
        private const string PrefixNameUbiquitous = "Ubiquitous";
        private const string PrefixNameUser = "User";
        private const string PrefixNameMailSend = "MailSend";
        private const string PrefixNameDeviceInfoSystem = "System";
        private const string PrefixNameDeviceInfoExFunc = "DeviceInfoExFunc";
        private const string PrefixNameEnableFunc = "EnableFunc";
        private const char PrefixUnderber = '_';
        private const string AppResSetResultInfo = "./Result/ResultInfo";
        private const string AppResSetStatus = "./Status";

        private readonly ILogger<AdminSettingsOperator> _logger;
        private readonly IConvertAdminSettings _convertAdminSettings;

        private Dictionary<string, XmlDocument> _adminSettingsXml;

        /// <summary>
        /// Initializes a new instance of the <see cref="AdminSettingsOperator"/> class.  
        /// </summary>
        /// <param name="convertAdminSettings">ConvertAdminSettings</param>
        /// <param name="logger">Logger</param>
        /// <param name="openApiRequestSettings">OpenApiRequestSettings</param>
        /// <param name="controller">IOpenApiController</param>
        public AdminSettingsOperator(
            OpenApiRequestSettings openApiRequestSettings,
            IOpenApiController controller,
            IConvertAdminSettings convertAdminSettings,
            ILogger<AdminSettingsOperator> logger)
            : base(openApiRequestSettings, controller)
        {
            _logger = logger;
            _convertAdminSettings = convertAdminSettings;
        }

        /// <summary>
        /// Obtain settings
        /// </summary>
        /// <param name="requestItemList">Request item list</param>
        /// <returns>
        /// Json string
        /// </returns>
        public async Task<List<SettingValue>> ObtainAdminSettingsAsync(List<string> requestItemList)
        {
            var result = new List<SettingValue>();
            _adminSettingsXml = new Dictionary<string, XmlDocument>();

            try
            {
                foreach (var settingName in requestItemList)
                {
                    var settingValue = new SettingValue { Name = settingName, Success = false, Values = null };
                    settingValue.Name = settingName;

                    try
                    {
                        var fixSettings = await SpecificFixSettingNameAsync(settingName, settingValue)
                            .ConfigureAwait(false);

                        if (fixSettings.Success)
                        {
                            result.Add(fixSettings.SettingValue);
                            continue;
                        }

                        settingValue = fixSettings.SettingValue;
                        fixSettings = await LicenseCheckSettingName(settingName, settingValue).ConfigureAwait(false);
                        if (fixSettings.Success)
                        {
                            result.Add(fixSettings.SettingValue);
                            continue;
                        }

                        settingValue = fixSettings.SettingValue;

                        var dickey = GetRequestItemDicKey(settingName);

                        // Get keep xml
                        var xml = GetKeepSettingsXml(dickey);

                        // Null check
                        if (xml == null)
                        {
                            xml = await GetDeviceSettingsAsync(settingName);
                            _adminSettingsXml.Add(dickey, xml);
                        }

                        if (settingName == AdminSettingNamesConst.ScanFileNameAddString)
                        {
                            dickey = GetRequestItemDicKey(settingName);

                            // Get keep xml
                            var deviceXml = GetKeepSettingsXml(dickey);

                            // Null check
                            if (deviceXml == null)
                            {
                                deviceXml = await GetDeviceSettingsAsync(settingName);
                                _adminSettingsXml.Add(dickey, deviceXml);
                            }

                            // Convert to addmin settings for deviceName "Scan_FileNameAddString"
                            settingValue = _convertAdminSettings.ConvertToAdminSettingsForScanFileNameAddString(xml, deviceXml, settingName);
                        }
                        else
                        {
                            // Convert to admin settings
                            settingValue = _convertAdminSettings.ConvertToAdminSettings(xml, settingName);
                        }
                    }
                    catch (Exception ex)
                    {
                        _logger.LogTrace(default(EventId), ex, $"{settingName}: Unable able to get the value");
                        settingValue.Success = false;
                        settingValue.Values = null;
                    }

                    // Add setting values
                    result.Add(settingValue);
                }
            }
            catch (XmlException ex)
            {
                _logger.LogTrace(default(EventId), ex, "Exception occurred.");
                result = new List<SettingValue>();
            }

            return result;
        }

        /// <summary>
        /// Notify Device Network Setting.
        /// </summary>
        /// <param name="addressType">Ip address type.</param>
        /// <param name="address">Ip address.</param>
        /// <param name="ipv6Type">Ip v6 type.</param>
        /// <returns>Success/Fail</returns>
        public async Task<AppResSetSHIPAddress> NotifyDeviceNetworkSettingAsync(
            IpAddressType addressType,
            string address,
            Ipv6Type? ipv6Type)
        {
            try
            {
                await OpenApiController.EnterDeviceLockAsync();
                XmlDocument result;
                try
                {
                    result = await OpenApiController.NotifyDeviceNetworkSettingAsync(addressType, address, ipv6Type);
                }
                finally
                {
                    await OpenApiController.ExitDeviceLockAsync();
                }

                var nodeList = result.GetElementsByTagName(AdminSettingNamesConst.AppResSetSHIPAddress);
                if (nodeList.Count == 0)
                {
                    return new AppResSetSHIPAddress(ResponseStatus.Nack.ToString(), OpenApiNamesConst.StatusServerError);
                }

                var xmlName = (XmlElement)nodeList.Item(0);
                var resultInfo = xmlName?.SelectSingleNode(AppResSetResultInfo)?.InnerText;
                var status = xmlName?.SelectSingleNode(AppResSetStatus)?.InnerText;
                if (resultInfo != ResponseStatus.Ack.ToString())
                {
                    status = status ?? OpenApiNamesConst.StatusBadRequest;
                }

                return new AppResSetSHIPAddress(resultInfo, status);
            }
            catch (Exception e)
            {
                _logger.LogTrace(default(EventId), e, "NotifyDeviceNetworkSetting failed.");
                return new AppResSetSHIPAddress(ResponseStatus.Nack.ToString(), OpenApiNamesConst.StatusServerError);
            }
        }

        /// <summary>
        /// Get device settings with openpi
        /// </summary>
        /// <param name="settingName">Setting name</param>
        /// <param name="serialNumber">Serial number</param>
        /// <returns>Xml document</returns>
        private async Task<XmlDocument> GetDeviceSettingsAsync(string settingName, string serialNumber = "")
        {
            var reqItem = GetRequestItemName(settingName);

            var dic = new Dictionary<string, Func<Task<XmlDocument>>>
            {
                { PrefixNameAuth, () => OpenApiController.GetDevicePermanentSettingsAsync(PermanentSettingsRequestItems.Authentication) },
                { PrefixNameScan, () => OpenApiController.GetDevicePermanentSettingsAsync(PermanentSettingsRequestItems.Scan) },
                { PrefixNameFax, () => OpenApiController.GetDevicePermanentSettingsAsync(PermanentSettingsRequestItems.Fax) },
                { PrefixNameIfax, () => OpenApiController.GetDevicePermanentSettingsAsync(PermanentSettingsRequestItems.Ifax) },
                { PrefixNameOplevel, () => OpenApiController.GetDevicePermanentSettingsAsync(PermanentSettingsRequestItems.OperationLevel) },
                { PrefixNameSecurity, () => OpenApiController.GetDevicePermanentSettingsAsync(PermanentSettingsRequestItems.Security) },
                { PrefixNameSystemConnection, () => OpenApiController.GetDeviceInfoDetailAsync(DetailSettingsRequestItems.SystemConnection) },
                { PrefixNameWinNwk, () => OpenApiController.GetDeviceInfoDetailAsync(DetailSettingsRequestItems.WindowsNetwork) },
                { PrefixNameMailSend, () => OpenApiController.GetDeviceInfoDetailAsync(DetailSettingsRequestItems.MailSend) },
                { PrefixNameDeviceInfoExFunc, () => OpenApiController.GetDeviceInfoAsync(GetDeviceInfoRequestItems.ExtensionFunction) },
                { PrefixNameDeviceInfoSystem, () => OpenApiController.GetDeviceInfoDetailAsync(DetailSettingsRequestItems.System) },
                { PrefixNameEnableFunc, () => OpenApiController.GetDeviceEnableFunctionInfo2Async(serialNumber) }
            };

            if (!dic.ContainsKey(reqItem))
            {
                throw new Exception("Prefix does not exist.");
            }

            return await dic[reqItem]();
        }

        /// <summary>
        /// Get request item name
        /// </summary>
        /// <param name="settingName">Setting name</param>
        /// <returns>Prefix name</returns>
        private string GetRequestItemName(string settingName)
        {
            return !string.IsNullOrWhiteSpace(settingName) ? settingName.Split(PrefixUnderber)[0] : string.Empty;
        }

        /// <summary>
        /// Get request item dic key
        /// </summary>
        /// <param name="settingName">Setting name</param>
        /// <returns>Dictionary key</returns>
        private string GetRequestItemDicKey(string settingName)
        {
            if (settingName == AdminSettingNamesConst.ScanisEnableOcr)
            {
                return DicKeyDeviceInfoExFunc;
            }

            var reqItem = GetRequestItemName(settingName);

            var dic = new Dictionary<string, string>
            {
                { PrefixNameAuth, DicKeyPermanentAuth },
                { PrefixNameScan, DicKeyPermanentScan },
                { PrefixNameFax, DicKeyPermanentFax },
                { PrefixNameIfax, DicKeyPermanentIfax },
                { PrefixNameOplevel, DicKeyPermanentOplevel },
                { PrefixNameDeviceInfoSystem, DicKeyPermanentSystem },
                { PrefixNameUbiquitous, DicKeyUbiquitous },
                { PrefixNameUser, DicKeyUser },
                { PrefixNameSecurity, DicKeyPermanentSecurity },
                { PrefixNameSystemConnection, DicKeyDetailSystemConnection },
                { PrefixNameWinNwk, DicKeyDetailWindowsNetwork },
                { PrefixNameMailSend, DicKeyDetailMailSend },
                { PrefixNameDeviceInfoExFunc, DicKeyDeviceInfoExFunc }, // Not dic key
                { PrefixNameEnableFunc, DicKeyEnableFunctionInfo2 }     // Not dic key
            };

            if (!dic.ContainsKey(reqItem))
            {
                throw new Exception("Request item key does not exist.");
            }

            return dic[reqItem];
        }

        /// <summary>
        /// Get keep settings xml
        /// </summary>
        /// <param name="dicKey">Dictionary key</param>
        /// <returns>Keep settigs xml document</returns>
        private XmlDocument GetKeepSettingsXml(string dicKey)
        {
            // Check dic xml
            return _adminSettingsXml.ContainsKey(dicKey) ? _adminSettingsXml[dicKey] : null;
        }

        /// <summary>
        /// Specific fix setting name
        /// </summary>
        /// <param name="settingName">Setting name</param>
        /// <param name="settingValue">Setting value</param>
        /// <returns>Continue flg</returns>
        private async Task<(bool Success, SettingValue SettingValue)> SpecificFixSettingNameAsync(
            string settingName,
            SettingValue settingValue)
        {
            switch (settingName)
            {
                // UbiquitousUseprint and UserMultiFeedDetectSetting is false
                case AdminSettingNamesConst.UbiquitousUsePrint:
                case AdminSettingNamesConst.UserMultiFeedDetectSetting:
                    settingValue.Success = true;
                    settingValue.Values = false;

                    return (true, settingValue);
                case AdminSettingNamesConst.IfaxIsEnable:
                    // IfaxIsEnable is specific.
                    var faxSettingsTask = GetDeviceSettingsAsync(PrefixNameIfax);
                    await Task.WhenAny(faxSettingsTask).ConfigureAwait(false);
                    var xmlIfaxGetDeviceInfo = faxSettingsTask.IsFaulted ?
                        null : await faxSettingsTask.ConfigureAwait(false);

                    if (xmlIfaxGetDeviceInfo != null)
                    {
                        return (true, _convertAdminSettings.ConvertToAdminSettings(xmlIfaxGetDeviceInfo, settingName));
                    }

                    settingValue.Success = true;
                    settingValue.Values = false;

                    return (true, settingValue);
                case AdminSettingNamesConst.OplevelOriginalSizeAutoDetectByUser:
                    // OplevelOriginalSizeAutoDetectByUser is Off
                    settingValue.Success = true;
                    settingValue.Values = "Off";

                    return (true, settingValue);
                case AdminSettingNamesConst.ScanisEnableOcr:
                    // ScanisEnableOcr is specific.
                    // Ocr get device info func
                    var infoExTask = GetDeviceSettingsAsync(PrefixNameDeviceInfoExFunc);
                    await Task.WhenAny(infoExTask).ConfigureAwait(false);
                    var xmlOcrGetDeviceInfoExFunc = infoExTask.IsFaulted ? null : await infoExTask;
                    var xmlOcrEnableFunc2 = await OcrEnabledDetailAsync().ConfigureAwait(false);

                    return (true, _convertAdminSettings.ConvertToAdminSettingsForEnableOcrScan(
                        xmlOcrGetDeviceInfoExFunc,
                        xmlOcrEnableFunc2,
                        settingName));
            }

            return (false, settingValue);
        }

        /// <summary>
        /// LicenseCheckSettingName
        /// </summary>
        /// <param name="settingName">Setting name</param>
        /// <param name="settingValue">Setting value</param>
        /// <returns>Continue flg</returns>
        private async Task<(bool Success, SettingValue SettingValue)> LicenseCheckSettingName(
            string settingName,
            SettingValue settingValue)
        {
            object value;

            switch (settingName)
            {
                // ScanPdfA or ScanLinearizedPdfg
                case AdminSettingNamesConst.ScanPdfA:
                    value = "Off";
                    break;
                case AdminSettingNamesConst.ScanIsEnablePdfA:
                case AdminSettingNamesConst.ScanLinearizedPdfg:
                case AdminSettingNamesConst.ScanIsEnableLinearizedPdf:
                    value = false;
                    break;
                case AdminSettingNamesConst.ScanOcrLanguage:
                    value = new List<string>();
                    break;
                default:
                    return (false, settingValue);
            }

            var xmlOcrEnableFunc2 = await OcrEnabledDetailAsync();

            if (!_convertAdminSettings.IsLicenseCheck(xmlOcrEnableFunc2, settingName))
            {
                settingValue.Success = true;
                settingValue.Values = value;
                return (true, settingValue);
            }

            // Acquire in later processing.
            return (false, settingValue);
        }

        private async Task<XmlDocument> OcrEnabledDetailAsync()
        {
            // Ocr enable func2
            var deviceInfoSystemTask = GetDeviceSettingsAsync(PrefixNameDeviceInfoSystem);
            await Task.WhenAny(deviceInfoSystemTask).ConfigureAwait(false);

            var xmlDeviceSerialNum = deviceInfoSystemTask.IsFaulted ? 
                null : await deviceInfoSystemTask.ConfigureAwait(false);
            var serialNumber = _convertAdminSettings.ConvertToDeviceInfoDetailSystemForSerialNumber(xmlDeviceSerialNum);

            var enableFunctionTask = GetDeviceSettingsAsync(PrefixNameEnableFunc, serialNumber);
            await Task.WhenAny(enableFunctionTask).ConfigureAwait(false);

            var xmlOcrEnableFunc2 = enableFunctionTask.IsFaulted ? 
                null : await enableFunctionTask.ConfigureAwait(false);

            return xmlOcrEnableFunc2;
        }
    }
}
