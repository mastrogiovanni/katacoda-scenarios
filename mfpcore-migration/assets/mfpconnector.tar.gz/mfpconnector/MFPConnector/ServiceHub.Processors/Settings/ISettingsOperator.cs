using System.Collections.Generic;
using System.Threading.Tasks;
using ServiceHub.Connectors.OpenAPI.Model;
using ServiceHub.Processors.Settings.Model;

namespace ServiceHub.Processors.Settings
{
    /// <summary>
    /// Operation settings interface.
    /// </summary>
    public interface ISettingsOperator
    {
        /// <summary>
        /// Obtain settings
        /// </summary>
        /// <param name="requestItemList">Request item list</param>
        /// <returns>Admin settings</returns>
        Task<List<SettingValue>> ObtainAdminSettingsAsync(List<string> requestItemList);

        /// <summary>
        /// Notify Device Network Setting.
        /// </summary>
        /// <param name="addressType">Ip address type.</param>
        /// <param name="address">Ip address.</param>
        /// <param name="ipv6Type">Ip v6 type.</param>
        /// <returns>Success/Fail</returns>
        Task<AppResSetSHIPAddress> NotifyDeviceNetworkSettingAsync(IpAddressType addressType, string address, Ipv6Type? ipv6Type);
    }
}
