using System.Collections.Generic;

namespace ServiceHub.Processors.Settings
{
    /// <summary>
    /// AdminSettingsOperatorConst
    /// </summary>
    public static class AdminSettingNamesConst
    {
        /// <summary>
        /// AuthColorManage
        /// </summary>
        public const string AuthColorManage = "Auth_ColorManage";

        /// <summary>
        /// AuthNoAuthPrintOn
        /// </summary>
        public const string AuthNoAuthPrintOn = "Auth_NoAuthPrintOn";

        /// <summary>
        /// AuthSendAddressLimit
        /// </summary>
        public const string AuthSendAddressLimit = "Auth_SendAddressLimit";

        /// <summary>
        /// FaxDefaultSenders
        /// </summary>
        public const string FaxDefaultSenders = "Fax_DefaultSenders";

        /// <summary>
        /// FaxDialType
        /// </summary>
        public const string FaxDialType = "Fax_DialType";

        /// <summary>
        /// FaxReceiveOnSettings
        /// </summary>
        public const string FaxReceiveOnSettings = "Fax_ReceiveOnSettings";

        /// <summary>
        /// FaxDataProtectType
        /// </summary>
        public const string FaxDataProtectType = "Fax_DataProtectType";

        /// <summary>
        /// FaxSendAuthPassword
        /// </summary>
        public const string FaxSendAuthPassword = "Fax_SendAuthPassword"; //NOSONAR

        /// <summary>
        /// SecuritySendProhibit
        /// </summary>
        public const string SecuritySendProhibit = "Security_SendProhibit";

        /// <summary>
        /// SysConnPrefixSuffix
        /// </summary>
        public const string SysConnPrefixSuffix = "SysConn_PrefixSuffix";

        /// <summary>
        /// OplevelOriginalSizeAutoDetectByUser
        /// </summary>
        public const string OplevelOriginalSizeAutoDetectByUser = "Oplevel_OriginalSizeAutoDetectByUser";

        /// <summary>
        /// IFaxIsEnable
        /// </summary>
        public const string IfaxIsEnable = "IFax_IsEnable";

        /// <summary>
        /// ScanOcrLanguage
        /// </summary>
        public const string ScanOcrLanguage = "Scan_OcrLanguage";

        /// <summary>
        /// ScanPdfA
        /// </summary>
        public const string ScanPdfA = "Scan_Pdf_A";

        /// <summary>
        /// ScanLinearizedPdfg
        /// </summary>
        public const string ScanLinearizedPdfg = "Scan_LinearizedPdfg";

        /// <summary>
        /// ScanisEnableOcr
        /// </summary>
        public const string ScanisEnableOcr = "Scan_is_enable_ocr";

        /// <summary>
        /// ScanIsEnablePdfA
        /// </summary>
        public const string ScanIsEnablePdfA = "Scan_IsEnablePdf_A";

        /// <summary>
        /// ScanIsEnableLinearizedPdf
        /// </summary>
        public const string ScanIsEnableLinearizedPdf = "Scan_IsEnableLinearizedPdf";

        /// <summary>
        /// ScanFileNameAddString
        /// </summary>
        public const string ScanFileNameAddString = "Scan_FileNameAddString";

        /// <summary>
        /// ScanFunctionInitial
        /// </summary>
        public const string ScanFunctionInitial = "Scan_FunctionInitial";

        /// <summary>
        /// WinNwkIsEnable
        /// </summary>
        public const string WinNwkIsEnable = "WinNwk_IsEnable";

        /// <summary>
        /// UbiquitousUsePrint
        /// </summary>
        public const string UbiquitousUsePrint = "Ubiquitous_UsePrint";

        /// <summary>
        /// AuthAuthType
        /// </summary>
        public const string AuthAuthType = "Auth_AuthType";

        /// <summary>
        /// UserMultiFeedDetectSetting
        /// </summary>
        public const string UserMultiFeedDetectSetting = "User_MultiFeedDetectSetting";

        /// <summary>
        /// MailSendAuth
        /// </summary>
        public const string MailSendAuth = "MailSend_Auth";

        /// <summary>
        /// MailSendBinaryDivisionSize
        /// </summary>
        public const string MailSendBinaryDivisionSize = "MailSend_BinaryDivisionSize";

        /// <summary>
        /// MailSendVerification
        /// </summary>
        public const string MailSendVerification = "MailSend_Verification";

        /// <summary>
        /// MailSendPopBeforeSmtp
        /// </summary>
        public const string MailSendPopBeforeSmtp = "MailSend_PopBeforeSmtp";

        /// <summary>
        /// MailSendPortNo
        /// </summary>
        public const string MailSendPortNo = "MailSend_PortNo";

        /// <summary>
        /// MailSendSslTslPortNo
        /// </summary>
        public const string MailSendSslTslPortNo = "MailSend_SslTslPortNo";

        /// <summary>
        /// MailSendServerLimitSize
        /// </summary>
        public const string MailSendServerLimit = "MailSend_ServerLimit";

        /// <summary>
        /// MailSendServerAddress
        /// </summary>
        public const string MailSendServerAddress = "MailSend_ServerAddress";

        /// <summary>
        /// MailSendEncryptionSetting
        /// </summary>
        public const string MailSendEncryptionSetting = "MailSend_EncryptionSetting";

        /// <summary>
        /// MailSendTimeOut
        /// </summary>
        public const string MailSendTimeOut = "MailSend_TimeOut";

        /// <summary>
        /// MailSendIsEnable
        /// </summary>
        public const string MailSendIsEnable = "MailSend_IsEnable";

        /// <summary>
        /// MailSendStatusNotify
        /// </summary>
        public const string MailSendStatusNotify = "MailSend_StatusNotify";

        /// <summary>
        /// MailSendScanSending
        /// </summary>
        public const string MailSendScanSending = "MailSend_ScanSending";

        /// <summary>
        /// MailSendTotalCounterNotify
        /// </summary>
        public const string MailSendTotalCounterNotify = "MailSend_TotalCounterNotify";

        /// <summary>
        /// All
        /// </summary>
        public const string All = "ALL";

        /// <summary>
        /// AppResSetSHIPAddress
        /// </summary>
        public const string AppResSetSHIPAddress = "AppResSetSHIPAddress";

        /// <summary>
        /// GetKeyAllList
        /// </summary>
        public static List<string> GetAllSettingNames => new List<string>
        {
            AuthColorManage,
            AuthNoAuthPrintOn,
            AuthSendAddressLimit,
            FaxDefaultSenders,
            FaxDialType,
            FaxReceiveOnSettings,
            FaxDataProtectType,
            FaxSendAuthPassword,
            SecuritySendProhibit,
            SysConnPrefixSuffix,
            OplevelOriginalSizeAutoDetectByUser,
            IfaxIsEnable,
            ScanOcrLanguage,
            ScanPdfA,
            ScanLinearizedPdfg,
            ScanisEnableOcr,
            ScanIsEnablePdfA,
            ScanIsEnableLinearizedPdf,
            ScanFileNameAddString,
            ScanFunctionInitial,
            WinNwkIsEnable,
            UbiquitousUsePrint,
            AuthAuthType,
            UserMultiFeedDetectSetting,
            MailSendAuth,
            MailSendBinaryDivisionSize,
            MailSendVerification,
            MailSendPopBeforeSmtp,
            MailSendPortNo,
            MailSendSslTslPortNo,
            MailSendServerLimit,
            MailSendServerAddress,
            MailSendEncryptionSetting,
            MailSendTimeOut,
            MailSendIsEnable,
            MailSendStatusNotify,
            MailSendScanSending,
            MailSendTotalCounterNotify
        };
    }
}
