namespace ServiceHub.Processors.Extensions.Model
{
    /// <summary>
    /// Power status type
    /// </summary>
    internal enum PowerStatus
    {
        SubPower,
        Sleep,
        LowPower
    }
}