using ServiceHub.Common.Settings.OpenApi;
using ServiceHub.Connectors.OpenAPI;
using ServiceHub.Processors.Extensions.Model;

namespace ServiceHub.Processors.Extensions
{
    internal static class NotifyPowerStatusExtensions
    {
        /// <summary>
        /// Get power status
        /// </summary>
        /// <param name="status">The status.</param>
        /// <param name="xml">The XML.</param>
        /// <param name="node">The node.</param>
        /// <param name="openApiVersion">The open API version.</param>
        /// <returns>
        /// Device status
        /// </returns>
        public static bool GetPowerStatus(this PowerStatus status, string xml, string node, OpenApiVersion openApiVersion)
        {
            var parser = new SoapXmlParser(xml, openApiVersion);
            var deviceStatusNode = parser.GetNode("/SOAP-ENV:Envelope/SOAP-ENV:Body").FirstChild;

            if (bool.TryParse(deviceStatusNode.SelectSingleNode($"{node}/{status.ToString()}")?.InnerText, out var powerStatus))
            {
                return powerStatus;
            }

            return false;
        }
    }
}