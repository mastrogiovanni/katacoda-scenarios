﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using ServiceHub.Processors.Bus;
using ServiceHub.Processors.Bus.Configurations;

namespace ServiceHub.Processors.Extensions
{
    public static class ServiceCollectionExtensions
    {
        public static IServiceCollection AddShMfpCoreProcessors(this IServiceCollection services,
            IConfigurationRoot configuration)
        {
            services
                .AddConfigurations(configuration)
                .AddMfpCorePublisher();

            return services;
        }

        private static IServiceCollection AddMfpCorePublisher(this IServiceCollection services)
        {
            services.AddSingleton<IMfpCounterPublisher, MfpCounterPublisher>();

            return services;
        }

        private static IServiceCollection AddConfigurations(this IServiceCollection services, IConfiguration configuration)
        {
            services.Configure<MfpCorePublisherSettings>(configuration.GetSection(MfpCorePublisherSettings.SectionName));

            return services;
        }
    }
}
