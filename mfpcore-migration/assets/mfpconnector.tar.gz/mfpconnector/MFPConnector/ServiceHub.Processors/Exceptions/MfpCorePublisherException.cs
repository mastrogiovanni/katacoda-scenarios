﻿using System;

namespace ServiceHub.Processors.Exceptions
{
    /// <summary>
    /// This class is used for exceptions related to sending to RabbitMQ.
    /// </summary>
    /// <seealso cref="System.Exception" />
    public class MfpCorePublisherException : Exception
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MfpCorePublisherException"/> class.
        /// </summary>
        /// <param name="message">The message that describes the error.</param>
        public MfpCorePublisherException(string message) : base(message)
        {
        }
    }
}
