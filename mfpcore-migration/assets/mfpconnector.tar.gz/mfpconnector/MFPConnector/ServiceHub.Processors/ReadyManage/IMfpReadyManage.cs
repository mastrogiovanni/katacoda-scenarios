namespace ServiceHub.Processors.ReadyManage
{
    /// <summary>
    /// Mfp Ready Manage.
    /// </summary>
    public interface IMfpReadyManage
    {
        /// <summary>
        /// Pause processing to send wakup command.
        /// </summary>
        /// <returns>OK or NG</returns>
        bool Pause();

        /// <summary>
        /// Resume processing to send wakup command.
        /// </summary>
        /// <returns>OK or NG</returns>
        bool Resume();

        /// <summary>
        /// A state of repeatedly sending "wakeup".
        /// </summary>
        bool ActiveState { get; set; }
    }
}
