using System;
using System.Threading;
using Microsoft.Extensions.Logging;
using ServiceHub.Common.DeviceState;
using ServiceHub.Connectors.OpenAPI;
using ServiceHub.Connectors.OpenAPI.Model;

namespace ServiceHub.Processors.ReadyManage
{
    /// <summary>
    /// Mfp Ready Manage.
    /// </summary>
    public class MfpReadyManage : OpenApiOperatable, IDisposable, IMfpReadyManage
    {
        private const int WaitTimeMiliseconds = 40000;

        private readonly ILogger<MfpReadyManage> _logger;
        private readonly IDeviceStateContext _deviceStateContext;
        
        /// <summary>
        /// Repeatedly sending "wakeup" task.
        /// </summary>
        private Timer _readySyncTask;

        /// <summary>
        /// Initializes a new instance of the <see cref="MfpReadyManage"/> class.  
        /// </summary>
        /// <param name="logger">Logger</param>
        /// <param name="openApiRequestSettings">OpenApiRequestSettings</param>
        /// <param name="openApiController">IOpenApiController</param>
        /// <param name="deviceStateContext">Context of MFP device state</param>
        public MfpReadyManage(
            ILogger<MfpReadyManage> logger,
            OpenApiRequestSettings openApiRequestSettings, 
            IOpenApiController openApiController, 
            IDeviceStateContext deviceStateContext)
            : base(openApiRequestSettings, openApiController)
        {
            _logger = logger;
            _deviceStateContext = deviceStateContext;
            Create();
        }

        /// <summary>
        /// A state of repeatedly sending "wakeup".
        /// </summary>
        public bool ActiveState { get; set; }

        /// <summary>
        /// Pause call wakeup command.
        /// </summary>
        /// <returns>OK or NG</returns>
        public bool Pause()
        {
            _logger.LogInformation("MfpReadyManage pause method start");
            var result = StopTask();
            _logger.LogInformation("MfpReadyManage pause method finish");

            return result;
        }

        /// <summary>
        /// Resume call wakeup command.
        /// </summary>
        /// <returns>OK or NG</returns>
        public bool Resume()
        {
            _logger.LogInformation("MfpReadyManage resume method start");
            var result = StartTask();
            _logger.LogInformation("MfpReadyManage resume method finish");

            return result;
        }

        /// <summary>
        /// MfpReadyManage dispose.
        /// </summary>
        public void Dispose()
        {
            if (_readySyncTask != null)
            {
                _readySyncTask.Dispose();
                _readySyncTask = null;
            }
        }

        /// <summary>
        /// Start call wakeup at 40 second intervals.
        /// </summary>
        /// <returns>OK or NG</returns>
        private void Create()
        {
            if (_readySyncTask != null)
            {
                return;
            }

            // create repeatedly task
            _readySyncTask = new Timer(
            async s =>
            {
                try
                {
                    if (_deviceStateContext.Usable)
                    {
                        // wakeup request
                        var wakeupResult = await OpenApiController.WakeupAsync();
                        _logger.LogInformation(string.Format("A process called for repeated wakeup and its response is {0}", wakeupResult.GetElementsByTagName("ResultInfo")[0].InnerText));
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError(default(EventId), ex, $"fail repeatedly wakeup request:{ex.Message}");
                }
            },
            null,
            Timeout.Infinite,
            Timeout.Infinite);
        }

        /// <summary>
        /// Start readySyncTask.
        /// </summary>
        /// <returns>OK or NG</returns>
        private bool StartTask()
        {
            var result = false;
            try
            {
                _readySyncTask.Change(0, WaitTimeMiliseconds);

                ActiveState = true;
                result = true;
            }
            catch
            {
                // do nothing
            }

            return result;
        }

        /// <summary>
        /// Stop readySyncTask.
        /// </summary>
        /// <returns>OK or NG</returns>
        private bool StopTask()
        {
            var result = false;
            try
            {
                _readySyncTask.Change(Timeout.Infinite, Timeout.Infinite);

                ActiveState = false;
                result = true;
            }
            catch
            {
                // do nothing
            }

            return result;
        }
    }
}
