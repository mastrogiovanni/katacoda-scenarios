using Newtonsoft.Json;

namespace ServiceHub.Processors.Iws.Model
{
    /// <summary>
    /// IWS Job result.
    /// </summary>
    public class IwsServiceResult
    {
        /// <summary>Result type string.</summary>
        [JsonProperty(PropertyName = "result")]
        public string Result { get; set; }

        /// <summary>Error detail string.</summary>
        [JsonProperty(PropertyName = "error")]
        public string Error { get; set; }

        /// <summary>Job ID.</summary>
        [JsonProperty(PropertyName = "job_id")]
        public int? JobId { get; set; }
    }
}
