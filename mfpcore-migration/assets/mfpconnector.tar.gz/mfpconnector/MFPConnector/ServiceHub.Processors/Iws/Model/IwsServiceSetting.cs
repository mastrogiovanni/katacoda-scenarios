using Newtonsoft.Json;
using ServiceHub.Common.Settings;

namespace ServiceHub.Processors.Iws.Model
{
    /// <summary>
    /// Job setting model on IWS.
    /// </summary>
    public class IwsServiceSetting
    {
        /// <summary>
        /// Gets or sets settings side for Iws job.
        /// </summary>
        [JsonProperty(PropertyName = "job_settings", NullValueHandling = NullValueHandling.Ignore)]
        public string JobSettings { get; set; }

        /// <summary>
        /// Gets or sets auth parameter.
        /// </summary>
        [JsonProperty(PropertyName = "auth_parameter", NullValueHandling = NullValueHandling.Ignore)]
        public AuthParameter AuthParameter { get; set; }
    }
}
