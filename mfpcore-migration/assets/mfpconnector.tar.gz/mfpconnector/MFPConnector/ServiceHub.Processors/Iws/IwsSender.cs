using System;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using ServiceHub.Connectors.IWS;
using ServiceHub.Processors.Common;
using ServiceHub.Processors.Iws.Model;

namespace ServiceHub.Processors.Iws
{
    /// <summary>
    /// Job sender.
    /// </summary>
    public class IwsSender : IMfpSender<IwsServiceSetting, IwsServiceResult>
    {
        private const string JobRequestPath = "/IWSJobrequest.json";
        private const string JobScriptPath = "/startJob.py";

        private readonly IIwsConnector _iwsConnectorUser;
        private readonly ILogger<IwsSender> _logger;

        /// <summary>
        /// Initializes a new instance of the <see cref="IwsSender" /> class.
        /// </summary>
        /// <param name="logger">Logger</param>
        /// <param name="iwsConnectorUser">The iws connector user.</param>
        public IwsSender(ILogger<IwsSender> logger, IIwsConnectorUser iwsConnectorUser)
        {
            _logger = logger;
            _iwsConnectorUser = iwsConnectorUser;
        }

        /// <summary>
        /// Send data to MFP.
        /// </summary>
        /// <param name="data">Processing data</param>
        /// <returns>Task that return output from MFP.</returns>
        public async Task<IwsServiceResult> SendToMfpAsync(IwsServiceSetting data)
        {
            _logger.LogInformation("SendToMfp Started.");
            return await ExecJobAsync(data);
        }

        /// <summary>
        /// Exec Job.
        /// </summary>
        /// <param name="data">Job request information.</param>
        /// <returns>Job response information.</returns>
        private async Task<IwsServiceResult> ExecJobAsync(IwsServiceSetting data)
        {
            if (data == null)
            {
                throw new ArgumentNullException(nameof(data));
            }

            try
            {
                var result = await _iwsConnectorUser.ExecuteAndWaitResponseAsync(JobScriptPath, data.AuthParameter, data.JobSettings, JobRequestPath);
                return !string.IsNullOrWhiteSpace(result)
                    ? JsonConvert.DeserializeObject<IwsServiceResult>(result)
                    : new IwsServiceResult
                    {
                        Error = "Timeout",
                        Result = SenderConfig.IwsResultStatus.NG.ToString()
                    };
            }
            catch (IwsException e)
            {
                return new IwsServiceResult
                {
                    Result = SenderConfig.IwsResultStatus.NG.ToString(),
                    Error = e.IwsErrorMessage
                };
            }
        }
    }
}
