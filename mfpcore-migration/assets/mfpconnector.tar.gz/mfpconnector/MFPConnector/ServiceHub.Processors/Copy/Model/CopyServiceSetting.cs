using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using ServiceHub.Common.Settings;

namespace ServiceHub.Processors.Copy.Model
{
    /// <summary>
    /// Copy setting model on IWS.
    /// </summary>
    public class CopyServiceSetting
    {
        /// <summary>
        /// Gets or sets number of sets for printing.
        /// </summary>
        [JsonProperty(PropertyName = "copies", NullValueHandling = NullValueHandling.Ignore)]
        [Range(1, 999)]
        public int Copies { get; set; }

        /// <summary>
        /// Gets or sets color for scanning.
        /// </summary>
        [JsonProperty(PropertyName = "color", NullValueHandling = NullValueHandling.Ignore)]
        public CopyColor Color { get; set; }

        /// <summary>
        /// Gets or sets density.
        /// </summary>
        [JsonProperty(PropertyName = "density", NullValueHandling = NullValueHandling.Ignore)]
        [Range(-4, 4)]
        public int Density { get; set; }

        /// <summary>
        /// Gets or sets duplex.
        /// </summary>
        [JsonProperty(PropertyName = "out_duplex", NullValueHandling = NullValueHandling.Ignore)]
        public bool Duplex { get; set; }

        /// <summary>
        /// Gets or sets class of scanning side.
        /// </summary>
        [JsonProperty(PropertyName = "in_duplex", NullValueHandling = NullValueHandling.Ignore)]
        [JsonConverter(typeof(StringEnumConverter))]
        public CopyScanSide ScanSide { get; set; }

        /// <summary>
        /// Gets or sets class of auth parameter.
        /// </summary>
        [JsonProperty(PropertyName = "auth_parameter", NullValueHandling = NullValueHandling.Ignore)]
        public AuthParameter AuthParameter { get; set; }

        /// <summary>
        /// Gets or sets class of input paper size.
        /// </summary>
        [JsonProperty(PropertyName = "in_paper_size", NullValueHandling = NullValueHandling.Ignore)]
        public CopyInPaperSize InPaperSize { get; set; }

        /// <summary>
        /// Gets or sets class of fit to page.
        /// </summary>
        [JsonProperty(PropertyName = "fit_to_page", NullValueHandling = NullValueHandling.Ignore)]
        [JsonConverter(typeof(StringEnumConverter))]
        public CopyFitToPage FitToPage { get; set; }

        /// <summary>
        /// Gets or sets class of output paper size.
        /// </summary>
        [JsonProperty(PropertyName = "out_paper_size", NullValueHandling = NullValueHandling.Ignore)]
        public CopyOutPaperSize OutPaperSize { get; set; }

        /// <summary>
        /// Gets or sets class of combine choices.
        /// </summary>
        [JsonProperty(PropertyName = "combine", NullValueHandling = NullValueHandling.Ignore)]
        [JsonConverter(typeof(StringEnumConverter))]
        public Combine Combine { get; set; }

        /// <summary>
        /// Gets or sets class of staple.
        /// </summary>
        [JsonProperty(PropertyName = "staple", NullValueHandling = NullValueHandling.Ignore)]
        public CopyStaple Staple { get; set; }

        /// <summary>
        /// Gets or sets class of punch.
        /// </summary> 
        [JsonProperty(PropertyName = "punch", NullValueHandling = NullValueHandling.Ignore)]
        public CopyPunch Punch { get; set; }

        /// <summary>
        /// Gets or sets class of background removal.
        /// </summary> 
        [JsonProperty(PropertyName = "background_removal", NullValueHandling = NullValueHandling.Ignore)]
        public CopyBackgroundRemoval BackgroundRemoval { get; set; }

        /// <summary>
        /// Gets or sets class of market area.
        /// </summary> 
        [JsonProperty(PropertyName = "market_area", NullValueHandling = NullValueHandling.Ignore)]
        [JsonConverter(typeof(StringEnumConverter))]
        public MarketArea MarketArea { get; set; }
    }
}
