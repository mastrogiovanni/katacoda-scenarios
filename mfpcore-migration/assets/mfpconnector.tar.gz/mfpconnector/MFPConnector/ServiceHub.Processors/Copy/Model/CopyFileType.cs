﻿namespace ServiceHub.Processors.Copy.Model
{
    /// <summary>
    /// input file_type.
    /// </summary>
    public enum CopyFileType
    {
        PDF,
        CompactPDF,
        TIFF,
        JPEG,
        XPS,
        CompactXPS,
        DOCX,
        XLSX,
        PPTX
    }
}
