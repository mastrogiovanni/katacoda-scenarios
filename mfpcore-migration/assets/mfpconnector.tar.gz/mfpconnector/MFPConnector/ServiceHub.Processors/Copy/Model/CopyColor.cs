using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace ServiceHub.Processors.Copy.Model
{
    /// <summary>
    /// Color model on IWS.
    /// </summary>
    public class CopyColor
    {
        /// <summary>
        /// Gets or sets class of color mode choices.
        /// </summary>
        [JsonProperty(PropertyName = "mode", Required = Required.Always)]
        [JsonConverter(typeof(StringEnumConverter))]
        public CopyColorMode Mode { get; set; }

        /// <summary>
        /// Gets or sets class of color choices.
        /// </summary>
        [JsonProperty(PropertyName = "color")]
        [JsonConverter(typeof(StringEnumConverter))]
        public CopyColorSelectColor SelectColor { get; set; }
    }
}
