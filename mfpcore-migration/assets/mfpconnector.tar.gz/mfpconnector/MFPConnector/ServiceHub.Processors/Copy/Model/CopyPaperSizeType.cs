﻿namespace ServiceHub.Processors.Copy.Model
{
    /// <summary>
    /// input paper_size_type.
    /// </summary>
    public enum CopyPaperSizeType
    {
        AUTO,
        STANDARD
    }
}
