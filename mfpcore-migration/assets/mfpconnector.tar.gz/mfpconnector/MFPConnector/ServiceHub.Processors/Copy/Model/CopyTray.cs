﻿namespace ServiceHub.Processors.Copy.Model
{
    /// <summary>
    /// input tray.
    /// </summary>
    public enum CopyTray
    {
        AUTO,
        MANUAL,
        TRAY_1,
        TRAY_2,
        TRAY_3,
        TRAY_4,
        TRAY_5
    }
}
