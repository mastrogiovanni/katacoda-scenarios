﻿namespace ServiceHub.Processors.Copy.Model
{
    /// <summary>
    /// Color choices.
    /// </summary>
    public enum CopyColorSelectColor
    {
        NOT_SELECTED,
        BLACK
    }
}
