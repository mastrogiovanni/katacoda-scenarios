﻿namespace ServiceHub.Processors.Copy.Model
{
    /// <summary>
    /// input mode.
    /// </summary>
    public enum CopyStapleMode
    {
        NOT_SELECTED,
        CORNER,
        CENTER,
        TWO_SIDE
    }
}
