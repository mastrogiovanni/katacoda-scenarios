using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace ServiceHub.Processors.Copy.Model
{
    /// <summary>
    /// OutPaperSize model on IWS.
    /// </summary>
    public class CopyOutPaperSize
    {
        /// <summary>
        /// Gets or sets class of paper size type choices.
        /// </summary>
        [JsonProperty(PropertyName = "tray", Required = Required.Always)]
        [JsonConverter(typeof(StringEnumConverter))]
        public CopyTray Tray { get; set; }


        /// <summary>
        /// Gets or sets class of paper size type choices.
        /// </summary>
        [JsonProperty(PropertyName = "size", Required = Required.Default)]
        public string Size { get; set; }
    }
}
