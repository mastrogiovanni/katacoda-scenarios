﻿namespace ServiceHub.Processors.Copy.Model
{
    /// <summary>
    /// Color mode choices.
    /// </summary>
    public enum CopyColorMode
    {
        AUTO,
        FULL_COLOR,
        SINGLE_COLOR
    }
}
