using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace ServiceHub.Processors.Copy.Model
{
    /// <summary>
    /// Staple model on IWS.
    /// </summary>
    public class CopyStaple
    {
        /// <summary>
        /// Gets or sets class of staple model choices.
        /// </summary>
        [JsonProperty(PropertyName = "model", Required = Required.Always)]
        [JsonConverter(typeof(StringEnumConverter))]
        public CopyStapleMode Mode { get; set; }


        /// <summary>
        /// Gets or sets class of staple position choices.
        /// </summary>
        [JsonProperty(PropertyName = "position", Required = Required.Default)]
        [JsonConverter(typeof(StringEnumConverter))]
        public CopyPosition Position { get; set; }
    }
}
