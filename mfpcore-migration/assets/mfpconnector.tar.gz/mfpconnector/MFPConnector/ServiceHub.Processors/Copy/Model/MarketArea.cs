﻿namespace ServiceHub.Processors.Copy.Model
{
    /// <summary>
    /// input market_area.
    /// </summary>
    public enum MarketArea
    {
        Japan,
        NorthAmerica,
        Europe
    }
}
