﻿namespace ServiceHub.Processors.Copy.Model
{
    /// <summary>
    /// input scan_side.
    /// </summary>
    public enum CopyScanSide
    {
        SIMPLEX,
        DUPLEX
    }
}
