﻿namespace ServiceHub.Processors.Copy.Model
{
    /// <summary>
    /// input position.
    /// </summary>
    public enum CopyPosition
    {
        AUTO,
        TOP,
        LEFT,
        RIGHT
    }
}
