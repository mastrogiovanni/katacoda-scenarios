﻿namespace ServiceHub.Processors.Copy.Model
{
    /// <summary>
    /// input fit_to_page.
    /// </summary>
    public enum CopyFitToPage
    {
        ON,
        OFF
    }
}
