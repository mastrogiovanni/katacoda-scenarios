﻿namespace ServiceHub.Processors.Copy.Model
{
    /// <summary>
    /// back ground type.
    /// </summary>
    public enum CopyScanBackgroundRemovalType
    {
        AUTO,
        MANUAL
    }
}
