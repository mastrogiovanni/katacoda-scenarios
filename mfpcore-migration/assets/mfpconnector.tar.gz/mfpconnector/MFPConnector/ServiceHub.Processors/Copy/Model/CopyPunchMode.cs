﻿namespace ServiceHub.Processors.Copy.Model
{
    /// <summary>
    /// input mode.
    /// </summary>
    public enum CopyPunchMode
    {
        NOT_SELECTED,
        TWO_HOLE,
        THREE_HOLE,
        FOUR_HOLE
    }
}
