﻿namespace ServiceHub.Processors.Copy.Model
{
    /// <summary>
    /// input combine.
    /// </summary>
    public enum Combine
    {
        SINGLE,
        TWO,
        FOUR_H,
        FOUR_V,
        EIGHT_H,
        EIGHT_V
    }
}
