using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace ServiceHub.Processors.Copy.Model
{
    /// <summary>
    /// Punch model on IWS.
    /// </summary>
    public class CopyPunch
    {
        /// <summary>
        /// Gets or sets class of punch mode choices.
        /// </summary>
        [JsonProperty(PropertyName = "mode", Required = Required.Always)]
        [JsonConverter(typeof(StringEnumConverter))]
        public CopyPunchMode Mode { get; set; }


        /// <summary>
        /// Gets or sets class of punch position choices.
        /// </summary>
        [JsonProperty(PropertyName = "position", Required = Required.Default)]
        [JsonConverter(typeof(StringEnumConverter))]
        public CopyPosition Position { get; set; }
    }
}
