using System;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using ServiceHub.Connectors.IWS;
using ServiceHub.Processors.Common;
using ServiceHub.Processors.Copy.Model;

namespace ServiceHub.Processors.Copy
{
    /// <summary>
    /// Copy sender.    
    /// </summary>
    public class CopySender : IMfpSender<CopyServiceSetting, CopyServiceResult>
    {
        private readonly IIwsConnector _iwsConnectorUser;
        private readonly ILogger<CopySender> _logger;

        /// <summary>
        /// Initializes a new instance of the <see cref="CopySender" /> class.
        /// </summary>
        /// <param name="logger">Logger</param>
        /// <param name="iwsConnectorUser">The iws connector user.</param>
        public CopySender(ILogger<CopySender> logger, IIwsConnectorUser iwsConnectorUser)
        {
            _logger = logger;
            _iwsConnectorUser = iwsConnectorUser;
        }

        /// <summary>
        /// Send data to MFP.
        /// </summary>
        /// <param name="data">Processing data</param>
        /// <returns>Task that return output from MFP.</returns>
        public async Task<CopyServiceResult> SendToMfpAsync(CopyServiceSetting data)
        {
            _logger.LogInformation("SendToMfp Started.");
            return await ExecCopyAsync(data);
        }

        /// <summary>
        /// Exec copy.
        /// </summary>
        /// <param name="data">Copy request information.</param>
        /// <returns>Copy response information.</returns>
        private async Task<CopyServiceResult> ExecCopyAsync(CopyServiceSetting data)
        {
            if (data == null)
            {
                throw new ArgumentNullException(nameof(data));
            }

            try
            {
                var result = await _iwsConnectorUser.ExecuteAsync(
                    SenderConfig.Get(SenderConfig.IwsCopyAction.Script),
                    data.AuthParameter,
                    JsonConvert.SerializeObject(
                        data,
                        Formatting.None,
                        new JsonSerializerSettings()),
                    SenderConfig.Get(SenderConfig.IwsCopyAction.Response),
                    SenderConfig.Get(SenderConfig.IwsCopyAction.Request));

                return result != null ?
                    JsonConvert.DeserializeObject<CopyServiceResult>(result)
                    : new CopyServiceResult
                    {
                        Result = SenderConfig.IwsResultStatus.NG.ToString(),
                        Error = SenderConfig.IwsError.Timeout.ToString()
                    };
            }
            catch (IwsException e)
            {
                return new CopyServiceResult
                {
                    Result = SenderConfig.IwsResultStatus.NG.ToString(),
                    Error = e.IwsErrorMessage
                };
            }
        }
    }
}
