using System;
using Newtonsoft.Json;

namespace ServiceHub.Common.Model
{
    /// <summary>
    /// Exception message
    /// </summary>
    public class ExceptionMessage
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ExceptionMessage" /> class.
        /// </summary>
        /// <param name="ex">Caused exception</param>
        public ExceptionMessage(Exception ex)
        {
            ClassName = ex.GetType().FullName;
            Message = ex.Message;
            StackTrace = ex.StackTrace;
            if (ex.InnerException != null)
            {
                InnerException = new ExceptionMessage(ex.InnerException);
            }
        }

        /// <summary>
        /// Exception class name
        /// </summary>
        public string ClassName { get; private set; }

        /// <summary>
        /// Exception.Message
        /// </summary>
        public string Message { get; private set; }

        /// <summary>
        /// Exception.StackTrace
        /// </summary>
        public string StackTrace { get; private set; }

        /// <summary>
        /// Exception.InnerException
        /// </summary>
        public ExceptionMessage InnerException { get; private set; }

        /// <summary>
        /// Serialize to JSON
        /// </summary>
        /// <returns>String representation</returns>
        public override string ToString()
        {
            return JsonConvert.SerializeObject(this);
        }
    }
}
