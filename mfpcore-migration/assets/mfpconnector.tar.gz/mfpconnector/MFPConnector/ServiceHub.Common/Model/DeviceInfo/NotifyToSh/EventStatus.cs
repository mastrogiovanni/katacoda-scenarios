using Newtonsoft.Json;

namespace ServiceHub.Common.Model.DeviceInfo.NotifyToSh
{
    /// <summary>
    /// LoginState model
    /// </summary>
    public class EventState
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="EventState"/> class
        /// </summary>
        /// <remarks>This constructor is for Serializing/Deserializing</remarks>
        public EventState()
        {
            Action = "notify";
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="EventState"/> class
        /// </summary>
        /// <param name="event">Applications with changed status.</param>
        public EventState(string @event) : this()
        {
            Event = @event;
        }

        /// <summary>
        /// Action.
        /// </summary>
        [JsonProperty("action")]
        public string Action { get; set; }

        /// <summary>
        /// Occurrence event.
        /// </summary>
        [JsonProperty("event")]
        public string Event { get; set; }
    }
}
