﻿using System.Runtime.Serialization;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace ServiceHub.Common.Model
{
    /// <summary>
    /// Availability Option (Basically: On/Off switch)
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum SwitchOption
    {
        /// <summary>
        /// Unidentified
        /// </summary>
        [EnumMember(Value = "Unidentified")]
        Unidentified,

        /// <summary>
        /// Enable
        /// </summary>
        [EnumMember(Value = "On")]
        On,

        /// <summary>
        /// Disabled
        /// </summary>
        [EnumMember(Value = "Off")]
        Off
    }
}
