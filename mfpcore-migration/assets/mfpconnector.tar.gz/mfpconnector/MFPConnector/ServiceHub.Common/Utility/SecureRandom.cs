﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;

namespace ServiceHub.Common.Utility
{
    public class SecureRandom : ISecureRandom
    {
        private readonly RandomNumberGenerator _secureRandomGenerator;

        /// <summary>
        /// Initializes a new instance of the <see cref="SecureRandom"/> class.
        /// </summary>
        public SecureRandom()
        {
            _secureRandomGenerator = RandomNumberGenerator.Create();
        }

        /// <inheritdoc cref="ISecureRandom"/>
        public int GetNextInt()
        {
            return GetNextInt(1).First();
        }

        /// <inheritdoc cref="ISecureRandom"/>
        public IEnumerable<int> GetNextInt(int quantity)
        {
            if (quantity <= 0)
            {
                throw new ArgumentException("The amount must be > 0", nameof(quantity));
            }

            var random = new byte[4 * quantity];
            _secureRandomGenerator.GetBytes(random);
            var rdm = random.AsSpan();

            var result = new List<int>();
            for (var i = 0; i < quantity; i++)
            {
                result.Add(BitConverter.ToInt32(rdm.Slice(0 + i * 4, 4).ToArray(), 0));
            }

            return result;
        }
    }
}
