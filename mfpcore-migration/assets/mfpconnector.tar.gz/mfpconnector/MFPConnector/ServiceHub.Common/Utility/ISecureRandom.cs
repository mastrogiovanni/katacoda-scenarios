﻿using System.Collections.Generic;

namespace ServiceHub.Common.Utility
{
    public interface ISecureRandom
    {
        /// <summary>
        /// Gets the next int.
        /// </summary>
        /// <returns>Returns the next random int.</returns>
        int GetNextInt();

        /// <summary>
        /// Gets the next int(s).
        /// </summary>
        /// <param name="quantity">The quantity of number to generate.</param>
        /// <returns>Returns the amount of random next int.</returns>
        IEnumerable<int> GetNextInt(int quantity);
    }
}
