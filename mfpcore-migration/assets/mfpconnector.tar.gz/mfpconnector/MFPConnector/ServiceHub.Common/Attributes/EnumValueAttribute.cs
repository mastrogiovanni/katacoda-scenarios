using System;

namespace ServiceHub.Common.Attributes
{
    /// <summary>
    /// Enum value attribute
    /// </summary>
    public sealed class EnumValueAttribute : Attribute
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="EnumValueAttribute" /> class
        /// </summary>
        /// <param name="value">Model value</param>
        public EnumValueAttribute(string value)
        {
            ModelValue = value;
        }

        /// <summary>
        /// Model value
        /// </summary>
        public string ModelValue { get; }
    }
}