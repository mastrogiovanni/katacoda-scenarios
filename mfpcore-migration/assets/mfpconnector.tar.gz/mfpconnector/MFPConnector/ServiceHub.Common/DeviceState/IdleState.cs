﻿namespace ServiceHub.Common.DeviceState
{
    /// <summary>
    /// MFP device state (Idle).
    /// </summary>
    public class IdleState : IDeviceState<IdleState>
    {
        /// <summary>
        /// State of environment for connect MFP.
        /// </summary>
        public bool Environment => true;

        /// <summary>
        /// State of MFP's usable.
        /// </summary>
        public bool Usable => true;

        /// <summary>
        /// Event handler for change state.
        /// </summary>
        /// <param name="previousState">Previous state</param>
        public void OnChangeState(IDeviceState previousState)
        {
            // do nothing
        }
    }
}
