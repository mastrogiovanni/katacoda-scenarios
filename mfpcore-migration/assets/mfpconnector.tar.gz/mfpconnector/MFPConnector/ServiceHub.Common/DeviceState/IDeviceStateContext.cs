﻿using System;
using System.Threading.Tasks;

namespace ServiceHub.Common.DeviceState
{
    /// <summary>
    /// Context of MFP device state.
    /// </summary>
    public interface IDeviceStateContext
    {
        /// <summary>
        /// State of environment for connect MFP.
        /// </summary>
        bool Environment { get; }

        /// <summary>
        /// State of MFP's usable.
        /// </summary>
        bool Usable { get; }

        /// <summary>
        /// Change state.
        /// </summary>
        /// <param name="state">Next state</param>
        void ChangeState(IDeviceState state);

        /// <summary>
        /// Queues a task to the scheduler
        /// </summary>
        /// <param name="name">Task Name</param>
        /// <param name="function">The task to be queued.</param>
        /// <param name="retryWhen">Retry When</param>
        void QueueTask(string name, Func<Task> function, Func<Task> retryWhen);
    }
}