using System;
using System.Collections.Concurrent;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;

namespace ServiceHub.Common.DeviceState
{
    /// <summary>
    /// Context of MFP device state.
    /// </summary>
    public class DeviceStateContext : IDeviceStateContext
    {
        private readonly ILogger<DeviceStateContext> _logger;
        private readonly IDeviceState<IdleState> _idleState;
        private readonly object _cuurentLock = new object();
        private readonly ConcurrentDictionary<string, FifoTaskScheduler> _schedulers;

        private IDeviceState _currentState;

        /// <summary>
        /// Initializes a new instance of the <see cref="DeviceStateContext"/> class.
        /// </summary>
        /// <param name="idleState">Idle device state</param>
        /// <param name="logger">Logger</param>
        public DeviceStateContext(
            IDeviceState<IdleState> idleState,
            ILogger<DeviceStateContext> logger)
        {
            _idleState = idleState;
            _currentState = idleState;
            _logger = logger;
            _schedulers = new ConcurrentDictionary<string, FifoTaskScheduler>();
        }

        /// <summary>
        /// State of environment for connect MFP.
        /// </summary>
        public bool Environment
        {
            get
            {
                lock (_cuurentLock)
                {
                    return _currentState.Environment;
                }
            }
        }

        /// <summary>
        /// State of MFP's usable.
        /// </summary>
        public bool Usable
        {
            get
            {
                lock (_cuurentLock)
                {
                    return _currentState.Usable;
                }
            }
        }

        /// <summary>
        /// Change state.
        /// </summary>
        /// <param name="state">Next state</param>
        public void ChangeState(IDeviceState state)
        {
            try
            {
                OnChangeState(state);
            }
            catch (Exception ex)
            {
                _logger.LogError(default(EventId), ex, "Exception occurred to change device state.");
            }
        }

        /// <summary>
        /// Event handler for change state.
        /// </summary>
        /// <param name="state">State</param>
        private void OnChangeState(IDeviceState state)
        {
            IDeviceState processState;
            IDeviceState previousState;
            lock (_cuurentLock)
            {
                previousState = _currentState;
                processState = state ?? _idleState;
                _currentState = processState;
            }

            try
            {
                if (previousState?.GetType() != processState.GetType())
                {
                    _logger.LogInformation($"Change state {previousState?.GetType()} to {processState.GetType()}");
                }

                processState.OnChangeState(previousState);
            }
            catch (Exception ex)
            {
                lock (_cuurentLock)
                {
                    _currentState = previousState;
                }

                _logger.LogError(default(EventId), ex, "Exception occurred to change device state.");
            }
        }

        /// <summary>
        /// Queues a task to the scheduler
        /// </summary>
        /// <param name="name">Task Name</param>
        /// <param name="function">The task to be queued.</param>
        /// <param name="retryWhen">Retry When</param>
        public void QueueTask(string name, Func<Task> function, Func<Task> retryWhen)
        {
            if (!_schedulers.TryGetValue(name, out var scheduler))
            {
                scheduler = new FifoTaskScheduler();
                _schedulers.TryAdd(name, scheduler);
            }

            Task.Factory.StartNew(async () => await RetryOnFaultAsync(function, retryWhen), CancellationToken.None, TaskCreationOptions.None, scheduler);
        }

        /// <summary>
        /// Retry on fault.
        /// </summary>
        /// <param name="function">Fuc</param>
        /// <param name="retryWhen">Retry When</param>
        /// <returns></returns>
        private static async Task RetryOnFaultAsync(Func<Task> function, Func<Task> retryWhen)
        {
            while (true)
            {
                try
                {
                    await function().ConfigureAwait(false);
                    return;
                }
                catch
                {
                    // Continuable
                }

                await retryWhen().ConfigureAwait(false);
            }
        }
    }
}
