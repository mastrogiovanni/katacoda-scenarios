﻿namespace ServiceHub.Common.DeviceState
{
    /// <summary>
    /// MFP device state.
    /// </summary>
    public interface IDeviceState
    {
        /// <summary>
        /// State of environment for connect MFP.
        /// </summary>
        bool Environment { get; }

        /// <summary>
        /// State of MFP's usable.
        /// </summary>
        bool Usable { get; }

        /// <summary>
        /// Event handler for change state.
        /// </summary>
        /// <param name="previousState">Previous state</param>
        void OnChangeState(IDeviceState previousState);
    }

    public interface IDeviceState<TState>: IDeviceState
    {
    }
}
