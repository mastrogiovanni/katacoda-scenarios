using System.IO;

namespace ServiceHub.Common.Extensions
{
    /// <summary>
    /// Extension for path
    /// </summary>
    public static class PathExtension
    {
        private const string RelativePathPrefix = "~/";

        /// <summary>
        /// Substitute Server.MapPath
        /// </summary>
        /// <param name="relativePath">Relative path</param>
        /// <param name="basePath">Base path</param>
        /// <returns>Absolute path</returns>
        public static string MapPath(this string relativePath, string basePath)
        {
            var result = string.Empty;

            if (relativePath.StartsWith(RelativePathPrefix))
            {
                result = Path.Combine(basePath, relativePath.Substring(RelativePathPrefix.Length));
            }
            else if (Path.IsPathRooted(relativePath))
            {
                result = relativePath;
            }
            else
            {
                result = Path.Combine(basePath, relativePath);
            }

            return result;
        }
    }
}
