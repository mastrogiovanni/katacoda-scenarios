using System;
using System.Reflection;
using ServiceHub.Common.Attributes;

namespace ServiceHub.Common.Extensions
{
    /// <summary>
    /// Enum value extension
    /// </summary>
    public static class EnumValueExtension
    {
        /// <summary>
        /// Get model value
        /// </summary>
        /// <param name="value">Enum value</param>
        /// <returns>Model value if defined, or member name</returns>
        public static string ModelValue(this Enum value)
        {
            var fieldInfo = value.GetType().GetTypeInfo().GetField(value.ToString());
            var descriptionAttributes = fieldInfo.GetCustomAttributes(typeof(EnumValueAttribute), false) as EnumValueAttribute[];

            return descriptionAttributes != null && descriptionAttributes.Length > 0 ? descriptionAttributes[0].ModelValue : value.ToString();
        }
    }
}
