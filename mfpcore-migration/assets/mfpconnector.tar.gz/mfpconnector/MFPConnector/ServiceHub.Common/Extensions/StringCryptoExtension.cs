using System;
using System.Security.Cryptography;
using System.Text;

namespace ServiceHub.Common.Extensions
{
    /// <summary>
    /// String extension for crypto
    /// </summary>
    public static class StringCryptoExtension
    {
        /// <summary>
        /// Compute SHA256 hash (ASCII)
        /// </summary>
        /// <param name="input">Input string</param>
        /// <returns>SHA256 hash string (upper case)</returns>
        public static string ComputeSha256Hash(this string input)
        {
            return input.ComputeSha256Hash(Encoding.ASCII);
        }

        /// <summary>
        /// Compute SHA256 hash
        /// </summary>
        /// <param name="input">Input string</param>
        /// <param name="encoding">Encoding</param>
        /// <returns>SHA256 hash string (upper case)</returns>
        public static string ComputeSha256Hash(this string input, Encoding encoding)
        {
            var hash = SHA256.Create().ComputeHash(encoding.GetBytes(input));
            return BitConverter.ToString(hash).ToUpper().Replace("-", string.Empty);
        }

        /// <summary>
        /// Compute HMAC-SHA256 (ASCII)
        /// </summary>
        /// <param name="input">Input message</param>
        /// <param name="key">Key</param>
        /// <returns>HMAC-SHA256 value</returns>
        public static string ComputeHmacSha256(this string input, string key)
        {
            return ComputeHmacSha256(input, key, Encoding.ASCII);
        }

        /// <summary>
        /// Compute HMAC-SHA256
        /// </summary>
        /// <param name="input">Input message</param>
        /// <param name="key">Key</param>
        /// <param name="encoding">Encoding</param>
        /// <returns>HMAC-SHA256 value</returns>
        public static string ComputeHmacSha256(this string input, string key, Encoding encoding)
        {
            using (var hmacSha256 = new HMACSHA256(Encoding.UTF8.GetBytes(key)))
            {
                var hmacHash = hmacSha256.ComputeHash(encoding.GetBytes(input));
                return BitConverter.ToString(hmacHash).ToUpper().Replace("-", string.Empty);
            }
        }
    }
}
