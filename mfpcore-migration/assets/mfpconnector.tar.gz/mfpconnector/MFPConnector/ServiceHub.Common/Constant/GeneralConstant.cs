namespace ServiceHub.Common.Constant
{
    /// <summary>
    /// General Constant Class.
    /// </summary>
    public static class GeneralConstant
    {
        /// <summary>
        /// ManuscriptADF1
        /// </summary>
        public static readonly string MANUSCRIPT_ADF1 = "ManuscriptADF1";

        /// <summary>
        /// MemoryOverflow
        /// </summary>
        public static readonly string MEMORY_OVERFLOW = "MemoryOverflow";

        /// <summary>
        /// TraySelection
        /// </summary>
        public static readonly string TRAY_SELECTION = "TraySelection";

        /// <summary>
        /// ForceStart
        /// </summary>
        public static readonly string FORCE_START = "ForceStart";

        /// <summary>
        /// ManuscriptSizeDetectError
        /// </summary>
        public static readonly string MANUSCRIPT_SIZE_DETECT_ERROR = "ManuscriptSizeDetectError";

        /// <summary>
        /// AMSMagnificationIncompatible
        /// </summary>
        public static readonly string AMS_MAGNIFICATION_INCOMPATIBLE = "AMSMagnificationIncompatible";

#pragma warning disable S1075 // URIs should not be hardcoded
        /// <summary>
        /// IWS WebAPI Path from IWS server root.
        /// </summary>
        public static readonly string IwsWebApiPath = "/IWS/WebAPI/";

        /// <summary>
        /// Remove file script path from IWS application data root.
        /// </summary>
        public static readonly string RemoveFileScriptPath = "/removeFile.py";
#pragma warning restore S1075 // URIs should not be hardcoded
    }
}
