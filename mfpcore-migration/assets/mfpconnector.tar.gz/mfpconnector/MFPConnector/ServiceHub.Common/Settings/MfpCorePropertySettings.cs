namespace ServiceHub.Common.Settings
{
    public class MfpCorePropertySettings
    {
        /// <summary>
        /// MfpCorePropertySettings name.
        /// </summary>
        public static readonly string SettingsName = "MfpCorePropertySettings";

        /// <summary>
        /// Gets or sets the mfpservice endpoints.
        /// </summary>
        public MfpServiceEndpoints MfpServiceEndpoints { get; set; }
    }
}
