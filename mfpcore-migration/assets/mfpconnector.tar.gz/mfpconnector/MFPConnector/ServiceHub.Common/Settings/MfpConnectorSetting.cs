using Newtonsoft.Json;
using ServiceHub.Common.Settings.Animations;
using ServiceHub.Common.Settings.Fax;
using ServiceHub.Common.Settings.Firmware;
using ServiceHub.Common.Settings.Ftp;
using ServiceHub.Common.Settings.Iws;
using ServiceHub.Common.Settings.Log;
using ServiceHub.Common.Settings.MfpCore;
using ServiceHub.Common.Settings.MfpSettings;
using ServiceHub.Common.Settings.NetworkInterface;
using ServiceHub.Common.Settings.OpenApi;
using ServiceHub.Common.Settings.PushNotification;
using ServiceHub.Common.Settings.Token;
using System.Collections.Generic;
using System.IO;

namespace ServiceHub.Common.Settings
{
    /// <summary>
    /// MFP Connector Setting
    /// </summary>
    public class MfpConnectorSetting
    {
        /// <summary>
        /// Kestrel (Web server) setting
        /// </summary>
        [JsonProperty("kestrel")]
        public KestrelSetting Kestrel { get; set; }

        /// <summary>
        /// Log Setting
        /// </summary>
        [JsonProperty(PropertyName = "log")]
        public LogSetting Log { get; set; }

        /// <summary>
        /// IWS Common Settings
        /// </summary>
        [JsonProperty(PropertyName = "iws")]
        public IwsSetting Iws { get; set; }

        /// <summary>
        /// OpenAPI setting
        /// </summary>
        [JsonProperty("openapi")]
        public OpenApiSetting OpenApi { get; set; }

        /// <summary>
        /// Fax Receive Setting
        /// </summary>
        [JsonProperty(PropertyName = "fax")]
        public FaxReceiveSetting Fax { get; set; }

        /// <summary>
        /// Push notification setting
        /// </summary>
        [JsonProperty(PropertyName = "push_notification")]
        public Dictionary<PushNotificationType, PushNotificationSetting> PushNotification { get; set; }

        /// <summary>
        /// Token setting
        /// </summary>
        [JsonProperty(PropertyName = "token")]
        public TokenSetting TokenSettings { get; set; }

        /// <summary>
        /// MFP settings setting
        /// </summary>
        [JsonProperty(PropertyName = "mfp_settings")]
        public MfpSettingsSetting MfpSettings { get; set; }

        /// <summary>
        /// Animation setting
        /// </summary>
        [JsonProperty(PropertyName = "animation")]
        public AnimationsSetting Animation { get; set; }

        /// <summary>
        /// Ftp setting
        /// </summary>
        [JsonProperty(PropertyName = "ftp")]
        public FtpSetting Ftp { get; set; }

        /// <summary>
        /// Ftp setting
        /// </summary>
        [JsonProperty(PropertyName = "firmware")]
        public FirmwareSetting Firmware { get; set; }

        /// <summary>
        /// Mfp core setting
        /// </summary>
        [JsonProperty(PropertyName = "mfp_core_settings")]
        public MfpCoreSettings MfpCoreSettings { get; set; }

        /// <summary>
        /// Network interface settings
        /// </summary>
        [JsonProperty(PropertyName = "network_interface_settings")]
        public NetworkInterfaceSettings NetworkInterfaceSettings { get; set; }

        [JsonIgnore]
        private static string _lastLoadPath;

        /// <summary>
        /// Load setting
        /// </summary>
        /// <param name="path">Path</param>
        /// <returns>Setting object</returns>
        public static MfpConnectorSetting Load(string path)
        {
            var setting = JsonConvert.DeserializeObject<MfpConnectorSetting>(File.ReadAllText(path));
            _lastLoadPath = path;
            return setting;
        }

        /// <summary>
        /// Save setting
        /// </summary>
        public void Save()
        {
            var settingJson = JsonConvert.SerializeObject(this);
            File.WriteAllText(_lastLoadPath, settingJson);
        }
    }
}
