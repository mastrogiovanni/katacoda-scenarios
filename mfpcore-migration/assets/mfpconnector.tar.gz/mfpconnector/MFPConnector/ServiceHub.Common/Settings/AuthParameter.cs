using Newtonsoft.Json;

namespace ServiceHub.Common.Settings
{
    public class AuthParameter
    {
        /// <summary>
        /// Gets or sets class of code for auth parameter.
        /// </summary>
        [JsonProperty(PropertyName = "code")]
        public string Code { get; set; }
    }
}
