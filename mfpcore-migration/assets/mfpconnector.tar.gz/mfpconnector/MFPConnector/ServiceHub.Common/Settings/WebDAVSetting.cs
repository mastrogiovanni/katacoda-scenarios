using Newtonsoft.Json;

namespace ServiceHub.Common.Settings
{
    /// <summary>
    /// WebDAV Setting
    /// </summary>
    public struct WebDavSetting
    {
        /// <summary>
        /// WebDAV Host
        /// </summary>
        [JsonProperty(PropertyName = "host")]
        public string Host { get; set; }

        /// <summary>
        /// WebDAV Port
        /// </summary>
        [JsonProperty(PropertyName = "port")]
        public int? Port { get; set; }

        /// <summary>
        /// WebDAV Root Directory
        /// </summary>
        [JsonProperty(PropertyName = "dir")]
        public string Dir { get; set; }

        /// <summary>
        /// WebDAV Authentication User
        /// </summary>
        [JsonProperty(PropertyName = "user")]
        public string User { get; set; }

        /// <summary>
        /// WebDAV Authentication Password
        /// </summary>
        [JsonProperty(PropertyName = "password")]
        public string Password { get; set; }
    }
}
