using Newtonsoft.Json;

namespace ServiceHub.Common.Settings
{
    /// <summary>
    /// Retry setting
    /// </summary>
    public class RetrySetting
    {
        /// <summary>
        /// Max retry count (including first try)
        /// </summary>
        [JsonProperty(PropertyName = "count")]
        public int Count { get; set; }

        /// <summary>
        /// Retry interval milli seconds
        /// </summary>
        [JsonProperty(PropertyName = "interval")]
        public int Interval { get; set; }
    }
}
