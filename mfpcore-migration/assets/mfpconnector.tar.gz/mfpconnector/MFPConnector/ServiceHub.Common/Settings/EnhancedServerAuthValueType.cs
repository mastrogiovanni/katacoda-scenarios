namespace ServiceHub.Common.Settings
{
    /// <summary>
    /// Auth parameter value type
    /// </summary>
    public enum EnhancedServerAuthValueType
    {
        /// <summary>
        /// Auth parameter code
        /// </summary>
        AuthParameterCode
    }
}
