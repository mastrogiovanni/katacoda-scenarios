using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace ServiceHub.Common.Settings.OpenApi
{
    /// <summary>
    /// Value item
    /// </summary>
    public class OpenApiEnhancedServerAuthValue
    {
        /// <summary>
        /// Control ID
        /// </summary>
        [JsonProperty("control_id", Required = Required.Always)]
        public string ControlId { get; set; }

        /// <summary>
        /// ArraySize
        /// </summary>
        [JsonProperty("array_size", Required = Required.Always)]
        public ushort ArraySize { get; set; }

        /// <summary>
        /// Value type
        /// </summary>
        [JsonProperty("value_type", Required = Required.Always)]
        [JsonConverter(typeof(StringEnumConverter))]
        public EnhancedServerAuthValueType ValueType { get; set; }
    }
}