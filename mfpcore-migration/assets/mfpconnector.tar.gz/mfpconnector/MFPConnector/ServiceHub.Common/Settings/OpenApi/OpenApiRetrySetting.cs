using Newtonsoft.Json;

namespace ServiceHub.Common.Settings.OpenApi
{
    /// <summary>
    /// OpenAPI retry setting
    /// </summary>
    public class OpenApiRetrySetting
    {
        /// <summary>
        /// Retry
        /// </summary>
        [JsonProperty(PropertyName = "set_device_info_detail")]
        public RetrySetting SetDeviceInfoDetail { get; set; }
    }
}
