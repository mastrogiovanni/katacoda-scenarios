using Newtonsoft.Json;

namespace ServiceHub.Common.Settings.OpenApi
{
    /// <summary>
    /// Alive monitor configuration.
    /// </summary>
    public class OpenApiAliveMonitorSetting
    {
        /// <summary>
        /// Ping interval.
        /// </summary>
        [JsonProperty(PropertyName = "ping_interval")]
        public int PingInterval { get; set; }

        /// <summary>
        /// Ping timeout.
        /// </summary>
        [JsonProperty(PropertyName = "ping_timeout")]
        public int PingTimeout { get; set; }

        /// <summary>
        /// Ping error max.
        /// </summary>
        [JsonProperty(PropertyName = "ping_error_max")]
        public int PingErrorMax { get; set; }

        /// <summary>
        /// OpenAPI confirm timeout.
        /// </summary>
        [JsonProperty(PropertyName = "oap_confirm_timeout")]
        public int OapConfirmTimeout { get; set; }

        /// <summary>
        /// OpenAPI confirm period by ping count.
        /// </summary>
        [JsonProperty(PropertyName = "oap_confirm_period")]
        public int OapConfirmPeriod { get; set; }
    }
}
