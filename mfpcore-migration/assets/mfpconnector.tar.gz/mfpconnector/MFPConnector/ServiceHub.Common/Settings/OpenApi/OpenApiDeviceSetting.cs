using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;

namespace ServiceHub.Common.Settings.OpenApi
{
    /// <summary>
    /// OpenAPI device setting.
    /// </summary>
    public class OpenApiDeviceSetting
    {
        /// <summary>
        /// Setting ID to be used
        /// </summary>
        [JsonProperty(PropertyName = "setting_id")]
        public string SettingId { get; set; }

        /// <summary>
        /// Detail settings
        /// </summary>
        [JsonProperty(PropertyName = "definitions")]
        public List<OpenApiDeviceDetailSetting> Definitions { get; set; }

        /// <summary>
        /// Current setting to used
        /// </summary>
        [JsonIgnore]
        public OpenApiDeviceDetailSetting CurrentSetting
        {
            get
            {
                return Definitions.FirstOrDefault(p => p.SettingId == SettingId);
            }
        }
    }
}