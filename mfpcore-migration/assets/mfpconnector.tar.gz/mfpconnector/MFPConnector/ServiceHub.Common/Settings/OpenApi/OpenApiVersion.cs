using Newtonsoft.Json;

namespace ServiceHub.Common.Settings.OpenApi
{
    /// <summary>
    /// OpenAPI Version Setting
    /// </summary>
    public class OpenApiVersion
    {
        /// <summary>
        /// Major
        /// </summary>
        [JsonProperty("major")]
        public short Major { get; set; }

        /// <summary>
        /// Minor
        /// </summary>
        [JsonProperty("minor")]
        public short Minor { get; set; }
    }
}