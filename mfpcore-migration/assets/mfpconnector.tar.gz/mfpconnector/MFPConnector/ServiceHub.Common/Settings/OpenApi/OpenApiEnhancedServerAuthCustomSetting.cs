using System.Collections.Generic;
using Newtonsoft.Json;

namespace ServiceHub.Common.Settings.OpenApi
{
    /// <summary>
    /// Custom Setting
    /// </summary>
    public class OpenApiEnhancedServerAuthCustomSetting
    {
        /// <summary>
        /// Screen ID
        /// </summary>
        [JsonProperty("screen_id", Required = Required.Always)]
        public string ScreenId { get; set; }

        /// <summary>
        /// Panel language
        /// </summary>
        [JsonProperty("panel_language", Required = Required.Always)]
        public string PanelLanguage { get; set; }

        /// <summary>
        /// Values
        /// </summary>
        [JsonProperty("values", Required = Required.DisallowNull)]
        public List<OpenApiEnhancedServerAuthValue> Values { get; set; }
    }
}