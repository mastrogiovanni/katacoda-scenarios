using Newtonsoft.Json;

namespace ServiceHub.Common.Settings.OpenApi
{
    /// <summary>
    /// OpenAPI Setting
    /// </summary>
    public class OpenApiSetting
    {
        /// <summary>
        /// Version
        /// </summary>
        [JsonProperty("version")]
        public OpenApiVersion Version { get; set; }

        /// <summary>
        /// Device Setting
        /// </summary>
        [JsonProperty("devices")]
        public OpenApiDeviceSetting Devices { get; set; }
    }
}