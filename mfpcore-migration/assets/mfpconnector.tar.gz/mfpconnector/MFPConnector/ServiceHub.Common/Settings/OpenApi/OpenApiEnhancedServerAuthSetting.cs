using System.ComponentModel;
using Newtonsoft.Json;

namespace ServiceHub.Common.Settings.OpenApi
{
    /// <summary>
    /// OpenAPI Enhanced Server Authentication setting
    /// </summary>
    public class OpenApiEnhancedServerAuthSetting
    {
        /// <summary>
        /// Use flag
        /// </summary>
        [JsonProperty("use", Required = Required.Always)]
        [DefaultValue(false)]
        public bool Use { get; set; }

        /// <summary>
        /// Fixed user for authentication
        /// </summary>
        [JsonProperty("app_req_login_custom_setting", Required = Required.Default)]
        public OpenApiEnhancedServerAuthCustomSetting CustomSetting { get; set; }
    }
}