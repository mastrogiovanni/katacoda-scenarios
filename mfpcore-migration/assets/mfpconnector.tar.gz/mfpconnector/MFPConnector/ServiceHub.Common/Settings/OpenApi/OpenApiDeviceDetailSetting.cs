using System.ComponentModel;
using Newtonsoft.Json;

namespace ServiceHub.Common.Settings.OpenApi
{
    /// <summary>
    /// OpenAPI Device detail setting.
    /// </summary>
    public class OpenApiDeviceDetailSetting
    {
        /// <summary>
        /// Setting ID to be recognized by OpenApiDeviceSetting
        /// </summary>
        [JsonProperty(PropertyName = "setting_id")]
        public string SettingId { get; set; }

        /// <summary>
        /// Device Ip
        /// </summary>
        [JsonProperty(PropertyName = "device_ip")]
        public string DeviceIp { get; set; }

        /// <summary>
        /// OpenApi Port
        /// </summary>
        [JsonProperty(PropertyName = "device_port")]
        public ushort DevicePort { get; set; }

        /// <summary>
        /// User
        /// </summary>
        [JsonProperty(PropertyName = "user")]
        public string User { get; set; }

        /// <summary>
        /// Password
        /// </summary>
        [JsonProperty(PropertyName = "password")]
        public string Password { get; set; }

        /// <summary>
        /// Notify Ip
        /// </summary>
        [JsonIgnore]
        public string NotifyIp { get; set; }

        /// <summary>
        /// Notify Port
        /// </summary>
        [JsonProperty(PropertyName = "notify_port")]
        public ushort NotifyPort { get; set; }

        /// <summary>
        /// Use SSL
        /// </summary>
        [JsonProperty("use_ssl", Required = Required.Default)]
        [DefaultValue(false)]
        public bool UseSsl { get; set; }

        /// <summary>
        /// Enhanced Server Authentication
        /// </summary>
        [JsonProperty("enhanced_server_auth", Required = Required.Always)]
        public OpenApiEnhancedServerAuthSetting EnhancedServerAuth { get; set; }

        /// <summary>
        /// HTTP KeepAlive
        /// </summary>
        [JsonProperty("keep_alive", Required = Required.Default)]
        [DefaultValue(true)]
        public bool KeepAlive { get; set; }

        /// <summary>
        /// Timeout
        /// </summary>
        [JsonProperty("timeout", Required = Required.Default)]
        [DefaultValue(30)]
        public int Timeout { get; set; }

        /// <summary>
        /// Retry
        /// </summary>
        [JsonProperty(PropertyName = "retry")]
        public OpenApiRetrySetting Retry { get; set; }

        /// <summary>
        /// BackUp
        /// </summary>
        [JsonProperty(PropertyName = "backup")]
        public bool BackUp { get; set; }

        /// <summary>
        /// BackUp Password
        /// </summary>
        [JsonProperty(PropertyName = "backup_password")]
        public string BackUpPassword { get; set; }

        /// <summary>
        /// EmptyText
        /// </summary>
        [JsonProperty(PropertyName = "empty_text")]
        public string EmptyText { get; set; }

        /// <summary>
        /// EmptyText
        /// </summary>
        [JsonProperty(PropertyName = "mfp_setting_lock_timeout_minute")]
        public int MfpSettingLockTimeoutMin { get; set; }

        /// <summary>
        /// Alive monitor.
        /// </summary>
        [JsonProperty(PropertyName = "alive_monitor")]
        public OpenApiAliveMonitorSetting AliveMonitor { get; set; }
    }
}