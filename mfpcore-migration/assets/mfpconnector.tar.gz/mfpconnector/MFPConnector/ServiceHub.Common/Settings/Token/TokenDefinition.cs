using System.Collections.Generic;
using Newtonsoft.Json;

namespace ServiceHub.Common.Settings.Token
{
    /// <summary>
    /// Token settings definition.
    /// </summary>
    public class TokenDefinition
    {
        /// <summary>
        /// Setting ID.
        /// </summary>
        [JsonProperty("setting_id")]
        public string SettingId { get; set; }
        /// <summary>
        /// Protocol.
        /// </summary>
        [JsonProperty("protocol")]
        public string Protocol { get; set; }
        /// <summary>
        /// Domain.
        /// </summary>
        [JsonProperty("domain")]
        public string Domain { get; set; }
        /// <summary>
        /// Port number.
        /// </summary>
        [JsonProperty("port")]
        public int Port { get; set; }
        /// <summary>
        /// URL path base.
        /// </summary>
        [JsonProperty("path_base")]
        public string PathBase { get; set; }
        /// <summary>
        /// URL for get IDM token.
        /// </summary>
        [JsonProperty("path_get_token")]
        public string PathGetToken { get; set; }
        /// <summary>
        /// Request content.
        /// </summary>
        [JsonProperty("request_content")]
        public Dictionary<string, string> RequestContent { get; set; }
        /// <summary>
        /// Request content.
        /// </summary>
        [JsonProperty("headers")]
        public TokenHeaderSetting Headers { get; set; }
        /// <summary>
        /// Base URL
        /// </summary>
        [JsonIgnore]
        public string ConnectTokenUrl => $"{Protocol}://{Domain}:{Port}{PathBase}{PathGetToken}";
    }
}
