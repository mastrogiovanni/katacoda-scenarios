using Newtonsoft.Json;

namespace ServiceHub.Common.Settings.Token
{
    /// <summary>
    /// Header setting for get IDM Token.
    /// </summary>
    public class TokenHeaderSetting
    {
        /// <summary>
        /// ContentType
        /// </summary>
        [JsonProperty("content_type")]
        public string ContentType { get; set; }
        /// <summary>
        /// Accept
        /// </summary>
        [JsonProperty("accept")]
        public string Accept { get; set; }
    }
}
