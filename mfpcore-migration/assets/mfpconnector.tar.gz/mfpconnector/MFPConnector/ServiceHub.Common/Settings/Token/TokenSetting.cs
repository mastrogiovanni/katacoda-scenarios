using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;

namespace ServiceHub.Common.Settings.Token
{
    /// <summary>
    /// Token setting.
    /// </summary>
    public class TokenSetting
    {
        /// <summary>
        /// Setting ID
        /// </summary>
        [JsonProperty("setting_id")]
        public string SettingId { get; set; }

        /// <summary>
        /// Definitions
        /// </summary>
        [JsonProperty("definitions")]
        public List<TokenDefinition> Definitions { get; set; }

        /// <summary>
        /// Current using definition
        /// </summary>
        [JsonIgnore]
        public TokenDefinition CurrentSetting
        {
            get
            {
                return Definitions.FirstOrDefault(p => p.SettingId == SettingId);
            }
        }
    }
}
