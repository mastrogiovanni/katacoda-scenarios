using Newtonsoft.Json;

namespace ServiceHub.Common.Settings.Ftp
{
    /// <summary>
    /// FTP Credential Setting
    /// </summary>
    public class FtpIiswSetting
    {
        /// <summary>
        /// Enable
        /// </summary>
        [JsonProperty("enable")]
        public string Enable { get; set; }

        /// <summary>
        /// User name
        /// </summary>
        [JsonProperty(PropertyName = "user")]
        public string UserName { get; set; }
        
        /// <summary>
        /// Password
        /// </summary>
        [JsonProperty(PropertyName = "password")]
        public string Password { get; set; }

        /// <summary>
        /// Download URL
        /// </summary>
        [JsonProperty(PropertyName = "download_url")]
        public string DownloadUrl { get; set; }

        /// <summary>
        /// Firmware file name
        /// </summary>
        [JsonProperty(PropertyName = "fw_file_name")]
        public string FwFileName { get; set; }

        /// <summary>
        /// Download polling wait time
        /// </summary>
        [JsonProperty(PropertyName = "polling_wait_time")]
        public int PollingWaitTime { get; set; }
    }
}
