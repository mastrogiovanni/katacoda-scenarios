using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;

namespace ServiceHub.Common.Settings.Ftp
{
    /// <summary>
    /// FTP Setting
    /// </summary>
    public class FtpSetting
    {
        /// <summary>
        /// Setting ID to be used
        /// </summary>
        [JsonProperty(PropertyName = "setting_id")]
        public string SettingId { get; set; }

        /// <summary>
        /// FTP Settings definitions
        /// </summary>
        [JsonProperty(PropertyName = "definitions")]
        public List<FtpDefinition> Definitions { get; set; }

        /// <summary>
        /// Current FTP Setting
        /// </summary>
        [JsonIgnore]
        public FtpDefinition CurrentSetting
        {
            get
            {
                return Definitions.FirstOrDefault(p => p.SettingId == SettingId);
            }
        }
    }
}
