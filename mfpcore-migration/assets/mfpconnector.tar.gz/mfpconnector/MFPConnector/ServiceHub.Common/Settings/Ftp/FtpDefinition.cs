using Newtonsoft.Json;

namespace ServiceHub.Common.Settings.Ftp
{
    /// <summary>
    /// FTP Setting
    /// </summary>
    public class FtpDefinition
    {
        /// <summary>
        /// Setting ID to be recognized by FTPSetting
        /// </summary>
        [JsonProperty(PropertyName = "setting_id")]
        public string SettingId { get; set; }
        
        /// <summary>
        /// Iisw
        /// </summary>
        [JsonProperty(PropertyName = "iisw")]
        public FtpIiswSetting Iisw { get; set; }
    }
}
