﻿using Newtonsoft.Json;

namespace ServiceHub.Common.Settings.MfpCore
{
    /// <summary>
    /// MFP Core settings.
    /// </summary>
    public class MfpCoreSettings
    {
        /// <summary>
        /// Service ID
        /// </summary>
        [JsonProperty("service_id")]
        public string ServiceId { get; set; }
    }
}
