﻿namespace ServiceHub.Common.Settings.Iws
{
    public class IwsScriptPath
    {
        public string RemoveFile { get; set; }
    }
}
