using Newtonsoft.Json;

namespace ServiceHub.Common.Settings.Iws
{
    /// <summary>
    /// IWS Detail Setting
    /// </summary>
    public struct IwsWebApiDetailSetting
    {
        /// <summary>
        /// Setting ID to use
        /// </summary>
        [JsonProperty(PropertyName = "setting_id")]
        public string SettingId { get; set; }
    }
}
