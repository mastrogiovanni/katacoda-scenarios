﻿namespace ServiceHub.Common.Settings.Iws
{
    public class IwsUriPath
    {
        public string WebApi { get; set; }
    }
}
