using System.Collections.Generic;
using Newtonsoft.Json;

namespace ServiceHub.Common.Settings.Iws
{
    /// <summary>
    /// IWS WebAPI Setting
    /// </summary>
    public class IwsWebApiSetting
    {
        /// <summary>
        /// Setting ID to be recognized by IWSWebAPIDetailSetting
        /// </summary>
        [JsonProperty(PropertyName = "setting_id")]
        public string SettingId { get; set; }

        /// <summary>
        /// Protocol
        /// </summary>
        public string Protocol { get; set; }

        /// <summary>
        /// MFP IP Address
        /// </summary>
        [JsonProperty(PropertyName = "ip_address")]
        public string IpAddress { get; set; }

        /// <summary>
        /// MFP TCP Port
        /// </summary>
        public ushort Port { get; set; }

        /// <summary>
        /// Application ID
        /// </summary>
        [JsonProperty(PropertyName = "app_id")]
        public string AppId { get; set; }

        /// <summary>
        /// Authentication User Name
        /// </summary>
        [JsonProperty(PropertyName = "auth_username")]
        public string AuthUserName { get; set; }

        /// <summary>
        /// Authentication Password
        /// </summary>
        [JsonProperty(PropertyName = "auth_password")]
        public string AuthPassword { get; set; }

        /// <summary>
        /// IWS Enhanced Server Authentication
        /// </summary>
        [JsonProperty(PropertyName = "enhanced_server_auth")]
        public IwsEnhancedServerAuthSetting EnhancedServerAuth { get; set; }

        /// <summary>
        /// Callback URL base
        /// </summary>
        [JsonProperty("callback_url_base")]
        public string CallbackUrlBase { get; set; }

        /// <summary>
        /// Span of timeout
        /// </summary>
        [JsonProperty(PropertyName = "callback_timeout")]
        public int CallbackTimeout { get; set; }


        /// <summary>
        /// MFP Device User Name
        /// </summary>
        [JsonProperty(PropertyName = "mfpdevice_username")]
        public string MfpUserName { get; set; }

        /// <summary>
        /// Gets or sets the URIs paths.
        /// </summary>
        public IwsUriPath UriPath { get; set; }

        /// <summary>
        /// Gets or sets the scripts paths.
        /// </summary>
        public IwsScriptPath ScriptPath { get; set; }

        /// <summary>
        /// Get admin setting
        /// </summary>
        /// <remarks>It basically clone the settings</remarks>
        /// <returns>Admin setting</returns>
        public IwsWebApiSetting GetAdmin()
        {
            return new IwsWebApiSetting
            {
                AppId = AppId,
                AuthPassword = AuthPassword,
                AuthUserName = AuthUserName,
                EnhancedServerAuth = EnhancedServerAuth,
                IpAddress = IpAddress,
                Port = Port,
                Protocol = Protocol,
                CallbackTimeout = CallbackTimeout,
                SettingId = SettingId,
                MfpUserName = MfpUserName,
                UriPath = UriPath
            };
        }

        public IList<string> IsValid()
        {
            var errors = new List<string>
            {
                !string.IsNullOrWhiteSpace(Protocol) ? null : "Protocol property cannot be null or empty.",
                !string.IsNullOrWhiteSpace(IpAddress) ? null : "IP Address property cannot be null or empty.",
                Port > 0 ? null : "Port property needs to be > 0.",
                !string.IsNullOrWhiteSpace(AppId) ? null : "AppId property cannot be null or empty.",
                AuthUserName != null ? null : "AuthUserName property cannot be null.",
                AuthPassword != null ? null : "AuthPassword property cannot be null.",
                MfpUserName != null ? null : "MfpUserName property cannot be null."
            };

            errors.RemoveAll(f => f == null);
            return errors;
        }
    }
}
