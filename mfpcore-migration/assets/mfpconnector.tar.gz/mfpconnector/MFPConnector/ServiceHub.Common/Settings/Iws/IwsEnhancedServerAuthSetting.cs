using System.Collections.Generic;
using System.ComponentModel;
using Newtonsoft.Json;

namespace ServiceHub.Common.Settings.Iws
{
    /// <summary>
    /// IWS Enhanced Server Authentication setting
    /// </summary>
    public class IwsEnhancedServerAuthSetting
    {
        /// <summary>
        /// Use flag
        /// </summary>
        [JsonProperty("use", Required = Required.Always)]
        [DefaultValue(false)]
        public bool Use { get; set; }

        /// <summary>
        /// Values
        /// </summary>
        [JsonProperty("values", Required = Required.DisallowNull)]
        public List<IwsEnhancedServerAuthValue> Values { get; set; }
    }
}