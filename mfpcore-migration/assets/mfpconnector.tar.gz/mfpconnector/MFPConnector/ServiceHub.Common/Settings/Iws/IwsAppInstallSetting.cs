using Newtonsoft.Json;

namespace ServiceHub.Common.Settings.Iws
{
    /// <summary>
    /// IWS Application install setting
    /// </summary>
    public class IwsAppInstallSetting
    {
        /// <summary>
        /// Folder path to save
        /// </summary>
        [JsonProperty("folder_path")]
        public string FolderPath { get; set; }

        /// <summary>
        /// File name to save
        /// </summary>
        [JsonProperty("file_name")]
        public string FileName { get; set; }

        /// <summary>
        /// Content-Disposition name to accept
        /// </summary>
        [JsonProperty("form_content_name")]
        public string FormContentName { get; set; }
    }
}