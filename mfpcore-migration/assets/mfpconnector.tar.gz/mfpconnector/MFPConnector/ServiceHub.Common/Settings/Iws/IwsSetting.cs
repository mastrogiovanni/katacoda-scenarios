using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;

namespace ServiceHub.Common.Settings.Iws
{
    /// <summary>
    /// IWS Setting
    /// </summary>
    public class IwsSetting
    {
        /// <summary>
        /// Setting ID to be used
        /// </summary>
        [JsonProperty(PropertyName = "setting_id")]
        public string SettingId { get; set; }

        /// <summary>
        /// IWS Settings definitions
        /// </summary>
        [JsonProperty(PropertyName = "definitions")]
        public List<IwsWebApiSetting> Definitions { get; set; }

        /// <summary>
        /// Current IWS Setting
        /// </summary>
        [JsonIgnore]
        public IwsWebApiSetting CurrentSetting
        {
            get
            {
                return Definitions.FirstOrDefault(p => p.SettingId == SettingId);
            }
        }

        /// <summary>
        /// IWS Application install setting
        /// </summary>
        [JsonProperty("app_install")]
        public IwsAppInstallSetting AppInstall { get; set; }
    }
}
