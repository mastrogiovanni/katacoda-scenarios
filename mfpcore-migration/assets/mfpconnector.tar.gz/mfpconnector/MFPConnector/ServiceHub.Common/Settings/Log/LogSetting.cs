using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Microsoft.Extensions.Logging;

namespace ServiceHub.Common.Settings.Log
{
    /// <summary>
    /// Log setting
    /// </summary>
    public class LogSetting
    {
        /// <summary>
        /// location of Log files
        /// </summary>
        [JsonProperty("path")]
        public string Path { get; set; }

        /// <summary>
        /// max numbers of log files
        /// </summary>
        [JsonProperty("max_file_count")]
        public int MaxFileCount { get; set; }

        /// <summary>
        /// max file size of each file
        /// </summary>
        [JsonProperty("max_file_size")]
        public int MaxFileSize { get; set; }

        /// <summary>
        /// Minimum level
        /// </summary>
        [JsonProperty("min_level")]
        [JsonConverter(typeof(StringEnumConverter))]
        public LogLevel MinLevel { get; set; }
    }
}

