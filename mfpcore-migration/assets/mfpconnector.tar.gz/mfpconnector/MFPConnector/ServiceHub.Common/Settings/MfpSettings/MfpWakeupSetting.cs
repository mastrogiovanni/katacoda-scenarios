﻿using System.IO;

using Microsoft.Extensions.Configuration;

using Newtonsoft.Json;

namespace ServiceHub.Common.Settings.MfpSettings
{
    public class MfpWakeupSetting
    {
        [JsonProperty("file_path")]
        public string FilePath { get; set; }

        /// <summary>
        /// MAC address.
        /// </summary>
        [JsonProperty("mac_address")]
        public string MacAddress { get; set; }

        /// <summary>
        /// Loads the specified path.
        /// </summary>
        /// <param name="path">The path.</param>
        /// <returns></returns>
        public static MfpWakeupSetting Load(string path)
        {
            var setting = JsonConvert.DeserializeObject<MfpWakeupSetting>(File.ReadAllText(path));
            return setting;
        }
    }
}