﻿using Newtonsoft.Json;

namespace ServiceHub.Common.Settings.MfpSettings
{
    /// <summary>
    /// MFP settings definition.
    /// </summary>
    public class MfpSettingsDefinition
    {
        /// <summary>
        /// Setting ID.
        /// </summary>
        [JsonProperty("setting_id")]
        public string SettingId { get; set; }
        /// <summary>
        /// Protocol.
        /// </summary>
        [JsonProperty("protocol")]
        public string Protocol { get; set; }
        /// <summary>
        /// Domain.
        /// </summary>
        [JsonProperty("domain")]
        public string Domain { get; set; }
        /// <summary>
        /// Port number.
        /// </summary>
        [JsonProperty("port")]
        public int Port { get; set; }
        /// <summary>
        /// URL path base.
        /// </summary>
        [JsonProperty("path_base")]
        public string PathBase { get; set; }
        /// <summary>
        /// URL for get mfp admin password.
        /// </summary>
        [JsonProperty("get_mfp_admin_password")]
        public string GetMfpAdminPassword { get; set; }
    }
}
