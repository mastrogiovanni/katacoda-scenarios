﻿using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;

namespace ServiceHub.Common.Settings.MfpSettings
{
    /// <summary>
    /// MFP settings setting.
    /// </summary>
    public class MfpSettingsSetting
    {
        /// <summary>
        /// Setting ID
        /// </summary>
        [JsonProperty("setting_id")]
        public string SettingId { get; set; }

        /// <summary>
        /// Definitions
        /// </summary>
        [JsonProperty("definitions")]
        public List<MfpSettingsDefinition> Definitions { get; set; }

        /// <summary>
        /// Current using definition
        /// </summary>
        [JsonIgnore]
        public MfpSettingsDefinition CurrentSetting
        {
            get
            {
                return Definitions.FirstOrDefault(p => p.SettingId == SettingId);
            }
        }
    }
}
