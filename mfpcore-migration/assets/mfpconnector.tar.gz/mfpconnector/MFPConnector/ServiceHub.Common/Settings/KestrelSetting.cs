﻿using Newtonsoft.Json;

namespace ServiceHub.Common.Settings
{
    /// <summary>
    /// Kestrel (Web server) setting
    /// </summary>
    public class KestrelSetting
    {
        /// <summary>
        /// Listening URLs
        /// </summary>
        [JsonProperty("urls")]
        public string[] Urls { get; set; }
    }
}