using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;

namespace ServiceHub.Common.Settings.Mfp
{
    public class CategoryMfpSetting
    {
        /// <summary>
        /// Setting items
        /// </summary>
        [JsonProperty(PropertyName = "setting_category")]
        public Dictionary<string, MfpSettingCategoryValue> SettingCategory { get; set; }

        /// <summary>
        /// Load setting
        /// </summary>
        /// <param name="path">Path</param>
        /// <returns>Setting object</returns>
        public static CategoryMfpSetting Load(string path)
        {
            var setting = JsonConvert.DeserializeObject<CategoryMfpSetting>(File.ReadAllText(path));
            return setting;
        }
    }
}
