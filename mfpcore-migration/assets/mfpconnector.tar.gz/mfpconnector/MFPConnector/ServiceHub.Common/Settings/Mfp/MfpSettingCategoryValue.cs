using Newtonsoft.Json;

namespace ServiceHub.Common.Settings.Mfp
{
    public class MfpSettingCategoryValue
    {
        /// <summary>
        /// Is administrator
        /// </summary>
        [JsonProperty(PropertyName = "is_admin")]
        public bool IsAdmin { get; set; }

        /// <summary>
        /// Get message
        /// </summary>
        [JsonProperty(PropertyName = "get_message")]
        public string GetMessage { get; set; }

        /// <summary>
        /// Get message tag
        /// </summary>
        [JsonProperty(PropertyName = "get_message_tag")]
        public string GetMessageTag { get; set; }

        /// <summary>
        /// Set message
        /// </summary>
        [JsonProperty(PropertyName = "set_message")]
        public string SetMessage { get; set; }

        /// <summary>
        /// Set message tag
        /// </summary>
        [JsonProperty(PropertyName = "set_message_tag")]
        public string SetMessageTag { get; set; }
    }
}
