using System.Collections.Generic;
using Newtonsoft.Json;

namespace ServiceHub.Common.Settings.Mfp
{
    public class MfpSettingItemValue
    {
        /// <summary>
        /// Data type
        /// </summary>
        [JsonProperty("datatype")]
        public string Datatype { get; set; }

        /// <summary>
        /// Request message & item
        /// </summary>
        [JsonProperty("request_msg_item")]
        public string RequestMsgItem { get; set; }

        /// <summary>
        /// Get Tag
        /// </summary>
        [JsonProperty("get_tag")]
        public string GetTag { get; set; }

        /// <summary>
        /// Set Tag
        /// </summary>
        [JsonProperty("set_tag")]
        public string SetTag { get; set; }

        /// <summary>
        /// Set Tag (Extra fixed items)
        /// </summary>
        [JsonProperty(PropertyName = "set_tag_extras", NullValueHandling = NullValueHandling.Ignore)]
        public List<MfpSettingItemValueExtra> SetTagExtra { get; set; }

        /// <summary>
        /// Setting range
        /// </summary>
        [JsonProperty("range")]
        public string Range { get; set; }

        /// <summary>
        /// Setting value
        /// </summary>
        [JsonProperty(PropertyName ="value", NullValueHandling = NullValueHandling.Ignore)]
        public string Value { get; set; }
    }
}
