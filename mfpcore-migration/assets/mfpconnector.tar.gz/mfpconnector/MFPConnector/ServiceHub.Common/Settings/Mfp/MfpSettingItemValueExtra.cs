﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace ServiceHub.Common.Settings.Mfp
{
    public class MfpSettingItemValueExtra
    {
        /// <summary>
        /// XPath
        /// </summary>
        [JsonProperty("path")]
        public string Path { get; set; }

        /// <summary>
        /// Type
        /// </summary>
        [JsonProperty("type")]
        [JsonConverter(typeof(StringEnumConverter))]
        public MfpSettingItemValueExtraType Type { get; set; }

        /// <summary>
        /// Value
        /// </summary>
        [JsonProperty(PropertyName = "value", NullValueHandling = NullValueHandling.Ignore)]
        public string Value { get; set; }
    }

    public enum MfpSettingItemValueExtraType
    {
        FixedValue,
        ArraySize,
    }
}