using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;

namespace ServiceHub.Common.Settings.Mfp
{
    public class MfpSettingItem
    {
        /// <summary>
        /// Setting items
        /// </summary>
        [JsonProperty(PropertyName = "mfp_settings")]
        public Dictionary<string, MfpSettingItemValue> AdminSettings { get; set; }

        /// <summary>
        /// Load setting
        /// </summary>
        /// <param name="path">Path</param>
        /// <returns>Setting object</returns>
        public static MfpSettingItem Load(string path)
        {
            var setting = JsonConvert.DeserializeObject<MfpSettingItem>(File.ReadAllText(path));
            return setting;
        }
    }
}
