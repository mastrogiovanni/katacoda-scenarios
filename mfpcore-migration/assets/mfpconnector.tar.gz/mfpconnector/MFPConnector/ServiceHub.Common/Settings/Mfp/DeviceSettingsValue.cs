using Newtonsoft.Json;

namespace ServiceHub.Common.Settings.Mfp
{
    /// <summary>
    /// Device Settings Value
    /// </summary>
    public class DeviceSettingsValue
    {
        /// <summary>
        /// Sleep Setting true/false (RequestItem=Power)
        /// </summary>
        [JsonProperty(PropertyName = "sleepSettings_activationSetting")]
        public string SleepSettingActivate { get; set; }

        /// <summary>
        /// Sleep Setting Timer Value (RequestItem=Power)
        /// </summary>
        [JsonProperty(PropertyName = "sleepSettings_timer_time")]
        public int SleepSettingTimer { get; set; }

        /// <summary>
        /// Localization Language (RequestItem=Panel)
        /// </summary>
        [JsonProperty(PropertyName = "localization_language")]
        public string LocalizationLanguage { get; set; }

        /// <summary>
        /// System Auto Reset Setting true/false (RequestItem=Panel)
        /// </summary>
        [JsonProperty(PropertyName = "systemAutoReset_activationSetting")]
        public string SystemAutoResetSettingActivate { get; set; }

        /// <summary>
        /// System Auto Reset Setting Timer (RequestItem=Panel)
        /// </summary>
        [JsonProperty(PropertyName = "systemAutoReset_activationSetting_timer_time")]
        public string SystemAutoResetSettingTimer { get; set; }

    }
}
