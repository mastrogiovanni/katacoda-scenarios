using Newtonsoft.Json;

namespace ServiceHub.Common.Settings.Firmware
{
    /// <summary>
    /// Firmware Setting
    /// </summary>
    public class FirmwareSetting
    {
        /// <summary>
        /// Firmware download completion notification URL.
        /// </summary>
        [JsonProperty(PropertyName = "url")]
        public string Url { get; set; }

    }
}
