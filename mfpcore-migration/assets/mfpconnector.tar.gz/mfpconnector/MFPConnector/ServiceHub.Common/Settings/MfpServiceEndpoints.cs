namespace ServiceHub.Common.Settings
{
    public class MfpServiceEndpoints
    {
        /// <summary>
        /// Gets or sets the notifying to mfp power status URI.
        /// </summary>
        public string NotifyPowerStatusUri { get; set; }
    }
}
