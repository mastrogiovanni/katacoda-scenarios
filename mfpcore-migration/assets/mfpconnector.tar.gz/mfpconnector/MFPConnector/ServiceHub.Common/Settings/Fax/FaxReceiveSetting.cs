using Newtonsoft.Json;

namespace ServiceHub.Common.Settings.Fax
{
    /// <summary>
    /// Fax Receive Setting
    /// </summary>
    public class FaxReceiveSetting
    {
        /// <summary>
        /// Abbreviation Adress Setting
        /// </summary>
        [JsonProperty(PropertyName = "abbreviation_address")]
        public AbbreviationAddressSetting AbbreviationAddress { get; set; }

        /// <summary>
        /// WebDAV Setting
        /// </summary>
        [JsonProperty(PropertyName = "webdav")]
        public WebDavSetting WebDav { get; set; }

        /// <summary>
        /// Fax Forwarding Setting
        /// </summary>
        [JsonProperty(PropertyName = "fax_forwarding")]
        public FaxForwardingSetting FaxForwarding { get; set; }
    }
}
