using Newtonsoft.Json;

namespace ServiceHub.Common.Settings.Fax
{
    /// <summary>
    /// Fax Forwarding Setting
    /// </summary>
    public class FaxForwardingSetting
    {
        /// <summary>
        /// AbbreviationAdress LineType
        /// </summary>
        [JsonProperty(PropertyName = "line_type")]
        public string LineType { get; set; }

        /// <summary>
        /// AbbreviationAdress Kind
        /// </summary>
        [JsonProperty(PropertyName = "kind")]
        public string Kind { get; set; }

        /// <summary>
        /// AbbreviationAdress TargetNo
        /// </summary>
        [JsonProperty(PropertyName = "target_no")]
        public string TargetNo { get; set; }

        /// <summary>
        /// AbbreviationAdress Condition
        /// </summary>
        [JsonProperty(PropertyName = "condition")]
        public string Condition { get; set; }

        /// <summary>
        /// AbbreviationAdress FileFormat
        /// </summary>
        [JsonProperty(PropertyName = "file_format")]
        public string FileFormat { get; set; }

        /// <summary>
        /// AbbreviationAdress OutputPageMode
        /// </summary>
        [JsonProperty(PropertyName = "output_page_mode")]
        public string OutputPageMode { get; set; }
    }
}
