using Newtonsoft.Json;

namespace ServiceHub.Common.Settings.Fax
{
    /// <summary>
    /// Abbreviation Adress Setting
    /// </summary>
    public struct AbbreviationAddressSetting
    {
        /// <summary>
        /// AbbreviationAdress AbbrNo
        /// </summary>
        [JsonProperty(PropertyName = "abbr_no")]
        public int AbbrNo { get; set; }

        /// <summary>
        /// AbbreviationAdress Name
        /// </summary>
        [JsonProperty(PropertyName = "name")]
        public string Name { get; set; }

        /// <summary>
        /// AbbreviationAdress Furigana
        /// </summary>
        [JsonProperty(PropertyName = "furigana")]
        public string Furigana { get; set; }

        /// <summary>
        /// AbbreviationAdress Language
        /// </summary>
        [JsonProperty(PropertyName = "language")]
        public string Language { get; set; }

        /// <summary>
        /// AbbreviationAdress SerchKey
        /// </summary>
        [JsonProperty(PropertyName = "search_key")]
        public string SearchKey { get; set; }

        /// <summary>
        /// AbbreviationAdress WellUse
        /// </summary>
        [JsonProperty(PropertyName = "well_use")]
        public bool WellUse { get; set; }

        /// <summary>
        /// AbbreviationAdress AddressKind
        /// </summary>
        [JsonProperty(PropertyName = "address_kind")]
        public string AddressKind { get; set; }

        /// <summary>
        /// AbbreviationAdress SendConfiguration
        /// </summary>
        [JsonProperty(PropertyName = "send_configuration")]
        public string SendConfiguration { get; set; }
    }
}
