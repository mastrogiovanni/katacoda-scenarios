using Newtonsoft.Json;

namespace ServiceHub.Common.Settings.PushNotification
{
    /// <summary>
    /// Push notification definition
    /// </summary>
    public class PushNotificationDefinition
    {
        /// <summary>
        /// Setting ID
        /// </summary>
        [JsonProperty("setting_id")]
        public string SettingId { get; set; }

        /// <summary>
        /// Protocol
        /// </summary>
        [JsonProperty("protocol")]
        public string Protocol { get; set; }

        /// <summary>
        /// Domain
        /// </summary>
        [JsonProperty("domain")]
        public string Domain { get; set; }

        /// <summary>
        /// Port
        /// </summary>
        [JsonProperty("port")]
        public int Port { get; set; }

        /// <summary>
        /// Path base
        /// </summary>
        [JsonProperty("path_base")]
        public string PathBase { get; set; }

        /// <summary>
        /// Base URL
        /// </summary>
        [JsonIgnore]
        public string BaseUrl => $"{Protocol}://{Domain}:{Port}{PathBase}";

        /// <summary>
        /// Send warning machine data path
        /// </summary>
        [JsonProperty("send_warning_machine_data_path")]
        public string SendWarningMachineDataPath { get; set; }

        /// <summary>
        /// Send warning data list path
        /// </summary>
        [JsonProperty("send_warning_data_list_path")]
        public string SendWarningDataListPath { get; set; }

        /// <summary>
        /// Send job status path
        /// </summary>
        [JsonProperty("send_job_status_path")]
        public string SendJobStatusPath { get; set; }

        /// <summary>
        /// Send init connect path
        /// </summary>
        [JsonProperty("send_init_connect_path")]
        public string SendInitConnectPath { get; set; }

        /// <summary>
        /// Send device event
        /// </summary>
        [JsonProperty("send_device_event_path")]
        public string SendDeviceEventPath { get; set; }
    }
}
