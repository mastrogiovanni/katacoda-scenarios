﻿namespace ServiceHub.Common.Settings.PushNotification
{
    /// <summary>
    /// Push notification type
    /// </summary>
    public enum PushNotificationType
    {
        MfpService
    }
}
