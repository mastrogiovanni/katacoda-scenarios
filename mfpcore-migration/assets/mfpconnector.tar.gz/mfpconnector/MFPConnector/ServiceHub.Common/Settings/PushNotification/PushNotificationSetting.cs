using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;

namespace ServiceHub.Common.Settings.PushNotification
{
    /// <summary>
    /// Push notification setting
    /// </summary>
    public class PushNotificationSetting
    {
        /// <summary>
        /// Setting ID
        /// </summary>
        [JsonProperty("setting_id")]
        public string SettingId { get; set; }

        /// <summary>
        /// Definitions
        /// </summary>
        [JsonProperty("definitions")]
        public List<PushNotificationDefinition> Definitions { get; set; }

        /// <summary>
        /// Current using definition
        /// </summary>
        [JsonIgnore]
        public PushNotificationDefinition CurrentSetting
        {
            get
            {
                return Definitions.FirstOrDefault(p => p.SettingId == SettingId);
            }
        }
    }
}