﻿using Newtonsoft.Json;

namespace ServiceHub.Common.Settings.NetworkInterface
{
    /// <summary>
    /// Network Interface settings.
    /// </summary>
    public class NetworkInterfaceSettings
    {
        /// <summary>
        /// Network Interface Name
        /// </summary>
        [JsonProperty("name")]
        public string name { get; set; }
    }
}
