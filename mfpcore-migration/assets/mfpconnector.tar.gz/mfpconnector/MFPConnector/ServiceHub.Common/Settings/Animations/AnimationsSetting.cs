using Newtonsoft.Json;

namespace ServiceHub.Common.Settings.Animations
{
    /// <summary>
    /// Animation setting.
    /// </summary>
    public class AnimationsSetting
    {
        /// <summary>
        /// Retry count.
        /// </summary>
        [JsonProperty("number_of_retries")]
        public int NumberOfRetries { get; set; }

        /// <summary>
        /// Retry count.
        /// </summary>
        [JsonProperty("waittime")]
        public int WaitTime { get; set; }

        /// <summary>
        /// Tar file path.
        /// </summary>
        [JsonProperty("tar_file_path")]
        public string TarFilePath { get; set; }

        /// <summary>
        /// Protocol
        /// </summary>
        [JsonProperty("protocol")]
        public string Protocol { get; set; }

        /// <summary>
        /// Domain
        /// </summary>
        [JsonProperty("domain")]
        public string Domain { get; set; }


        /// <summary>
        /// Tar file full path.
        /// </summary>
        [JsonIgnore]
        public string TarFileFullPath => $"{Protocol}://{Domain}/{TarFilePath}";

        /// <summary>
        /// WebDAV user ID.
        /// </summary>
        [JsonProperty("user_id")]
        public string UserId { get; set; }

        /// <summary>
        /// WebDAV password.
        /// </summary>
        [JsonProperty("password")]
        public string Password { get; set; }

    }
}
