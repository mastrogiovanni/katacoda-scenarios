using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using ServiceHub.Common.Settings;
using ServiceHub.CommonTools.Bus.Extensions;
using ServiceHub.CommonTools.Configurations;
using ServiceHub.CommonTools.Logger.Extensions;
using ServiceHub.CommonTools.WebApi.Configurations;
using ServiceHub.CommonTools.WebApi.Extensions;
using ServiceHub.Connectors.OpenAPI;
using ServiceHub.Processors.Monitoring;
using ServiceHub.Processors.Settings;
using ServiceHub.Web.MfpConnector.Extensions;
using ServiceHub.Web.MfpConnector.Filters;
using System;
using ServiceHub.Processors.Extensions;
using ServiceHub.Client.TokenProvider.Extensions;
using IHostingEnvironment = Microsoft.AspNetCore.Hosting.IHostingEnvironment;

namespace ServiceHub.Web.MfpConnector
{
    /// <summary>
    /// Startup configuration
    /// </summary>
    public class Startup
    {
        private readonly IConfigurationRoot _configuration;
        private readonly IConfigurator _configurator;

        /// <summary>
        /// Initializes a new instance of the <see cref="Startup" /> class.
        /// </summary>
        /// <param name="configuration">The configuration.</param>
        public Startup(IConfiguration configuration)
        {
            _configuration = configuration as IConfigurationRoot;
            _configurator = new Configurator(configuration)
                .SetApplicationInformation()
                .SetSwagger(f =>
                {
                    f.OperationFilter<FormFileOperationFilter>();
                })
                .SetMessagePublisher()
                .SetLogger()
                .SetMapExceptionToStatusCode()
                .SetMvc(opts => opts.Cors = true)
                .SetTokenProvider();
        }

        /// <summary>
        /// This method gets called by the runtime. Use this method to add services to the container.
        /// For more information on how to configure your application, visit https://go.microsoft.com/fwlink/?LinkID=398940
        /// </summary>
        /// <param name="services">The services.</param>
        public IServiceProvider ConfigureServices(IServiceCollection services)
        {
            services
                .AddMvcCore()
                .AddApiExplorer()
                .AddJsonFormatters()
                .AddXmlSerializerFormatters()
                .AddCors();

            services.Configure<FormOptions>(c =>
            {
                c.BufferBody = true;
            });

            _configurator.ConfigureServices(services);

            // Injection for Mfp Core Processors Project
            services.AddShMfpCoreProcessors(_configuration);

            // AppSettings configurations
            services.Configure<MfpCorePropertySettings>(_configuration.GetSection(MfpCorePropertySettings.SettingsName));

            // Background process Job
            services.AddSingleton<IHostedService, LockTaskManager>();
            services.AddSingleton<IHostedService, MfpMonitoring>();

            // Settings
            services.AddSingleton(Settings.MfpConnectorSetting);
            services.AddSingleton(Settings.MfpSettingItem);
            services.AddSingleton(Settings.CategoryMfpSetting);
            services.AddSingleton(Settings.MfpWakeupSetting);
            services.AddSingleton<IConvertAdminSettings, ConvertAdminSettings>();

            // Add Mfp Core services
            services.AddMfpCore();

            // Register headers filter.
            // (Cref: https://docs.microsoft.com/en-us/aspnet/core/mvc/controllers/filters?view=aspnetcore-2.1 also valid for core 1)
            services.AddScoped<LoggingActionFilter>();

            return services.BuildServiceProvider();
        }

        /// <summary>
        /// This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        /// </summary>
        /// <param name="app">The application.</param>
        /// <param name="env">The env.</param>
        /// <param name="loggerFactory">The logger factory.</param>
        public void Configure(IApplicationBuilder app, IHostingEnvironment env, ILoggerFactory loggerFactory)
        {
            _configurator.Configure(app, loggerFactory);

            if (env.IsDevelopment())
            {
                loggerFactory.AddDebug(LogLevel.Trace);
                app.UseDeveloperExceptionPage();
                app.UseStatusCodePages();
            }
        }
    }
}
