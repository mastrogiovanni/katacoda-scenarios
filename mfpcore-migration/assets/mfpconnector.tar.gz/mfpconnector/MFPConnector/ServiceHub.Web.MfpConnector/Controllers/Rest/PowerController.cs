using System;
using System.Net;
using System.Threading.Tasks;

using KonicaMinolta.OpenApi;

using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ServiceHub.Common.Model;
using ServiceHub.Common.Settings;
using ServiceHub.Connectors.OpenAPI.Model;
using ServiceHub.Processors.Common;
using ServiceHub.Processors.Power;
using ServiceHub.Processors.ReadyManage;
using ServiceHub.Web.MfpConnector.Controllers.Rest.Model;
using ServiceHub.Web.MfpConnector.Controllers.Utility;

namespace ServiceHub.Web.MfpConnector.Controllers.Rest
{
    /// <summary>
    /// Power controller
    /// See at
    ///   interface: https://confluence.kmiservicehub.com/display/SHS/Wake+up+MFP
    ///   sequence: https://confluence.kmiservicehub.com/display/SHS/%28Sequence%29+MFP+Sleep+Mode+Recover
    ///   interface: https://confluence.kmiservicehub.com/display/SHS/Set+Sleep+mode
    ///   sequence: https://confluence.kmiservicehub.com/display/SHS/%28Sequence%29+MFP+Sleep+Mode+Set
    /// </summary>
    [Route("api/power")]
    public class PowerController : AbstractController
    {
        private readonly IPowerOperator _powerOperator;
        private readonly IMfpReadyManage _mfpReadyManage;
        private readonly ILogger<PowerController> _logger;

        /// <summary>
        /// Initializes a new instance of the <see cref="PowerController" /> class.
        /// </summary>
        /// <param name="logger">Logger</param>
        /// <param name="mfpConnectorSetting">The MFP connector setting.</param>
        /// <param name="powerOperator">The power operator.</param>
        /// <param name="mfpReadyManage">The MFP ready manage.</param>
        public PowerController(
            ILogger<PowerController> logger,
            MfpConnectorSetting mfpConnectorSetting,
            IPowerOperator powerOperator,
            IMfpReadyManage mfpReadyManage)
            : base(mfpConnectorSetting)
        {
            _logger = logger;
            _powerOperator = powerOperator;
            _mfpReadyManage = mfpReadyManage;
        }

        /// <summary>
        /// Wakes up the MFP.
        /// </summary>
        /// <remarks>
        /// Returns "OK" if it was able to wake up and "NG" otherwise.
        /// </remarks>
        /// <returns>
        /// HttpResponse
        /// </returns>
        [HttpPost("wakeup")]
        [ProducesResponseType(typeof(PowerControllerResult), (int)HttpStatusCode.Created)]
        [ProducesResponseType(typeof(ExceptionMessage), (int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> WakeUp()
        {
            try
            {
                var result = await _powerOperator.WakeUpToMfpAsync();
                if (result)
                {
                    _mfpReadyManage.Resume();
                }

                return JsonResponseCreator.Create(new PowerControllerResult(result), HttpStatusCode.Created);
            }
            catch (Exception e)
            {
                _logger.LogError(default(EventId), e, "Exception occurred during waking up MFP.");
                return JsonResponseCreator.CreateException(e, HttpStatusCode.InternalServerError);
            }
        }

        /// <summary>
        /// Sets the MFP power mode.
        /// </summary>
        /// <param name="powerMode">The MFP power mode.</param>
        /// <returns>
        /// Http response
        /// </returns>
        /// <remarks>
        /// Sets the MFP power mode.
        /// </remarks>
        [HttpPost("sleep")]
        [ProducesResponseType(typeof(PowerControllerResult), (int) HttpStatusCode.Created)]
        [ProducesResponseType(typeof(PowerControllerResult), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ExceptionMessage), (int) HttpStatusCode.ServiceUnavailable)]
        [ProducesResponseType(typeof(ExceptionMessage), (int) HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> Sleep([FromBody] PowerModeRequest powerMode)
        {
            var status = HttpStatusCode.Created;
            var response = new PowerControllerResult
            {
                Result = SenderConfig.IwsResultStatus.OK.ToString()
            };

            if (!Valid(powerMode))
            {
                status = HttpStatusCode.BadRequest;
                response.Result = SenderConfig.IwsResultStatus.NG.ToString();
                return JsonResponseCreator.Create(response, status);
            }

            try
            {
                _mfpReadyManage.Pause();

               
                    string resultInfo =
                        await _powerOperator.ChangePowerModeAsync(powerMode.PowerMode.GetValueOrDefault());
                    response.Result = resultInfo == "Ack"
                        ? SenderConfig.IwsResultStatus.OK.ToString()
                        : SenderConfig.IwsResultStatus.NG.ToString();
               
                return JsonResponseCreator.Create(response, status);

            }
            catch (OpenApiFaultException ex) when (
                ex.FaultMessage.ErrorDescription.Equals(RestControllerConst.ErrorDescriptionReqChangePowerSaveStatusInIdle)
            )
            {
                _logger.LogError(default(EventId), ex, ex.FaultMessage.ToString());
                _mfpReadyManage.Resume();
                response.Result = SenderConfig.IwsResultStatus.NG.ToString();
                return JsonResponseCreator.Create(response, HttpStatusCode.ServiceUnavailable);
            }
            catch (OpenApiFaultException e)
            {
                _logger.LogError(default(EventId), e, "Exception occurred while changing power mode.");
                _mfpReadyManage.Resume();
                response.Result = SenderConfig.IwsResultStatus.NG.ToString();
                return JsonResponseCreator.Create(response, HttpStatusCode.InternalServerError);
            }
            catch (Exception e)
            {
                _logger.LogError(default(EventId), e, "Exception occurred during making MFP sleep.");
                _mfpReadyManage.Resume();
                response.Result = SenderConfig.IwsResultStatus.NG.ToString();
                return JsonResponseCreator.CreateException(e, HttpStatusCode.InternalServerError);
            }
        }

        /// <summary>
        /// Check request validity.
        /// </summary>
        /// <param name="request">Request</param>
        /// <returns>
        /// Request is valid
        /// </returns>
        private static bool Valid(PowerModeRequest request)
        {
            return request?.PowerMode != null
                && Enum.IsDefined(typeof(PowerMode), request.PowerMode)
                && request.PowerMode != PowerMode.Unidentified;
        }
    }
}
