using System.Collections.Generic;
using Newtonsoft.Json;

namespace ServiceHub.Web.MfpConnector.Controllers.Rest.Model
{
    /// <summary>
    /// MFP settings get request
    /// </summary>
    public class MfpSettingsGetRequest
    {
        /// <summary>
        /// Setting names.
        /// </summary>
        [JsonProperty("setting_names")]
        public List<string> SettingNames { get; set; }
    }
}