using System;
using System.IO;
using System.Net;
using System.Threading.Tasks;

using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ServiceHub.Common.Model;
using ServiceHub.Common.Settings;
using ServiceHub.Connectors.IWS;
using ServiceHub.Processors.Common;
using ServiceHub.Processors.Iws.Model;
using ServiceHub.Processors.Power;
using ServiceHub.Web.MfpConnector.Controllers.Rest.Model;

namespace ServiceHub.Web.MfpConnector.Controllers.Rest.Iws
{
    /// <summary>
    /// Internal Web Server (IWS) controller.
    /// </summary>
    [Route("api/iws")]
    public class IwsController : AbstractController
    {
        private readonly IPowerOperator _powerOperator;
        private readonly IMfpSender<IwsServiceSetting, IwsServiceResult> _iwsSettingSender;
        private readonly ILogger<IwsController> _logger;

        /// <summary>
        /// Initializes a new instance of the <see cref="IwsController" /> class.
        /// </summary>
        /// <param name="logger">Logger</param>
        /// <param name="mfpConnectorSetting">The MFP connector setting.</param>
        /// <param name="powerOperator">The power operator.</param>
        /// <param name="iwsServiceSettingSender">The iws service setting sender.</param>
        public IwsController(
            ILogger<IwsController> logger,
            MfpConnectorSetting mfpConnectorSetting,
            IPowerOperator powerOperator,
            IMfpSender<IwsServiceSetting, IwsServiceResult> iwsServiceSettingSender)
            : base(mfpConnectorSetting)
        {
            _logger = logger;
            _powerOperator = powerOperator;
            _iwsSettingSender = iwsServiceSettingSender;
        }

        /// <summary>
        /// Creates a job on the MFP device.
        /// </summary>
        /// <param name="authenticationCode">The authentication code.</param>
        /// <returns>
        /// Returns the created details containing information such as the job id result and status.
        /// </returns>
        /// <remarks>
        /// Returns the created details containing information such as the job id result and status.
        /// </remarks>
        [HttpPost("")]
        [ProducesResponseType(typeof(IwsControllerResult), (int)HttpStatusCode.Created)]
        [ProducesResponseType(typeof(IwsControllerResult), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(IwsControllerResult), (int)HttpStatusCode.ServiceUnavailable)]
        [ProducesResponseType(typeof(IwsControllerResult), (int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> ExecuteJob([FromHeader(Name = "auth-parameter")]string authenticationCode)
        {
            var content = string.Empty;
            var requestObj = new IwsServiceSetting();
            try
            {
                var jobSettings = string.Empty;
                var stream = HttpContext.Request.Body;
                using (var reader = new StreamReader(stream))
                {
                    jobSettings = reader.ReadToEnd();
                }

                if (string.IsNullOrWhiteSpace(jobSettings))
                {
                    throw new ArgumentException("Null or whitespace.", nameof(jobSettings));
                }

                requestObj.JobSettings = jobSettings;
                requestObj.AuthParameter = new AuthParameter
                {
                    Code = authenticationCode
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(default(EventId), ex, $"Exception occurred during parsing job.{ex.Message}");

                return BadRequest(new IwsControllerResult
                {
                    Result = SenderConfig.IwsResultStatus.NG.ToString(),
                    Error = string.Format(RestControllerConst.ResponseErrorInvalidParameter, content)
                });
            }

            var mfpWakeupResult = await SendMfpWakeupAsync().ConfigureAwait(false);

            return mfpWakeupResult ?? await GetControllerResultAsync(requestObj).ConfigureAwait(false);
        }

        /// <summary>
        /// Send wakeups to MFP asynchronous.
        /// </summary>
        /// <returns></returns>
        private async Task<IActionResult> SendMfpWakeupAsync()
        {
            try
            {
                var resultMfp = await _powerOperator.WakeUpToMfpAsync();
                if (!resultMfp)
                {
                    return InternalServerError(new IwsControllerResult
                    {
                        Result = SenderConfig.IwsResultStatus.NG.ToString(),
                        Error = RestControllerConst.ResponseErrorWakeUp
                    });
                }

                return null;
            }
            catch (Exception ex)
            {
                _logger.LogError(default(EventId), ex, $"Exception occurred during waking up.{ex.Message}");
                return InternalServerError(new IwsControllerResult
                {
                    Result = SenderConfig.IwsResultStatus.NG.ToString(),
                    Error = new ExceptionMessage(ex).ToString()
                });
            }
        }

        /// <summary>
        /// Gets the controller result.
        /// </summary>
        /// <param name="iwsServiceRequest">The request object.</param>
        /// <returns></returns>
        private async Task<IActionResult> GetControllerResultAsync(IwsServiceSetting iwsServiceRequest)
        {
            try
            {
                var result = await _iwsSettingSender.SendToMfpAsync(iwsServiceRequest).ConfigureAwait(false);
                var errorMessage = result.Error;

                var response = new IwsControllerResult
                {
                    Result = result.Result,
                    JobId = result.JobId,
                    Error = GerError(result.Error)
                };

                return ControllerResult(response, result.Result, errorMessage);
            }
            catch (IwsException ex)
            {
                _logger.LogError(default(EventId), ex, $"IwsException occurred during copy job. {ex.Message}");

                var iwsControllerResult = new IwsControllerResult
                {
                    Result = SenderConfig.IwsResultStatus.NG.ToString(),
                    Error = IwsException.IwsErrorFatal
                };

                return ControllerResult(iwsControllerResult, iwsControllerResult.Result, ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(default(EventId), ex, $"Exception occurred during executing job. {ex.Message}");
                return InternalServerError(new IwsControllerResult
                {
                    Result = SenderConfig.IwsResultStatus.NG.ToString(),
                    Error = new ExceptionMessage(ex).ToString()
                });
            }
        }
    }
}
