using Newtonsoft.Json;

namespace ServiceHub.Web.MfpConnector.Controllers.Rest.Model
{
    /// <summary>
    /// Animations result.
    /// </summary>
    public class AnimationsControllerResult : IResponseModel
    {
        /// <summary>Animation rom version.</summary>
        [JsonProperty(PropertyName = "animation_rom_version")]
        public string AnimationRomVersion { get; set; }

        /// <summary>Animation rom version.</summary>
        [JsonProperty(PropertyName = "serial_number")]
        public string SerialNumber { get; set; }
    }
}