using System;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ServiceHub.Common.Model;
using ServiceHub.Common.Settings;
using ServiceHub.CommonTools.Validations;
using ServiceHub.CommonTools.WebApi.DTOs;
using ServiceHub.Processors.Common;
using ServiceHub.Processors.Setup;
using ServiceHub.Web.MfpConnector.Controllers.Rest.Model;
using ServiceHub.Web.MfpConnector.Controllers.Utility;

namespace ServiceHub.Web.MfpConnector.Controllers.Rest
{
    /// <summary>
    /// MFP firmware controller
    /// Cref: https://confluence.kmiservicehub.com/pages/viewpage.action?pageId=23167271
    /// </summary>
    [Route("api/firmware/mfp")]
    public class MfpFirmwareController : AbstractController
    {
        private readonly IFirmwareOperator _firmwareOperator;
        private readonly ILogger<MfpFirmwareController> _logger;

        /// <summary>
        /// Initializes a new instance of the <see cref="MfpFirmwareController" /> class.
        /// </summary>
        /// <param name="logger">Logger</param>
        /// <param name="mfpConnectorSetting">The MFP connector setting.</param>
        /// <param name="firmwareOperator">The firmware operator.</param>
        public MfpFirmwareController(
            ILogger<MfpFirmwareController> logger, 
            MfpConnectorSetting mfpConnectorSetting, 
            IFirmwareOperator firmwareOperator)
            : base(mfpConnectorSetting)
        {
            _logger = logger;
            _firmwareOperator = firmwareOperator;
        }

        /// <summary>
        /// Downloads the requested MFP firmware.
        /// </summary>
        /// <param name="firmware">The firmware.</param>
        /// <returns>
        /// HttpResponse
        /// </returns>
        /// <remarks>
        /// Downloads the requested MFP firmware.
        /// </remarks>
        [HttpPost("download")]
        [ProducesResponseType(typeof(MfpFirmwareControllerResult), (int)HttpStatusCode.Created)]
        [ProducesResponseType(typeof(ErrorResult), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(MfpFirmwareControllerResult), (int)HttpStatusCode.InternalServerError)]
        [ProducesResponseType(typeof(ExceptionMessage), (int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> Download([FromBody] MfpFirmwareControllerResponse firmware)
        {
            Check.NullArgument(firmware, nameof(firmware));
            Check.EmptyOrWhiteSpaceArgument(firmware.Filename, nameof(firmware.Filename));

            var response = new MfpFirmwareControllerResult();

            try
            {
                var success = await _firmwareOperator.LetDownloadMfpFirmwareAsync(firmware.Filename);
                if (!success)
                {
                    response.Result = SenderConfig.IwsResultStatus.NG.ToString();
                    return JsonResponseCreator.Create(response, HttpStatusCode.InternalServerError);
                }

                response.Result = SenderConfig.IwsResultStatus.OK.ToString();
                return JsonResponseCreator.Create(response, HttpStatusCode.Created);
            }
            catch (Exception e)
            {
                _logger.LogError(default(EventId), e, "Occurs unexpected error download.");
                response.Result = SenderConfig.IwsResultStatus.NG.ToString();
                return JsonResponseCreator.Create(response, HttpStatusCode.InternalServerError);
            }
        }

        /// <summary>
        /// Updates the MFP firmware.
        /// </summary>
        /// <remarks>
        /// Updates the MFP firmware.
        /// </remarks>
        /// <returns>
        /// HttpResponse
        /// </returns>
        [HttpPut("update")]
        [ProducesResponseType(typeof(MfpFirmwareControllerResult), (int)HttpStatusCode.Created)]
        [ProducesResponseType(typeof(MfpFirmwareControllerResult), (int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> Update()
        {
            var response = new MfpFirmwareControllerResult();

            try
            {
                var success = await _firmwareOperator.UpdateFirmwareAsync();
                if (!success)
                {
                    _logger.LogWarning("Occurs unexpected error update.");
                    response.Result = SenderConfig.IwsResultStatus.NG.ToString();
                    return JsonResponseCreator.Create(response, HttpStatusCode.InternalServerError);
                }

                response.Result = SenderConfig.IwsResultStatus.OK.ToString();
                return JsonResponseCreator.Create(response, HttpStatusCode.Created);
            }
            catch (Exception e)
            {
                _logger.LogError(default(EventId), e, "Occurs unexpected error update.");
                response.Result = SenderConfig.IwsResultStatus.NG.ToString();
                return JsonResponseCreator.Create(response, HttpStatusCode.InternalServerError);
            }
        }
    }
}
