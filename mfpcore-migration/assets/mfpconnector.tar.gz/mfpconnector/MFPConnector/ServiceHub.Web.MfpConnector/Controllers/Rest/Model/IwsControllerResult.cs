using Newtonsoft.Json;

namespace ServiceHub.Web.MfpConnector.Controllers.Rest.Model
{
    /// <summary>
    /// Copy result
    /// </summary>
    public class IwsControllerResult : IResponseModel
    {
        /// <summary>Result type string.</summary>
        [JsonProperty(PropertyName = "result")]
        public string Result { get; set; }

        /// <summary>Error detail string.</summary>
        [JsonProperty(PropertyName = "error")]
        public string Error { get; set; }

        /// <summary>Job ID.</summary>
        [JsonProperty(PropertyName = "mfp_job_id")]
        public int? JobId { get; set; }
    }
}