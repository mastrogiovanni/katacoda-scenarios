using KonicaMinolta.OpenApi;
using Microsoft.AspNetCore.Mvc;
using ServiceHub.Common.Model;
using ServiceHub.Connectors.OpenAPI.Exceptions;
using ServiceHub.Processors.Job;
using ServiceHub.Processors.Job.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using ServiceHub.Common.Settings;
using ServiceHub.Web.MfpConnector.Controllers.Utility;

namespace ServiceHub.Web.MfpConnector.Controllers.Rest.Jobs
{
    /// <summary>
    /// Jobs status controller.
    /// </summary>
    [Route("api/jobs")]
    public class JobsController : AbstractController
    {
        private const string ParseErrorJobId = "cannot parse from string to int(jobId)";
        private const string NotFoundJob = "No job was found";

        private readonly IJobOperator _jobOperator;
        private readonly ILogger<JobsController> _logger;

        /// <summary>
        /// Initializes a new instance of the <see cref="JobsController" /> class.
        /// </summary>
        /// <param name="logger">Logger</param>
        /// <param name="mfpConnectorSetting">The MFP connector setting.</param>
        /// <param name="jobOperator">The job operator.</param>
        public JobsController(ILogger<JobsController> logger, MfpConnectorSetting mfpConnectorSetting, IJobOperator jobOperator)
            : base(mfpConnectorSetting)
        {
            _logger = logger;
            _jobOperator = jobOperator;
        }

        /// <summary>
        /// Gets all available MFP jobs.
        /// </summary>
        /// <returns>No content if none, one item if one, a list if many.</returns>
        /// <remarks>Returns no content if no job is found, one job details if only one found and a list of job details if many.</remarks>
        [HttpGet("")]
        [ProducesResponseType(typeof(MfpJobResponse), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(List<MfpJobResponse>), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NoContent)]
        [ProducesResponseType((int)HttpStatusCode.NotFound)]
        [ProducesResponseType(typeof(ExceptionMessage), (int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> Get()
        {
            try
            {
                // Get active jobs status
                var content = await _jobOperator.GetJobsAsync(null);

                // Update response code
                if (content == null || !content.Any())
                {
                    return NoContent();
                }

                return content.Count() == 1 ? Ok(content.First()) : Ok(content);
            }
            catch (OpenApiFaultException)
            {
                return NotFound();
            }
            catch (Exception ex)
            {
                return JsonResponseCreator.CreateException(ex, HttpStatusCode.InternalServerError);
            }
        }

        /// <summary>
        /// Gets a specific MFP job details.
        /// </summary>
        /// <param name="id">Job identifier from the MFP device.</param>
        /// <returns>
        /// Returns the details from a specific job identifier.
        /// </returns>
        /// <remarks>Returns the details from a specific job identifier.</remarks>
        [HttpGet("{id}")]
        [ProducesResponseType(typeof(List<MfpJobResponse>), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(JsonResponseCreator.JsonErrorMessage), (int)HttpStatusCode.NotFound)]
        [ProducesResponseType(typeof(ExceptionMessage), (int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> Get(string id)
        {
            try
            {
                if (ulong.TryParse(id, out var jobId))
                {
                    // Get specified job status
                    var content = await _jobOperator.GetJobsAsync(jobId);

                    // Update response code
                    if (content == null || !content.Any())
                    {

                        return NotFound(NotFoundJob);
                    }

                    return Ok(content.First());
                }

                _logger.LogWarning(ParseErrorJobId);
                return NotFound(ParseErrorJobId);
            }
            catch (OpenApiFaultException)
            {
                return NotFound();
            }
            catch (Exception ex)
            {
                return JsonResponseCreator.CreateException(ex, HttpStatusCode.InternalServerError);
            }
        }

        /// <summary>
        /// Gets the MPF jobs history.
        /// </summary>
        /// <returns>Returns an history list of job details.</returns>
        /// <remarks>Returns an history list of job details.</remarks>
        [HttpGet("history")]
        [ProducesResponseType(typeof(List<MfpJobResponse>), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NoContent)]
        [ProducesResponseType(typeof(ExceptionMessage), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ExceptionMessage), (int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> History()
        {
            try
            {
                var content = await _jobOperator.GetJobHistoryAsync();

                // Update response code
                if (content == null || !content.Any())
                {
                    return NoContent();
                }

                return Ok(content);
            }
            catch (OpenApiRequestException openApiEx)
            {
                _logger.LogError(default(EventId), openApiEx, openApiEx.Message);

                return BadRequest(openApiEx);
            }
            catch (OpenApiFaultException oapFaltEx)
            {
                _logger.LogError(default(EventId), oapFaltEx, oapFaltEx.FaultMessage.ToString());
                return NotFound();
            }
            catch (Exception ex)
            {
                _logger.LogError(default(EventId), ex, "Exception occurred during job history.");
                return JsonResponseCreator.CreateException(ex, HttpStatusCode.InternalServerError);
            }
        }

        /// <summary>
        /// Deletes a specific MFP job.
        /// </summary>
        /// <param name="id">Job identifier from the MFP device.</param>
        /// <param name="jobsManipulateRequest">The request body.</param>
        /// <returns>
        /// No content if successfull.
        /// </returns>
        /// <remarks>Delete the requested job identifier using the provided authorization parameters.</remarks>
        [HttpDelete("{id}")]
        [ProducesResponseType((int)HttpStatusCode.NoContent)]
        [ProducesResponseType(typeof(ExceptionMessage), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType((int)HttpStatusCode.Forbidden)]
        [ProducesResponseType((int)HttpStatusCode.NotFound)]
        [ProducesResponseType(typeof(ExceptionMessage), (int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> Delete([FromRoute] string id, [FromBody] JobsManipulateRequest jobsManipulateRequest)
        {
            try
            {
                if (!await _jobOperator.DeleteJobAsync(id, jobsManipulateRequest?.AuthParameter?.Code ?? ""))
                {
                    return NotFound();
                }

                return NoContent();
            }
            catch (OpenApiRequestException openApiEx)
            {
                _logger.LogError(default(EventId), openApiEx, openApiEx.Message);
                return BadRequest(openApiEx);
            }
            catch (OpenApiFaultException oapFaltEx) when (oapFaltEx.FaultMessage.FaultCode.Equals(
                                                            SoapFaultCode.Client) &&
                                                          oapFaltEx.FaultMessage.FaultString.Equals("Client Error") &&
                                                          oapFaltEx.FaultMessage.FaultRequest
                                                              .Equals("AppReqDeleteJob") &&
                                                          oapFaltEx.FaultMessage.ErrorDetails.Equals(
                                                              "AuthNotAllowedAuthSetting")
            )
            {
                _logger.LogError(default(EventId), oapFaltEx, oapFaltEx.FaultMessage.ToString());
                return JsonResponseCreator.CreateException(oapFaltEx, HttpStatusCode.Forbidden);
            }
            catch (Exception ex)
            {
                _logger.LogError(default(EventId), ex, "Exception occurred during delete job.");
                return JsonResponseCreator.CreateException(ex, HttpStatusCode.InternalServerError);
            }
        }

        /// <summary>
        /// Delete all active jobs.
        /// </summary>
        /// <returns>
        /// No content if successfull.
        /// </returns>
        /// <remarks>Since it will not be called from the FE, the authentication parameters is not included.</remarks>
        [HttpDelete]
        [ProducesResponseType((int)HttpStatusCode.NoContent)]
        public async Task<IActionResult> DeleteAllActiveJobsAsync()
        {
            // TODO This returns success = true/false and we should return different code when not succesfull
            await _jobOperator.DeleteAllActiveJobsAsync();

            return NoContent();
        }
    }
}
