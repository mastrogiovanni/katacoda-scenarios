using System.Linq;
using System.Net;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ServiceHub.Common.Model;
using ServiceHub.Common.Settings;
using ServiceHub.Connectors.OpenAPI.Model;
using ServiceHub.Processors.Common;
using ServiceHub.Processors.Settings;
using ServiceHub.Web.MfpConnector.Controllers.Rest.Model;
using ServiceHub.Web.MfpConnector.Controllers.Utility;

namespace ServiceHub.Web.MfpConnector.Controllers.Rest.Settings
{
    /// <summary>
    /// Settings controller
    /// Cref: https://confluence.kmiservicehub.com/pages/viewpage.action?pageId=23167271
    /// </summary>
    [Route("api/settings/admin")]
    public class NetworkSettingsController : AbstractController
    {
        private const string Ipv4Text =
            "^(([1-9]?[0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5]).){3}([1-9]?[0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$";

        private const string Ipv6Text =
                "^((([0-9A-Fa-f]{1,4}:){7}([0-9A-Fa-f]{1,4}|:))|(([0-9A-Fa-f]{1,4}:){6}(:[0-9A-Fa-f]{1,4}|((25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)(.(25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)){3})|:))|(([0-9A-Fa-f]{1,4}:){5}(((:[0-9A-Fa-f]{1,4}){1,2})|:((25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)(.(25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)){3})|:))|(([0-9A-Fa-f]{1,4}:){4}(((:[0-9A-Fa-f]{1,4}){1,3})|((:[0-9A-Fa-f]{1,4})?:((25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)(.(25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){3}(((:[0-9A-Fa-f]{1,4}){1,4})|((:[0-9A-Fa-f]{1,4}){0,2}:((25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)(\\.(25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){2}(((:[0-9A-Fa-f]{1,4}){1,5})|((:[0-9A-Fa-f]{1,4}){0,3}:((25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)(\\.(25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){1}(((:[0-9A-Fa-f]{1,4}){1,6})|((:[0-9A-Fa-f]{1,4}){0,4}:((25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)(\\.(25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)){3}))|:))|(:(((:[0-9A-Fa-f]{1,4}){1,7})|((:[0-9A-Fa-f]{1,4}){0,5}:((25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)(\\.(25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)){3}))|:)))(%.+)?$"
            ;

        private readonly ISettingsOperator _settingsOperator;

        /// <summary>
        /// Initializes a new instance of the <see cref="NetworkSettingsController" /> class.
        /// </summary>
        /// <param name="mfpConnectorSetting">The MFP connector setting.</param>
        /// <param name="settingsOperator">The settings operator.</param>
        public NetworkSettingsController(MfpConnectorSetting mfpConnectorSetting, ISettingsOperator settingsOperator)
            : base(mfpConnectorSetting)
        {
            _settingsOperator = settingsOperator;
        }

        /// <summary>
        /// Notifies the ip address to the MFP device.
        /// </summary>
        /// <remarks>
        /// Notifies the ip address to the MFP device.
        /// </remarks>
        /// <param name="networkSettingsRequest">The network settings request.</param>
        /// <returns>
        /// HttpResponse
        /// </returns>
        [HttpPost("device/network/tcpip")]
        [ProducesResponseType(typeof(SettingsControllerResult), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(SettingsControllerResult), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ExceptionMessage), (int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> NotifyIpAddress([FromBody] NetworkSettingsRequest networkSettingsRequest)
        {
            var status = HttpStatusCode.OK;
            var response = new SettingsControllerResult
            {
                Result = SenderConfig.IwsResultStatus.OK.ToString()
            };

            if (!ValidateNetworkSettingsRequest(networkSettingsRequest))
            {
                status = HttpStatusCode.BadRequest;
                response.Result = SenderConfig.IwsResultStatus.NG.ToString();
                return JsonResponseCreator.Create(response, status);
            }

            if (networkSettingsRequest?.IpAddressV4 != null)
            {
                // Request Ipv4
                var resultIpv4 = await _settingsOperator.NotifyDeviceNetworkSettingAsync(IpAddressType.IPv4,
                    networkSettingsRequest.IpAddressV4, Ipv6Type.Unidentified);
                status = GetStatusCode(resultIpv4.Status);

                if (status != HttpStatusCode.OK)
                {
                    response.Result = SenderConfig.IwsResultStatus.NG.ToString();
                    return JsonResponseCreator.Create(response, status);
                }
            }

            if (networkSettingsRequest?.IpAddressV6 != null)
            {
                // Request Ipv6
                var resultIpv6 = await _settingsOperator.NotifyDeviceNetworkSettingAsync(IpAddressType.IPv6,
                    networkSettingsRequest.IpAddressV6, networkSettingsRequest.IpV6Type);
                status = GetStatusCode(resultIpv6.Status);

                if (status != HttpStatusCode.OK)
                {
                    response.Result = SenderConfig.IwsResultStatus.NG.ToString();
                    return JsonResponseCreator.Create(response, status);
                }
            }

            response.Result = SenderConfig.IwsResultStatus.OK.ToString();
            return JsonResponseCreator.Create(response, status);
        }

        private HttpStatusCode GetStatusCode(string statusName)
        {
            switch (statusName)
            {
                case "BadRequest":
                    return HttpStatusCode.BadRequest;
                case "ServerError":
                    return HttpStatusCode.InternalServerError;
                case "Timeout":
                    return HttpStatusCode.GatewayTimeout;
                default:
                    return HttpStatusCode.OK;
            }
        }

        private bool ValidateNetworkSettingsRequest(NetworkSettingsRequest request)
        {
            if (request == null || !ValidateIpAddress(request))
            {
                return false;
            }

            return Ipv6Type.Local == request.IpV6Type || Ipv6Type.Global == request.IpV6Type;
        }

        private bool ValidateIpAddress(NetworkSettingsRequest request)
        {
            if ((string.IsNullOrEmpty(request.IpAddressV4) && string.IsNullOrEmpty(request.IpAddressV6))
                || (!string.IsNullOrEmpty(request.IpAddressV4) && !ValidateIpAddressMatch(request.IpAddressV4, true))
                || (!string.IsNullOrEmpty(request.IpAddressV6) && !ValidateIpAddressMatch(request.IpAddressV6, false)))
            {
                return false;
            }

            return true;
        }

        private bool ValidateIpAddressMatch(string address, bool isVersion4)
        {
            var regIpV4 = new Regex(Ipv4Text);
            var regIpV6 = new Regex(Ipv6Text);

            if ((isVersion4 && (!regIpV4.Match(address).Success || address.Count(v => v == '.') != 3))
                || (!isVersion4 && (!regIpV6.Match(address).Success || address.Count(v => v == ':') != 7 || address.Contains("::")))
                )
            {
                return false;
            }

            return true;
        }
    }
}
