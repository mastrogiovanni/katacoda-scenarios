using System;
using System.Net;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ServiceHub.Common.DeviceState;
using ServiceHub.Common.Model;
using ServiceHub.Common.Settings;
using ServiceHub.Web.MfpConnector.Controllers.Rest.Model;
using ServiceHub.Web.MfpConnector.Controllers.Utility;

namespace ServiceHub.Web.MfpConnector.Controllers.Rest
{
    /// <summary>
    /// Alive controller.
    /// </summary>
    [Route("api/alive")]
    public class AliveController : AbstractController
    {
        private readonly IDeviceStateContext _deviceStateContext;
        private readonly ILogger<AliveController> _logger;

        /// <summary>
        /// Initializes a new instance of the <see cref="AliveController" /> class.
        /// </summary>
        /// <param name="logger">Logger</param>
        /// <param name="mfpConnectorSetting">The MFP connector setting.</param>
        /// <param name="deviceStateContext">The device state context.</param>
        public AliveController(
            ILogger<AliveController> logger,
            MfpConnectorSetting mfpConnectorSetting,
            IDeviceStateContext deviceStateContext)
            : base(mfpConnectorSetting)
        {
            _deviceStateContext = deviceStateContext;
            _logger = logger;
        }

        /// <summary>
        /// Gets the MFP running state.
        /// </summary>
        /// <returns>True when usable</returns>
        /// <remarks>Returns if the MFP device is alive and ready to be used.</remarks>
        [HttpGet("")]
        [ProducesResponseType(typeof(MfpStateResult), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ExceptionMessage), (int)HttpStatusCode.InternalServerError)]
        public IActionResult Get()
        {
            try
            {
                var result = new MfpStateResult
                {
                    Alive = _deviceStateContext.Usable
                };

                return JsonResponseCreator.Create(result, HttpStatusCode.OK);
            }
            catch (Exception ex)
            {
                _logger.LogError(default(EventId), ex, "Exception occurred during get mf startup state.");
                return JsonResponseCreator.CreateException(ex, HttpStatusCode.InternalServerError);
            }
        }
    }
}
