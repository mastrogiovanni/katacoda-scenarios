using System.Collections.Generic;
using Newtonsoft.Json;
using ServiceHub.Processors.Settings.Model;

namespace ServiceHub.Web.MfpConnector.Controllers.Rest.Model
{
    /// <summary>
    /// Admin settings response
    /// </summary>
    public class AdminSettingsResponse : IResponseModel
    {
        /// <summary>
        /// Settins value
        /// </summary>
        [JsonProperty(PropertyName = "setting_values")]
        public List<SettingValue> SettingValues { get; set; }
    }
}
