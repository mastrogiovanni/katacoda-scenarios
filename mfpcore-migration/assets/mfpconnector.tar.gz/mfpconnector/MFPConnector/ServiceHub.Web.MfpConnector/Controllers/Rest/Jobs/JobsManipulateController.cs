using System;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ServiceHub.Common.Model;
using ServiceHub.Common.Settings;
using ServiceHub.Connectors.OpenAPI.Exceptions;
using ServiceHub.Processors.Common;
using ServiceHub.Processors.Job;
using ServiceHub.Processors.Job.Model;
using ServiceHub.Web.MfpConnector.Controllers.Rest.Model;
using OpenApiNackException = KonicaMinolta.OpenApi.OpenApiNackException;
using Microsoft.Extensions.Logging;
using ServiceHub.Web.MfpConnector.Controllers.Utility;

namespace ServiceHub.Web.MfpConnector.Controllers.Rest.Jobs
{
    /// <summary>
    /// Job restart controller
    /// </summary>
    [Route("api/jobs")]
    public class JobsManipulateController : AbstractController
    {
        private static readonly ManualResetEventSlim ManualResetEvent = new ManualResetEventSlim();
        private static JobsManipulateControllerResult _responseManipulate;

        private readonly IMfpSender _mfpSender;
        private readonly IJobOperator _jobOperator;
        private readonly ILogger<JobsManipulateController> _logger;

        /// <summary>
        /// Initializes a new instance of the <see cref="JobsManipulateController" /> class
        /// </summary>
        /// <param name="logger">Logger</param>
        /// <param name="mfpConnectorSetting">The MFP connector setting.</param>
        /// <param name="jobRedialSender">The job redial sender.</param>
        /// <param name="jobOperator">The job operator.</param>
        public JobsManipulateController(
            ILogger<JobsManipulateController> logger,
            MfpConnectorSetting mfpConnectorSetting,
            IJobRedialSender jobRedialSender,
            IJobOperator jobOperator)
            : base(mfpConnectorSetting)
        {
            _logger = logger;
            _mfpSender = jobRedialSender;
            _jobOperator = jobOperator;
            _responseManipulate = new JobsManipulateControllerResult();
        }

        /// <summary>
        /// Manipulates the MFP job (Redial or Restart).
        /// </summary>
        /// <param name="id">Job identifier from the MFP device</param>
        /// <param name="requestObj">Request object</param>
        /// <returns>HTTP response</returns>
        /// <remarks>Manipulate the MFP job (Redial or Restart).</remarks>
        [HttpPut("{id}")]
        [ProducesResponseType(typeof(JobsManipulateControllerResult), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(JobsManipulateControllerResult), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ExceptionMessage), (int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> Manipulate([FromRoute] string id, [FromBody] JobsManipulateRequest requestObj)
        {
            IActionResult res;

            try
            {
                ManualResetEvent.Reset();

                if (requestObj == null)
                {
                    // Do nothing
                }
                else if (requestObj.Mode == Mode.REDIAL)
                {
                    // call redial method
                    res = CallRedial(id, MfpConnectorSetting.Iws.CurrentSetting.CallbackUrlBase);
                    return res;
                }
                else if (requestObj.Mode == Mode.RESTART)
                {
                    // call restart method
                    res = await CallRestartAsync(id, requestObj.AuthParameter?.Code);
                    return res;
                }

                // bad request
                var resp = new JobsManipulateControllerResult
                {
                    Success = false,
                };
                res = JsonResponseCreator.Create(resp, HttpStatusCode.BadRequest);
                return res;
            }
            catch (Exception ex)
            {
                _logger.LogError(default(EventId), ex, "Manipulate() catches exception.");
                res = JsonResponseCreator.CreateException(ex, HttpStatusCode.InternalServerError);
                return res;
            }
        }

        /// <summary>
        /// Receives and interprets an IWS redial job result (callback).
        /// </summary>
        /// <param name="id">Job identifier from the MFP device</param>
        /// <param name="redialJobResult">The redial job result.</param>
        /// <returns>
        /// HTTP response
        /// </returns>
        /// <remarks>
        /// Receive and interpret an IWS redial job result (callback). 
        /// The call to this endpoint is done only from the MFP.
        /// </remarks>
        [HttpPost("{id}/callback")]
        [ProducesResponseType(typeof(JobsManipulateControllerResult), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(JobsManipulateControllerResult), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ExceptionMessage), (int)HttpStatusCode.InternalServerError)]
        public IActionResult RedialCallback([FromRoute] string id, [FromBody] CallBackJobResult redialJobResult)
        {
            IActionResult res;
            try
            {
                if (redialJobResult == null)
                {
                    // bad request
                    _logger.LogError("RedialCallback() receives no result.");
                    res = BadRequest();
                }
                else
                {
                    res = Ok();

                    if (string.IsNullOrEmpty(redialJobResult.Error))
                    {
                        _responseManipulate.Success = true;
                    }
                    else
                    {
                        _responseManipulate.Success = false;
                    }

                    // reset wait
                    ManualResetEvent.Set();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(default(EventId), ex, "RedialCallback() catches exception.");
                res = JsonResponseCreator.CreateException(ex, HttpStatusCode.OK);
            }

            return res;
        }

        /// <summary>
        /// IWS:Call Redial job
        /// </summary>
        /// <param name="id">Job identifier from the MFP device.</param>
        /// <param name="requestUri">Request URL</param>
        /// <returns>
        /// HTTP response
        /// </returns>
        private IActionResult CallRedial(string id, string requestUri)
        {
            IActionResult res;

            // initialize callback res
            _responseManipulate.Success = false;

            var sender = _mfpSender;
            sender.Parameter = $"{requestUri}/api/jobs/{id}/callback {id}";
            sender.SendToMfp();

            // get Response (Wait response for timeout)
            ManualResetEvent.Wait(MfpConnectorSetting.Iws.CurrentSetting.CallbackTimeout);

            // Result object is null or not
            res = JsonResponseCreator.Create(_responseManipulate,
                _responseManipulate.Success ? HttpStatusCode.OK : HttpStatusCode.BadRequest);

            return res;
        }

        /// <summary>
        /// OpenAPI:Restart job
        /// </summary>
        /// <param name="id">Job ID by MFP device</param>
        /// <param name="enhancedAuthParameterCode">Enhanced auth parameter code</param>
        /// <returns>HTTP response</returns>
        private async Task<IActionResult> CallRestartAsync(string id, string enhancedAuthParameterCode)
        {
            IActionResult res;
            var result = new JobsManipulateControllerResult();

            try
            {
                // Restart job
                HttpStatusCode status;
                try
                {
                    await _jobOperator.RestartJobAsync(id, enhancedAuthParameterCode);
                    status = HttpStatusCode.OK;
                    result.Success = true;
                }
                catch (OpenApiNackException)
                {
                    status = HttpStatusCode.BadRequest;
                    result.Success = false;
                }

                res = JsonResponseCreator.Create(result, status);
            }
            catch (OpenApiRequestException openApiEx)
            {
                _logger.LogTrace(default(EventId), openApiEx, openApiEx.Message);
                result.Success = false;
                res = JsonResponseCreator.Create(result, HttpStatusCode.BadRequest);
            }
            catch (Exception ex)
            {
                _logger.LogTrace(default(EventId), ex, "Exception occurred uring scan job.");
                result.Success = false;
                res = JsonResponseCreator.Create(result, HttpStatusCode.BadRequest);
            }

            return res;
        }
    }
}
