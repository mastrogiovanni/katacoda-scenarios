﻿using Newtonsoft.Json;

namespace ServiceHub.Web.MfpConnector.Controllers.Rest.Model
{
    /// <summary>
    /// Scan result from IWS
    /// </summary>
    public class WarningServiceResult : IResponseModel
    {
        /// <summary>Result type string.</summary>
        [JsonProperty(PropertyName = "result")]
        public bool Result { get; set; }
    }
}
