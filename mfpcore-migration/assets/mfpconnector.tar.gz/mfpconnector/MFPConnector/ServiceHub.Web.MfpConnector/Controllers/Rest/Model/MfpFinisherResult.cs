﻿using Newtonsoft.Json;

namespace ServiceHub.Web.MfpConnector.Controllers.Rest.Model
{
    /// <summary>
    /// Get Finisher info result.
    /// </summary>
    public class MfpFinisherResult : IResponseModel
    {
        /// <summary>
        /// Finisher Product Name
        /// </summary>
        [JsonProperty(PropertyName = "finisher_product_name")]
        public string ProductName { get; set; }
    }
}
