using Newtonsoft.Json;

namespace ServiceHub.Web.MfpConnector.Controllers.Rest.Model
{
    /// <summary>
    /// IWS Special app result
    /// </summary>
    public class IwsSpecialAppsControllerResult : IResponseModel
    {
        /// <summary>
        /// Error code
        /// </summary>
        [JsonProperty(PropertyName = "err_details")]
        public string ErrorCode { get; set; }
    }
}