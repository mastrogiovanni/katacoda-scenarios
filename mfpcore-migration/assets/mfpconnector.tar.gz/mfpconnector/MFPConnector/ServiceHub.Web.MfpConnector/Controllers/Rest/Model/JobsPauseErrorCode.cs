using ServiceHub.Common.Attributes;

namespace ServiceHub.Web.MfpConnector.Controllers.Rest.Model
{
    /// <summary>
    /// Job Pause error code
    /// </summary>
    public enum JobsPauseErrorCode
    {
        /// <summary>
        /// Unexpected error (like raised in MFP Connector, MFP Service, etc.)
        /// </summary>
        [EnumValue("UNEXPECTED")]
        Unexpected,

        /// <summary>
        /// Cannot send request to IWS script
        /// </summary>
        [EnumValue("UNREACHABLE")]
        Unreachable,

        /// <summary>
        /// IWS's exception "TypeError"
        /// </summary>
        [EnumValue("TYPE_ERROR")]
        TypeError,

        /// <summary>
        /// IWS's exception "mfp.MFPInvalidStateErr"
        /// </summary>
        [EnumValue("MFP_INVALID_STATE")]
        MfpInvalidState,

        /// <summary>
        /// IWS's exception "mfp.MFPPermissionErr"
        /// </summary>
        [EnumValue("MFP_PERMISSION")]
        MfpPermission,

        /// <summary>
        /// OpenAPI's result is Nack
        /// </summary>
        [EnumValue("NOT_ACKNOWLEDGED")]
        NotAcknowledged,

        /// <summary>
        /// Cannot receive result from IWS Script until timeout
        /// </summary>
        [EnumValue("TIMEOUT")]
        Timeout
    }
}