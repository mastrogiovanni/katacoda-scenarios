using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using ServiceHub.Connectors.OpenAPI.Model;

namespace ServiceHub.Web.MfpConnector.Controllers.Rest.Model
{
    /// <summary>
    /// Power mode request.
    /// </summary>
    public class PowerModeRequest
    {
        /// <summary>
        /// Power mode.
        /// </summary>
        [JsonProperty("power_mode")]
        [JsonConverter(typeof(StringEnumConverter))]
        public PowerMode? PowerMode { get; set; }
    }
}