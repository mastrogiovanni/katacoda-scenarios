using System;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ServiceHub.Common.Model;
using ServiceHub.Common.Settings;
using ServiceHub.Connectors.OpenAPI.Exceptions;
using ServiceHub.Processors.Settings;
using ServiceHub.Processors.Settings.Model;
using ServiceHub.Web.MfpConnector.Controllers.Rest.Model;
using ServiceHub.Web.MfpConnector.Controllers.Utility;

namespace ServiceHub.Web.MfpConnector.Controllers.Rest.Settings
{
    /// <summary>
    /// Administrator Settings controller.
    /// </summary>
    [Route("api/settings/admin")]
    public class AdminSettingsController : AbstractController
    {
        private readonly ISettingsOperator _settingsOperator;
        private readonly ILogger<AdminSettingsController> _logger;

        /// <summary>
        /// Initializes a new instance of the <see cref="AdminSettingsController" /> class.
        /// </summary>
        /// <param name="logger">Logger</param>
        /// <param name="settingsOperator">The settings operator.</param>
        /// <param name="mfpConnectorSetting">The MFP connector setting.</param>
        public AdminSettingsController(
            ILogger<AdminSettingsController> logger,
            ISettingsOperator settingsOperator, 
            MfpConnectorSetting mfpConnectorSetting)
            : base(mfpConnectorSetting)
        {
            _logger = logger;
            _settingsOperator = settingsOperator;
        }

        /// <summary>
        /// Gets specific administration settings from the MFP device.
        /// </summary>
        /// <param name="requestObj">Administration setting list. The settings can include any of the following: ALL, Auth_ColorManage, Auth_NoAuthPrintOn, Auth_SendAddressLimit,
        /// Fax_DefaultSenders, Fax_DialType, Fax_ReceiveOnSettings, Fax_DataProtectType, Fax_SendAuthPassword, Security_SendProhibit, SysConn_PrefixSuffix,
        /// Oplevel_OriginalSizeAutoDetectByUser, IFax_IsEnable, Scan_OcrLanguage, Scan_Pdf_A, Scan_LinearizedPdfg, Scan_is_enable_ocr, Scan_IsEnablePdf_A,
        /// Scan_IsEnableLinearizedPdf, Scan_FileNameAddString, Scan_FunctionInitial, WinNwk_IsEnable, Ubiquitous_UsePrint, Auth_AuthType, User_MultiFeedDetectSetting,
        /// MailSend_Auth, MailSend_BinaryDivisionSize, MailSend_Verification, MailSend_PopBeforeSmtp, MailSend_PortNo, MailSend_SslTslPortNo, 
        /// MailSend_ServerLimit, MailSend_ServerAddress, MailSend_EncryptionSetting, MailSend_TimeOut, MailSend_IsEnable, 
        /// MailSend_StatusNotify, MailSend_ScanSending, MailSend_TotalCounterNotify</param>
        /// <returns>
        /// List of requested MFP administration settings with their actual value.
        /// </returns>
        /// <remarks>
        /// Returns the existing administration settings with their value.
        /// </remarks>
        [HttpPost("")]
        [ProducesResponseType(typeof(AdminSettingsResponse), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ExceptionMessage), (int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> ObtainAdminSettings([FromBody] AdminSettingsRequest requestObj)
        {
            IActionResult res;
            try
            {
                // Get request content
                var status = HttpStatusCode.OK;

                var settingList = requestObj.SettingsNames.Contains(AdminSettingNamesConst.All) ? AdminSettingNamesConst.GetAllSettingNames : requestObj.SettingsNames;

                if (settingList.Count <= 0)
                {
                    res = BadRequest();
                }
                else
                {
                    var result = new AdminSettingsResponse
                    {
                        SettingValues = await _settingsOperator.ObtainAdminSettingsAsync(settingList)
                    };
                    res = JsonResponseCreator.Create(result, status);
                }
            }
            catch (OpenApiRequestException openApiEx)
            {
                _logger.LogError(default(EventId), openApiEx, openApiEx.Message);
                res = JsonResponseCreator.CreateException(openApiEx, HttpStatusCode.BadRequest);
            }
            catch (Exception ex)
            {
                _logger.LogError(default(EventId), ex, "Exception occurred during obtain admin settings.");
                res = JsonResponseCreator.CreateException(ex, HttpStatusCode.BadRequest);
            }

            return res;
        }
    }
}
