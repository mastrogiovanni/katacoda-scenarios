using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ServiceHub.Connectors.OpenAPI.Exceptions;
using ServiceHub.Processors.Animations;
using ServiceHub.Processors.DeviceInfo;
using ServiceHub.Web.MfpConnector.Controllers.Rest.Model;
using System.Xml;
using Microsoft.Extensions.Logging;
using ServiceHub.Common.Model;
using ServiceHub.Common.Settings;
using ServiceHub.Processors.Animations.Model;
using ServiceHub.Web.MfpConnector.Controllers.Utility;

namespace ServiceHub.Web.MfpConnector.Controllers.Rest
{
    /// <summary>
    /// Animation file list controller.
    /// </summary>
    [Route("api/animations")]
    public class AnimationsController : AbstractController
    {
        private readonly IAnimationsOperator _animationsOperator;
        private readonly IDeviceInfoOperator _deviceInfoOperator;
        private readonly ILogger<AnimationsController> _logger;

        /// <summary>
        /// Initializes a new instance of the <see cref="AliveController" /> class.
        /// </summary>
        /// <param name="logger">Logger</param>
        /// <param name="mfpConnectorSetting">The MFP connector setting.</param>
        /// <param name="animationsOperator">The animations operator.</param>
        /// <param name="deviceInfoOperator">The device information operator.</param>
        public AnimationsController(
            ILogger<AnimationsController> logger, 
            MfpConnectorSetting mfpConnectorSetting, 
            IAnimationsOperator animationsOperator, 
            IDeviceInfoOperator deviceInfoOperator)
            : base(mfpConnectorSetting)
        {
            _animationsOperator = animationsOperator;
            _deviceInfoOperator = deviceInfoOperator;
            _logger = logger;
        }

        /// <summary>
        /// Gets the animations files.
        /// </summary>
        /// <remarks>Returns a list of animations files.</remarks>
        /// <returns>HTTP response</returns>
        /// <response code="200">Succesfully retrived the list of animation file.</response>
        /// <response code="500">Unable to retrieve the information using the OpenAPI.</response>
        [ProducesResponseType(typeof(List<AnimationFile>), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ExceptionMessage), (int)HttpStatusCode.InternalServerError)]
        [Route("")]
        [HttpGet]
        public async Task<IActionResult> GetAnimationDataList()
        {
            IActionResult response;

            try
            {
                response = Ok(await _animationsOperator.GetAnimationFileListAsync());
            }
            catch (OpenApiRequestException openApiEx)
            {
                _logger.LogError(default(EventId), openApiEx, openApiEx.Message);
                response = JsonResponseCreator.CreateException(openApiEx, HttpStatusCode.InternalServerError);
            }
            catch (OpenApiNackException openApiNackEx)
            {
                _logger.LogError(default(EventId), openApiNackEx, openApiNackEx.Message);
                response = JsonResponseCreator.CreateException(openApiNackEx, HttpStatusCode.InternalServerError);
            }
            catch (Exception ex)
            {
                var message = $"Exception occurred during obtain animation data: {ex.Message}";
                _logger.LogError(default(EventId), ex, message);
                response = JsonResponseCreator.CreateException(ex, HttpStatusCode.InternalServerError);
            }

            return response;
        }

        /// <summary>
        /// Gets the rom version and serial number.
        /// </summary>
        /// <remarks>Returns the rom version and serial number of the MFP device.</remarks>
        /// <returns>The rom version with the MFP device serial number.</returns>
        [Route("romversion")]
        [ProducesResponseType(typeof(AnimationsControllerResult), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ExceptionMessage), (int)HttpStatusCode.InternalServerError)]
        [HttpGet]
        public async Task<IActionResult> GetAnimationRomVersion()
        {
            IActionResult response;

            try
            {
                // get movie rom version
                var version = await _animationsOperator.GetAnimationRomVersionAsync();

                // get serial number
                var serialNumber = await _deviceInfoOperator.GetSerialNumberAsync();
                if (serialNumber != null)
                {
                    var result = new AnimationsControllerResult
                    {
                        AnimationRomVersion = version,
                        SerialNumber = serialNumber
                    };

                    response = JsonResponseCreator.Create(result, HttpStatusCode.OK);
                }
                else
                {
                    throw new XmlException("Could not found AppResGetDeviceInfoDetail tag.");
                }
            }
            catch (OpenApiRequestException openApiEx)
            {
                _logger.LogError(default(EventId), openApiEx, openApiEx.Message);
                response = JsonResponseCreator.CreateException(openApiEx, HttpStatusCode.InternalServerError);
            }
            catch (OpenApiNackException openApiNackEx)
            {
                _logger.LogError(default(EventId), openApiNackEx , openApiNackEx.Message);
                response = JsonResponseCreator.CreateException(openApiNackEx, HttpStatusCode.InternalServerError);
            }
            catch (Exception ex)
            {
                _logger.LogError(default(EventId), ex, "Exception occurred during obtain animation rom version. : {0}", ex.Message);
                response = JsonResponseCreator.CreateException(ex, HttpStatusCode.InternalServerError);
            }

            return response;
        }
    }
}
