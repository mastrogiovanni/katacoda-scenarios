using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using KonicaMinolta.OpenApi;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ServiceHub.Common.Model;
using ServiceHub.Common.Settings;
using ServiceHub.Common.Settings.Mfp;
using ServiceHub.Processors.Common.Model;
using ServiceHub.Processors.MfpSetting;
using ServiceHub.Processors.MfpSetting.Model;
using ServiceHub.Processors.Power;
using ServiceHub.Web.MfpConnector.Controllers.Rest.Model;
using ServiceHub.Web.MfpConnector.Controllers.Utility;

namespace ServiceHub.Web.MfpConnector.Controllers.Rest.Settings
{
    /// <summary>
    /// Mfp Settings controller.
    /// </summary>
    [Route("api/settings/mfp")]
    public class MfpSettingsController : AbstractController
    {
        private readonly IMfpSettingsOperator _mfpSettingsOperator;
        private readonly IPowerOperator _powerOperator;
        private readonly MfpSettingItem _mfpSettingItem;
        private readonly CategoryMfpSetting _categoryMfpSetting;
        private readonly ILogger<MfpSettingsController> _logger;

        /// <summary>
        /// Initializes a new instance of the <see cref="MfpSettingsController" /> class.
        /// </summary>
        /// <param name="mfpConnectorSetting">The MFP connector setting.</param>
        /// <param name="mfpSettingsOperator">The MFP settings operator.</param>
        /// <param name="powerOperator">The power operator.</param>
        /// <param name="mfpSettingItem">The MFP setting item.</param>
        /// <param name="categoryMfpSetting">The category MFP setting.</param>
        /// <param name="logger">Logger</param>
        public MfpSettingsController(
            MfpConnectorSetting mfpConnectorSetting,
            IMfpSettingsOperator mfpSettingsOperator,
            IPowerOperator powerOperator,
            MfpSettingItem mfpSettingItem,
            CategoryMfpSetting categoryMfpSetting,
            ILogger<MfpSettingsController> logger)
            : base(mfpConnectorSetting)
        {
            _logger = logger;
            _mfpSettingsOperator = mfpSettingsOperator;
            _powerOperator = powerOperator;
            _mfpSettingItem = mfpSettingItem;
            _categoryMfpSetting = categoryMfpSetting;
        }

        /// <summary>
        /// Gets all existing setting details from the MFP device.
        /// </summary>
        /// <returns>HttpResponse</returns>
        /// <remarks>
        /// Returns all the setting details from the MFP device.
        /// </remarks>
        [HttpGet("")]
        [ProducesResponseType(typeof(MfpSettingsGetResponse), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ExceptionMessage), (int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> GetDeviceSettingAll()
        {
            return await GetCommonSettingAsync(null);
        }

        /// <summary>
        /// Gets a specific setting details from the MFP device.
        /// </summary>
        /// <param name="settingName">Name of the setting.</param>
        /// <returns>
        /// HttpResponse
        /// </returns>
        /// <remarks>
        /// Returns the specific setting details from the MFP device.
        /// </remarks>
        [HttpGet("{settingName}")]
        [ProducesResponseType(typeof(MfpSettingsGetResponse), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ExceptionMessage), (int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> GetDeviceSetting([FromRoute] string settingName)
        {
            return await GetCommonSettingAsync(settingName);
        }

        /// <summary>
        /// Sets the MFP device settings.
        /// </summary>
        /// <param name="content">The content.</param>
        /// <returns>
        /// HttpResponse
        /// </returns>
        /// <remarks>
        /// Sets the MFP device settings.
        /// </remarks>
        [HttpPut("")]
        [ProducesResponseType(typeof(MfpSettingsSetResponse), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ExceptionMessage), (int)HttpStatusCode.InternalServerError)]
        [ProducesResponseType(typeof(ExceptionMessage), (int)HttpStatusCode.ServiceUnavailable)]
        public async Task<IActionResult> SetDeviceSetting([FromBody] MfpSettingsSetRequest content)
        {
            _logger.LogInformation("MfpSettingsController.SetCommonSetting START");
            var settingValues = new List<SetSettingValue>();

            try
            {
                var status = HttpStatusCode.OK;

                if (content?.SettingValues?.Count == 0)
                {
                    _logger.LogWarning("Mfp setting request has no setting value.");
                    return BadRequest();
                }

                _logger.LogDebug("Execute service.");
                _mfpSettingsOperator.Init(
                    _categoryMfpSetting.SettingCategory,
                    _mfpSettingItem.AdminSettings,
                    _powerOperator);

                settingValues = GetSettingNamesModels(content?.SettingValues);

                if (settingValues == null)
                {
                    _logger.LogWarning("Mfp settings request is Bad request.");
                    return BadRequest();
                }

                var response = await _mfpSettingsOperator.SetMfpSettingsAsync(settingValues);

                if (response.Any(x => !x.Result) ||
                    response.Any(x => x.ErrorCode == OpenApiFaultErrorDetailsType.GeneralDuringDeviceLock.ToString()))
                {
                    status = HttpStatusCode.ServiceUnavailable;
                }

                return JsonResponseCreator.Create(new MfpSettingsSetResponse
                {
                    SettingResult = response
                }, status);
            }
            catch (OpenApiFaultException ex)
            {
                _logger.LogError(ex.FaultMessage.ErrorDetails);
                var result = new OapResponseXmlResult();
                var errorResultString = result.ConvertErrorCode(ex.FaultMessage.ErrorDetails);

                return JsonResponseCreator.Create(new MfpSettingsSetResponse
                {
                    SettingResult = _mfpSettingsOperator.GetAllErrorResult(settingValues, errorResultString)
                }, HttpStatusCode.ServiceUnavailable);
            }
            catch (Exception ex)
            {
                _logger.LogError(default(EventId), ex,
                    $"Exception occurred during obtain admin Mfp settings. Message {ex.Message}");
                return JsonResponseCreator.CreateException(ex, HttpStatusCode.InternalServerError);
            }
        }

        /// <summary>
        /// Gets MFP common setting by name.
        /// </summary>
        /// <param name="settingName">Setting name</param>
        /// <returns>Http Response</returns>
        /// <remarks>
        /// Returns the setting details.
        /// </remarks>
        private async Task<IActionResult> GetCommonSettingAsync(string settingName)
        {
            _logger.LogInformation("MfpSettingsController.GetCommonSetting START");

            try
            {
                var settingNames = new List<string>();
                try
                {
                    if (!string.IsNullOrEmpty(settingName))
                    {
                        _logger.LogInformation($"Request setting name:[{settingName}]");
                        settingNames.Add(settingName);
                    }
                }
                catch
                {
                    // Do nothing
                }

                _logger.LogInformation("Execute service.");

                _mfpSettingsOperator.Init(
                    _categoryMfpSetting.SettingCategory,
                    _mfpSettingItem.AdminSettings,
                    _powerOperator);

                var mfpSettingsResponse = await _mfpSettingsOperator.GetMfpSettingsAsync(settingNames);

                if (mfpSettingsResponse == null)
                {
                    _logger.LogWarning("Mfp settings request is Bad request.");
                    return BadRequest();
                }

                return Ok(new MfpSettingsGetResponse { SettingValues = mfpSettingsResponse });
            }
            catch (Exception ex)
            {
                _logger.LogError(default(EventId), ex, "Exception occurred during obtain admin Mfp settings.");
                return JsonResponseCreator.CreateException(ex, HttpStatusCode.InternalServerError);
            }
        }

        /// <summary>
        /// Gets the setting names models.
        /// </summary>
        /// <param name="settingNames">The setting names.</param>
        /// <returns></returns>
        private List<SetSettingValue> GetSettingNamesModels(List<SetSettingValue> settingNames)
        {
            var settingNamesModels = new List<SetSettingValue>();
            var sb = new StringBuilder();

            foreach (var settingNamesModel in settingNames)
            {
                if (string.IsNullOrEmpty(settingNamesModel.Name)|| !_mfpSettingItem.AdminSettings.ContainsKey(settingNamesModel.Name))
                {
                    return null;
                }

                sb.AppendLine($"Add setting names model SettingModelName:{settingNamesModel.Name}");
                settingNamesModels.Add(settingNamesModel);
            }

            return settingNamesModels;
        }
    }
}
