﻿using Newtonsoft.Json;

namespace ServiceHub.Web.MfpConnector.Controllers.Rest.Model
{
    /// <summary>
    /// Get envelope mode state result.
    /// </summary>
    public class EnvelopeResult : IResponseModel
    {
        /// <summary>
        /// Whether mfp is envelope mode or not.
        /// </summary>
        [JsonProperty(PropertyName = "envelope_mode")]
        public bool Mode { get; set; }
    }
}
