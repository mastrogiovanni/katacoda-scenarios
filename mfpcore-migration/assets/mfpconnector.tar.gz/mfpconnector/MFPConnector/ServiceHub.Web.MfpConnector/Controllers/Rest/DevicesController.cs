using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ServiceHub.Common.DeviceState;
using ServiceHub.Common.Model;
using ServiceHub.Common.Model.DeviceInfo.NotifyToSh;
using ServiceHub.Common.Settings;
using ServiceHub.Connectors.OpenAPI.Exceptions;
using ServiceHub.Processors.DeviceInfo;
using ServiceHub.Processors.DeviceInfo.Model;
using ServiceHub.Processors.Notify;
using ServiceHub.Processors.Notify.Model;
using ServiceHub.Processors.Setup;
using ServiceHub.Web.MfpConnector.Controllers.Rest.Model;
using ServiceHub.Web.MfpConnector.Controllers.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Xml;
using ServiceHub.CommonTools.Extensions;
using ServiceHub.CommonTools.Validations;
using ServiceHub.CommonTools.WebApi.DTOs;

namespace ServiceHub.Web.MfpConnector.Controllers.Rest
{
    /// <summary>
    /// Devices status controller.
    /// </summary>
    [Route("api/devices")]
    public class DevicesController : AbstractController
    {
        private const string MsgExceptionMarket = "Exception occurred while acquiring the MFP market area information.";

        private readonly INotifySetter _notifySetter;
        private readonly IDeviceInfoOperator _deviceInfoOperator;
        private readonly IPasswordOperator _passwordOperator;
        private readonly IDeviceStateContext _deviceStateContext;
        private readonly IMapper _mapper;
        private readonly ILogger<DevicesController> _logger;

        /// <summary>
        /// Initializes a new instance of the <see cref="DevicesController" /> class.
        /// </summary>
        /// <param name="logger">Logger</param>
        /// <param name="mfpConnectorSetting">The MFP connector setting.</param>
        /// <param name="notifySetter">The notify setter.</param>
        /// <param name="deviceInfoOperator">The device information operator.</param>
        /// <param name="passwordOperator">The password operator.</param>
        /// <param name="deviceStateContext">The device state context.</param>
        public DevicesController(
            ILogger<DevicesController> logger,
            MfpConnectorSetting mfpConnectorSetting,
            INotifySetter notifySetter,
            IDeviceInfoOperator deviceInfoOperator,
            IPasswordOperator passwordOperator,
            IDeviceStateContext deviceStateContext)
            : base(mfpConnectorSetting)
        {
            _logger = logger;
            _notifySetter = notifySetter;
            _deviceInfoOperator = deviceInfoOperator;
            _passwordOperator = passwordOperator;
            _deviceStateContext = deviceStateContext;

            var config = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<MfpApplicationOption, MfpApplicationOptionResult>();
                cfg.CreateMap<MfpSupportFunctions, MfpSupportFunctionsResult>();
                cfg.CreateMap<Envelope, EnvelopeResult>();
                cfg.CreateMap<MfpFinisher, MfpFinisherResult>();
                cfg.CreateMap<MfpProductInfo, MfpProductInfoResult>();
                cfg.CreateMap<MfpMarketAreaInfo, MfpMarketAreaResult>();
                cfg.CreateMap<MfpDeviceInfo, MfpDeviceInfoResult>();
                cfg.CreateMap<PrinterEncryptionSetting, PrinterEncryptionResponse>();
                cfg.CreateMap<MfpFaxCapabilityInfo, MfpFaxCapbilityInfoResult>();
            });
            _mapper = config.CreateMapper();
        }

        /// <summary>
        /// Gets the MFP device list status.
        /// </summary>
        /// <returns>Returns a list of devices status.</returns>
        /// <remarks>Returns a list of devices status.</remarks>
        [HttpGet("")]
        [ProducesResponseType(typeof(List<NotifyDeviceStatus>), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ExceptionMessage), (int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> Get()
        {
            IActionResult res;

            try
            {
                // Get device status
                var content = await _notifySetter.GetDeviceListStatusAsync();
                if (content == null)
                {
                    res = NoContent();
                }
                else
                {
                    res = StatusCode((int)HttpStatusCode.OK, content);
                }
            }
            catch (Exception ex)
            {
                res = JsonResponseCreator.CreateException(ex, HttpStatusCode.InternalServerError);
            }

            return res;
        }

        /// <summary>
        /// Gets the MFP device lock status.
        /// </summary>
        /// <remarks>Returns the lock status notification such as IllegalAdminPassword, MFP_Down or MFP_Up.</remarks>
        /// <returns>Returns the lock status notification such as IllegalAdminPassword, MFP_Down or MFP_Up.</returns>
        [HttpGet("lock")]
        [ProducesResponseType(typeof(EventState), (int)HttpStatusCode.OK)]
        public IActionResult GetLockInfo()
        {
            var resContent = new EventState();

            if (!_deviceStateContext.Environment)
            {
                resContent.Event = "IllegalAdminPassword";
            }
            else if (!_deviceStateContext.Usable)
            {
                resContent.Event = "MFP_Down";
            }
            else
            {
                resContent.Event = "MFP_Up";
            }

            return StatusCode((int)HttpStatusCode.OK, resContent);
        }

        /// <summary>
        /// Gets the MFP device information.
        /// </summary>
        /// <returns>
        /// Returns the MFP device information such as the product name, company name, color, duplex and more.
        /// </returns>
        /// <remarks>
        /// Returns the MFP device information such as the product name, company name, color, duplex and more.
        /// </remarks>
        [HttpGet("detail/mfpdeviceinfo")]
        [ProducesResponseType(typeof(MfpDeviceInfo), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ExceptionMessage), (int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> GetMfpDeviceInfo()
        {
            IActionResult response;

            try
            {
                // get mfp device info
                MfpDeviceInfo mfpDeviceInfo = await _deviceInfoOperator.GetMfpDeviceInfoAsync();
                if (mfpDeviceInfo.ValidateMfpDeviceInfoResponse())
                {
                    response = JsonResponseCreator.Create(_mapper.Map<MfpDeviceInfoResult>(mfpDeviceInfo),
                        HttpStatusCode.OK);
                }
                else
                {
                    var exception = new XmlException("Could not found AppResGetDeviceInfoDetail tag.");
                    _logger.LogError(default(EventId), exception, exception.Message);
                    response = JsonResponseCreator.CreateException(exception, HttpStatusCode.InternalServerError);
                }
            }
            catch (OpenApiRequestException openApiEx)
            {
                _logger.LogError(default(EventId), openApiEx, openApiEx.Message);
                response = JsonResponseCreator.CreateException(openApiEx, HttpStatusCode.InternalServerError);
            }
            catch (OpenApiNackException openApiNackEx)
            {
                _logger.LogError(default(EventId), openApiNackEx, openApiNackEx.Message);
                response = JsonResponseCreator.CreateException(openApiNackEx, HttpStatusCode.InternalServerError);
            }
            catch (Exception ex)
            {
                _logger.LogError(default(EventId), ex, "Exception occurred while acquiring the MFP device information.");
                response = JsonResponseCreator.CreateException(ex, HttpStatusCode.InternalServerError);
            }

            return response;
        }

        /// <summary>
        /// Gets the MFP fax capability.
        /// </summary>
        /// <remarks>Returns the MFP fax capability.</remarks>
        /// <returns>Returns the MFP fax capability.</returns>
        [HttpGet("detail/mfpfaxcapabilityinfo")]
        [ProducesResponseType(typeof(MfpFaxCapabilityInfo), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ExceptionMessage), (int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> GetMfpFaxCapabilityInfo()
        {
            IActionResult response;

            try
            {
                // get mfp fax capability info
                MfpFaxCapabilityInfo mfpFaxCapabilityInfo = await _deviceInfoOperator.GetMfpFaxCapabilityInfoAsync();
                var result = new MfpFaxCapbilityInfoResult
                {
                    FaxEnabled = mfpFaxCapabilityInfo.FaxEnabled
                };

                response = JsonResponseCreator.Create(result, HttpStatusCode.OK);
            }
            catch (Exception e)
            {
                if (e is OpenApiRequestException || e is OpenApiNackException)
                {
                    _logger.LogError(default(EventId), e, e.Message);
                }
                else
                {
                    const string message = "Exception occurred while acquiring the MFP fax cpability information.";
                    _logger.LogError(default(EventId), e, message);
                }

                response = JsonResponseCreator.CreateException(e, HttpStatusCode.InternalServerError);
            }

            return response;
        }

        /// <summary>
        /// Gets the MFP product information.
        /// </summary>
        /// <returns>
        /// Returns the product information such as the product identifier and the market area.
        /// </returns>
        /// <remarks>
        /// Returns the MFP product information such as the product identifier and the market area.
        /// </remarks>
        [HttpGet("detail/mfpproductinfo")]
        [ProducesResponseType(typeof(MfpProductInfo), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ExceptionMessage), (int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> GetMfpProductInfo()
        {
            IActionResult response;

            try
            {
                // get mfp device info
                MfpProductInfo mfpProductInfo = await _deviceInfoOperator.GetMfpProductInfoAsync();
                if (mfpProductInfo.ValidateMfpProductInfoResponse())
                {
                    return Ok(_mapper.Map<MfpProductInfoResult>(mfpProductInfo));
                }

                var exception = new XmlException("Could not found AppResGetDeviceInfoDetail tag.");
                _logger.LogTrace(default(EventId), exception, exception.Message);
                response = JsonResponseCreator.CreateException(exception, HttpStatusCode.InternalServerError);
            }
            catch (OpenApiRequestException openApiEx)
            {
                _logger.LogError(default(EventId), openApiEx, openApiEx.Message);
                response = JsonResponseCreator.CreateException(openApiEx, HttpStatusCode.InternalServerError);
            }
            catch (OpenApiNackException openApiNackEx)
            {
                _logger.LogError(default(EventId), openApiNackEx, openApiNackEx.Message);
                response = JsonResponseCreator.CreateException(openApiNackEx, HttpStatusCode.InternalServerError);
            }
            catch (Exception ex)
            {
                _logger.LogError(default(EventId), ex, "Exception occurred while acquiring the MFP devce information.");
                response = JsonResponseCreator.CreateException(ex, HttpStatusCode.InternalServerError);
            }

            return response;
        }

        /// <summary>
        /// Gets the MFP market area information.
        /// </summary>
        /// <returns>
        /// Returns the MFP market area information.
        /// </returns>
        /// <remarks>
        /// Returns the MFP market area information.
        /// </remarks>
        [HttpGet("detail/mfpmarketareainfo")]
        [ProducesResponseType(typeof(MfpMarketAreaInfo), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ExceptionMessage), (int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> GetMfpMarketArea()
        {
            IActionResult response;

            try
            {
                // get mfp market area
                var mfpMarketAreaInfo = new MfpMarketAreaInfo
                {
                    MarketArea = await _deviceInfoOperator.GetMfpMarketAreaAsync()
                };

                if (mfpMarketAreaInfo.ValidateMfpMarketAreaResponse())
                {
                    return Ok(_mapper.Map<MfpMarketAreaResult>(mfpMarketAreaInfo));
                }

                throw new XmlException("Could not found AppResGetDeviceInfoDetail tag.");
            }
            catch (Exception ex)
            {
                if (ex is OpenApiRequestException || ex is OpenApiNackException || ex is XmlException)
                {
                    _logger.LogError(default(EventId), ex, ex.Message);
                }
                else
                {
                    _logger.LogError(default(EventId), ex, MsgExceptionMarket);
                }

                response = JsonResponseCreator.CreateException(ex, HttpStatusCode.InternalServerError);
            }

            return response;
        }

        /// <summary>
        /// Gets the device toner status.
        /// </summary>
        /// <remarks>
        /// You can check the remaining amount of each toner.
        /// </remarks>
        /// <returns>HttpStatusCode and Toner Infomation.</returns>
        [HttpGet("detail/toner")]
        [ProducesResponseType(typeof(NotifyDeviceTonerStatus), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(NotifyDeviceTonerStatus), (int)HttpStatusCode.NoContent)]
        [ProducesResponseType(typeof(ExceptionMessage), (int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> GetTonerStatus()
        {
            // Get toner status
            var content = await _notifySetter.GetDeviceTonerStatusAsync();

            if (content == null)
            {
                return NoContent();
            }

            return Ok(content);
        }

        /// <summary>
        /// Get MFP application option.
        /// </summary>
        /// <remarks>Request to get mfp application option.</remarks>
        /// <returns>Return MFP application option.</returns>
        [HttpGet("detail/mfpappoption")]
        [ProducesResponseType(typeof(MfpApplicationOptionResult), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ExceptionMessage), (int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> GetMfpApplicationOptionAsync()
        {
            IActionResult response;

            try
            {
                var mfpApplicationOption = await _deviceInfoOperator.GetMfpApplicationOptionAsync();

                return Ok(_mapper.Map<MfpApplicationOptionResult>(mfpApplicationOption));
            }
            catch (Exception ex)
            {
                if (ex is OpenApiRequestException || ex is OpenApiNackException || ex is XmlException)
                {
                    _logger.LogError(default(EventId), ex, ex.Message);
                }
                else
                {
                    const string message = "Exception occurred while acquiring the MFP application option.";
                    _logger.LogError(default(EventId), ex, message);
                }

                response = JsonResponseCreator.CreateException(ex, HttpStatusCode.InternalServerError);
            }

            return response;
        }

        /// <summary>
        /// Get the functions supported by the MFP.
        /// </summary>
        /// <remarks>Get the functions supported by the MFP.</remarks>
        /// <returns>Return whether MFP functions is supported.</returns>
        [HttpGet("detail/function")]
        [ProducesResponseType(typeof(MfpSupportFunctionsResult), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ExceptionMessage), (int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> GetMfpSupportFunctionsAsync()
        {
            IActionResult response;

            try
            {
                var mfpApplicationOption = await _deviceInfoOperator.GetMfpSupportFunctionsAsync();

                return Ok(_mapper.Map<MfpSupportFunctionsResult>(mfpApplicationOption));
            }
            catch (Exception ex)
            {
                if (ex is OpenApiRequestException || ex is OpenApiNackException || ex is XmlException)
                {
                    _logger.LogError(default(EventId), ex, ex.Message);
                }
                else
                {
                    const string message = "Exception occurred while acquiring the functions supported by the MFP.";
                    _logger.LogError(default(EventId), ex, message);
                }

                response = JsonResponseCreator.CreateException(ex, HttpStatusCode.InternalServerError);
            }

            return response;
        }

        /// <summary>
        /// Request to get whether mfp is envelope mode or not.
        /// </summary>
        /// <remarks>Request to get whether mfp is envelope mode or not.</remarks>
        /// <returns>Return whether mfp is envelope mode or not.</returns>
        [HttpGet("detail/envelopemode")]
        [ProducesResponseType(typeof(MfpSupportFunctionsResult), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ExceptionMessage), (int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> GetEnvelopeModeStateAsync()
        {
            IActionResult response;

            try
            {
                var envelopemode = await _deviceInfoOperator.GetEnvelopeModeStateAsync();

                return Ok(_mapper.Map<EnvelopeResult>(envelopemode));
            }
            catch (Exception ex)
            {
                if (ex is OpenApiRequestException || ex is OpenApiNackException || ex is XmlException)
                {
                    _logger.LogError(default(EventId), ex, ex.Message);
                }
                else
                {
                    const string message = "Exception occurred while acquiring the functions supported by the MFP.";
                    _logger.LogError(default(EventId), ex, message);
                }

                response = JsonResponseCreator.CreateException(ex, HttpStatusCode.InternalServerError);
            }

            return response;
        }

        /// <summary>
        /// Get mfp finisher function.
        /// </summary>
        /// <remarks>Request to get mfp finisher function.</remarks>
        /// <returns>Return The MFP device version.</returns>
        [HttpGet("detail/finisher")]
        [ProducesResponseType(typeof(MfpDeviceVersionInfoResult), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ExceptionMessage), (int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> GetMfpFinisherAsync()
        {
            IActionResult response;

            try
            {
                var mfpApplicationOption = await _deviceInfoOperator.GetMfpFinisherAsync();

                return Ok(_mapper.Map<MfpFinisherResult>(mfpApplicationOption));
            }
            catch (Exception ex)
            {
                if (ex is OpenApiRequestException || ex is OpenApiNackException || ex is XmlException)
                {
                    _logger.LogError(default(EventId), ex, ex.Message);
                }
                else
                {
                    _logger.LogError(default(EventId), ex, MsgExceptionMarket);
                }

                response = JsonResponseCreator.CreateException(ex, HttpStatusCode.InternalServerError);
            }

            return response;
        }

        /// <summary>
        /// </summary>
        /// <remarks>
        /// Update the administrators passwords settings in order to communicate with the MFP. It 
        /// returns a password change result containing the user id from the change request.
        /// </remarks>
        /// <param name="passwordKeyValues">Key and value pairs of usernames and passwords.</param>
        /// <returns>Returns a password change result containing the username from the last change request.</returns>
        [HttpPost("administratorpassword/retention/updates")]
        [ProducesResponseType(typeof(PasswordChangeResult), (int)HttpStatusCode.Created)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        [ProducesResponseType((int)HttpStatusCode.Unauthorized)]
        [ProducesResponseType(typeof(ExceptionMessage), (int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> SetAdminPassword([FromBody] List<PasswordKeyValue> passwordKeyValues)
        {
            IActionResult response;

            // validate parameter
            if (passwordKeyValues == null || passwordKeyValues.Count == 0 ||
                passwordKeyValues.FindIndex(pair => string.IsNullOrEmpty(pair.Key)) != -1)
            {
                return JsonResponseCreator.CreateError(string.Empty, HttpStatusCode.BadRequest);
            }

            try
            {
                var passwordPairs = passwordKeyValues.ToDictionary(f => f.Key, g => g.Password);
                var resultKey = await _passwordOperator.ChangePasswordAsync(passwordPairs);
                response = JsonResponseCreator.Create(new PasswordChangeResult { Key = resultKey },
                    string.IsNullOrEmpty(resultKey) ? HttpStatusCode.Unauthorized : HttpStatusCode.Created);
            }
            catch (Exception ex)
            {
                _logger.LogError(default(EventId), ex, ex.Message);
                response = JsonResponseCreator.CreateException(ex, HttpStatusCode.InternalServerError);
            }

            return response;
        }

        /// <summary>
        /// Get printer encryption setting.
        /// </summary>
        /// <returns>Printer encryption setting</returns>
        [HttpGet("printer/encryption")]
        [ProducesResponseType(typeof(PrinterEncryptionSetting), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ExceptionMessage), (int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> GetPrinterEncryptionSetting()
        {
            IActionResult response;

            try
            {
                var setting = await _deviceInfoOperator.GetPrinterEncryptionSettingAsync();
                response = JsonResponseCreator.Create(_mapper.Map<PrinterEncryptionResponse>(setting),
                    HttpStatusCode.OK);
            }
            catch (Exception ex)
            {
                _logger.LogTrace(default(EventId), ex, ex.Message);
                response = JsonResponseCreator.CreateException(ex, HttpStatusCode.InternalServerError);
            }

            return response;
        }

        /// <summary>
        /// Get MFP device version.
        /// </summary>
        /// <remarks>The MFP device version.</remarks>
        /// <returns>Return The MFP device version.</returns>
        [ProducesResponseType(typeof(MfpDeviceVersionInfoResult), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ErrorResult), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ExceptionMessage), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("version")]
        public async Task<IActionResult> GetMfpDeviceVersionAsync([FromBody] MfpDeviceVersionInfo mfpDeviceVersionInfo)
        {
            Check.NullArgument(mfpDeviceVersionInfo, nameof(mfpDeviceVersionInfo));
            Check.EmptyOrWhiteSpaceArgument(mfpDeviceVersionInfo.TargetName, nameof(mfpDeviceVersionInfo.TargetName));

            try
            {
                var deviceVersion = await _deviceInfoOperator.GetMfpDeviceVersionAsync(
                    mfpDeviceVersionInfo.TargetName);

                return Ok(new MfpDeviceVersionInfoResult(deviceVersion));
            }
            catch (Exception ex)
            {
                var message = $"Exception occurred during obtain {mfpDeviceVersionInfo.TargetName} MFP Version.";
                _logger.LogError(default(EventId), ex, message);
                return JsonResponseCreator.CreateException(ex, HttpStatusCode.InternalServerError);
            }
        }
    }
}
