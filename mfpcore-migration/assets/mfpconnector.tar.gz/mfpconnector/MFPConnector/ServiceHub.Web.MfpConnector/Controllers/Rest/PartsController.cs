using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ServiceHub.Common.Model;
using ServiceHub.Common.Settings;
using ServiceHub.Processors.Notify;
using ServiceHub.Processors.Notify.Model;
using ServiceHub.Web.MfpConnector.Controllers.Utility;

namespace ServiceHub.Web.MfpConnector.Controllers.Rest
{
    /// <summary>
    /// Parts (ADF/Platen) status controller.
    /// </summary>
    [Route("api/parts")]
    public class PartsController : AbstractController
    {
        private readonly INotifySetter _notifySetter;

        /// <summary>
        /// Initializes a new instance of the <see cref="_notifySetter" /> class.
        /// </summary>
        /// <param name="mfpConnectorSetting">The MFP connector setting.</param>
        /// <param name="notifySetter">The notify setter.</param>
        public PartsController(MfpConnectorSetting mfpConnectorSetting, INotifySetter notifySetter)
            : base(mfpConnectorSetting)
        {
            _notifySetter = notifySetter;
        }

        /// <summary>
        /// Gets the MFP device parts status.
        /// </summary>
        /// <returns>
        /// Returns a list of device part status.
        /// </returns>
        /// <remarks>
        /// Returns a list of device part status.
        /// </remarks>
        [HttpGet("")]
        [ProducesResponseType(typeof(List<NotifyDevicePartsStatus>), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NoContent)]
        [ProducesResponseType(typeof(ExceptionMessage), (int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> Get()
        {
            IActionResult res;

            try
            {
                // Get device parts (ADF/Platen)
                var content = await _notifySetter.GetDevicePartsStatusAsync();
                var status = HttpStatusCode.OK;
                if (content == null || content.Count == 0)
                {
                    res = NoContent();
                }
                else
                {
                    res = StatusCode((int) status, content);
                }
            }
            catch (Exception ex)
            {
                res = JsonResponseCreator.CreateException(ex, HttpStatusCode.InternalServerError);
            }

            return res;
        }
    }
}
