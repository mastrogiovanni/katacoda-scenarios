using Newtonsoft.Json;

namespace ServiceHub.Web.MfpConnector.Controllers.Rest.Model
{
    /// <summary>
    /// SettingsController result
    /// </summary>
    public class SettingsControllerResult : IResponseModel
    {
        /// <summary>Result type string.</summary>
        [JsonProperty(PropertyName = "result")]
        public string Result { get; set; }
    }
}