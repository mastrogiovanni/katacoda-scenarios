using Newtonsoft.Json;

namespace ServiceHub.Web.MfpConnector.Controllers.Rest.Model
{
    /// <summary>
    /// Get MFP device version info.
    /// </summary>
    public class MfpDeviceVersionInfoResult : IResponseModel
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MfpDeviceVersionInfoResult" /> class.
        /// </summary>
        public MfpDeviceVersionInfoResult(string version)
        {
            MfpDeviceVersion = version;
        }

        /// <summary>MFP Device version.</summary>
        [JsonProperty(PropertyName = "version")]
        public string MfpDeviceVersion { get; }
    }
}