﻿using Newtonsoft.Json;

namespace ServiceHub.Web.MfpConnector.Controllers.Rest.Model
{
    /// <summary>
    /// Get MFP product info result.
    /// </summary>
    public class MfpProductInfoResult : MfpMarketAreaResult
    {
        /// <summary>product id.</summary>
        [JsonProperty(PropertyName = "product_id")]
        public string ProductId { get; set; }
    }
}