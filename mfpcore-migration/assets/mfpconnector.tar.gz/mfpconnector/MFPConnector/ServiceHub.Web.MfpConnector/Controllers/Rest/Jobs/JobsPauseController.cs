using System;
using System.Net;
using System.Threading;
using Microsoft.AspNetCore.Mvc;
using ServiceHub.Common.Extensions;
using ServiceHub.Common.Settings;
using ServiceHub.Connectors.IWS;
using ServiceHub.Processors.Common;
using ServiceHub.Processors.Job;
using ServiceHub.Processors.Job.Model;
using ServiceHub.Web.MfpConnector.Controllers.Rest.Model;
using Microsoft.Extensions.Logging;
using ServiceHub.Web.MfpConnector.Controllers.Utility;

namespace ServiceHub.Web.MfpConnector.Controllers.Rest.Jobs
{
    /// <summary>
    /// Job pause controller
    /// </summary>
    [Route("api/jobs/pause")]
    public class JobsPauseController : AbstractController
    {
        /// <summary>
        /// Thread pause control
        /// </summary>
        private static readonly ManualResetEventSlim ManualResetEvent = new ManualResetEventSlim();

        private static PauseAllJobsControllerResult _responsePauseAllJobs;

        private readonly IMfpSender _mfpSender;
        private readonly ILogger<JobsPauseController> _logger;

        /// <summary>
        /// Initializes a new instance of the <see cref="JobsPauseController" /> class
        /// </summary>
        /// <param name="logger">Logger</param>
        /// <param name="mfpConnectorSetting">The MFP connector setting.</param>
        /// <param name="jobPauseSender">The job pause sender.</param>
        public JobsPauseController(
            ILogger<JobsPauseController> logger,
            MfpConnectorSetting mfpConnectorSetting,
            IJobPauseSender jobPauseSender)
            : base(mfpConnectorSetting)
        {
            _logger = logger;
            _mfpSender = jobPauseSender;
            _responsePauseAllJobs = new PauseAllJobsControllerResult();
        }

        /// <summary>
        /// Sets the IWS MFP jobs in paused state.
        /// </summary>
        /// <remarks>
        /// Set the IWS MFP jobs in paused state.
        /// </remarks>
        /// <param name="requestObj">The request body.</param>
        /// <returns>HTTP response</returns>
        [HttpPost("")]
        [ProducesResponseType(typeof(PauseAllJobsControllerResult), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(PauseAllJobsControllerResult), (int)HttpStatusCode.BadRequest)]
        public IActionResult Pause([FromBody] JobsManipulateRequest requestObj)
        {
            IActionResult res;

            // initialize callback res
            _responsePauseAllJobs.Success = false;
            _responsePauseAllJobs.ErrorCode = null;

            try
            {
                ManualResetEvent.Reset();

                if (requestObj == null)
                {
                    // bad request
                    var resp = new PauseAllJobsControllerResult
                    {
                        Success = false,
                        ErrorCode = JobsPauseErrorCode.Unexpected.ModelValue()
                    };
                    res = JsonResponseCreator.Create(resp, HttpStatusCode.BadRequest);
                }
                else
                {
                    var sender = _mfpSender;
                    sender.Parameter = $"{MfpConnectorSetting.Iws.CurrentSetting.CallbackUrlBase}/api/jobs/pause/callback";
                    sender.SendToMfp();

                    // get Response (Wait response for timeout)
                    ManualResetEvent.Wait(MfpConnectorSetting.Iws.CurrentSetting.CallbackTimeout);

                    // Result object is null or not
                    if (!_responsePauseAllJobs.Success && string.IsNullOrWhiteSpace(_responsePauseAllJobs.ErrorCode))
                    {
                        _responsePauseAllJobs.Success = false;
                        _responsePauseAllJobs.ErrorCode = JobsPauseErrorCode.Timeout.ModelValue();
                        res = JsonResponseCreator.Create(_responsePauseAllJobs, HttpStatusCode.BadRequest);
                    }
                    else
                    {
                        res = JsonResponseCreator.Create(_responsePauseAllJobs,
                            _responsePauseAllJobs.Success ? HttpStatusCode.OK : HttpStatusCode.BadRequest);
                    }
                }
            }
            catch (IwsException ex)
            {
                _logger.LogError(default(EventId), ex, "Pause() catches exception.");
                _responsePauseAllJobs.Success = false;
                _responsePauseAllJobs.ErrorCode =
                    ex.Message.Equals(IwsException.NetworkConnectionErrMsg, StringComparison.OrdinalIgnoreCase)
                        ? JobsPauseErrorCode.Unreachable.ModelValue()
                        : JobsPauseErrorCode.Unexpected.ModelValue();
                res = JsonResponseCreator.Create(_responsePauseAllJobs, HttpStatusCode.BadRequest);
            }
            catch (Exception ex)
            {
                _logger.LogError(default(EventId), ex, "Pause() catches exception.");
                _responsePauseAllJobs.Success = false;
                _responsePauseAllJobs.ErrorCode = JobsPauseErrorCode.Unexpected.ModelValue();
                res = JsonResponseCreator.Create(_responsePauseAllJobs, HttpStatusCode.BadRequest);
            }

            return res;
        }

        /// <summary>
        /// Receives and interprets an IWS pause all job result (callback).
        /// </summary>
        /// <param name="requestObj">The request object.</param>
        /// <returns>
        /// HTTP response
        /// </returns>
        /// <remarks>
        /// Receives and interprets an IWS pause all job result (callback).
        /// The call to this endpoint is done only from the MFP.
        /// </remarks>
        [HttpPost("callback")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public IActionResult PauseCallback([FromBody] CallBackJobResult requestObj)
        {
            IActionResult res;
            try
            {
                if (requestObj == null)
                {
                    // bad request
                    _logger.LogError("PauseCallback() receives no result.");
                    res = BadRequest();
                }
                else
                {
                    res = Ok();

                    if (string.IsNullOrWhiteSpace(requestObj.Error))
                    {
                        _responsePauseAllJobs.Success = true;
                    }
                    else
                    {
                        _responsePauseAllJobs.Success = false;
                        switch (requestObj.Error)
                        {
                            case RestControllerConst.EnumException:
                            case RestControllerConst.Exception:
                                _responsePauseAllJobs.ErrorCode = JobsManipulateErrorCode.Unexpected.ModelValue();
                                break;
                            case RestControllerConst.MfpInvalidState:
                                _responsePauseAllJobs.ErrorCode = JobsPauseErrorCode.MfpInvalidState.ModelValue();
                                break;
                            default:
                                _responsePauseAllJobs.ErrorCode = requestObj.Error;
                                break;
                        }
                    }

                    // reset wait
                    ManualResetEvent.Set();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(default(EventId), ex, "PauseCallback() catches exception.");
                res = JsonResponseCreator.CreateException(ex, HttpStatusCode.OK);
            }

            return res;
        }
    }
}
