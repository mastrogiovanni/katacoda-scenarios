﻿using Newtonsoft.Json;

namespace ServiceHub.Web.MfpConnector.Controllers.Rest.Model
{
    /// <summary>
    /// Result to change password.
    /// </summary>
    public class PasswordChangeResult : IResponseModel
    {
        /// <summary>
        /// Key of password.
        /// </summary>
        [JsonProperty(PropertyName = "key")]
        public string Key { get; set; }
    }
}
