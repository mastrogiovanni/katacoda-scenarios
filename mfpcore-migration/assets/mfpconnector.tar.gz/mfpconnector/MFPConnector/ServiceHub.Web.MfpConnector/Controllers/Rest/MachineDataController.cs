using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ServiceHub.Common.Model;
using ServiceHub.Processors.DeviceInfo;
using Microsoft.Extensions.Logging;
using ServiceHub.Common.Settings;
using ServiceHub.Web.MfpConnector.Controllers.Utility;

namespace ServiceHub.Web.MfpConnector.Controllers.Rest
{
    /// <summary>
    /// Machine data controller.
    /// </summary>
    [Route("api/machinedata")]
    public class MachineDataController : AbstractController
    {
        private readonly IDeviceInfoOperator _deviceInfoOperator;
        private readonly ILogger<MachineDataController> _logger;

        /// <summary>
        /// Initializes a new instance of the <see cref="MachineDataController" /> class.
        /// </summary>
        /// <param name="logger">Logger</param>
        /// <param name="deviceInfoOperator">The device information operator.</param>
        /// <param name="mfpConnectorSetting">The MFP connector setting.</param>
        public MachineDataController(
            ILogger<MachineDataController> logger, 
            IDeviceInfoOperator deviceInfoOperator,
            MfpConnectorSetting mfpConnectorSetting) 
            : base(mfpConnectorSetting)
        {
            _logger = logger;
            _deviceInfoOperator = deviceInfoOperator;
        }

        /// <summary>
        /// Gets the image/png from the specified path.
        /// </summary>
        /// <param name="imageFilePath">The image file path.</param>
        /// <returns>
        /// Returns the binary data from the image in a image/png format.
        /// </returns>
        /// <remarks>
        /// Returns the file content from the image in a image/png format.
        /// </remarks>
        [HttpGet("")]
        [ProducesResponseType(typeof(ICollection<IFormFile>), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(string), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ExceptionMessage), (int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> Get([FromHeader(Name = "Content-MachineDataPath")] string imageFilePath)
        {
            IActionResult res;

            try
            {
                if (string.IsNullOrEmpty(imageFilePath))
                {
                    _logger.LogWarning("Invalid header");
                    return JsonResponseCreator.CreateError("Invalid header", HttpStatusCode.BadRequest);
                }
                
                // Get machine image
                var image = await _deviceInfoOperator.GetMachineImageFileAsync(imageFilePath);
                if (image == null)
                {
                    _logger.LogWarning($"Image not found. Animation path : {imageFilePath}");
                    // TODO Validate, but this should create a response NotFound (404) instead.
                    return JsonResponseCreator.CreateError("Not found", HttpStatusCode.InternalServerError);
                }

                res = File(image.Binary, "image/png");
            }
            catch (Exception ex)
            {
                res = JsonResponseCreator.CreateException(ex, HttpStatusCode.InternalServerError);
            }

            return res;
        }
    }
}
