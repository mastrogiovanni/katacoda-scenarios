using Newtonsoft.Json;
using ServiceHub.Processors.DeviceInfo.Model;
using System.Collections.Generic;

namespace ServiceHub.Web.MfpConnector.Controllers.Rest.Model
{
    /// <summary>
    /// Get MFP device info result.
    /// </summary>
    public class MfpDeviceInfoResult : IResponseModel
    {
        /// <summary>product name.</summary>
        [JsonProperty(PropertyName = "product_name")]
        public string ProductName { get; set; }

        /// <summary>company name.</summary>
        [JsonProperty(PropertyName = "company_name")]
        public string CompanyName { get; set; }

        /// <summary>color.</summary>
        [JsonProperty(PropertyName = "color")]
        public bool Color { get; set; }

        /// <summary>duplex.</summary>
        [JsonProperty(PropertyName = "duplex")]
        public bool Duplex { get; set; }

        /// <summary>corner staple.</summary>
        [JsonProperty(PropertyName = "corner_staple")]
        public bool CornerStaple { get; set; }

        /// <summary>side staple.</summary>
        [JsonProperty(PropertyName = "side_staple")]
        public bool SideStaple { get; set; }

        /// <summary>punch 2point.</summary>
        [JsonProperty(PropertyName = "punch_2point")]
        public bool Punch2Point { get; set; }

        /// <summary>punch 3point.</summary>
        [JsonProperty(PropertyName = "punch_3point")]
        public bool Punch3Point { get; set; }

        /// <summary>punch 4point.</summary>
        [JsonProperty(PropertyName = "punch_4point")]
        public bool Punch4Point { get; set; }

        /// <summary>trays.</summary>
        [JsonProperty(PropertyName = "trays")]
        public List<Tray> Trays { get; set; }
    }
}