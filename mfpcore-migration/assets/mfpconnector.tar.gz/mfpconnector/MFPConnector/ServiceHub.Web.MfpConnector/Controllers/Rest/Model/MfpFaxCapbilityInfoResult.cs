﻿using Newtonsoft.Json;

namespace ServiceHub.Web.MfpConnector.Controllers.Rest.Model
{
    /// <summary>
    /// Get MFP Fax Capability info result.
    /// </summary>
    public class MfpFaxCapbilityInfoResult : IResponseModel
    {
        /// <summary>fax enabled.</summary>
        [JsonProperty(PropertyName = "fax_enabled")]
        public bool FaxEnabled { get; set; }
    }

}