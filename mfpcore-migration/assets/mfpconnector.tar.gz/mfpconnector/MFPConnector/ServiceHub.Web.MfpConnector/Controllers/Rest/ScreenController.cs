using System;
using System.Net;
using System.Threading.Tasks;
using KonicaMinolta.OpenApi;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ServiceHub.Common.Model;
using ServiceHub.Common.Settings;
using ServiceHub.Connectors.OpenAPI.Model;
using ServiceHub.Processors.ReadyManage;
using ServiceHub.Processors.Screen;
using ServiceHub.Processors.Screen.Model;
using ServiceHub.Web.MfpConnector.Controllers.Utility;

namespace ServiceHub.Web.MfpConnector.Controllers.Rest
{
    /// <summary>
    /// Screen controller
    /// See at
    ///   interface: https://confluence.kmiservicehub.com/display/SHS/Switch+Screen
    ///   sequence: https://confluence.kmiservicehub.com/display/SHS/%28Sequence%29+MFP+Switching+Screen
    /// </summary>
    [Route("api/screen")]
    public class ScreenController : AbstractController
    {
        private readonly IScreenOperator _screenOperator;
        private readonly IMfpReadyManage _mfpReadyManage;
        private readonly ILogger<ScreenController> _logger;

        /// <summary>
        /// Initializes a new instance of the <see cref="ScreenController" /> class.
        /// </summary>
        /// <param name="logger">Logger</param>
        /// <param name="mfpConnectorSetting">The MFP connector setting.</param>
        /// <param name="screenOperator">The screen operator.</param>
        /// <param name="mfpReadyManage">The MFP ready manage.</param>
        public ScreenController(
            ILogger<ScreenController> logger, 
            MfpConnectorSetting mfpConnectorSetting, 
            IScreenOperator screenOperator, 
            IMfpReadyManage mfpReadyManage) 
            : base(mfpConnectorSetting)
        {
            _logger = logger;
            _screenOperator = screenOperator;
            _mfpReadyManage = mfpReadyManage;
        }

        /// <summary>
        /// Sets the screen to legacy or Workplace Hub.
        /// </summary>
        /// <param name="changeSetting">The screen setting.</param>
        /// <returns>HTTP response</returns>
        /// <remarks>
        /// Sets the screen to legacy or Workplace Hub.
        /// </remarks>
        [HttpPut]
        [ProducesResponseType((int)HttpStatusCode.NoContent)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ExceptionMessage), (int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> ScreenChange([FromBody] ScreenSetting changeSetting)
        {
            try
            {               
                if (changeSetting.SwitchType == SwitchType.MFP)
                {
                    _mfpReadyManage.Pause();
                }

                await _screenOperator.ScreenChangeAsync(changeSetting.SwitchType, changeSetting.ScreenType, changeSetting.AppNo);

                if (changeSetting.SwitchType == SwitchType.WPH)
                {
                    _mfpReadyManage.Resume();
                }

                return StatusCode((int)HttpStatusCode.NoContent);
            }
            catch (OpenApiNackException)
            {
                if (changeSetting.SwitchType == SwitchType.MFP)
                {
                    _mfpReadyManage.Resume();
                }

                return StatusCode((int)HttpStatusCode.BadRequest);
            }
            catch (Exception e)
            {
                _logger.LogError(default(EventId), e, "ScreenChange occurs unexpected error.");
                if (changeSetting.SwitchType == SwitchType.MFP)
                {
                    _mfpReadyManage.Resume();
                }

                return JsonResponseCreator.CreateException(e, HttpStatusCode.InternalServerError);
            }
        }
    }
}
