using Newtonsoft.Json;

namespace ServiceHub.Web.MfpConnector.Controllers.Rest.Model
{
    /// <summary>
    /// Jobs controller result
    /// </summary>
    public class JobsControllerResult : IResponseModel
    {
        /// <summary>
        /// Gets or sets results for job.
        /// </summary>
        [JsonProperty(PropertyName = "result")]
        public string Result { get; set; }

        /// <summary>
        /// Gets or sets error for job.
        /// </summary>
        [JsonProperty(PropertyName = "error")]
        public string Error { get; set; }

        /// <summary>
        /// Gets or sets errorMsg for job.
        /// </summary>
        [JsonProperty(PropertyName = "errorMsg")]
        public string ErrorMsg { get; set; }
    }
}