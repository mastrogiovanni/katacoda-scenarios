using Newtonsoft.Json;

namespace ServiceHub.Web.MfpConnector.Controllers.Rest.Model
{
    /// <summary>
    /// Copy result
    /// </summary>
    public class CopyControllerResult : IResponseModel
    {
        /// <summary>Result type string.</summary>
        [JsonProperty(PropertyName = "result")]
        public string Result { get; set; }

        /// <summary>Error detail string.</summary>
        [JsonProperty(PropertyName = "error")]
        public string Error { get; set; }

        /// <summary>Combination prohibited.</summary>
        [JsonProperty(PropertyName = "is_combination_prohibited")]
        public bool? IsCombinationProhibited { get; set; }

        /// <summary>Job ID.</summary>
        [JsonProperty(PropertyName = "mfp_job_id")]
        public int? JobId { get; set; }
    }
}