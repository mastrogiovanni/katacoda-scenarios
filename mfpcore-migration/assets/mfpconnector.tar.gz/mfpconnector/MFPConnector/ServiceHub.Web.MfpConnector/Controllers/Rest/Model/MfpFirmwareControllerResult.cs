using Newtonsoft.Json;

namespace ServiceHub.Web.MfpConnector.Controllers.Rest.Model
{
    /// <summary>
    /// MFP-Firmware controll result
    /// </summary>
    public class MfpFirmwareControllerResult : IResponseModel
    {
        /// <summary>
        /// Results for job.
        /// </summary>
        [JsonProperty(PropertyName = "result")]
        public string Result { get; set; }
    }
}