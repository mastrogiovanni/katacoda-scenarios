using Newtonsoft.Json;

namespace ServiceHub.Web.MfpConnector.Controllers.Rest.Model
{
    /// <summary>
    /// Jobs Manipulate result
    /// </summary>
    public class JobsManipulateControllerResult : IResponseModel
    {
        /// <summary>
        /// Gets or sets results for job.
        /// </summary>
        [JsonProperty(PropertyName = "success")]
        public bool Success { get; set; }
    }
}