﻿using Newtonsoft.Json;

namespace ServiceHub.Web.MfpConnector.Controllers.Rest.Model
{
    /// <summary>
    /// Get MFP product info result.
    /// </summary>
    public class MfpMarketAreaResult : IResponseModel
    {
        /// <summary>market area.</summary>
        [JsonProperty(PropertyName = "market_area")]
        public string MarketArea { get; set; }
    }
}