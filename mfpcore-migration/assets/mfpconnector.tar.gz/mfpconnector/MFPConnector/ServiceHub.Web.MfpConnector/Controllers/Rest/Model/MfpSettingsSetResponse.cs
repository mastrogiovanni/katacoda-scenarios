using System.Collections.Generic;
using Newtonsoft.Json;
using ServiceHub.Processors.MfpSetting.Model;

namespace ServiceHub.Web.MfpConnector.Controllers.Rest.Model
{
    /// <summary>
    /// MFP Settings set response
    /// </summary>
    public class MfpSettingsSetResponse : IResponseModel
    {
        /// <summary>
        /// Settins result
        /// </summary>
        [JsonProperty(PropertyName = "setting_result")]
        public List<SetSettingResult> SettingResult { get; set; }
    }
}
