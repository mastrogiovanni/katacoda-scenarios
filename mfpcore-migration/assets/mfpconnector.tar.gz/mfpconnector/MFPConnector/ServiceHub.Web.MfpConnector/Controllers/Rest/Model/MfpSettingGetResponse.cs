using Newtonsoft.Json;

namespace ServiceHub.Web.MfpConnector.Controllers.Rest.Model
{
    /// <summary>
    /// Mfp settings get response
    /// </summary>
    public class MfpSettingGetResponse : IResponseModel
    {
        /// <summary>
        /// Success
        /// </summary>
        [JsonProperty(PropertyName = "result")]
        public bool Result { get; set; }

        /// <summary>
        /// Key
        /// </summary>
        [JsonProperty(PropertyName = "key")]
        public string Key { get; set; }

        /// <summary>
        /// Values
        /// </summary>
        [JsonProperty(PropertyName = "value")]
        public object Values { get; set; }

        /// <summary>
        /// Datatype
        /// </summary>
        [JsonProperty(PropertyName = "datatype")]
        public string Datatype { get; set; }

        /// <summary>
        /// Range
        /// </summary>
        [JsonProperty(PropertyName = "range")]
        public short Range { get; set; }
    }
}
