using Newtonsoft.Json;

namespace ServiceHub.Web.MfpConnector.Controllers.Rest.Model
{
    /// <summary>
    /// Result of PauseAllJobs
    /// </summary>
    public class PauseAllJobsControllerResult : IResponseModel
    {
        /// <summary>
        /// Gets or sets results for job.
        /// </summary>
        [JsonProperty(PropertyName = "success")]
        public bool Success { get; set; }

        /// <summary>
        /// Gets or sets error for job.
        /// </summary>
        [JsonProperty(PropertyName = "error_code", DefaultValueHandling = DefaultValueHandling.IgnoreAndPopulate)]
        public string ErrorCode { get; set; }
    }
}