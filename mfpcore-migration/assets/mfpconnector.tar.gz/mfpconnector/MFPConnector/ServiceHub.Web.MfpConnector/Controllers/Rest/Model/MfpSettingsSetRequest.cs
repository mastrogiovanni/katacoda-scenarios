using System.Collections.Generic;
using Newtonsoft.Json;
using ServiceHub.Processors.MfpSetting.Model;

namespace ServiceHub.Web.MfpConnector.Controllers.Rest.Model
{
    /// <summary>
    /// MFP Settings set request
    /// </summary>
    public class MfpSettingsSetRequest
    {
        /// <summary>
        /// Setting names.
        /// </summary>
        [JsonProperty("setting_values")]
        public List<SetSettingValue> SettingValues { get; set; }
    }
}