namespace ServiceHub.Web.MfpConnector.Controllers.Rest.Model
{
    /// <summary>
    /// Response data marker interface
    /// </summary>
    public interface IResponseModel
    {
    }
}
