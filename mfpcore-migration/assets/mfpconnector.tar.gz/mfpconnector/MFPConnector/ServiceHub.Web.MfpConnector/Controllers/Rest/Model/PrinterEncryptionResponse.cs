﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using ServiceHub.Processors.DeviceInfo.Model;

namespace ServiceHub.Web.MfpConnector.Controllers.Rest.Model
{
    /// <summary>
    /// Printer encryption setting response.
    /// </summary>
    public class PrinterEncryptionResponse : IResponseModel
    {
        /// <summary>
        /// Printer encryption type.
        /// </summary>
        [JsonProperty(PropertyName = "type", Required = Required.Always)]
        [JsonConverter(typeof(StringEnumConverter))]
        public PrinterEncryptionType? Type { get; set; }

        /// <summary>
        /// Printer encryption word.
        /// </summary>
        [JsonProperty(PropertyName = "encryption_word", Required = Required.Default)]
        public string EncryptionWord { get; set; }
    }
}
