using Newtonsoft.Json;

namespace ServiceHub.Web.MfpConnector.Controllers.Rest.Model
{
    /// <summary>
    /// MFP State result class.
    /// </summary>
    public class MfpStateResult : IResponseModel
    {
        /// <summary>
        /// Result
        /// </summary>
        [JsonProperty(PropertyName = "alive")]
        public bool Alive { get; set; }
    }
}
