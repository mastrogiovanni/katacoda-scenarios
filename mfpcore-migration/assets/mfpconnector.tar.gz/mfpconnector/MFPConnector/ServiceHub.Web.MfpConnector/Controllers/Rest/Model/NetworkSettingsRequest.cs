using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using ServiceHub.Connectors.OpenAPI.Model;

namespace ServiceHub.Web.MfpConnector.Controllers.Rest.Model
{
    /// <summary>
    /// Network settings request.
    /// </summary>
    public class NetworkSettingsRequest
    {
        /// <summary>
        /// Ip address v4.
        /// </summary>
        [JsonProperty("ip_address_v4")]
        public string IpAddressV4 { get; set; }

        /// <summary>
        /// Ip address v6.
        /// </summary>
        [JsonProperty("ip_address_v6")]
        public string IpAddressV6 { get; set; }

        /// <summary>
        /// Ip v6 type.
        /// </summary>
        [JsonProperty("ip_v6_type")]
        [JsonConverter(typeof(StringEnumConverter))]
        public Ipv6Type? IpV6Type { get; set; }
    }
}