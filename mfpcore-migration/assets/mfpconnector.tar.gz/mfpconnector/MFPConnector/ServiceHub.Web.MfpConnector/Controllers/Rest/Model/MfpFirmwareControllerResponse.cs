﻿using Newtonsoft.Json;

namespace ServiceHub.Web.MfpConnector.Controllers.Rest.Model
{
    /// <summary>
    /// MFP-Firmware controll response
    /// </summary>
    public class MfpFirmwareControllerResponse : IResponseModel
    {
        /// <summary>
        /// Settins value
        /// </summary>
        [JsonProperty(PropertyName = "filename")]
        public string Filename { get; set; }
    }
}
