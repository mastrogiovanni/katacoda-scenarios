using System;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ServiceHub.Connectors.OpenAPI.Model;
using ServiceHub.Processors.Warning;
using ServiceHub.Common.Model;
using ServiceHub.Web.MfpConnector.Controllers.Rest.Model;
using Microsoft.Extensions.Logging;
using ServiceHub.Common.Settings;
using ServiceHub.Web.MfpConnector.Controllers.Utility;

namespace ServiceHub.Web.MfpConnector.Controllers.Rest
{
    /// <summary>
    /// Warning controller.
    /// </summary>
    [Route("api/device/warning")]
    public class WarningController : AbstractController
    {
        private readonly IWarningOperator _warningOperator;
        private readonly ILogger<WarningController> _logger;

        /// <summary>
        /// Initializes a new instance of the <see cref="IWarningOperator" /> class.
        /// </summary>
        /// <param name="logger">Logger</param>
        /// <param name="mfpConnectorSetting">The MFP connector setting.</param>
        /// <param name="warningOperator">The warning operator.</param>
        public WarningController(
            ILogger<WarningController> logger,
            MfpConnectorSetting mfpConnectorSetting,
            IWarningOperator warningOperator)
            : base(mfpConnectorSetting)
        {
            _logger = logger;
            _warningOperator = warningOperator;
        }

        /// <summary>
        /// Sends a warnings request to the MFP device using the request body.
        /// </summary>
        /// <param name="request">The request.</param>
        /// <returns>
        /// HTTP response
        /// </returns>
        /// <remarks>
        /// Sends a warnings request to the MFP device using the request body.
        /// </remarks>
        [HttpPost("canceldatalist")]
        [ProducesResponseType(typeof(WarningServiceResult), (int)HttpStatusCode.Created)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ExceptionMessage), (int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> Warning([FromBody] WarningServiceSetting request)
        {
            IActionResult response;

            try
            {
                if (request == null)
                {
                    _logger.LogWarning("Invalid parameters");
                    return JsonResponseCreator.CreateError("Invalid parameters", HttpStatusCode.BadRequest);
                }

                // Cencel Warning.
                var resultCancel = await _warningOperator.CancelWarningAsync(request);

                var result = new WarningServiceResult
                {
                    Result = resultCancel
                };

                response = JsonResponseCreator.Create(result, HttpStatusCode.Created);
            }
            catch (Exception e)
            {
                _logger.LogError(default(EventId), e, "Exception occurred cancel warning.");
                response = JsonResponseCreator.CreateException(e, HttpStatusCode.InternalServerError);
            }

            return response;
        }
    }
}
