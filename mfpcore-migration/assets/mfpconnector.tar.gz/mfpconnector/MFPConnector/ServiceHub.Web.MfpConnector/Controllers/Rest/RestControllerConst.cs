namespace ServiceHub.Web.MfpConnector.Controllers.Rest
{
    /// <summary>
    /// Constants of rest controller class.
    /// </summary>
    internal static class RestControllerConst
    {
        public const string ResponseErrorInvalidParameter = "Invalid request parameter. {0}";
        public const string ResponseErrorWakeUp = "MFP wake up failed.";
        public const string ResponseErrorPaperSizeDifference = "ManualPaperSizeDifferenceErr";

        public const string EnumException = "EnumException";
        public const string MfpInvalidState = "MFPInvalidStateErr";
        public const string Exception = "Exception";

        /// <summary>
        /// The error description req_change power save status in idle
        /// </summary>
        public const string ErrorDescriptionReqChangePowerSaveStatusInIdle = "req_changePowerSaveStatusInIdle";
    }
}