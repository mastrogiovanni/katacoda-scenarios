using System;
using System.ComponentModel.DataAnnotations;
using System.IO;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ServiceHub.Common.Extensions;
using ServiceHub.Common.Settings;
using ServiceHub.Connectors.IWS;
using ServiceHub.Processors.DeviceInfo;
using ServiceHub.Web.MfpConnector.Controllers.Rest.Model;
using Microsoft.Extensions.Logging;
using ServiceHub.Web.MfpConnector.Controllers.Utility;

namespace ServiceHub.Web.MfpConnector.Controllers.Rest.Iws
{
    /// <summary>
    /// Internal Web Server (IWS) special application install controller
    /// </summary>
    [Route("api/iws_special_apps")]
    public class IwsSpecialAppsController : AbstractController
    {
        private readonly IIwsConnector _iwsConnectorAdmin;
        private readonly IDeviceInfoOperator _deviceInfoOperator;
        private readonly ILogger<IwsSpecialAppsController> _logger;

        /// <summary>
        /// Initializes a new instance of the <see cref="IwsSpecialAppsController" /> class.
        /// </summary>
        /// <param name="logger">Logger</param>
        /// <param name="mfpConnectorSetting">The MFP connector setting.</param>
        /// <param name="iwsConnectorAdmin">The iws connector admin.</param>
        /// <param name="deviceInfoOperator">The device information operator.</param>
        public IwsSpecialAppsController(
            ILogger<IwsSpecialAppsController> logger,
            MfpConnectorSetting mfpConnectorSetting,
            IIwsConnectorAdmin iwsConnectorAdmin,
            IDeviceInfoOperator deviceInfoOperator)
            : base(mfpConnectorSetting)
        {
            _logger = logger;
            _iwsConnectorAdmin = iwsConnectorAdmin;
            _deviceInfoOperator = deviceInfoOperator;
        }

        /// <summary>
        /// Gets all special IWS application list.
        /// </summary>
        /// <returns>
        /// Return the application list with the remaining space on the drive.
        /// </returns>
        /// <remarks>
        /// Return the application list with the remaining space on the drive.
        /// </remarks>
        [ProducesResponseType(typeof(IwsSpecialAppsListResult), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(IwsSpecialAppsListResult), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("getAppList")]
        public async Task<IActionResult> GetAppList()
        {
            var status = HttpStatusCode.OK;
            IwsSpecialAppsListResult response = null;
            try
            {
                // Get app list 
                var appList = await _iwsConnectorAdmin.GetAppListAsync();

                response = new IwsSpecialAppsListResult
                {
                    RemainHdd = appList.RemainHdd,
                    AppList = appList.AppList
                };

            }
            catch (Exception e)
            {
                _logger.LogError($"getAppList() catches exception. {e.Message}");
                status = HttpStatusCode.InternalServerError;
            }

            return JsonResponseCreator.Create(response, status);
        }

        /// <summary>
        /// Installs a special IWS application.
        /// </summary>
        /// <returns>
        /// Returns created when successfully installed the special application.
        /// </returns>
        /// <remarks>
        /// Install the special application and then remove the installation file.
        /// </remarks>
        [HttpPost("install")]
        [ProducesResponseType((int)HttpStatusCode.Created)]
        [ProducesResponseType(typeof(IwsSpecialAppsControllerResult), (int)HttpStatusCode.InternalServerError)]
        [ProducesResponseType(typeof(IwsSpecialAppsControllerResult), (int)HttpStatusCode.ServiceUnavailable)]
        public async Task<IActionResult> Install()
        {
            _logger.LogInformation(GetType().Name + ".Install START");

            IActionResult response;

            try
            {
                // Obtain serial number
                var serialNumber = await GetSerialNumberAsync();
                if (string.IsNullOrWhiteSpace(serialNumber))
                {
                    throw new ArgumentNullException(nameof(serialNumber));
                }

                var filePath = GetAppFilePath();

                // install 
                await _iwsConnectorAdmin.InstallSpecialAppAsync(
                    MfpConnectorSetting.Iws.CurrentSetting.AppId,
                    filePath,
                    serialNumber);

                // delete file
                try
                {
                    DeleteFile(filePath);
                }
                catch (Exception e)
                {
                    _logger.LogWarning(default(EventId), e, $"[Err:001] Install() catches exception. {e.Message}\n{e.StackTrace}");
                }

                response = StatusCode((int)HttpStatusCode.Created);
            }
            catch (IwsException e)
            {
                _logger.LogError(default(EventId), e, $"[Err:002] Install() catches exception. {e.Message}");
                var resp = new IwsSpecialAppsControllerResult
                {
                    ErrorCode = e.Message
                };
                response = 
                    IwsException.IwsErrorFatal == GerError(e.Message) ?
                    StatusCode((int)HttpStatusCode.ServiceUnavailable, resp) :
                    StatusCode((int)HttpStatusCode.InternalServerError, resp);
            }
            catch (ArgumentNullException e)
            {
                _logger.LogError(default(EventId), e, $"[Err:003] Install() catches exception. {e.Message}");
                var resp = new IwsSpecialAppsControllerResult
                {
                    ErrorCode = $"{e.ParamName} is null."
                };
                response = StatusCode((int)HttpStatusCode.InternalServerError, resp);
            }
            catch (ArgumentException e)
            {
                _logger.LogError(default(EventId), e, $"[Err:004] Install() catches exception. {e.Message}");
                var resp = new IwsSpecialAppsControllerResult
                {
                    ErrorCode = $"{e.ParamName} is not valid."
                };
                response = StatusCode((int)HttpStatusCode.InternalServerError, resp);
            }
            catch (Exception e)
            {
                _logger.LogError(default(EventId), e, $"[Err:005] Install() catches exception. {e.Message}");
                var resp = new IwsSpecialAppsControllerResult
                {
                    ErrorCode = $"Unexpected error occurs. {e.Message}"
                };
                response = StatusCode((int)HttpStatusCode.InternalServerError, resp);
            }
            finally
            {
                _logger.LogInformation(GetType().Name + ".Install END");
            }

            return response;
        }

        /// <summary>
        /// Uninstalls a special IWS application.
        /// </summary>
        /// <returns>Returns no-content when successfull.</returns>
        /// <remarks>Uninstall the special application.</remarks>
        [HttpPost("uninstall")]
        [ProducesResponseType((int)HttpStatusCode.NoContent)]
        [ProducesResponseType(typeof(IwsSpecialAppsControllerResult), (int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> Uninstall()
        {
            _logger.LogInformation(GetType().Name + ".Uninstall START");

            IActionResult response;

            try
            {
                // Obtain serial number
                var serialNumber = await GetSerialNumberAsync();
                if (string.IsNullOrWhiteSpace(serialNumber))
                {
                    throw new ArgumentNullException(nameof(serialNumber));
                }

                // install 
                await _iwsConnectorAdmin.UninstallSpecialAppAsync(
                    MfpConnectorSetting.Iws.CurrentSetting.AppId,
                    serialNumber);

                response = NoContent();
            }
            catch (IwsException e)
            {
                _logger.LogError(default(EventId), e, $"Uninstall() catches exception. {e.Message}");
                response = JsonResponseCreator.Create(new IwsSpecialAppsControllerResult
                {
                    ErrorCode = e.Message
                }, HttpStatusCode.InternalServerError);
            }
            catch (ArgumentNullException e)
            {
                _logger.LogError(default(EventId), e, $"Uninstall() catches exception. {e.Message}");
                response = JsonResponseCreator.Create(new IwsSpecialAppsControllerResult
                {
                    ErrorCode = $"{e.ParamName} is null."
                }, HttpStatusCode.InternalServerError);
            }
            catch (ArgumentException e)
            {
                _logger.LogError(default(EventId), e, $"Uninstall() catches exception. {e.Message}");
                response = JsonResponseCreator.Create(new IwsSpecialAppsControllerResult
                {
                    ErrorCode = $"{e.ParamName} is not valid."
                }, HttpStatusCode.InternalServerError);
            }
            catch (Exception e)
            {
                _logger.LogError(default(EventId), e, $"Uninstall() catches exception. {e.Message}");
                response = JsonResponseCreator.Create(new IwsSpecialAppsControllerResult
                {
                    ErrorCode = $"Unexpected error occurs. {e.Message}"
                }, HttpStatusCode.InternalServerError);
            }
            finally
            {
                _logger.LogInformation(GetType().Name + ".Uninstall END");
            }

            return response;
        }

        /// <summary>
        /// Uploads a special IWS application to the MFP.
        /// </summary>
        /// <param name="specialApp">The special application from an upload file form.</param>
        /// <returns>
        /// Returns the error if any.
        /// </returns>
        /// <remarks>Upload the special application without starting the installation process.</remarks>
        [HttpPost("upload")]
        [Consumes("multipart/form-data")]
        [ProducesResponseType((int)HttpStatusCode.Created)]
        [ProducesResponseType(typeof(IwsSpecialAppsControllerResult), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(IwsSpecialAppsControllerResult), (int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> Upload([FromForm] [Required] IFormFile specialApp)
        {
            _logger.LogInformation(GetType().Name + ".Upload START");

            try
            {
                if (specialApp == null)
                {
                    _logger.LogError("[IwsSpecialAppsController.Upload] Attached file is not 1.");
                    var resp = new IwsSpecialAppsControllerResult
                    {
                        ErrorCode = "File not found or attached more than 1."
                    };
                    return StatusCode((int)HttpStatusCode.BadRequest, resp);
                }
                else if (specialApp.Name?.TrimStart('"').TrimEnd('"') != MfpConnectorSetting.Iws.AppInstall.FormContentName)
                {
                    _logger.LogError("[IwsSpecialAppsController.Upload] Attached name is not expected.");
                    var resp = new IwsSpecialAppsControllerResult
                    {
                        ErrorCode = "Attached file is not expected Content-Disposition name."
                    };
                    return StatusCode((int)HttpStatusCode.BadRequest, resp);
                }

                await SaveFileAsync(specialApp.OpenReadStream(), GetAppFilePath());

                return StatusCode((int)HttpStatusCode.Created);
            }
            catch (IOException ex)
            {
                _logger.LogError(default(EventId), ex, "Upload() catches exception.");
                var resp = new IwsSpecialAppsControllerResult
                {
                    ErrorCode = "File saving failed."
                };
                return StatusCode((int)HttpStatusCode.InternalServerError, resp);
            }
            catch (ArgumentException ex)
            {
                _logger.LogError(default(EventId), ex, "Upload() catches exception.");
                var resp = new IwsSpecialAppsControllerResult
                {
                    ErrorCode = "Invalid request format."
                };
                return StatusCode((int)HttpStatusCode.InternalServerError, resp);
            }
            catch (Exception ex)
            {
                _logger.LogError(default(EventId), ex, "Upload() catches exception.");
                var resp = new IwsSpecialAppsControllerResult
                {
                    ErrorCode = "Unexpected error."
                };
                return StatusCode((int)HttpStatusCode.InternalServerError, resp);
            }
            finally
            {
                _logger.LogInformation(GetType().Name + ".Upload END");
            }
        }

        /// <summary>
        /// Saves a file
        /// </summary>
        /// <param name="stream">File stream</param>
        /// <param name="filePath">Local file path</param>
        /// <exception cref="IOException">Failed saving stream</exception>
        [ApiExplorerSettings(IgnoreApi = true)]
        public virtual async Task SaveFileAsync(Stream stream, string filePath)
        {
            _logger.LogInformation($"Save file to {filePath}");

            if (stream == null || stream.Length == 0)
            {
                throw new IOException("File is empty.");
            }

            using (var fs = System.IO.File.Create(filePath))
            {
                if (stream.CanSeek)
                {
                    stream.Seek(0, SeekOrigin.Begin);
                }

                await stream.CopyToAsync(fs);
            }
        }

        /// <summary>
        /// Deletes a file
        /// </summary>
        /// <param name="filePath">Local file path</param>
        [ApiExplorerSettings(IgnoreApi = true)]
        public virtual void DeleteFile(string filePath)
        {
            _logger.LogInformation($"Delete file from {filePath}");
            System.IO.File.Delete(filePath);
        }

        /// <summary>
        /// Obtain serial number
        /// </summary>
        /// <returns>Serial number</returns>
        private async Task<string> GetSerialNumberAsync()
        {
            return await _deviceInfoOperator.GetSerialNumberAsync();
        }

        /// <summary>
        /// Obtain application file path
        /// </summary>
        /// <returns>Application file path</returns>
        private string GetAppFilePath()
        {
            var savePath = MfpConnectorSetting.Iws.AppInstall.FolderPath;
            if (savePath.StartsWith("~/"))
            {
                savePath = savePath.MapPath(MfpConnector.Settings.ContentRootPath);
            }

            return Path.Combine(savePath, MfpConnectorSetting.Iws.AppInstall.FileName);
        }
    }
}
