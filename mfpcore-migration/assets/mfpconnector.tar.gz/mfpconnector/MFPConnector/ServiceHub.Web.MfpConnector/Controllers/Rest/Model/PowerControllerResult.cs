using Newtonsoft.Json;

using ServiceHub.Processors.Common;

namespace ServiceHub.Web.MfpConnector.Controllers.Rest.Model
{
    /// <summary>
    /// Power controller result
    /// </summary>
    public class PowerControllerResult : IResponseModel
    {
        /// <summary>
        /// Initializes a new instance of the PowerControllerResult class.
        /// </summary>
        public PowerControllerResult()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PowerControllerResult"/> class.
        /// </summary>
        /// <param name="result">The result information.</param>
        public PowerControllerResult(bool result)
        {
            Result = result ? SenderConfig.IwsResultStatus.OK.ToString() : SenderConfig.IwsResultStatus.NG.ToString();
        }

        /// <summary>
        /// Result type string.
        /// </summary>
        [JsonProperty(PropertyName = "result")]
        public string Result { get; set; }
    }
}