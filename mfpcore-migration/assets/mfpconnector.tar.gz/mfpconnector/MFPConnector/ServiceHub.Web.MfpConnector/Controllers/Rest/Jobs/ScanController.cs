using System;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ServiceHub.Common.Model;
using ServiceHub.Common.Settings;
using ServiceHub.Connectors.IWS;
using ServiceHub.Processors.Common;
using ServiceHub.Processors.Power;
using ServiceHub.Processors.Scan.Model;
using ServiceHub.Web.MfpConnector.Controllers.Rest.Model;
using ServiceHub.Web.MfpConnector.Controllers.Utility;

namespace ServiceHub.Web.MfpConnector.Controllers.Rest.Jobs
{
    /// <summary>
    /// Scan controller.
    /// </summary>
    [Route("api/scan")]
    public class ScanController : AbstractController
    {
        private readonly IPowerOperator _powerOperator;
        private readonly IMfpSender<ScanServiceSetting, ScanServiceResult> _scanServiceSender;
        private readonly ILogger<ScanController> _logger;

        /// <summary>
        /// Initializes a new instance of the <see cref="ScanController" /> class.
        /// </summary>
        /// <param name="logger">Logger</param>
        /// <param name="mfpConnectorSetting">The MFP connector setting.</param>
        /// <param name="powerOperator">The power operator.</param>
        /// <param name="scanServiceSender">The scan service sender.</param>
        public ScanController(
            ILogger<ScanController> logger, 
            MfpConnectorSetting mfpConnectorSetting, 
            IPowerOperator powerOperator,
            IMfpSender<ScanServiceSetting, ScanServiceResult> scanServiceSender)
            : base(mfpConnectorSetting)
        {
            _powerOperator = powerOperator;
            _scanServiceSender = scanServiceSender;
            _logger = logger;
        }

        /// <summary>
        /// Scans the specified request object.
        /// </summary>
        /// <param name="requestObj">The request object.</param>
        /// <returns>
        /// HTTP response
        /// </returns>
        /// <remarks>
        /// Scans the specified request object.
        /// </remarks>
        [HttpPost("")]
        [ProducesResponseType(typeof(ScanControllerResult), (int)HttpStatusCode.Created)]
        [ProducesResponseType(typeof(ScanControllerResult), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ScanControllerResult), (int)HttpStatusCode.ServiceUnavailable)]
        [ProducesResponseType(typeof(ScanControllerResult), (int)HttpStatusCode.InternalServerError)]
        [ProducesResponseType(typeof(ExceptionMessage), (int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> Scan([FromBody] ScanServiceSetting requestObj)
        {
            try
            {
                if (requestObj == null)
                {
                    // bad request
                    return BadRequest(new ScanControllerResult
                    {
                        Result = SenderConfig.IwsResultStatus.NG.ToString(),
                        Error = string.Format(RestControllerConst.ResponseErrorInvalidParameter, string.Empty)
                    });
                }

                // wake up.
                var resultMfp = await _powerOperator.WakeUpToMfpAsync();

                if (!resultMfp)
                {
                    return InternalServerError(new ScanControllerResult
                    {
                        Result = SenderConfig.IwsResultStatus.NG.ToString(),
                        Error = RestControllerConst.ResponseErrorWakeUp
                    });
                }
               
                // exec scan.
                var result = await _scanServiceSender.SendToMfpAsync(requestObj);
                var errorMessage = result.Error;

                var response = new ScanControllerResult
                {
                    Result = result.Result,
                    JobId = result.JobId,
                    Error = GerError(result.Error)
                };

                return ControllerResult(response, result.Result, errorMessage);
               
            }
            catch (IwsException ex)
            {
                _logger.LogError(default(EventId), ex, $"IwsException occurred during copy job.{ex.Message}");

                var scanControllerResult = new ScanControllerResult
                {
                    Result = SenderConfig.IwsResultStatus.NG.ToString(),
                    Error = IwsException.IwsErrorFatal
                };

                return ControllerResult(scanControllerResult, scanControllerResult.Result,ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(default(EventId), ex, "Exception occurred during scan job.");
                return JsonResponseCreator.CreateException(ex, HttpStatusCode.InternalServerError);
            }
        }
    }
}
