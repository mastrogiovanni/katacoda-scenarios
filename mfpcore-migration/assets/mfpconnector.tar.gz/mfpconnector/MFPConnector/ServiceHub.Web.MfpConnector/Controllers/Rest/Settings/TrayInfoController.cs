using System;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ServiceHub.Common.Model;
using ServiceHub.Common.Settings;
using ServiceHub.Connectors.OpenAPI.Model;
using ServiceHub.Processors.DeviceInfo;
using ServiceHub.Web.MfpConnector.Controllers.Rest.Model;
using Microsoft.Extensions.Logging;
using ServiceHub.Web.MfpConnector.Controllers.Utility;

namespace ServiceHub.Web.MfpConnector.Controllers.Rest.Settings
{
    /// <summary>
    /// Tray Info Settings controller.
    /// </summary>
    [Route("api/settings/trayinfo")]
    public class TrayInfoController : AbstractController
    {
        private readonly IDeviceInfoOperator _deviceInfoOperator;
        private readonly ILogger<TrayInfoController> _logger;

        /// <summary>
        /// Initializes a new instance of the <see cref="TrayInfoController" /> class.
        /// </summary>
        /// <param name="logger">Logger</param>
        /// <param name="mfpConnectorSetting">Mfp connector settings</param>
        /// <param name="deviceInfoOperator">Device info operator</param>
        public TrayInfoController(ILogger<TrayInfoController> logger, MfpConnectorSetting mfpConnectorSetting,
            IDeviceInfoOperator deviceInfoOperator)
            : base(mfpConnectorSetting)
        {
            _logger = logger;
            _deviceInfoOperator = deviceInfoOperator;
        }

        /// <summary>
        /// Sets the tray information of MFP.
        /// </summary>
        /// <param name="trayInfoSettingsRequest">The tray settings request.</param>
        /// <returns>
        /// HttpResponse
        /// </returns>
        /// <remarks>
        /// Sets the tray information of MFP.
        /// </remarks>
        [HttpPut("")]
        [ProducesResponseType(typeof(MfpSettingsSetResponse), (int)HttpStatusCode.NoContent)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ExceptionMessage), (int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> TrayInfo([FromBody] TrayInfoSettingsSetRequest trayInfoSettingsRequest)
        {

            if (trayInfoSettingsRequest?.SettingValues == null || trayInfoSettingsRequest.SettingValues.Count == 0)
            {
                _logger.LogWarning("Invalid request while creating or updating the Try Settings.");
                return BadRequest();
            }

            bool result;

            try
            {
                // Get result
                result = await _deviceInfoOperator.SetTrayInfoSettingAsync(trayInfoSettingsRequest?.SettingValues);
            }
            catch (Exception ex)
            {
                _logger.LogError(default(EventId), ex, "Exception occurred during set tray information of MFP.");
                return JsonResponseCreator.CreateException(ex, HttpStatusCode.InternalServerError);
            }

            if (result)
            {
                return StatusCode((int) HttpStatusCode.NoContent);
            }

            return BadRequest();
        }
    }
}
