using System;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ServiceHub.Common.Model;
using ServiceHub.Common.Settings;
using ServiceHub.Connectors.IWS;
using ServiceHub.Processors.Common;
using ServiceHub.Processors.Copy.Model;
using ServiceHub.Processors.DeviceInfo;
using ServiceHub.Processors.Power;
using ServiceHub.Web.MfpConnector.Controllers.Rest.Model;

namespace ServiceHub.Web.MfpConnector.Controllers.Rest.Jobs
{
    /// <summary>
    /// Copy controller.
    /// </summary>
    [Route("api/copy")]
    public class CopyController : AbstractController
    {
        private readonly IPowerOperator _powerOperator;
        private readonly IMfpSender<CopyServiceSetting, CopyServiceResult> _copyServiceSender;
        private readonly ILogger<CopyController> _logger;
        private readonly IDeviceInfoOperator _deviceInfoOperator;

        /// <summary>
        /// Initializes a new instance of the <see cref="CopyController" /> class.
        /// </summary>
        /// <param name="logger">Logger</param>
        /// <param name="deviceInfoOperator"></param>
        /// <param name="mfpConnectorSetting">The MFP connector setting.</param>
        /// <param name="powerOperator">The power operator.</param>
        /// <param name="copyServiceSender">The copy service sender.</param>
        public CopyController(
            ILogger<CopyController> logger,
            IDeviceInfoOperator deviceInfoOperator,
            MfpConnectorSetting mfpConnectorSetting,
            IPowerOperator powerOperator,
            IMfpSender<CopyServiceSetting, CopyServiceResult> copyServiceSender)
            : base(mfpConnectorSetting)
        {
            _logger = logger;
            _powerOperator = powerOperator;
            _copyServiceSender = copyServiceSender;
            _deviceInfoOperator = deviceInfoOperator;
        }

        /// <summary>
        /// Creates a copy request to the MFP device.
        /// </summary>
        /// <remarks>
        /// Create a job on the MFP using the provided copy settings.
        /// </remarks>
        /// <param name="copyServiceSetting">Job copy settings.</param>
        /// <returns>
        /// Copy result containing the job ID.
        /// </returns>
        [HttpPost("")]
        [ProducesResponseType(typeof(CopyControllerResult), (int)HttpStatusCode.Created)]
        [ProducesResponseType(typeof(ExceptionMessage), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ExceptionMessage), (int)HttpStatusCode.ServiceUnavailable)]
        [ProducesResponseType(typeof(ExceptionMessage), (int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> Post([FromBody] CopyServiceSetting copyServiceSetting)
        {
            try
            {
                if (copyServiceSetting == null)
                {
                    return BadRequest(new CopyControllerResult
                    {
                        Result = SenderConfig.IwsResultStatus.NG.ToString(),
                        Error = string.Format(RestControllerConst.ResponseErrorInvalidParameter, string.Empty)
                    });
                }

                // wake up.
                var resultMfp = await _powerOperator.WakeUpToMfpAsync();

                if (!resultMfp)
                {
                    return InternalServerError(new CopyControllerResult
                    {
                        Result = SenderConfig.IwsResultStatus.NG.ToString(),
                        Error = RestControllerConst.ResponseErrorWakeUp
                    });
                }

                if (copyServiceSetting?.OutPaperSize.Tray == CopyTray.MANUAL
                    && await _deviceInfoOperator.GetMfpManualTrayPaperSizeUnmatchAsync().ConfigureAwait(false))
                {
                    return BadRequest(new CopyControllerResult
                    {
                        Result = SenderConfig.IwsResultStatus.NG.ToString(),
                        Error = RestControllerConst.ResponseErrorPaperSizeDifference
                    });
                }

                // exec copy.
                var result = await _copyServiceSender.SendToMfpAsync(copyServiceSetting);
                var errorMessage = result.Error;

                var response = new CopyControllerResult
                {
                    Result = result.Result,
                    JobId = result.JobId,
                    Error = GerError(result.Error),
                    IsCombinationProhibited = result.IsCombinationProhibited
                };

                return ControllerResult(response, result.Result, errorMessage);
            }
            catch (IwsException ex)
            {
                _logger.LogError(default(EventId), ex, $"IwsException occurred during copy job.{ex.Message}");

                var copyControllerResult = new CopyControllerResult
                {
                    Result = SenderConfig.IwsResultStatus.NG.ToString(),
                    Error = IwsException.IwsErrorFatal
                };

                return ControllerResult(copyControllerResult, copyControllerResult.Result, ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(default(EventId), ex, "Exception occurred during copy job.");

                return InternalServerError(new CopyControllerResult
                {
                    Result = SenderConfig.IwsResultStatus.NG.ToString(),
                    Error = IwsException.IwsErrorFatal
                });
            }
        }
    }
}
