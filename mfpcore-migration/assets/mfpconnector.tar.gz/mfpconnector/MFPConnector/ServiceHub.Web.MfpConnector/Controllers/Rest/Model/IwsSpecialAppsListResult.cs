﻿using Newtonsoft.Json;
using System.Collections.Generic;
using ServiceHub.Connectors.IWS.Model;

namespace ServiceHub.Web.MfpConnector.Controllers.Rest.Model
{
    /// <inheritdoc />
    /// <summary>
    /// IWS Special app list result
    /// </summary>
    public class IwsSpecialAppsListResult : IResponseModel
    {
        /// <summary>RemainHdd type string.</summary>
        [JsonProperty(PropertyName = "remainHdd")]
        public uint RemainHdd { get; set; }

        /// <summary>AppList type AppIndo.</summary>
        [JsonProperty(PropertyName = "appList")]
        public List<AppInfo> AppList { get; set; }

    }
}
