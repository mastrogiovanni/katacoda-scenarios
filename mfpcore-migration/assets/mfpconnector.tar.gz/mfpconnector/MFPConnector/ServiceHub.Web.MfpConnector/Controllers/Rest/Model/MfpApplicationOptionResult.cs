﻿using ServiceHub.Common.Model;

namespace ServiceHub.Web.MfpConnector.Controllers.Rest.Model
{
    /// <summary>
    /// Get MFP application option result.
    /// </summary>
    public class MfpApplicationOptionResult : IResponseModel
    {
        /// <summary>
        /// stamp license
        /// </summary>
        public SwitchOption Stamp { get; set; }

        /// <summary>
        /// ooxml license
        /// </summary>
        public SwitchOption Ooxml { get; set; }
    }
}
