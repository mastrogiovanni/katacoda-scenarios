using System.Net;
using Microsoft.AspNetCore.Mvc;
using ServiceHub.Common.Settings;

namespace ServiceHub.Web.MfpConnector.Controllers
{
    /// <summary>
    /// Home controller
    /// </summary>
    [Route("")]
    [ApiExplorerSettings(IgnoreApi = true)]
    public class HomeController : Controller
    {
        private readonly MfpConnectorSetting _mfpConnectorSetting;

        /// <summary>
        /// Home controller
        /// </summary>
        /// <param name="mfpConnectorSetting">The MFP connector setting.</param>
        public HomeController(MfpConnectorSetting mfpConnectorSetting)
        {
            _mfpConnectorSetting = mfpConnectorSetting;
        }

        /// <summary>
        /// Index action
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [ProducesResponseType(typeof(MfpConnectorSetting), (int)HttpStatusCode.OK)]
        public IActionResult Index()
        {
            return Json(_mfpConnectorSetting);
        }
    }
}
