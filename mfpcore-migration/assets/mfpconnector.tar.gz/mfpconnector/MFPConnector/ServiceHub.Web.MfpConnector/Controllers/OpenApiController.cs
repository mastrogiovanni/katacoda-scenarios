using KonicaMinolta.OpenApi;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using ServiceHub.Common.Model;
using ServiceHub.Common.Settings;
using ServiceHub.Connectors.IWS;
using ServiceHub.Connectors.OpenAPI;
using ServiceHub.Processors.Bus;
using ServiceHub.Processors.Common;
using ServiceHub.Processors.DeviceInfo;
using ServiceHub.Processors.Exceptions;
using ServiceHub.Processors.Job;
using ServiceHub.Processors.Notify;
using ServiceHub.Processors.Notify.Model;
using ServiceHub.Processors.PushNotification;
using System;
using System.IO;
using System.Net;
using System.Threading.Tasks;

namespace ServiceHub.Web.MfpConnector.Controllers
{
    /// <summary>
    /// Api controller for OpenAPI's message.
    /// </summary>
    [Route("OpenAPI")]
    public class OpenApiController : AbstractController
    {
        private readonly IDeviceInfoOperator _deviceInfoOperator;
        private readonly IPushNotifier _pushNotifier;
        private readonly IOpenApiService _openApiService;
        private readonly INotifySetter _notifySetter;
        private readonly IJobOperator _jobOperator;
        private readonly ILogger<OpenApiController> _logger;
        private readonly IConvertNotification _mfpNotificationConverter;
        private readonly TimeSpan _waitForRetry = TimeSpan.FromMilliseconds(100);
        private readonly IwsThreadWorker _iwsThreadWorker;
        private readonly IMfpCounterPublisher _mfpCorePublisher;

        /// <summary>
        /// Initializes a new instance of the <see cref="OpenApiController" /> class.
        /// </summary>
        /// <param name="logger">Logger</param>
        /// <param name="mfpConnectorSetting">The MFP connector setting.</param>
        /// <param name="deviceInfoOperator">The device information operator.</param>
        /// <param name="pushNotifier">The push notifier.</param>
        /// <param name="openApiService">The open API service.</param>
        /// <param name="notifySetter">The notify setter.</param>
        /// <param name="jobOperator">The job operator.</param>
        /// <param name="iwsThreadWorker">The thread executor.</param>
        /// <param name="mfpCorePublisher"></param>
        public OpenApiController(
            ILogger<OpenApiController> logger,
            MfpConnectorSetting mfpConnectorSetting,
            IDeviceInfoOperator deviceInfoOperator,
            IPushNotifier pushNotifier,
            IOpenApiService openApiService,
            INotifySetter notifySetter,
            IJobOperator jobOperator,
            IwsThreadWorker iwsThreadWorker,
            IMfpCounterPublisher mfpCorePublisher)
            : base(mfpConnectorSetting)
        {
            _deviceInfoOperator = deviceInfoOperator;
            _pushNotifier = pushNotifier;
            _openApiService = openApiService;
            _notifySetter = notifySetter;
            _jobOperator = jobOperator;

            var version = new Common.Settings.OpenApi.OpenApiVersion
            {
                Major = mfpConnectorSetting.OpenApi.Version.Major,
                Minor = mfpConnectorSetting.OpenApi.Version.Minor
            };
            _mfpNotificationConverter = new ConvertNotification(version);
            _logger = logger;
            _iwsThreadWorker = iwsThreadWorker;
            _mfpCorePublisher = mfpCorePublisher;
        }

        /// <summary>
        /// Process the requested OpenAPI message.
        /// </summary>
        /// <remarks>Process the requested OpenAPI message through the body.</remarks>
        /// <returns>
        /// HTTP response
        /// </returns>
        [HttpPost]
        [ProducesResponseType(typeof(void), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> Post()
        {
            try
            {
                var bodyContentStream = HttpContext.Request.Body;
                using (var reader = new StreamReader(bodyContentStream))
                {
                    return await ProcessDevRptMessageAsync(reader.ReadToEnd()).ConfigureAwait(false);
                }
            }
            catch (Exception ex)
            {
                var message = new ExceptionMessage(ex).ToString();
                _logger.LogError(message);
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }
        }

        /// <summary>
        /// Process the callback message received by the MFP.
        /// </summary>
        /// <param name="request">Request callback from the MFP</param>
        /// <remarks>Can be used only by the MFP.</remarks>
        /// <returns>HTTP response</returns>
        [ApiExplorerSettings(IgnoreApi = true)]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> Post(string request)
        {
            return await ProcessDevRptMessageAsync(request).ConfigureAwait(false);
        }

        /// <summary>
        /// Process message
        /// </summary>
        /// <param name="request">Request</param>
        /// <returns>HTTP response</returns>
        private async Task<IActionResult> ProcessDevRptMessageAsync(string request)
        {
            try
            {
                // check type
                var parser = new SoapXmlParser(request, MfpConnectorSetting.OpenApi.Version);
                var type = parser.GetNode("/SOAP-ENV:Envelope/SOAP-ENV:Body").FirstChild.LocalName;
                _logger.LogInformation($"OpenAPI: {type}{request}");

                // process
                switch (type)
                {
                    case "DevRptNotifyDeviceStatus2":
                        await NotifyDeviceStatusAsync(request).ConfigureAwait(false);
                        break;

                    case "DevRptNotifyWarningChange":
                        var warning = _deviceInfoOperator.ConvertNotifyWarningChange(request);
                        var infoListJson = JsonConvert.SerializeObject(warning);

                        await _pushNotifier.SendWarningInfoAsync(infoListJson).ConfigureAwait(false);
                        break;

                    case "DevRptEventOccurNotifyToSH":
                        await _deviceInfoOperator.NotifyDeviceEventAsync(request).ConfigureAwait(false);
                        break;

                    case "DevRptNotifyEventNotification":
                    case "DevRptNotifyPreEventNotification":
                        _logger.LogInformation("Set event notification");
                        await _notifySetter.SetEventNotificationAsync().ConfigureAwait(false);
                        break;

                    case "DevRptNotifyDisconnect":
                        _openApiService.ReportDisconnect();
                        break;

                    case "DevRptNotifyDevicePartsStatus":
                        await NotifyDevicePartsStatusAsync(request).ConfigureAwait(false);
                        break;

                    case "DevRptNotifyJobStatus":
                    case "DevRptNotifyJobTraceStatus":
                        try
                        {
                            await NotifyJobStatusAsync(request).ConfigureAwait(false);
                        }
                        catch (Exception ex)
                        {
                            _logger.LogTrace(default(EventId), ex, "Exception occurred(NotifyJobStatusAsync).");
                            return StatusCode((int)HttpStatusCode.OK);
                        }
                        break;

                    default:
                        // do nothing
                        _logger.LogDebug("Noop");
                        break;
                }
            }
            catch (Exception ex)
            {
                var message = new ExceptionMessage(ex).ToString();
                _logger.LogError(message);
                return StatusCode((int)HttpStatusCode.BadRequest);
            }

            return StatusCode((int)HttpStatusCode.OK);
        }

        /// <summary>
        /// Notify device status
        /// </summary>
        /// <param name="request">Request</param>
        private async Task NotifyDeviceStatusAsync(string request)
        {
            await _deviceInfoOperator.NotifyDeviceLockEventAsync(request);
            var partsStatus = _mfpNotificationConverter.ConvertToFinisherDoorStatus(request);
            await PushNotifierDevicePartsStatusAsync(partsStatus);
            var powerStatus = _mfpNotificationConverter.ConvertToNotifyPowerStatus(request);
            await PushNotifierPowerStatusAsync(powerStatus);
        }

        /// <summary>
        /// Notify device parts status
        /// </summary>
        /// <param name="request">Request</param>
        private Task NotifyDevicePartsStatusAsync(string request)
        {
            var partsStatus = _mfpNotificationConverter.ConvertToPushDevicePartsStatus(request);
            return PushNotifierDevicePartsStatusAsync(partsStatus);
        }

        /// <summary>
        /// Push notifier device parts status
        /// </summary>
        /// <param name="partsStatus">Parts status</param>
        private Task PushNotifierDevicePartsStatusAsync(NotifyDevicePartsStatus partsStatus)
        {
            if (partsStatus != null)
            {
                _logger.LogDebug($"Notify parts status to MFPService. Request: {partsStatus.Type}");
                _deviceInfoOperator.NotifyDevicePartsStatusAsync(partsStatus);
            }
            else
            {
                _logger.LogDebug($"[{GetType().Name}] There is nothing to notify device parts status.");
            }

            return Task.CompletedTask;
        }

        /// <summary>
        /// Push notifier power status
        /// </summary>
        /// <param name="powerStatus">Power status</param>
        private Task PushNotifierPowerStatusAsync(NotifyPowerStatus powerStatus)
        {
            if (powerStatus != null)
            {
                _logger.LogInformation($"Notify power status to MFPService. request : {powerStatus}");
                return _deviceInfoOperator.NotifyPowerStatusAsync(powerStatus);
            }

            return Task.CompletedTask;
        }

        /// <summary>
        /// Notify job status
        /// </summary>
        /// <param name="request">Request</param>
        private async Task NotifyJobStatusAsync(string request)
        {
            _logger.LogDebug("Handling of NotifyJobStatusAsync.");
            var jobStatus = await _mfpNotificationConverter
                .ConvertToNotifyJobStatusAsync(_jobOperator, request)
                .ConfigureAwait(false);
            var infoJson = JsonConvert.SerializeObject(jobStatus);

            await WaitForJobCompletion(jobStatus).ConfigureAwait(false);
            await _pushNotifier.NotifyJobStatusAsync(infoJson).ConfigureAwait(false);

            if (jobStatus.Status == JobStatus.CREATE)
            {
                try
                {
                    _logger.LogInformation($"Set job trace to MFP. Job id: {jobStatus.JobId}");
                    await _notifySetter.SetJobTraceAsync(jobStatus.JobId).ConfigureAwait(false);
                }
                catch (OpenApiFaultException ex) when (
                    ex.FaultMessage.FaultCode.Equals(SoapFaultCode.Client) &&
                    ex.FaultMessage.FaultString.Equals("Client Error") &&
                    ex.FaultMessage.FaultRequest.Equals("AppReqSetJobTrace") &&
                    ex.FaultMessage.ErrorDetails.Equals("JobInfoNotFoundJobID") &&
                    ex.FaultMessage.ErrorDescription.Equals("JobID"))
                {
                    _logger.LogTrace(default(EventId), ex, ex.FaultMessage.ToString());
                    var jobStatusCopyErr = await _mfpNotificationConverter.ConvertToNotifyJobStatusCopyErrAsync(
                        _jobOperator,
                        jobStatus).ConfigureAwait(false);

                    var infoJsonCopyErr = JsonConvert.SerializeObject(jobStatusCopyErr);
                    await _pushNotifier.NotifyJobStatusAsync(infoJsonCopyErr).ConfigureAwait(false);
                }
            }

            await _mfpCorePublisher.NotifyFromJobStatusAsync(jobStatus).ConfigureAwait(false);
        }

        /// <summary>
        /// Waits for job completion.
        /// Check whether or not delete task is ended if status is 'END'.
        /// </summary>
        /// <param name="jobStatus">The job status.</param>
        /// <returns>A task</returns>
        private async Task WaitForJobCompletion(NotifyJobStatus jobStatus)
        {
            if (jobStatus.Status == JobStatus.END && _iwsThreadWorker.IsProgress)
            {
                do
                {
                    if (!_iwsThreadWorker.IsCompleted())
                    {
                        await Task.Delay(_waitForRetry).ConfigureAwait(false);
                    }
                } while (_iwsThreadWorker.IsProgress);
            }
        }
    }
}
