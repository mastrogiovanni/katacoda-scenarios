using System.Net;

using Microsoft.AspNetCore.Mvc;

using ServiceHub.Common.Settings;
using ServiceHub.Connectors.IWS;
using ServiceHub.Processors.Common;
using ServiceHub.Web.MfpConnector.Controllers.Rest;
using ServiceHub.Web.MfpConnector.Controllers.Rest.Model;
using ServiceHub.Web.MfpConnector.Controllers.Utility;
using ServiceHub.Web.MfpConnector.Filters;

namespace ServiceHub.Web.MfpConnector.Controllers
{
    /// <summary>
    /// Abstract REST controller
    /// </summary>
    [ServiceFilter(typeof(LoggingActionFilter))]
    public class AbstractController : Controller
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AbstractController"/> class.
        /// </summary>
        /// <param name="mfpConnectorSetting">The MFP connector setting.</param>
        protected AbstractController(MfpConnectorSetting mfpConnectorSetting)
        {
            MfpConnectorSetting = mfpConnectorSetting;
        }

        protected MfpConnectorSetting MfpConnectorSetting { get; }

        /// <summary>
        /// Internals the server error.
        /// </summary>
        /// <param name="error">The error.</param>
        /// <returns></returns>
        protected IActionResult InternalServerError(object error)
        {
            return JsonResponseCreator.Create((IResponseModel)error, HttpStatusCode.InternalServerError);
        }

        /// <summary>
        /// Controllers the result.
        /// </summary>
        /// <param name="controllerResult"></param>
        /// <param name="result">The result.</param>
        /// <param name="errorMessage">Error message</param>
        /// <returns></returns>
        protected IActionResult ControllerResult(IResponseModel controllerResult, string result, string errorMessage)
        {
            if (result == SenderConfig.IwsResultStatus.OK.ToString())
            {
                return Created(string.Empty, controllerResult);
            }

            if (errorMessage == string.Format(IwsException.NetworkErrMsg, (int)HttpStatusCode.ServiceUnavailable))
            {
                return JsonResponseCreator.Create(controllerResult, HttpStatusCode.ServiceUnavailable);
            }

            return InternalServerError(controllerResult);
        }

        /// <summary>
        /// Gets the error.
        /// </summary>
        /// <param name="error">The error.</param>
        /// <returns></returns>
        protected string GerError(string error)
        {
            return (error == string.Format(
                        IwsException.NetworkErrMsg,
                        (int)HttpStatusCode.ServiceUnavailable)
                ? IwsException.IwsErrorFatal
                : error);
        }
    }
}
