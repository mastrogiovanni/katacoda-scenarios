using System;
using System.Net;
using Microsoft.AspNetCore.Mvc;
using ServiceHub.Common.Model;
using ServiceHub.Web.MfpConnector.Controllers.Rest.Model;

namespace ServiceHub.Web.MfpConnector.Controllers.Utility
{
    /// <summary>
    /// Class for create response of json.
    /// </summary>
    internal static class JsonResponseCreator
    {
        /// <summary>
        /// Create response.
        /// </summary>
        /// <param name="content">HTTP body content</param>
        /// <param name="statusCode">HTTP status code</param>
        /// <returns>HTTP response</returns>
        public static IActionResult Create(IResponseModel content, HttpStatusCode statusCode)
        {
            var result = new ObjectResult(content)
            {
                StatusCode = (int) statusCode
            };

            return result;
        }
        
        /// <summary>
        /// Create response by error message.
        /// </summary>
        /// <param name="errorMessage">Error message</param>
        /// <param name="statusCode">HTTP status code</param>
        /// <returns>HTTP response</returns>
        public static IActionResult CreateError(string errorMessage, HttpStatusCode statusCode)
        {
            var content = new JsonErrorMessage
            {
                Message = errorMessage
            };

            var result = new ObjectResult(content)
            {
                StatusCode = (int) statusCode
            };

            return result;
        }

        /// <summary>
        /// Create response by error message.
        /// </summary>
        /// <param name="exp">Error exception</param>
        /// <param name="statusCode">HTTP status code</param>
        /// <returns>HTTP response</returns>
        public static IActionResult CreateException(Exception exp, HttpStatusCode statusCode)
        {
            var content = new ExceptionMessage(exp);

            var result = new ObjectResult(content)
            {
                StatusCode = (int) statusCode
            };

            return result;
        }

        /// <summary>
        /// Error message by json.
        /// </summary>
        public class JsonErrorMessage
        {
            /// <summary>
            /// Message
            /// </summary>
            public string Message { get; set; }
        }
    }
}
