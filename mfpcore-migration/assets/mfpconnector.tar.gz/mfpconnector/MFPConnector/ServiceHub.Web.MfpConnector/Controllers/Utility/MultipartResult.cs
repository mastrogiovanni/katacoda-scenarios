using System.Collections.ObjectModel;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ContentDispositionHeaderValue = Microsoft.Net.Http.Headers.ContentDispositionHeaderValue;

namespace ServiceHub.Web.MfpConnector.Controllers.Utility
{
    /// <summary>
    /// Multipart response
    /// </summary>
    public class MultipartResult : Collection<MultipartContent>, IActionResult
    {
        /// <summary>
        /// MultipartContent
        /// </summary>
        private readonly System.Net.Http.MultipartContent _content;

        private readonly HttpStatusCode _httpStatusCode;

        /// <summary>
        /// Initializes a new instance of the <see cref="MultipartResult" /> class.
        /// </summary>
        /// <param name="statusCode">Status code</param>
        /// <param name="subtype">MIME sub type</param>
        /// <param name="boundary">MIME boundary</param>
        public MultipartResult(HttpStatusCode statusCode, string subtype = "form-data", string boundary = null)
        {
            _httpStatusCode = statusCode;

            _content = boundary == null ? new System.Net.Http.MultipartContent(subtype) : new System.Net.Http.MultipartContent(subtype, boundary);
        }

        /// <summary>
        /// Executes the result operation of the action method asynchronously.
        /// This method is called by MVC to process the result of an action method.
        /// </summary>
        /// <param name="context">The context in which the result is executed. The context information includes information about the action that was executed and request information.</param>
        /// <returns>A task that represents the asynchronous execute operation.</returns>
        public async Task ExecuteResultAsync(ActionContext context)
        {
            foreach (var item in this)
            {
                if (item.Stream == null)
                {
                    continue;
                }

                var content = new StreamContent(item.Stream);

                if (item.ContentType != null)
                {
                    content.Headers.ContentType = new MediaTypeHeaderValue(item.ContentType);
                }

                if (item.FileName != null)
                {
                    var contentDisposition = new ContentDispositionHeaderValue("attachment");
                    contentDisposition.SetHttpFileName(item.FileName);
                    content.Headers.ContentDisposition = new System.Net.Http.Headers.ContentDispositionHeaderValue("attachment")
                    {
                        FileName = contentDisposition.FileName.Value,
                        FileNameStar = contentDisposition.FileNameStar.Value
                    };
                }

                _content.Add(content);
            }

            context.HttpContext.Response.ContentLength = _content.Headers.ContentLength;
            context.HttpContext.Response.ContentType = _content.Headers.ContentType.ToString();

            context.HttpContext.Response.StatusCode = (int)_httpStatusCode;
            await _content.CopyToAsync(context.HttpContext.Response.Body);
        }
    }
}
