﻿using System.IO;

namespace ServiceHub.Web.MfpConnector.Controllers.Utility
{
    /// <summary>
    /// Multipart content
    /// </summary>
    public class MultipartContent
    {
        /// <summary>
        /// Content-Type
        /// </summary>
        public string ContentType { get; set; }

        /// <summary>
        /// File name
        /// </summary>
        public string FileName { get; set; }

        /// <summary>
        /// Stream (byte array)
        /// </summary>
        public Stream Stream { get; set; }
    }
}
