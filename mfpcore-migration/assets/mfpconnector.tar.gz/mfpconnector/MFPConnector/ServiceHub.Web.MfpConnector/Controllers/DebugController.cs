﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using Microsoft.AspNetCore.Mvc;
using ServiceHub.Common.Settings;
using ServiceHub.Connectors.OpenAPI;

namespace ServiceHub.Web.MfpConnector.Controllers
{
    /// <summary>
    /// Controller for debugging
    /// </summary>
    [Route("debug")]
    public class DebugController : AbstractController
    {
        private readonly IOpenApiService _openApiService;

        /// <summary>
        /// Initializes a new instance of the <see cref="DebugController" /> class.
        /// </summary>
        /// <param name="mfpConnectorSetting">The MFP connector setting.</param>
        /// <param name="openApiService">The open API service.</param>
        public DebugController(MfpConnectorSetting mfpConnectorSetting, IOpenApiService openApiService)
            : base(mfpConnectorSetting)
        {
            _openApiService = openApiService;
        }

        /// <summary>
        /// Gets all OpenApi users details.
        /// </summary>
        /// <remarks>Returns all the username, password and authentication key currently
        /// being used in order to communicate with OpenAPI.</remarks>
        /// <returns>Successfully retrived available user details.</returns>
        /// <response code="200">Successfully retrieved all user details.</response>
        [ProducesResponseType(typeof(IEnumerable<DebugCurrentUserDto>), (int)HttpStatusCode.OK)]
        [HttpGet("current_user")]
        public IActionResult DebugGetCurrentUser()
        {
            var list = _openApiService.GetCurrentUserInfo()
                .Select(item => new DebugCurrentUserDto
                {
                    UserType = item.Key.UserType.ToString(),
                    AuthKey = item.Value.AuthKey,
                    ObtainedDateTime = item.Value.ObtainedDateTime,
                    Detail = new DebugCurrentUserDto.DebugCurrentUserDetailDto
                    {
                        UserName = item.Key.UserName,
                        UserPassword = item.Key.UserPassword,
                        EnhancedAuthParameterCode = item.Key.EnhancedAuthParameterCode
                    }
                });

            return Ok(list);
        }

        /// <summary>
        /// Debug class
        /// </summary>
        public class DebugCurrentUserDto
        {
            /// <summary>
            /// Gets or sets the type of the user.
            /// </summary>
            public string UserType { get; set; }

            /// <summary>
            /// Gets or sets the authentication key.
            /// </summary>
            public string AuthKey { get; set; }

            /// <summary>
            /// Gets or sets the obtained date time.
            /// </summary>
            public DateTime ObtainedDateTime { get; set; }

            /// <summary>
            /// Gets or sets the detail.
            /// </summary>
            public DebugCurrentUserDetailDto Detail { get; set; }

            /// <summary>
            /// Debug class
            /// </summary>
            public class DebugCurrentUserDetailDto
            {
                /// <summary>
                /// Gets or sets the enhanced authentication parameter code.
                /// </summary>
                public string EnhancedAuthParameterCode { get; set; }

                /// <summary>
                /// Gets or sets the user password.
                /// </summary>
                public string UserPassword { get; set; }

                /// <summary>
                /// Gets or sets the name of the user.
                /// </summary>
                public string UserName { get; set; }
            }
        }
    }
}
