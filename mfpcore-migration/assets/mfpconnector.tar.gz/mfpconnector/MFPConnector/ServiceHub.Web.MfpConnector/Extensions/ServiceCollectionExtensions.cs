﻿using Microsoft.Extensions.DependencyInjection;
using ServiceHub.Common.DeviceState;
using ServiceHub.Connectors.IWS;
using ServiceHub.Connectors.IWS.Env;
using ServiceHub.Connectors.IWS.ResponseListener;
using ServiceHub.Connectors.MfpService;
using ServiceHub.Connectors.OpenAPI;
using ServiceHub.Connectors.OpenAPI.DeviceState;
using ServiceHub.Connectors.OpenAPI.Model;
using ServiceHub.Processors.Animations;
using ServiceHub.Processors.Common;
using ServiceHub.Processors.Copy;
using ServiceHub.Processors.Copy.Model;
using ServiceHub.Processors.DeviceInfo;
using ServiceHub.Processors.Fax;
using ServiceHub.Processors.Iws;
using ServiceHub.Processors.Iws.Model;
using ServiceHub.Processors.Job;
using ServiceHub.Processors.MfpSetting;
using ServiceHub.Processors.Monitoring.State;
using ServiceHub.Processors.Notify;
using ServiceHub.Processors.Power;
using ServiceHub.Processors.PushNotification;
using ServiceHub.Processors.ReadyManage;
using ServiceHub.Processors.Scan;
using ServiceHub.Processors.Scan.Model;
using ServiceHub.Processors.Screen;
using ServiceHub.Processors.Settings;
using ServiceHub.Processors.Setup;
using ServiceHub.Processors.Warning;

namespace ServiceHub.Web.MfpConnector.Extensions
{
    internal static class ServiceCollectionExtensions
    {
        public static IServiceCollection AddMfpCore(this IServiceCollection services)
        {
            return services
                .AddMfpCoreProcessors()
                .AddMfpIws()
                .AddMfpOpenApi()
                .AddMfpServices()
                .AddMfpDeviceState();
        }

        public static IServiceCollection AddMfpCoreProcessors(this IServiceCollection services)
        {
            // OpenAPI operator classes
            services.AddSingleton<INotifySetter, NotifySetter>();
            services.AddSingleton<IPushNotifier, MfpServicePushNotifier>();
            services.AddSingleton<IJobOperator, JobOperator>();
            services.AddSingleton<ISettingsOperator, AdminSettingsOperator>();
            services.AddSingleton<IMfpSettingsOperator, MfpSettingsOperator>();
            services.AddSingleton<IScreenOperator, ScreenOperator>();
            services.AddSingleton<IFaxReceiveSetter, FaxReceiveSetter>();
            services.AddSingleton<IPowerOperator, PowerOperator>();
            services.AddSingleton<IDeviceDescriptionOperator, DeviceDescriptionOperator>();
            services.AddSingleton<IDeviceInfoOperator, DeviceInfoOperator>();
            services.AddSingleton<IFirmwareOperator, FirmwareOperator>();
            services.AddSingleton<IAnimationsOperator, AnimationsOperator>();
            services.AddSingleton<IWarningOperator, WarningOperator>();
            services.AddSingleton<IConvertJobs, ConvertJobs>();
            services.AddSingleton<ConvertNotification>();

            services.AddSingleton<IJobPauseSender, JobPauseSender>();
            services.AddSingleton<IJobRedialSender, JobRedialSender>();
            services.AddSingleton<IMfpSender<CopyServiceSetting, CopyServiceResult>, CopySender>();
            services.AddSingleton<IMfpSender<ScanServiceSetting, ScanServiceResult>, ScanSender>();

            // MFP monitoring classes
            services.AddSingleton<IMfpInitialize, MfpInitialize>();
            services.AddSingleton<IMfpReadyManage, MfpReadyManage>();
            services.AddSingleton<IPasswordOperator, PasswordOperator>();

            return services;
        }

        public static IServiceCollection AddMfpIws(this IServiceCollection services)
        {
            services.AddSingleton<IEnvContainer, RealEnvContainer>();
            services.AddSingleton<IIwsConnectorUser, IwsConnectorUser>();
            services.AddSingleton<IIwsConnectorAdmin, IwsConnectorAdmin>();
            services.AddSingleton<IMfpSender<IwsServiceSetting, IwsServiceResult>, IwsSender>();
            services.AddSingleton<IResponseListenerBuilder, IwsResponseListenerBuilder>();
            services.AddSingleton<IwsThreadWorker>();

            return services;
        }

        public static IServiceCollection AddMfpServices(this IServiceCollection services)
        {
            // MFP service base classes
            services.AddSingleton<IMfpService, MfpService>();

            return services;
        }

        public static IServiceCollection AddMfpOpenApi(this IServiceCollection services)
        {
            // OpenAPI base classes
            services.AddSingleton<OpenApiRequestSettings>();
            services.AddSingleton<IOpenApiService, OpenApiService>();
            services.AddSingleton<IOpenApiController, OpenApiController>();
            // Note: Added in double... (Hosted service and as ILockTaskManager), so we need to be careful
            services.AddSingleton<ILockTaskManager, LockTaskManager>();

            return services;
        }

        public static IServiceCollection AddMfpDeviceState(this IServiceCollection services)
        {
            // Device State classes
            services.AddSingleton<IDeviceState<IdleState>, IdleState>();
            services.AddSingleton<IDeviceState<PowerOnState>, PowerOnState>();
            services.AddSingleton<IDeviceState<PowerOffState>, PowerOffState>();
            services.AddSingleton<IDeviceState<PasswordErrorState>, PasswordErrorState>();
            services.AddSingleton<IDeviceStateContext, DeviceStateContext>();

            return services;
        }
    }
}
