using System;
using System.IO;
using System.Net;
using System.Reflection;
using System.Security.Authentication;
using System.Security.Cryptography.X509Certificates;
using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Server.Kestrel.Https;
using Microsoft.Extensions.Configuration;
using ServiceHub.CommonTools.WebApi.Extensions;

namespace ServiceHub.Web.MfpConnector
{
    /// <summary>
    /// Program for the MfpCore
    /// </summary>
    public class Program
    {
        private const string CertFileName = "mfpcore.pfx";
        private const string CertPath = "/var/mfpcore/" + CertFileName;

        private static string Environment;

        /// <summary>
        /// Main program
        /// </summary>
        /// <param name="args">Arguments</param>
        public static void Main(string[] args)
        {
            var contentRoot = Directory.GetCurrentDirectory();
            // load Setting.json and set notify ip
            Settings.SetOpenApiNotifyIp();

            var hostBuilder = WebHost.CreateDefaultBuilder(args);
            var pathToDirectory = GetPathToExecutingDirectory();
            var config = InitializeConfigurations(hostBuilder, pathToDirectory);

            var host = hostBuilder
                .UseKestrel(options =>
                {
                    options.Listen(IPAddress.Any, 80);
                    // Code change after migration to core 2.0 (Port 443 is in the default port in the setting.json)
                    options.Listen(IPAddress.Any, 443, listenOptions =>
                    {
                        listenOptions.UseHttps(new HttpsConnectionAdapterOptions
                        {
                            ClientCertificateMode = ClientCertificateMode.NoCertificate,
                            ServerCertificate = new X509Certificate2(GetCertPath()),
                            SslProtocols = SslProtocols.Tls12,
                        });
                    });
                })
                .UseContentRoot(contentRoot)
                .UseConfiguration(config)
                .UseStartup<Startup>()
                .Build();

            host.Run();
        }
        private static string GetPathToExecutingDirectory()
        {
            return Path.GetDirectoryName(Assembly.GetEntryAssembly().Location);
        }

        private static IConfigurationRoot InitializeConfigurations(IWebHostBuilder hostBuilder, string pathToDirectory)
        {
            Environment = hostBuilder.GetSetting("environment");

            var configuration = new ConfigurationBuilder()
                .AddEnvironmentVariables()
                .SetBasePath(pathToDirectory)
                .AddJsonFile("appsettings.json", true, true)
                .AddJsonFile($"appsettings.{Environment}.json", true)
                .AddRegistrationService()
                .Build();

            return configuration;
        }

        private static string GetCertPath()
        {
            var temporaryCertPath = Path.Combine(Directory.GetCurrentDirectory(), "App_Data", CertFileName);

            if (File.Exists(CertPath))
            {
                return CertPath;
            }

            if (File.Exists(temporaryCertPath))
            {
                return temporaryCertPath;
            }

            throw new NotSupportedException($"Any cert files are not found. Place the file {CertPath} or {temporaryCertPath}");
        }
    }
}
