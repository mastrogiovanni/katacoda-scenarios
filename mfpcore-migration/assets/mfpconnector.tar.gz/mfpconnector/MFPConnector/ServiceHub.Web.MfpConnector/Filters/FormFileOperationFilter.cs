using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Http;
using Swashbuckle.AspNetCore.Swagger;
using Swashbuckle.AspNetCore.SwaggerGen;
using System.Linq;
using System.Reflection;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Abstractions;

namespace ServiceHub.Web.MfpConnector.Filters
{
    /// <summary>
    /// Filter in order to add the file upload into swagger.
    /// </summary>
    /// <seealso cref="Swashbuckle.AspNetCore.SwaggerGen.IOperationFilter" />
    /// <remarks>Cref: https://github.com/domaindrivendev/Swashbuckle.AspNetCore/issues/193 </remarks>
    internal class FormFileOperationFilter : IOperationFilter
    {
        private struct ContainerParameterData
        {
            public ContainerParameterData(ParameterDescriptor parameter, PropertyInfo property)
            {
                Parameter = parameter;
                Property = property;
            }

            public string Name => Property.Name;
            public string FullName => $"{Parameter.Name}.{Property.Name}";
            public readonly ParameterDescriptor Parameter;
            public readonly PropertyInfo Property;
        }

        private static readonly ImmutableArray<string> FormFilePropertyNames =
            typeof(IFormFile).GetTypeInfo().DeclaredProperties.Select(p => p.Name).ToImmutableArray();

        /// <summary>
        /// Applies the specified operation.
        /// </summary>
        /// <param name="operation">The operation.</param>
        /// <param name="context">The context.</param>
        public void Apply(Operation operation, OperationFilterContext context)
        {
            var parameters = operation.Parameters;
            if (parameters == null)
            {
                return;
            }

            var @params = context.ApiDescription.ActionDescriptor.Parameters;
            if (parameters.Count == @params.Count)
            {
                return;
            }

            var formFileParams =
                (from parameter in @params
                 where parameter.ParameterType.IsAssignableFrom(typeof(IFormFile))
                 select parameter).ToArray();

            var iFormFileType = typeof(IFormFile).GetTypeInfo();
            var containerParams =
                @params.Select(p => new KeyValuePair<ParameterDescriptor, PropertyInfo[]>(
                    p, p.ParameterType.GetProperties()))
                .Where(pp => pp.Value.Any(p => iFormFileType.IsAssignableFrom(p.PropertyType)))
                .SelectMany(p => p.Value.Select(pp => new ContainerParameterData(p.Key, pp)))
                .ToImmutableArray();

            if (!(formFileParams.Any() || containerParams.Any()))
            {
                return;
            }

            var consumeAttributes = (from attribute in context.ApiDescription.ActionAttributes()
                                     where attribute.GetType() == typeof(ConsumesAttribute)
                                     select attribute).ToList();

            string contentType = null;
            if (consumeAttributes.Any())
            {
                contentType = ((ConsumesAttribute)consumeAttributes.First()).ContentTypes.FirstOrDefault(); // We take 1st, but could be multiple
            }

            var consumes = operation.Consumes;
            consumes.Clear();
            consumes.Add(contentType ?? "application/form-data");

            if (!containerParams.Any())
            {
                var nonIFormFileProperties =
                    parameters.Where(p =>
                        !(FormFilePropertyNames.Contains(p.Name)
                        && string.Compare(p.In, "formData", StringComparison.OrdinalIgnoreCase) == 0))
                        .ToImmutableArray();

                parameters.Clear();
                foreach (var parameter in nonIFormFileProperties)
                {
                    parameters.Add(parameter);
                }

                foreach (var parameter in formFileParams)
                {
                    parameters.Add(new NonBodyParameter
                    {
                        Name = parameter.Name,
                        Description = "File to upload.",
                        @In = "formData",
                        Required = true, // TODO: find a way to determine
                        Type = "file"
                    });
                }
            }
            else
            {
                var paramsToRemove = new List<IParameter>();
                foreach (var parameter in containerParams)
                {
                    var parameterFilter = parameter.Property.Name + ".";
                    paramsToRemove.AddRange(from p in parameters
                                            where p.Name.StartsWith(parameterFilter)
                                            select p);
                }

                paramsToRemove.ForEach(x => parameters.Remove(x));

                foreach (var parameter in containerParams)
                {
                    if (iFormFileType.IsAssignableFrom(parameter.Property.PropertyType))
                    {
                        var originalParameter = parameters.FirstOrDefault(param => param.Name == parameter.Name);
                        parameters.Remove(originalParameter);

                        parameters.Add(new NonBodyParameter
                        {
                            Name = parameter.Name,
                            Description = originalParameter?.Description,
                            Required = IsRequired(parameter.Property),
                            Type = "file",
                            In = "formData"
                        });
                    }
                }
            }
        }

        /// <summary>
        /// Determines whether the specified property information is required.
        /// </summary>
        /// <param name="propertyInfo">The property information.</param>
        /// <returns>
        ///   <c>true</c> if the specified property information is required; otherwise, <c>false</c>.
        /// </returns>
        private static bool IsRequired(PropertyInfo propertyInfo) => 
            propertyInfo.CustomAttributes.OfType<RequiredAttribute>().Any();
    }
}
