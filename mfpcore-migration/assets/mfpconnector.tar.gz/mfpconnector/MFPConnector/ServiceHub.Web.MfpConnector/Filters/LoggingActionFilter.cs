using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Logging;
using System;

namespace ServiceHub.Web.MfpConnector.Filters
{
    /// <summary>
    /// ActionFilter for logging (A.k.a. middleware)
    /// </summary>
    [AttributeUsage(AttributeTargets.Class)]
    public class LoggingActionFilter : ActionFilterAttribute
    {
        /// <summary>
        /// Logger
        /// </summary>
        private readonly ILogger<LoggingActionFilter> _logger;

        /// <summary>
        /// Initializes a new instance of the <see cref="LoggingActionFilter" /> class.
        /// </summary>
        /// <param name="logger"></param>
        public LoggingActionFilter(ILogger<LoggingActionFilter> logger)
        {
            _logger = logger;
        }

        /// <summary>
        /// OnActionExecuting
        /// </summary>
        /// <param name="context">A context for action filter</param>
        public override void OnActionExecuting(ActionExecutingContext context)
        {
            _logger.LogTrace($"[Web] START {context.HttpContext.Request.Path}");
            base.OnActionExecuting(context);
        }

        /// <summary>
        /// OnResultExecuted
        /// </summary>
        /// <param name="context">A context for result filter</param>
        public override void OnResultExecuted(ResultExecutedContext context)
        {
            _logger.LogTrace($"[Web] FINISH {context.HttpContext.Request.Path}");
            base.OnResultExecuted(context);
        }
    }
}
