using ServiceHub.Common.Extensions;
using ServiceHub.Common.Settings;
using ServiceHub.Common.Settings.Mfp;
using ServiceHub.Common.Settings.MfpSettings;
using System;
using System.IO;
using System.Linq;
using System.Net.NetworkInformation;
using System.Net.Sockets;

namespace ServiceHub.Web.MfpConnector
{
    /// <summary>
    /// Class for settings
    /// </summary>
    internal class Settings
    {
        protected Settings()
        {
        }

        /// <summary>
        /// Setting.json path
        /// </summary>
        public const string SettingJsonPath = "~/App_Data/Setting.json";

        /// <summary>
        /// Mfp setting path for administrator
        /// </summary>
        public const string AdminMfpSettingPath = "~/App_Data/Settings/Settings.json";

        /// <summary>
        /// Mfp admin setting path for category
        /// </summary>
        public const string CategoryMfpAdminSettingPath = "~/App_Data/Settings/SettingCategory.json";

        /// <summary>
        /// Mfp wakeup setting path 
        /// </summary>
        public const string MfpWakeupSettingPath = "~/App_Data/MfpSettings/MfpWakeupSettings.json";

        /// <summary>
        /// Setting.json setting
        /// </summary>
        public static MfpConnectorSetting MfpConnectorSetting
        {
            get
            {
                if (ContentRootPath == null)
                {
                    ContentRootPath = Directory.GetCurrentDirectory();
                }

                if (_mfpConnectorSetting == null)
                {
                    _mfpConnectorSetting = MfpConnectorSetting.Load(SettingJsonPath.MapPath(ContentRootPath));
                    _mfpConnectorSetting.Log.Path = MfpConnectorSetting.Log.Path.MapPath(ContentRootPath);
                }

                return _mfpConnectorSetting;
            }
        }

        private static MfpConnectorSetting _mfpConnectorSetting;

        /// <summary>
        /// Mfp setting for administrator
        /// </summary>
        public static MfpSettingItem MfpSettingItem
        {
            get
            {
                if (ContentRootPath == null)
                {
                    ContentRootPath = Directory.GetCurrentDirectory();
                }

                if (_mfpSettingItem == null)
                {
                    _mfpSettingItem = MfpSettingItem.Load(AdminMfpSettingPath.MapPath(ContentRootPath));
                }

                return _mfpSettingItem;
            }
        }

        private static MfpSettingItem _mfpSettingItem;

        /// <summary>
        /// Mfp admin setting for category
        /// </summary>
        public static CategoryMfpSetting CategoryMfpSetting
        {
            get
            {
                if (ContentRootPath == null)
                {
                    ContentRootPath = Directory.GetCurrentDirectory();
                }

                if (_categoryMfpSetting == null)
                {
                    _categoryMfpSetting = CategoryMfpSetting.Load(CategoryMfpAdminSettingPath.MapPath(ContentRootPath));
                }

                return _categoryMfpSetting;
            }
        }

        private static CategoryMfpSetting _categoryMfpSetting;

        /// <summary>
        /// Gets the MFP wakeup setting.
        /// </summary>
        public static MfpWakeupSetting MfpWakeupSetting
        {
            get
            {
                if (ContentRootPath == null)
                {
                    ContentRootPath = Directory.GetCurrentDirectory();
                }

                if (_mfpWakeupSetting == null)
                {
                    _mfpWakeupSetting = MfpWakeupSetting.Load(MfpWakeupSettingPath.MapPath(ContentRootPath));
                }

                return _mfpWakeupSetting;
            }
        }

        private static MfpWakeupSetting _mfpWakeupSetting;
        
        /// <summary>
        /// Content root path
        /// </summary>
        public static string ContentRootPath { get; set; }

        /// <summary>
        /// Set Notification IP address.
        /// </summary>
        public static void SetOpenApiNotifyIp()
        {
            var nic = NetworkInterface.GetAllNetworkInterfaces().FirstOrDefault(nicTmp =>
                nicTmp.Name.Equals(MfpConnectorSetting.NetworkInterfaceSettings.name, StringComparison.OrdinalIgnoreCase));

            if (nic != null)
            {
                foreach (var definition in MfpConnectorSetting.OpenApi.Devices.Definitions)
                {
                    definition.NotifyIp = nic.GetIPProperties().UnicastAddresses
                        .FirstOrDefault(a => a.Address.AddressFamily == AddressFamily.InterNetwork)?.Address.ToString();
                }
            }
        }
    }
}
