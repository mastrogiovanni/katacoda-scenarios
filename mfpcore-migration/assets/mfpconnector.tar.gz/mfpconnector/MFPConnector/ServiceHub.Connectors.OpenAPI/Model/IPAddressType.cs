namespace ServiceHub.Connectors.OpenAPI.Model
{
    /// <summary>
    /// IP address type.
    /// </summary>
    public enum IpAddressType
    {
        IPv4,
        IPv6,
        Unidentified
    }
}