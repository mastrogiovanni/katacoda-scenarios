﻿namespace ServiceHub.Connectors.OpenAPI.Model
{
    public enum ManuscriptSizeDetectErrorType
    {
        MagnificationSelection,
        TraySelection,
        OriginalSizeSelection
    }
}