﻿using Newtonsoft.Json;

namespace ServiceHub.Connectors.OpenAPI.Model
{
    /// <summary>
    /// Dimension
    /// </summary>
    public class Dimension
    {
        /// <summary>
        /// Trays Info
        /// </summary>
        [JsonProperty(PropertyName = "x", Required = Required.Always)]
        public double X { get; set; }

        [JsonProperty(PropertyName = "y", Required = Required.Always)]
        public double Y { get; set; }
    }
}
