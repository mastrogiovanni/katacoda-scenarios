namespace ServiceHub.Connectors.OpenAPI.Model
{
    /// <summary>
    /// Power mode.
    /// </summary>
    public enum PowerMode
    {
        Unidentified,
        PowerModeRequestLowPower,
        PowerModeRequestSleep,
        PowerModeRequestSubPowerOff,
        PowerModeRequestErp
    }
}