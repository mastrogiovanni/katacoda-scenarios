using System.Xml.Serialization;

namespace ServiceHub.Connectors.OpenAPI.Model.DeviceInfoDetail
{
    /// <summary>
    /// DeviceInfoDetail item.
    /// </summary>
    public abstract class DeviceInfoDetailItem
    {
        /// <summary>
        /// Request item type
        /// </summary>
        [XmlIgnore]
        public abstract string RequestItem { get; }
    }
}
