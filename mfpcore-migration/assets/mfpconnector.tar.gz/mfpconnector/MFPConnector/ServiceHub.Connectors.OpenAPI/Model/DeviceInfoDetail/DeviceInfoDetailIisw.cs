using System.Xml.Serialization;

namespace ServiceHub.Connectors.OpenAPI.Model.DeviceInfoDetail
{
    /// <summary>
    /// Device Info Detail model (Iisw)
    /// </summary>
    [XmlRoot("Iisw")]
    public class DeviceInfoDetailIisw : DeviceInfoDetailItem
    {
        /// <summary>
        /// Request item type
        /// </summary>
        public override string RequestItem => "Iisw";

        /// <summary>
        /// Transfer access setting
        /// </summary>
        public TransferAccessSettingStuct TransferAccessSetting { get; set; }

        /// <summary>
        /// FTP enable
        /// </summary>
        public string FtpEnable { get; set; }

        /// <summary>
        /// Transfer access setting.
        /// </summary>
        public class TransferAccessSettingStuct
        {
            /// <summary>
            /// User
            /// </summary>
            public string User { get; set; }

            /// <summary>
            /// Password
            /// </summary>
            public string Password { get; set; }

            /// <summary>
            /// Download URL
            /// </summary>
            public string DownLoadUrl { get; set; }

            /// <summary>
            /// Firmware file name
            /// </summary>
            public string FwFileName { get; set; }
    }
    }
}
