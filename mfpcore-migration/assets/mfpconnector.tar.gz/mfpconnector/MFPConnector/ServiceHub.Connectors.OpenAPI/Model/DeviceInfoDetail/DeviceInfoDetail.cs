using System.IO;
using System.Xml;
using System.Xml.Serialization;

namespace ServiceHub.Connectors.OpenAPI.Model.DeviceInfoDetail
{
    /// <summary>
    /// Device Info Detail model base
    /// </summary>
    public class DeviceInfoDetail
    {
        /// <summary>
        /// Item
        /// </summary>
        public DeviceInfoDetailItem Item { get; set; }
        
        /// <summary>
        /// Create request
        /// </summary>
        /// <param name="lockKey">Lock key</param>
        /// <returns>Request</returns>
        public XmlDocument CreateRequest(string lockKey)
        {
            var request = new XmlDocument();
            
            var serializer = new XmlSerializer(Item.GetType());
            using (var writer = new StringWriter())
            {
                serializer.Serialize(writer, Item);
                request.LoadXml(writer.ToString());
            }

            var itemNode = request.FirstChild.NextSibling;
            request.RemoveAll();

            var root = request.AppendChild(request.CreateElement("AppReqSetDeviceInfoDetail"));

            root.AppendChild(request.CreateElement("RequestItem"))
                .InnerText = Item.RequestItem;
            
            root.AppendChild(request.CreateElement("LockKey"))
                .InnerText = lockKey;

            if (itemNode != null)
            {
                root.AppendChild(itemNode);
            }

            return request;
        }
    }
}
