﻿namespace ServiceHub.Connectors.OpenAPI.Model
{
    /// <summary>
    /// Permanent Settings PublicUser
    /// </summary>
    public enum PermanentSettingsPublicUser
    {
        Mode1,
        Mode3,
        Mode4,
        Unidentified
    }
}