using ServiceHub.Common.Attributes;

namespace ServiceHub.Connectors.OpenAPI.Model
{
    /// <summary>
    /// Permanent settings request items
    /// </summary>
    public enum PermanentSettingsRequestItems
    {
        Print,
        Copy,
        Scan,
        Network,
        Fax,
        Ifax,
        System,
        Panel,
        Power,
        DateTime,
        Alert,
        WeeklyTimer,
        CommonPaperHandling,
        OperationLevel,
        Security,
        Counter,
        Authentication,
        Admin,
        MfpService,
        Tsi,
        NetworkFax,
        CounterReport,
        ReferLicence,
        AuthDevice,
        HeaderFooter,
        Pswc,
        Box,
        SingleSignOnDomain,
        SingleSignOnService,
        CustomPaper,
        InternalWebServer,
        PanelTopMenu,
        Size,
        AdminMyPanel,
        AcquirePermission,
        UbiquitousPrint,
        CloudConnection,
        [EnumValue("SVRBackupRestoreSetting")]
        SvrBackupRestoreSetting,
        [EnumValue("HDDBackupRestoreSetting")]
        HddBackupRestoreSetting
    }
}
