using System.Xml.Serialization;
using ServiceHub.Common.Attributes;

namespace ServiceHub.Connectors.OpenAPI.Model
{
    /// <summary>
    /// Detail settings request items
    /// </summary>
    public enum DetailSettingsRequestItems
    {
        System,
        Version,
        Input,
        Output,
        Consumable,
        Marker,
        MediaPath,
        Odh,
        Sensor,
        Storage,
        PhysicalInterface,
        Snmp,
        TcpipGeneral,
        Lpr,
        RawPort,
        Ipp,
        FtpClient,
        Http,
        MailSend,
        MailReceive,
        MailReceiveSmtp,
        Slp,
        Ldap,
        NetWare,
        AppleTalk,
        WindowsNetwork,
        Ftpd,
        OpenApi,
        Filtering,
        Ntp,
        ReportPrintList,
        PdlInfoList,
        MarketArea,
        TcpSocket,
        Bonjour,
        NetworkFax,
        Smime,
        WebService,
        WebDav,
        Fax,
        [EnumValue("Ieee8021x")]
        [XmlEnum("Ieee8021x")]
        Ieee8021X,
        CertificateVerification,
        SystemConnection,
        Bmlinks,
        Ssdp,
        Iisw,
        RemoteFwUpdate,
        NetworkErrorDetail,
        ExpansionNetwork,
        AirPrint,
        FwRollback,
        DistributerFolder
    }
}
