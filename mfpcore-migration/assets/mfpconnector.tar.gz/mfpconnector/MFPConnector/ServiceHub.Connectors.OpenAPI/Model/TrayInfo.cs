﻿using Newtonsoft.Json;

namespace ServiceHub.Connectors.OpenAPI.Model
{
    /// <summary>
    /// Trays info
    /// </summary>
    public class TrayInfo
    {
        /// <summary>
        /// Tray Id
        /// </summary>
        [JsonProperty(PropertyName = "tray_id", Required = Required.Always)]
        public string TrayId { get; set; }

        /// <summary>
        /// Media Type
        /// </summary>
        [JsonProperty(PropertyName = "media_type")]
        public string MediaType { get; set; }

        /// <summary>
        /// Paper Info
        /// </summary>
        [JsonProperty(PropertyName = "paper_info")]
        public PaperInfo PaperInfo { get; set; }
    }
}
