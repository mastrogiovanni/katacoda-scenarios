namespace ServiceHub.Connectors.OpenAPI.Model
{
    public enum MfpCounterType
    {
        Total,
        BySize
    }
}