namespace ServiceHub.Connectors.OpenAPI.Model
{
    /// <summary>
    /// Get device info request items
    /// </summary>
    public enum GetDeviceInfoRequestItems
    {
        Company,
        Option,
        SupportFunction,
        ExtensionFunction,
        AccessPointList,
        WirelessStatus
    }
}
