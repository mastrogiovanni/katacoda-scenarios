﻿using System;

namespace ServiceHub.Connectors.OpenAPI.Model
{
    /// <summary>
    /// UserInfo
    /// </summary>
    public struct UserInfo : IEquatable<UserInfo>
    {
        /// <summary>
        /// User type
        /// </summary>
        public OperatorInfoUserType UserType { get; }

        /// <summary>
        /// User: user name
        /// </summary>
        public string UserName { get; }

        /// <summary>
        /// User: password
        /// </summary>
        public string UserPassword { get; }

        /// <summary>
        /// Enhanced: auth parameter code
        /// </summary>
        public string EnhancedAuthParameterCode { get; }

        /// <summary>
        /// Public user
        /// </summary>
        public static UserInfo Public => new UserInfo(OperatorInfoUserType.Public);

        /// <summary>
        /// Admin user
        /// </summary>
        public  static  UserInfo Admin => new UserInfo(OperatorInfoUserType.Admin);

        /// <summary>
        /// Driver user
        /// </summary>
        public  static UserInfo Driver => new UserInfo(OperatorInfoUserType.Driver);

        /// <summary>
        /// Enhanced user
        /// </summary>
        /// <param name="enhancedAuthParameterCode">auth parameter code</param>
        /// <returns></returns>
        public static UserInfo Enhanced(string enhancedAuthParameterCode)
        {
            return new UserInfo(OperatorInfoUserType.Enhanced, enhancedAuthParameterCode);
        }

        /// <summary>
        /// Normal user
        /// </summary>
        /// <param name="name">User name</param>
        /// <param name="password">User password</param>
        /// <returns></returns>
        public static UserInfo User(string name, string password)
        {
            return new UserInfo(OperatorInfoUserType.User, name, password);
        }


        private UserInfo(OperatorInfoUserType userType)
        {
            switch (userType)
            {
                case OperatorInfoUserType.Admin:
                case OperatorInfoUserType.Driver:
                case OperatorInfoUserType.Public:
                    UserType = userType;
                    UserName = null;
                    UserPassword = null;
                    EnhancedAuthParameterCode = null;
                    break;
                default:
                    throw new ArgumentException($"{nameof(userType)} is invalid for this constructor. Must be {OperatorInfoUserType.Admin} or {OperatorInfoUserType.Driver} or {OperatorInfoUserType.Public}.");
            }
        }

        private UserInfo(OperatorInfoUserType userType, string enhancedAuthParameterCode)
        {
            if (userType != OperatorInfoUserType.Enhanced)
            {
                throw new ArgumentException($"{nameof(userType)} is invalid for this constructor. Must be {OperatorInfoUserType.Enhanced}.");
            }

            UserType = userType;
            UserName = null;
            UserPassword = null;
            EnhancedAuthParameterCode = enhancedAuthParameterCode;
        }

        private UserInfo(OperatorInfoUserType userType, string userName, string userPassword)
        {
            if (userType != OperatorInfoUserType.User)
            {
                throw new ArgumentException($"{nameof(userType)} is invalid for this constructor. Must be {OperatorInfoUserType.User}.");
            }

            UserType = userType;
            UserName = userName;
            UserPassword = userPassword;
            EnhancedAuthParameterCode = null;
        }

        public override string ToString()
        {
            return $"{nameof(UserType)} = {UserType}, {nameof(UserName)} = {UserName}, {nameof(UserPassword)} = {UserPassword}, {nameof(EnhancedAuthParameterCode)}= {EnhancedAuthParameterCode}";
        }

        public bool Equals(UserInfo other)
        {
            // Compare by number
            switch (other.UserType)
            {
                case OperatorInfoUserType.Admin:
                case OperatorInfoUserType.Driver:
                case OperatorInfoUserType.Public:
                    return UserType == other.UserType;
                case OperatorInfoUserType.User:
                    return UserType == other.UserType
                           && UserName == other.UserName
                           && UserPassword == other.UserPassword;
                case OperatorInfoUserType.Enhanced:
                    return UserType == other.UserType
                           && EnhancedAuthParameterCode == other.EnhancedAuthParameterCode;
            }

            return false;
        }

        public override bool Equals(object obj)
        {
            if (obj == null || GetType() != obj.GetType())
            {
                return false;
            }

            if (!(obj is UserInfo))
            {
                return false;
            }

            return Equals((UserInfo) obj);
        }

        public override int GetHashCode()
        {
            switch (UserType)
            {
                case OperatorInfoUserType.Admin:
                case OperatorInfoUserType.Driver:
                case OperatorInfoUserType.Public:
                    return UserType.GetHashCode();
                case OperatorInfoUserType.User:
                    return UserType.GetHashCode() ^ UserName.GetHashCode() ^ UserPassword.GetHashCode();
                case OperatorInfoUserType.Enhanced:
                    return UserType.GetHashCode() ^ EnhancedAuthParameterCode.GetHashCode();
                default:
                    return base.GetHashCode();
            }
        }
    }
}
