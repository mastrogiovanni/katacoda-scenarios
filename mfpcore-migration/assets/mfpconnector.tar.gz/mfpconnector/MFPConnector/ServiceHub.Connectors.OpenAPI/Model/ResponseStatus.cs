﻿namespace ServiceHub.Connectors.OpenAPI.Model
{
    public enum ResponseStatus
    {
        Ack,
        Nack
    }
}
