﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ServiceHub.Connectors.OpenAPI.Model.PermanentSettings.Security
{
    /// <summary>
    /// Personal Information Protect Setting
    /// </summary>
    public class PersonalInfoProtect
    {
        public PersonalInfoProtect(JobHistory jobHistory, ExecutingJob executingJob)
        {
            JobHistory = jobHistory;
            ExecutingJob = executingJob;
        }

        /// <summary>
        /// Gets or sets the job history.
        /// </summary>
        public JobHistory JobHistory { get;}

        /// <summary>
        /// Gets or sets thExecutingJob executing job.
        /// </summary>
        public ExecutingJob ExecutingJob { get;}
    }
}
