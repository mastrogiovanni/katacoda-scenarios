﻿namespace ServiceHub.Connectors.OpenAPI.Model.PermanentSettings.Security
{
    /// <summary>
    /// JobHistory Setting
    /// </summary>
    public class JobHistory
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="JobHistory"/> class.
        /// </summary>
        /// <param name="enable">The enable.</param>
        /// <param name="displayMode">The display mode.</param>
        /// <param name="publicUser">The public user.</param>
        public JobHistory(string enable, string displayMode, string publicUser)
        {
            Enable = enable;
            DisplayMode = displayMode;
            PublicUser = publicUser;
        }

        /// <summary>
        /// Gets or sets the enable.
        /// </summary>
        public string Enable { get;}

        /// <summary>
        /// Gets or sets the display mode.
        /// </summary>
        public string DisplayMode { get;}

        /// <summary>
        /// Gets or sets the public user.
        /// </summary>
        public string PublicUser { get;}
    }
}