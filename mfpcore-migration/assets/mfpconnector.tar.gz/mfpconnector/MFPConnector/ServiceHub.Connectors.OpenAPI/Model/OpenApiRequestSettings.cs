using ServiceHub.Common.Settings;

namespace ServiceHub.Connectors.OpenAPI.Model
{
    /// <summary>
    /// Open api request model
    /// </summary>
    public class OpenApiRequestSettings
    {
        /// <summary>
        /// Gets the Namespace.
        /// </summary>
        public string Namespace { get; }

        /// <summary>
        /// Initializes a new instance of the <see cref="OpenApiRequestSettings" /> class.
        /// </summary>
        /// <param name="mfpConnectorSetting">Settings from Setting.json</param>
        public OpenApiRequestSettings(MfpConnectorSetting mfpConnectorSetting)
        {
            MfpConnectorSetting = mfpConnectorSetting;
            if (mfpConnectorSetting?.OpenApi?.Version != null)
            {
                Namespace = string.Format("http://www.konicaminolta.com/service/OpenAPI-{0}-{1}",
                    mfpConnectorSetting.OpenApi.Version.Major,
                    mfpConnectorSetting.OpenApi.Version.Minor);
            }
        }

        /// <summary>
        /// Settings from Setting.json
        /// </summary>
        public MfpConnectorSetting MfpConnectorSetting { get; set; }
    }
}
