using System.Collections.Generic;
using System.Xml.Serialization;

namespace ServiceHub.Connectors.OpenAPI.Model.ResponseXmlModel.Animations
{
    /// <summary>
    /// Animation fiule list.
    /// </summary>
    [XmlRoot("AnimationFileList")]
    public class AnimationFileList
    {
        /// <summary>
        /// Array size
        /// </summary>
        [XmlElement("ArraySize")]
        public int ArraySize { get; set; }

        /// <summary>
        /// Animation file list
        /// </summary>
        [XmlElement("AnimationFile")]
        public List<AnimationFile> AnimationFiles { get; set; }
    }
}
