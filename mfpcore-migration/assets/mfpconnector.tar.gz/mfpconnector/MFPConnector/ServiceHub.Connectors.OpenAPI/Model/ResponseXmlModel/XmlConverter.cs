using System.IO;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Serialization;

namespace ServiceHub.Connectors.OpenAPI.Model.ResponseXmlModel
{
    /// <summary>
    /// Convert function for XML
    /// </summary>
    public static class XmlConverter
    {
        /// <summary>
        /// Deserialize xml
        /// </summary>
        /// <typeparam name="T">Type of result object</typeparam>
        /// <param name="xml">XML</param>
        /// <param name="tagName">Target tag name</param>
        /// <returns>Deserialized object</returns>
        public static T Deserialize<T>(string xml, string tagName)
        {
            var content = new XmlDocument();
            content.LoadXml(xml);
            return Deserialize<T>(content, tagName);
        }

        /// <summary>
        /// Deserialize xml
        /// </summary>
        /// <typeparam name="T">Type of result object</typeparam>
        /// <param name="xml">XML</param>
        /// <param name="tagName">Target tag name</param>
        /// <returns>Deserialized object</returns>
        public static T Deserialize<T>(XmlDocument xml, string tagName)
        {
            // select body element
            var nodes = xml.GetElementsByTagName(tagName);
            return nodes.Count == 0 ? default(T) : Deserialize<T>(nodes[0]);
        }

        /// <summary>
        /// Deserialize xml
        /// </summary>
        /// <typeparam name="T">Type of result object</typeparam>
        /// <param name="node">Deserialize target</param>
        /// <returns>Deserialized object</returns>
        public static T Deserialize<T>(XmlNode node)
        {
            if (node == null)
            {
                return default(T);
            }
            
            // remove namespace
            var xdoc = XDocument.Parse(node.OuterXml);
            foreach (var e in xdoc.Descendants())
            {
                e.Name = e.Name.LocalName;
            }

            var xml = xdoc.ToString(SaveOptions.DisableFormatting);
            
            // deserialize
            var serializer = new XmlSerializer(typeof(T));
            return (T)serializer.Deserialize(new StringReader(xml));
        }
    }
}
