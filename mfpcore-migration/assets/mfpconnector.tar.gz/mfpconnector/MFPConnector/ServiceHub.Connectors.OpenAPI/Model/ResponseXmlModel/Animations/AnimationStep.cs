using System.Collections.Generic;
using System.Xml.Serialization;

namespace ServiceHub.Connectors.OpenAPI.Model.ResponseXmlModel.Animations
{
    /// <summary>
    /// Animation step.
    /// </summary>
    [XmlRoot("AnimationStep")]
    public class AnimationStep
    {
        /// <summary>
        /// Step id.
        /// </summary>
        [XmlElement("StepID")]
        public int StepId { get; set; }

        /// <summary>
        /// Array size
        /// </summary>
        [XmlElement("AnimationFilePathList")]
        public List<AnimationFilePathList> AnimationFilePathList { get; set; }
    }
}
