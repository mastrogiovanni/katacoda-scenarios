using System.Xml.Serialization;

namespace ServiceHub.Connectors.OpenAPI.Model.ResponseXmlModel
{
    /// <summary>
    /// OpenAPI Result Class.
    /// </summary>
    [XmlRoot("Result")]
    public class OpenApiResult
    {
        /// <summary>
        /// ResultInfo[Ack/Nack]
        /// </summary>
        [XmlElement("ResultInfo")]
        public string ResultInfo { get; set; }
    }
}
