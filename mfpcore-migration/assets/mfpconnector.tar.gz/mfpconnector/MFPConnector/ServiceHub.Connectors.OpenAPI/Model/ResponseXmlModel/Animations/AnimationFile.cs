using System.Collections.Generic;
using System.Xml.Serialization;

namespace ServiceHub.Connectors.OpenAPI.Model.ResponseXmlModel.Animations
{
    /// <summary>
    /// Animation file
    /// </summary>
    [XmlRoot("AnimationFile")]
    public class AnimationFile
    {
        /// <summary>
        /// Animation file id
        /// </summary>
        [XmlElement("AnimationID")]
        public int AnimationId { get; set; }

        /// <summary>
        /// Animation step list
        /// </summary>
        [XmlElement("AnimationStepList")]
        public List<AnimationStepList> AnimationStepList { get; set; }
    }
}
