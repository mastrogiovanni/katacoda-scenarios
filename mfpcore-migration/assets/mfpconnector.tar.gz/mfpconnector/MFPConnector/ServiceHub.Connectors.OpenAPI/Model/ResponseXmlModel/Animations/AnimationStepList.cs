using Newtonsoft.Json;
using System.Collections.Generic;
using System.Xml.Serialization;

namespace ServiceHub.Connectors.OpenAPI.Model.ResponseXmlModel.Animations
{
    /// <summary>
    /// Animation step list.
    /// </summary>
    [XmlRoot("AnimationStepList")]
    public class AnimationStepList
    {
        /// <summary>
        /// Array size
        /// </summary>
        [XmlElement("ArraySize")]
        public int ArraySize { get; set; }

        /// <summary>
        /// Array size
        /// </summary>
        [XmlElement("AnimationStep")]
        public List<AnimationStep> AnimationStep { get; set; }
    }
}
