using System.Xml.Serialization;

namespace ServiceHub.Connectors.OpenAPI.Model.ResponseXmlModel.Animations
{
    /// <summary>
    /// Animation file path.
    /// </summary>
    [XmlRoot("AnimationFilePath")]
    public class AnimationFilePath
    {
        /// <summary>
        /// File path
        /// </summary>
        [XmlElement("FilePath")]
        public string FilePath { get; set; }
    }
}
