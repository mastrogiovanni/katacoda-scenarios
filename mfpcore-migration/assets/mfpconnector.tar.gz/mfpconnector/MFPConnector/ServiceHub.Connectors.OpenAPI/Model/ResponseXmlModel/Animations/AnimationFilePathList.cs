using System.Collections.Generic;
using System.Xml.Serialization;

namespace ServiceHub.Connectors.OpenAPI.Model.ResponseXmlModel.Animations
{
    /// <summary>
    /// Animation file path list.
    /// </summary>
    [XmlRoot("AnimationFilePathList")]
    public class AnimationFilePathList
    {
        /// <summary>
        /// Array size
        /// </summary>
        [XmlElement("ArraySize")]
        public int ArraySize { get; set; }

        /// <summary>
        /// File path
        /// </summary>
        [XmlElement("AnimationFilePath")]
        public List<AnimationFilePath> AnimationFilePath { get; set; }
    }
}
