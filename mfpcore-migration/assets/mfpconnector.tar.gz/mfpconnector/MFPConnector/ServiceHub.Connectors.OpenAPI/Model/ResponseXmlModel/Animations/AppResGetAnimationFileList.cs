using System.Xml.Serialization;

namespace ServiceHub.Connectors.OpenAPI.Model.ResponseXmlModel.Animations
{
    [XmlRoot("AppResGetAnimationFileList")]
    public class AppResGetAnimationFileList
    {
        [XmlElement("Result")]
        public OpenApiResult OpenApiResult { get; set; }

        [XmlElement("AnimationFileList")]
        public AnimationFileList AnimationFiles { get; set; }
    }
}
