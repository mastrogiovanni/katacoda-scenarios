﻿namespace ServiceHub.Connectors.OpenAPI.Model
{
    /// <summary>
    /// Permanent Settings RequestSourceSH
    /// </summary>
    public enum PermanentSettingsRequestSourceSH
    {
        On,
        Off,
        Unidentified
    }
}