﻿namespace ServiceHub.Connectors.OpenAPI.Model
{
    /// <summary>
    /// Warning message
    /// </summary>
    public enum WarningMessage
    {
        AMSMagnificationIncompatible,
        APSAcceptable,
        APSSizeMismatch,
        BlackCounter,
        ExtDocumentSizeAssign,
        FatalCodeList,
        FullColorCounter,
        ManuscriptADF1,
        ManuscriptADF2,
        ManuscriptSizeDetectError,
        MemoryOverflow,
        OverFoldNoWarning,
        PaperEmptyCaution,
        PaperEmptyError,
        PaperRelease,
        PrintIncompatible,
        PunchDirectionNotAcceptable,
        PunchFormStaple,
        PunchPaperIncompatibility,
        PunchRubbishFull,
        StapleDirectionNotAcceptable,
        StapleExaggerated,
        StapleForm,
        StaplePaperMismatch,
        StaplingEmpty,
        TentativeRelief,
        TonerEmptyStop,
        IuLife,
        TotalCounter,
        TwoSidedIncompatible
    }
}