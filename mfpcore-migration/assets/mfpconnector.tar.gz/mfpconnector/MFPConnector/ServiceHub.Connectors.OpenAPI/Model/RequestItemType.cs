using System.Xml.Serialization;
using ServiceHub.Common.Attributes;

namespace ServiceHub.Connectors.OpenAPI.Model
{
    /// <summary>
    /// Request item type of AppReq
    /// </summary>
    public enum AppRequestItemType
    {
        /// <summary>
        /// Copy protect
        /// </summary>
        TintBlock,

        /// <summary>
        /// Stamp
        /// </summary>
        Stamp,

        /// <summary>
        /// Animation
        /// </summary>
        [EnumValue("SHAnimationData")]
        [XmlEnum("SHAnimationData")]
        ShAnimationData,

        /// <summary>
        /// Machine image
        /// </summary>
        [EnumValue("SHMachineChart")]
        [XmlEnum("SHMachineChart")]
        ShMachineChart
    }
}
