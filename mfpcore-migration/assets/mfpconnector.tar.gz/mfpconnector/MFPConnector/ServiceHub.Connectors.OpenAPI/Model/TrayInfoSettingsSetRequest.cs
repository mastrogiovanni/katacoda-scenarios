﻿using System.Collections.Generic;
using Newtonsoft.Json;

namespace ServiceHub.Connectors.OpenAPI.Model
{
    /// <summary>
    /// TrayInfoSettingsSetRequest
    /// </summary>
    public class TrayInfoSettingsSetRequest
    {
        /// <summary>
        /// Setting names.
        /// </summary>
        [JsonProperty(PropertyName = "trays")]
        public List<TrayInfo> SettingValues { get; set; }
    }
}