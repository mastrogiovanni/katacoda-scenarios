namespace ServiceHub.Connectors.OpenAPI.Model
{
    /// <summary>
    /// IP address type.
    /// </summary>
    public enum Ipv6Type
    {
        Local,
        Global,
        Unidentified
    }
}