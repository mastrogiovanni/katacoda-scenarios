﻿namespace ServiceHub.Connectors.OpenAPI.Model
{
    /// <summary>
    /// Permanent Settings Enable
    /// </summary>
    public enum PermanentSettingsEnable
    {
        On,
        Off,
        Unidentified
    }
}