namespace ServiceHub.Connectors.OpenAPI.Model
{
    /// <summary>
    /// OpenAPI Result structure
    /// </summary>
    public class OpenApiResult
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="OpenApiResult"/> class.
        /// </summary>
        public OpenApiResult()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="OpenApiResult" /> class.
        /// </summary>
        /// <param name="resultInfo">The result information.</param>
        public OpenApiResult(string resultInfo)
        {
            ResultInfo = resultInfo;
        }

        /// <summary>
        /// ResultInfo[Ack/Nack]
        /// </summary>
        public string ResultInfo { get; set; }
    }
}
