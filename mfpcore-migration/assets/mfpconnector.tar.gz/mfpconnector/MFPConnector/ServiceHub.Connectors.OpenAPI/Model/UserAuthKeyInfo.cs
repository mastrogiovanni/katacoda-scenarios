﻿using System;

namespace ServiceHub.Connectors.OpenAPI.Model
{
    /// <summary>
    /// User auth key info
    /// </summary>
    public struct UserAuthKeyInfo : IEquatable<UserAuthKeyInfo>
    {
        /// <summary>
        /// Auth key
        /// </summary>
        public string AuthKey { get; }

        /// <summary>
        /// Obtained date time
        /// </summary>
        public DateTime ObtainedDateTime { get; }

        /// <summary>
        /// Initializes a new instance of the <see cref="UserAuthKeyInfo"/> class.  
        /// </summary>
        /// <param name="authKey">Auth key</param>
        public UserAuthKeyInfo(string authKey)
        {
            AuthKey = authKey;
            ObtainedDateTime = DateTime.Now;
        }

        public bool Equals(UserAuthKeyInfo other)
        {
            return AuthKey == other.AuthKey;
        }

        public override bool Equals(object obj)
        {
            if (obj == null || GetType() != obj.GetType())
            {
                return false;
            }

            if (!(obj is UserAuthKeyInfo))
            {
                return false;
            }

            return Equals((UserAuthKeyInfo)obj);
        }

        public override int GetHashCode()
        {
            return AuthKey.GetHashCode();
        }

        public override string ToString()
        {
            return $"{nameof(AuthKey)} = {AuthKey}, {nameof(ObtainedDateTime)} = {ObtainedDateTime}";
        }
    }
}