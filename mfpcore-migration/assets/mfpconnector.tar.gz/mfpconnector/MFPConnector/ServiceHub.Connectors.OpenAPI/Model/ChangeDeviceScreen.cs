using ServiceHub.Common.Attributes;

namespace ServiceHub.Connectors.OpenAPI.Model
{
    /// <summary>
    /// SwitchType
    /// </summary>
    public enum SwitchType
    {
        [EnumValue("MFPtoSH")]
        WPH,
        [EnumValue("SHtoMFP")]
        MFP,
        Unidentified
    }

    /// <summary>
    /// ScreenType
    /// </summary>
    public enum ScreenType
    {
        Copy,
        Scan,
        Box,
        WebBrowser,
        TopMenu,
        UbiquitousPrint,
        ApplicationList,
        OAPIApplication,
        IWSApplication,
        None,
        Unidentified
    }
}
