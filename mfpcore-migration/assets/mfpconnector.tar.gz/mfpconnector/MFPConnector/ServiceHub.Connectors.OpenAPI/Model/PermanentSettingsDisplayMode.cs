﻿namespace ServiceHub.Connectors.OpenAPI.Model
{
    /// <summary>
    /// Permanent Settings DisplayMode
    /// </summary>
    public enum PermanentSettingsDisplayMode
    {
        Mode1,
        Mode2,
        Unidentified
    }
}