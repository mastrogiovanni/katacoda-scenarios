using System.Data;
using System.IO;
using System.Xml;
using KonicaMinolta.OpenApi;

namespace ServiceHub.Connectors.OpenAPI.Model
{
    /// <summary>
    /// OpenAPI response with attach
    /// </summary>
    public class OpenApiResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="OpenApiResponse"/> class.
        /// </summary>
        /// <param name="message">The message.</param>
        public OpenApiResponse(OpenApiMessage message)
        {
            var xml = new XmlDocument();
            xml.LoadXml(message.Text);
            Message = xml;
            Attachment = message.Attachment?.ContentBytes;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="OpenApiResponse"/> class.
        /// </summary>
        /// <param name="message">The message.</param>
        /// <param name="attachment">The attachment.</param>
        public OpenApiResponse(XmlDocument message, byte[] attachment)
        {
            Message = message;
            Attachment = attachment;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="OpenApiResponse"/> class.
        /// </summary>
        /// <param name="message">The message.</param>
        /// <param name="attachment">The attachment.</param>
        /// <exception cref="DataException"></exception>
        public OpenApiResponse(XmlDocument message, Stream attachment)
        {
            Message = message;

            if (attachment != null)
            {
                var length = attachment.Length;
                var binary = new byte[length];
                var readBytes = attachment.Read(binary, 0, (int)length);
                if (readBytes == 0 && length > 0)
                {
                    throw new DataException($"Unable to read the attachment originally of {length}bytes");
                }

                Attachment = binary;
            }
        }

        /// <summary>
        /// OpenAPI message
        /// </summary>
        public XmlDocument Message { get; set; }

        /// <summary>
        /// Attachment binary
        /// </summary>
        public byte[] Attachment { get; set; }
    }
}
