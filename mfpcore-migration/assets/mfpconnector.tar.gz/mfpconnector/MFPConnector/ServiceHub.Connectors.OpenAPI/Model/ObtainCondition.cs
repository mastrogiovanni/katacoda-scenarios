﻿namespace ServiceHub.Connectors.OpenAPI.Model
{
    /// <summary>
    /// Obtain condition
    /// </summary>
    public enum ObtainCondition
    {
        OffsetList,
        SpecifiedNo,
        IndexList
    }
}