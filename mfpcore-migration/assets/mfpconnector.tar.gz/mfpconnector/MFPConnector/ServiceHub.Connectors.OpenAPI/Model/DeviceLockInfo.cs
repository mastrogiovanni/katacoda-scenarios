﻿using System.Threading;

namespace ServiceHub.Connectors.OpenAPI.Model
{
    /// <summary>
    /// Device lock info.
    /// </summary>
    public class DeviceLockInfo
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="DeviceLockInfo"/> class.  
        /// </summary>
        public DeviceLockInfo()
        {
            Event = new ManualResetEvent(false);
            ReferenceEvent = new ManualResetEvent(false);
            TimeoutMin = 0;
            LockKey = string.Empty;
        }

        /// <summary>
        /// Manual reset event.
        /// </summary>
        public ManualResetEvent Event { get; }

        /// <summary>
        /// Wait timeout [minute].
        /// </summary>
        public int TimeoutMin { get; set; }

        /// <summary>
        /// Device lock key.
        /// </summary>
        public string LockKey { get; set; }

        /// <summary>
        /// Reference count.
        /// </summary>
        public ManualResetEvent ReferenceEvent { get; }
    }
}
