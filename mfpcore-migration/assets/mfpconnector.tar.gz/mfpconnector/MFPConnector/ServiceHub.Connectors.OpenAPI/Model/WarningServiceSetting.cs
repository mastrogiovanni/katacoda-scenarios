﻿using Newtonsoft.Json;

namespace ServiceHub.Connectors.OpenAPI.Model
{
    /// <summary>
    /// WarningServiceSetting class.
    /// </summary>
    public class WarningServiceSetting
    {
        [JsonProperty(PropertyName = "job_id")]
        public ulong? JobId { get; set; }

        [JsonProperty(PropertyName = "warn_cancel_name")]
        public string Name { get; set; }

        [JsonProperty(PropertyName = "warn_ope_type", Required = Required.Always)]
        public string Type { get; set; }

        [JsonProperty(PropertyName = "aps_acceptable")]
        public ApsAcceptableModel ApsAcceptable { get; set; }

        /// <summary>
        /// ApsAcceptableModel class
        /// </summary>
        public class ApsAcceptableModel
        {
            [JsonProperty(PropertyName = "acceptable_type")]
            public string AcceptableType { get; set; }

            [JsonProperty(PropertyName = "tray_selection")]
            public string TraySelection { get; set; }

            [JsonProperty(PropertyName = "dimension")]
            public DimensionModel Dimension { get; set; }
        }

        /// <summary>
        /// DimensionModel class
        /// </summary>
        public class DimensionModel
        {
            [JsonProperty(PropertyName = "x")]
            public float? X { get; set; }
            [JsonProperty(PropertyName = "y")]
            public float? Y { get; set; }
        }

        [JsonProperty(PropertyName = "paper_empty_caution")]
        public PaperEmptyCautionModel PaperEmptyCaution { get; set; }

        /// <summary>
        /// PaperEmptyCautionModel class
        /// </summary>
        public class PaperEmptyCautionModel
        {
            [JsonProperty(PropertyName = "paper_empty_caution_type")]
            public string PaperEmptyCautionType { get; set; }

            [JsonProperty(PropertyName = "tray_selection")]
            public string TraySelection { get; set; }
        }

        [JsonProperty(PropertyName = "paper_empty_error")]
        public PaperEmptyErrorModel PaperEmptyError { get; set; }

        /// <summary>
        /// PaperEmptyErrorModel class
        /// </summary>
        public class PaperEmptyErrorModel
        {
            [JsonProperty(PropertyName = "tray_selection")]
            public string TraySelection { get; set; }

        }

        [JsonProperty(PropertyName = "two_sided_incompatible")]
        public TwoSidedIncompatibleModel TwoSidedIncompatible { get; set; }

        /// <summary>
        /// TwoSidedIncompatibleModel class
        /// </summary>
        public class TwoSidedIncompatibleModel
        {
            [JsonProperty(PropertyName = "two_sided_incompatible_type")]
            public string TwoSidedIncompatibleType { get; set; }

            [JsonProperty(PropertyName = "tray_selection")]
            public string TraySelection { get; set; }
        }

        [JsonProperty(PropertyName = "manuscript_size_detect_error")]
        public ManuscriptSizeDetectErrorModel ManuscriptSizeDetectError { get; set; }

        /// <summary>
        /// ManuscriptSizeDetectErrorModel class
        /// </summary>
        public class ManuscriptSizeDetectErrorModel
        {
            [JsonProperty(PropertyName = "manuscript_size_detect_error_type")]
            public string ManuscriptSizeDetectErrorType { get; set; }

            [JsonProperty(PropertyName = "dimension")]
            public DimensionModel Dimension { get; set; }

            [JsonProperty(PropertyName = "tray_selection")]
            public string TraySelection { get; set; }

            [JsonProperty(PropertyName = "paper_size")]
            public PaperSizeModel PaperSize { get; set; }
        }

        /// <summary>
        /// PaperSizeModel class
        /// </summary>
        public class PaperSizeModel
        {
            [JsonProperty(PropertyName = "size_code")]
            public string SizeCode { get; set; }

            [JsonProperty(PropertyName = "dimension2")]
            public DimensionModel Dimension2 { get; set; }

            [JsonProperty(PropertyName = "feed_direction")]
            public string FeedDirection { get; set; }
        }

        [JsonProperty(PropertyName = "print_incompatible")]
        public PrintIncompatibleModel PrintIncompatible { get; set; }

        /// <summary>
        /// PrintIncompatibleModel class
        /// </summary>
        public class PrintIncompatibleModel
        {
            [JsonProperty(PropertyName = "print_incompatible_type")]
            public string PrintIncompatibleType { get; set; }

            [JsonProperty(PropertyName = "tray_selection")]
            public string TraySelection { get; set; }
        }

        [JsonProperty(PropertyName = "ams_magnification_incompatible")]
        public AmsMagnificationIncompatibleModel AmsMagnificationIncompatible { get; set; }

        /// <summary>
        /// AmsMagnificationIncompatibleModel class
        /// </summary>
        public class AmsMagnificationIncompatibleModel
        {
            [JsonProperty(PropertyName = "ams_magnification_incompatible_type")]
            public string AmsMagnificationIncompatibleType { get; set; }

            [JsonProperty(PropertyName = "tray_selection")]
            public string TraySelection { get; set; }

            [JsonProperty(PropertyName = "dimension")]
            public DimensionModel Dimension { get; set; }
        }

        [JsonProperty(PropertyName = "staple_form")]
        public StapleFormModel StapleForm { get; set; }

        /// <summary>
        /// StapleFormModel class
        /// </summary>
        public class StapleFormModel
        {
            [JsonProperty(PropertyName = "staple_form_type")]
            public string StapleFormType { get; set; }

            [JsonProperty(PropertyName = "tray_selection")]
            public string TraySelection { get; set; }
        }

        [JsonProperty(PropertyName = "staple_paper_mismatch")]
        public StaplePaperMismatchModel StaplePaperMismatch { get; set; }

        /// <summary>
        /// StaplePaperMismatchModel class
        /// </summary>
        public class StaplePaperMismatchModel
        {
            [JsonProperty(PropertyName = "staple_paper_mismatch_type")]
            public string StaplePaperMismatchType { get; set; }

            [JsonProperty(PropertyName = "tray_selection")]
            public string TraySelection { get; set; }
        }

        [JsonProperty(PropertyName = "punch_paper_incompatibility")]
        public PunchPaperIncompatibilityModel PunchPaperIncompatibility { get; set; }

        /// <summary>
        /// PunchPaperIncompatibilityModel class
        /// </summary>
        public class PunchPaperIncompatibilityModel
        {
            [JsonProperty(PropertyName = "punch_paper_incompatibility_type")]
            public string PunchPaperIncompatibilityType { get; set; }

            [JsonProperty(PropertyName = "tray_selection")]
            public string TraySelection { get; set; }
        }

        [JsonProperty(PropertyName = "staple_direction_not_acceptable")]
        public StapleDirectionNotAcceptableModel StapleDirectionNotAcceptable { get; set; }

        /// <summary>
        /// StapleDirectionNotAcceptableModel class
        /// </summary>
        public class StapleDirectionNotAcceptableModel
        {
            [JsonProperty(PropertyName = "staple_direction_change_type")]
            public string StapleDirectionChangeType { get; set; }

            [JsonProperty(PropertyName = "staple_position")]
            public string StaplePosition { get; set; }
        }

        [JsonProperty(PropertyName = "punch_direction_not_acceptable")]
        public PunchDirectionNotAcceptableModel PunchDirectionNotAcceptable { get; set; }

        /// <summary>
        /// PunchDirectionNotAcceptable class
        /// </summary>
        public class PunchDirectionNotAcceptableModel
        {
            [JsonProperty(PropertyName = "punch_direction_not_acceptable_type")]
            public string PunchDirectionNotAcceptableType { get; set; }

            [JsonProperty(PropertyName = "punch_position")]
            public string PunchPosition { get; set; }
        }

        [JsonProperty(PropertyName = "aps_size_mismatch")]
        public ApsSizeMismatchModel ApsSizeMismatch { get; set; }

        /// <summary>
        /// ApsSizeMismatchModel class
        /// </summary>
        public class ApsSizeMismatchModel
        {
            [JsonProperty(PropertyName = "tray_selection")]
            public string TraySelection { get; set; }
        }

        [JsonProperty(PropertyName = "toner_empty_stop")]
        public TonerEmptyStopModel TonerEmptyStop { get; set; }

        /// <summary>
        /// TonerEmptyStopModel class
        /// </summary>
        public class TonerEmptyStopModel
        {
            [JsonProperty(PropertyName = "temp_rescue_status")]
            public string TempRescueStatus { get; set; }
        }

        [JsonProperty(PropertyName = "iu_life")]
        public IuLifeModel IuLife { get; set; }

        /// <summary>
        /// IuLifeModel class
        /// </summary>
        public class IuLifeModel
        {
            [JsonProperty(PropertyName = "temp_rescue_status")]
            public string TempRescueStatus { get; set; }
        }

        [JsonProperty(PropertyName = "punch_form_staple")]
        public PunchFormStapleModel PunchFormStaple { get; set; }

        /// <summary>
        /// PunchFormStapleModel class
        /// </summary>
        public class PunchFormStapleModel
        {
            [JsonProperty(PropertyName = "punch_form_staple_type")]
            public string PunchFormStapleType { get; set; }

            [JsonProperty(PropertyName = "tray_selection")]
            public string TraySelection { get; set; }
        }

        [JsonProperty(PropertyName = "ext_document_size_assign")]
        public ExtDocumentSizeAssignModel ExtDocumentSizeAssign { get; set; }

        /// <summary>
        /// ExtDocumentSizeAssignModel class
        /// </summary>
        public class ExtDocumentSizeAssignModel
        {
            [JsonProperty(PropertyName = "paper_size")]
            public PaperSizeModel PaperSize { get; set; }
        }
    }
}