﻿using Newtonsoft.Json;

namespace ServiceHub.Connectors.OpenAPI.Model
{
    /// <summary>
    /// Paper info
    /// </summary>
    public class PaperInfo
    {
        /// <summary>
        /// Paper Size
        /// </summary>
        [JsonProperty(PropertyName = "paper_size", Required = Required.Always)]
        public string PaperSize { get; set; }

        /// <summary>
        /// Feed Direction
        /// </summary>
        [JsonProperty(PropertyName = "feed_direction")]
        public string FeedDirection { get; set; }

        /// <summary>
        /// Dimension
        /// </summary>
        [JsonProperty(PropertyName = "dimension")]
        public Dimension Dimension { get; set; }

    }
}
