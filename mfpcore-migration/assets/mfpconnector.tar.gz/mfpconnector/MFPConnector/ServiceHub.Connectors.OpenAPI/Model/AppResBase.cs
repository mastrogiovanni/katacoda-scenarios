namespace ServiceHub.Connectors.OpenAPI.Model
{
    /// <summary>
    /// AppRes base
    /// </summary>
    public class AppResBase
    {
        /// <summary>
        /// Result
        /// </summary>
        public OpenApiResult Result { get; set; }
    }
}
