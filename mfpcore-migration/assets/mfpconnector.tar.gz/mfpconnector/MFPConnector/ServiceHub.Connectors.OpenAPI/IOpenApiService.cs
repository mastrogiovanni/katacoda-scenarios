using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using System.Xml;
using ServiceHub.Connectors.OpenAPI.Model;
using KonicaMinolta.OpenApi.DeviceDescriptions;

namespace ServiceHub.Connectors.OpenAPI
{
    /// <summary>
    /// IOpenApiService
    /// </summary>
    public interface IOpenApiService
    {
        /// <summary>
        /// Request
        /// </summary>
        /// <param name="req">Xml</param>
        /// <param name="userInfo">user info</param>
        /// <param name="requireApplicationId">Add application ID to message</param>
        /// <param name="addOperatorInfoByAuthKey">Add operator info by holding AuthKey</param>
        /// <param name="jobDeleteFlg">Job delete flag</param>
        /// <param name="timeout">Request time out</param>
        /// <returns>Xml document</returns>
        Task<XmlDocument> RequestAsync(
            XmlDocument req, 
            UserInfo userInfo, 
            bool requireApplicationId = true, 
            bool addOperatorInfoByAuthKey = true, 
            bool jobDeleteFlg = false, 
            int? timeout = null);

        /// <summary>
        /// Request
        /// </summary>
        /// <param name="req">Xml</param>
        /// <param name="userInfo">user info</param>
        /// <param name="stream">Stream</param>
        /// <param name="requireApplicationId">Add application ID to message</param>
        /// <param name="addOperatorInfoByAuthKey">Add operator info by holding AuthKey</param>
        /// <param name="jobDeleteFlg">Job delete flag</param>
        /// <param name="timeout">Request time out</param>
        /// <returns>Xml document</returns>
        Task<OpenApiResponse> RequestFileAsync(
            XmlDocument req, 
            UserInfo userInfo, 
            Stream stream = null, 
            bool requireApplicationId = true, 
            bool addOperatorInfoByAuthKey = true, 
            bool jobDeleteFlg = false, 
            int? timeout = null);

        /// <summary>
        /// Received disconnect message
        /// </summary>
        void ReportDisconnect();

        /// <summary>
        /// Get current user info
        /// </summary>
        /// <returns>Current user info</returns>
        Dictionary<UserInfo, UserAuthKeyInfo> GetCurrentUserInfo();

        /// <summary>
        /// Get current user info
        /// </summary>
        /// <returns>Current user info</returns>
        DeviceDescription GetDeviceDescription();

        /// <summary>
        /// Confirm connect
        /// </summary>
        /// <param name="timeout">Request time out</param>
        /// <returns>Confirm result</returns>
        Task<bool> ConfirmConnectAsync(int? timeout = null);

        /// <summary>
        /// Confirm admin login.
        /// </summary>
        /// <param name="password">Admin password</param>
        /// <returns>Confirm result</returns>
        Task<bool> ConfirmAdminLoginAsync(string password);

        /// <summary>
        /// Removes the current authentication keys.
        /// </summary>
        void RemoveCurrentAuthKeys();
    }
}
