using KonicaMinolta.OpenApi;
using KonicaMinolta.OpenApi.DeviceDescriptions;
using Microsoft.Extensions.Logging;
using ServiceHub.Common.Extensions;
using ServiceHub.Common.Settings.Fax;
using ServiceHub.Connectors.OpenAPI.Model;
using ServiceHub.Connectors.OpenAPI.Model.DeviceInfoDetail;
using ServiceHub.Connectors.OpenAPI.Model.PermanentSettings.Security;
using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using System.Xml;
using ServiceHub.Connectors.OpenAPI.WarningMessages;

namespace ServiceHub.Connectors.OpenAPI
{
    /// <inheritdoc cref="IDisposable" />
    /// <summary>
    /// Sequential connection.
    /// </summary>
    public class OpenApiController : IDisposable, IOpenApiController
    {
        private const int AnimationListWaitTime = 300_000;
        private const int ExitDeviceLockWaitTime = 10_000;

        private readonly InvalidOperationException _exceptionDeviceIsNotLocked = new InvalidOperationException("Device is needed to lock but not locked.");
        private readonly ILockTaskManager _lockTaskManager;
        private readonly IOpenApiService _service;
        private readonly ILogger<OpenApiController> _logger;

        private static DeviceLockInfo _currentDeviceLockInfo;

        private bool _disposedValue;
        private IWarningMessageFactory _warningMessageFactory;

        /// <summary>
        /// Initializes a new instance of the <see cref="OpenApiController" /> class.
        /// </summary>
        /// <param name="openApiService">IOpenApiService</param>
        /// <param name="lockTaskManager">lockTaskManager</param>
        /// <param name="logger">_logger</param>
        public OpenApiController(
            IOpenApiService openApiService,
            ILockTaskManager lockTaskManager,
            ILogger<OpenApiController> logger)
        {
            _service = openApiService;
            _logger = logger;
            _lockTaskManager = lockTaskManager;
            _warningMessageFactory = new WarningMessageFactory();
        }

        /// <summary>
        /// Finalizes an instance of the <see cref="OpenApiController"/> class.
        /// </summary>
        ~OpenApiController()
        {
            Dispose(false);
        }

        /// <summary>
        /// Device is seemed to be locked?
        /// </summary>
        public virtual bool IsDeviceSeemedToBeLocked => _currentDeviceLockInfo != null;

        /// <summary>
        /// Dispose Me.
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Confirm connect by OpenAPI.
        /// </summary>
        /// <param name="timeout">Request time out</param>
        /// <returns>
        /// Confirm result
        /// </returns>
        public Task<bool> ConfirmConnectAsync(int? timeout = null) => _service.ConfirmConnectAsync(timeout);

        /// <summary>
        /// Confirm admin login by OpenAPI.
        /// </summary>
        /// <param name="password">Admin password</param>
        /// <returns>
        /// Confirm result
        /// </returns>
        public Task<bool> ConfirmAdminLoginAsync(string password) => _service.ConfirmAdminLoginAsync(password);

        /// <summary>
        /// Enter device lock.
        /// </summary>
        /// <param name="timeoutMin">Lock time out [minute] (Default 1 minute)</param>
        /// <returns>
        /// Lock key
        /// </returns>
        public async Task EnterDeviceLockAsync(int timeoutMin = 1)
        {
            // wait for get device lock by another thread
            var lockInfo = new DeviceLockInfo
            {
                TimeoutMin = timeoutMin,
            };

            // set the task to queue class
            _lockTaskManager.AddTask(lockInfo);
            lockInfo.Event.WaitOne();

            var req = new XmlDocument();
            req.AppendChild(req.CreateElement("AppReqEnterDeviceLock"));
            if (req.DocumentElement != null)
            {
                CreateChildElement(ref req, "LockType", "DownloadLock");
                CreateChildElement(ref req, "PackageEntryFlg", "Normal");
                CreateChildElement(ref req, "TimeOut", timeoutMin.ToString());
            }

            XmlDocument result;
            try
            {
                result = await _service.RequestAsync(req, UserInfo.Admin);
            }
            catch (OpenApiFaultException)
            {
                _lockTaskManager.RemoveTask(lockInfo);
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogTrace(default(EventId), ex, ex.Message);
                _lockTaskManager.RemoveTask(lockInfo);
                throw;
            }

            var lockKeyNodes = result.GetElementsByTagName("LockKey");
            if (lockKeyNodes.Count != 0)
            {
                lockInfo.LockKey = lockKeyNodes[0].InnerText;
            }

            _currentDeviceLockInfo = lockInfo;
        }

        /// <summary>
        /// Exit device lock.
        /// </summary>
        public async Task ExitDeviceLockAsync()
        {
            var lockInfo = _currentDeviceLockInfo;

            try
            {
                if (string.IsNullOrEmpty(lockInfo?.LockKey))
                {
                    return;
                }

                var req = new XmlDocument();
                req.AppendChild(req.CreateElement("AppReqExitDeviceLock"));
                if (req.DocumentElement != null)
                {
                    CreateChildElement(ref req, "LockKey", lockInfo.LockKey);
                }

                _currentDeviceLockInfo.ReferenceEvent.WaitOne(ExitDeviceLockWaitTime);
                await _service.RequestAsync(req, UserInfo.Admin);
            }
            finally
            {
                // reset the task to queue class
                _currentDeviceLockInfo = null;
                _lockTaskManager.RemoveTask(lockInfo);
            }
        }

        /// <summary>
        /// Get device list status.
        /// </summary>
        /// <returns>Xml document</returns>
        public Task<XmlDocument> GetDeviceListStatusAsync() => CreateAdminRequest("AppReqGetDeviceListStatus");

        /// <summary>
        /// Get device Parts status.
        /// </summary>
        /// <param name="deviceType">Device Type</param>
        /// <returns>Xml document</returns>
        public Task<XmlDocument> GetDevicePartsStatusAsync(string deviceType)
        {
            var req = new XmlDocument();
            req.AppendChild(req.CreateElement("AppReqGetDevicePartsStatus"));
            var item = req.CreateElement("RequestItem");
            item.InnerText = deviceType;
            req.DocumentElement?.AppendChild(item);

            // Request by Admin user
            return _service.RequestAsync(req, UserInfo.Admin);
        }

        /// <summary>
        /// DeleteJob.
        /// </summary>
        /// <param name="jobId">Job id</param>
        /// <param name="enhancedAuthParameterCode">Enhanced auth parameter code</param>
        /// <returns>Xml document</returns>
        /// <remarks>
        /// In V1.0, enhancedAuthParameterCode param is unnecessary,
        /// There is a possibility to use it in v1.2 It is left behind.
        /// </remarks>
        public Task<XmlDocument> DeleteJobAsync(string jobId, string enhancedAuthParameterCode)
        {
            var req = new XmlDocument();
            req.AppendChild(req.CreateElement("AppReqDeleteJob"));
            var factor = req.CreateElement("JobDeleteFactor");
            req.DocumentElement?.AppendChild(MessageCreator.CreateJobId(req, jobId));
            req.DocumentElement?.AppendChild(factor);

            factor.InnerText = "UserCancel";

            return _service.RequestAsync(req, UserInfo.Admin, true, true, true);
        }

        /// <summary>
        /// GetJobList.
        /// </summary>
        /// <param name="mfpJobId">Mfp Job Id</param>
        /// <returns>Xml Document</returns>
        public Task<XmlDocument> GetJobListAsync(ulong? mfpJobId)
        {
            var req = new XmlDocument();
            // get job list
            req.AppendChild(req.CreateElement("AppReqGetJobList"));
            var item = req.CreateElement("RequestItem");
            item.InnerText = !mfpJobId.HasValue ? "JobList" : "JobHistory";
            req.DocumentElement?.AppendChild(item);

            var condition = req.CreateElement("JobListCondition");
            var type = req.CreateElement("JobType");
            type.InnerText = "All";
            condition.AppendChild(type);

            condition.AppendChild(MessageCreator.CreateObtainCondition(
                req, mfpJobId.HasValue ? ObtainCondition.SpecifiedNo : ObtainCondition.IndexList, mfpJobId));
            req.DocumentElement?.AppendChild(condition);

            // Request by Admin user
            return _service.RequestAsync(req, UserInfo.Admin);
        }

        /// <summary>
        /// GetJobList - is activated.
        /// </summary>
        /// <param name="mfpJobId">Mfp Job Id</param>
        /// <returns>Xml Document</returns>
        public Task<XmlDocument> GetJobActiveListAsync(ulong? mfpJobId)
        {
            var req = new XmlDocument();
            // get job list
            req.AppendChild(req.CreateElement("AppReqGetJobList"));
            var item = req.CreateElement("RequestItem");
            item.InnerText = "JobList";
            req.DocumentElement?.AppendChild(item);

            var condition = req.CreateElement("JobListCondition");
            var type = req.CreateElement("JobType");
            type.InnerText = "All";
            condition.AppendChild(type);

            condition.AppendChild(MessageCreator.CreateObtainCondition(
                req, mfpJobId.HasValue ? ObtainCondition.SpecifiedNo : ObtainCondition.IndexList, mfpJobId));
            req.DocumentElement?.AppendChild(condition);

            // Request by Admin user
            return _service.RequestAsync(req, UserInfo.Admin);
        }

        /// <summary>
        /// GetJobList - AppReqGetJobStatus.
        /// </summary>
        /// <param name="mfpJobId">Mfp Job Id</param>
        /// <returns>Xml Document</returns>
        public Task<XmlDocument> GetJobStatusListAsync(ulong? mfpJobId)
        {
            var req = new XmlDocument();
            req.AppendChild(req.CreateElement("AppReqGetJobStatus"));
            var type = req.CreateElement("JobID");
            type.InnerText = mfpJobId.ToString();
            req.DocumentElement?.AppendChild(type);

            // Request by Admin user
            return _service.RequestAsync(req, UserInfo.Admin);
        }

        /// <summary>
        /// GetJobHistory.
        /// </summary>
        /// <returns>Xml Document</returns>
        public Task<XmlDocument> GetJobHistoryAsync()
        {
            var req = new XmlDocument();
            // get job history
            req.AppendChild(req.CreateElement("AppReqGetJobList"));
            var item = req.CreateElement("RequestItem");
            item.InnerText = "JobHistory";
            req.DocumentElement?.AppendChild(item);

            var condition = req.CreateElement("JobListCondition");
            var type = req.CreateElement("JobType");
            type.InnerText = "All";
            condition.AppendChild(type);

            condition.AppendChild(MessageCreator.CreateObtainCondition(req, ObtainCondition.IndexList, null));
            req.DocumentElement?.AppendChild(condition);

            // Request by Admin user
            return _service.RequestAsync(req, UserInfo.Admin);
        }

        /// <summary>
        /// RestartJob
        /// </summary>
        /// <param name="jobId">Job id</param>
        /// <param name="enhancedAuthParameterCode">Enhanced auth parameter code</param>
        /// <param name="jobDeleteFlg">Job delete flag</param>
        /// <returns>Xml document</returns>
        /// <para><paramref name="enhancedAuthParameterCode"/>In V1.0, this is unnecessary,</para>
        /// <para><paramref name="enhancedAuthParameterCode"/>There is a possibility to use it in v1.2 It is left behind.</para>
        public Task<XmlDocument> RestartJobAsync(string jobId, string enhancedAuthParameterCode = null, bool jobDeleteFlg = false)
        {
            var req = new XmlDocument();
            req.AppendChild(req.CreateElement("AppReqRestartJob"));
            req.DocumentElement?.AppendChild(MessageCreator.CreateJobId(req, jobId));
            var userInfo = enhancedAuthParameterCode != null
                ? UserInfo.Enhanced(enhancedAuthParameterCode)
                : UserInfo.Admin;

            return _service.RequestAsync(req, userInfo, true, true, jobDeleteFlg);
        }

        /// <summary>
        /// Set abbreviation address book.
        /// </summary>
        /// <param name="faxReceiveSetting">FaxReceiveSetting</param>
        public Task SetAbbreviationAddressbookAsync(FaxReceiveSetting faxReceiveSetting)
        {
            var req = new XmlDocument();
            req.AppendChild(req.CreateElement("AppReqSetAbbr"));
            req.DocumentElement?.AppendChild(MessageCreator.CreateCondition(req));
            req.DocumentElement?.AppendChild(MessageCreator.CreateAbbr(req, faxReceiveSetting));

            // Request by Admin user
            return _service.RequestAsync(req, UserInfo.Admin);
        }

        /// <summary>
        /// Set device permanent setting.
        /// </summary>
        /// <param name="faxReceiveSetting">FaxReceiveSetting</param>
        /// <exception cref="InvalidOperationException">Device is not locked</exception>
        public Task SetDevicePermanentSettingAsync(FaxReceiveSetting faxReceiveSetting)
        {
            if (!IsDeviceSeemedToBeLocked)
            {
                throw _exceptionDeviceIsNotLocked;
            }

            var req = new XmlDocument();
            req.AppendChild(req.CreateElement("AppReqSetDevicePermanentSetting"));

            if (req.DocumentElement != null)
            {
                req.DocumentElement.AppendChild(MessageCreator.CreateRequestItem(req));
                req.DocumentElement.AppendChild(req.CreateElement("LockKey")).InnerText = _currentDeviceLockInfo?.LockKey;
                req.DocumentElement?.AppendChild(MessageCreator.CreateFax(req, faxReceiveSetting));
            }

            // Request by Admin user
            return _service.RequestAsync(req, UserInfo.Admin);
        }

        /// <summary>
        /// Sets the device permanent setting security asynchronous.
        /// </summary>
        /// <param name="personalInfoProtect">The personal information protect.</param>
        /// <returns></returns>
        public Task<XmlDocument> SetDevicePermanentSettingSecurityAsync(PersonalInfoProtect personalInfoProtect)
        {
            if (!IsDeviceSeemedToBeLocked)
            {
                throw _exceptionDeviceIsNotLocked;
            }

            var req = new XmlDocument();
            req.AppendChild(req.CreateElement("AppReqSetDevicePermanentSetting"));

            if (req.DocumentElement != null)
            {
                req.DocumentElement.AppendChild(req.CreateElement("RequestItem"))
                    .InnerText= PermanentSettingsRequestItems.Security.ToString();
                req.DocumentElement.AppendChild(req.CreateElement("LockKey"))
                    .InnerText = _currentDeviceLockInfo?.LockKey;
                req.DocumentElement?.AppendChild(MessageCreator.CreateSecurity(req, personalInfoProtect));
            }

            return _service.RequestAsync(req, UserInfo.Admin);
        }

        /// <summary>
        /// Get device permanent settings
        /// </summary>
        /// <param name="requestItem">Request item</param>
        /// <returns>Xml document</returns>
        public Task<XmlDocument> GetDevicePermanentSettingsAsync(PermanentSettingsRequestItems requestItem)
        {
            var req = new XmlDocument();
            req.AppendChild(req.CreateElement("AppReqGetDevicePermanentSetting"));
            var item = req.CreateElement("RequestItem");
            item.InnerText = requestItem.ModelValue();
            req.DocumentElement?.AppendChild(item);

            return _service.RequestAsync(req, UserInfo.Admin);
        }

        /// <summary>
        /// Get device detail settings
        /// </summary>
        /// <param name="requestItem">Request item</param>
        /// <returns>Xml document</returns>
        public virtual Task<XmlDocument> GetDeviceInfoDetailAsync(DetailSettingsRequestItems requestItem)
        {
            var req = new XmlDocument();
            req.AppendChild(req.CreateElement("AppReqGetDeviceInfoDetail"));
            var item = req.CreateElement("RequestItem");
            item.InnerText = requestItem.ModelValue();
            req.DocumentElement?.AppendChild(item);

            return _service.RequestAsync(req, UserInfo.Admin);
        }

        /// <summary>
        /// Get device info
        /// </summary>
        /// <param name="requestItem">Get device info request items</param>
        /// <returns>Xml document</returns>
        public Task<XmlDocument> GetDeviceInfoAsync(GetDeviceInfoRequestItems requestItem)
        {
            var req = new XmlDocument();
            req.AppendChild(req.CreateElement("AppReqGetDeviceInfo"));
            var item = req.CreateElement("RequestItem");
            item.InnerText = requestItem.ModelValue();
            req.DocumentElement?.AppendChild(item);

            return _service.RequestAsync(req, UserInfo.Admin);
        }

        /// <summary>
        /// Get device enable function info2
        /// </summary>
        /// <param name="deviceSerialNumber">Device serial number</param>
        /// <returns>Xml document</returns>
        public Task<XmlDocument> GetDeviceEnableFunctionInfo2Async(string deviceSerialNumber)
        {
            var req = new XmlDocument();
            req.AppendChild(req.CreateElement("AppReqGetEnableFunctionInfo2"));
            var item = req.CreateElement("DeviceSerialNumber");
            item.InnerText = deviceSerialNumber;
            req.DocumentElement?.AppendChild(item);

            return _service.RequestAsync(req, UserInfo.Admin);
        }

        /// <summary>
        /// Change device screen.
        /// </summary>
        /// <param name="switchType">SwitchType</param>
        /// <param name="screenType">ScreenType</param>
        /// <param name="appNo">Application Number</param>
        /// <returns>Xml document</returns>
        public Task<XmlDocument> ChangeDeviceScreenAsync(SwitchType switchType, ScreenType? screenType, int? appNo)
        {
            var req = new XmlDocument();
            req.AppendChild(req.CreateElement("AppReqSHScreenChange"));
            XmlNode screenChangeNode = req.CreateElement("SHScreenChange");
            CreateChildElement(ref req, "SwitchType", switchType.ModelValue(), screenChangeNode);
            if (screenType.HasValue)
            {
                CreateChildElement(ref req, "ScreenType", screenType.ToString(), screenChangeNode);
            }
            else
            {
                CreateChildElement(ref req, "ScreenType", ScreenType.None.ToString(), screenChangeNode);
            }

            if (appNo.HasValue)
            {
                CreateChildElement(ref req, "AppNo", appNo.ToString(), screenChangeNode);
            }

            req.DocumentElement?.AppendChild(screenChangeNode);

            // Request by Admin user
            return _service.RequestAsync(req, UserInfo.Admin);
        }

        /// <summary>
        /// Set the installed mode to WPH installed mode.
        /// </summary>
        /// <returns>Success/Fail</returns>
        public Task<XmlDocument> SetInstalledAsync()
        {
            var req = new XmlDocument();
            req.AppendChild(req.CreateElement("AppReqSetSHInstalled"));
            var lockKeyNode = req.CreateElement("LockKey");
            lockKeyNode.InnerText = _currentDeviceLockInfo?.LockKey;
            req.DocumentElement?.AppendChild(lockKeyNode);

            return _service.RequestAsync(req, UserInfo.Admin);
        }

        /// <summary>
        /// Change power mode.
        /// </summary>
        /// <param name="powerMode">Power mode</param>
        /// <returns>Xml document</returns>
        public Task<XmlDocument> ChangePowerModeAsync(PowerMode powerMode)
        {
            var req = new XmlDocument();
            req.AppendChild(req.CreateElement("AppReqChangePowerMode"));
            if (req.DocumentElement != null)
            {
                CreateChildElement(ref req, "PowerModeRequest", powerMode != PowerMode.PowerModeRequestSubPowerOff
                    ? powerMode.ToString()
                    : PowerMode.PowerModeRequestSleep.ToString());
            }

            // Request by Admin user
            return _service.RequestAsync(req, UserInfo.Admin);
        }

        /// <summary>
        /// Get Device Power Status.
        /// </summary>
        /// <returns>Xml document</returns>
        public Task<XmlDocument> GetDevicePowerStatusAsync() => CreateAdminRequest("AppReqGetDeviceStatus2");

        /// <summary>
        /// Get printer encryption setting
        /// </summary>
        /// <returns>Xml document</returns>
        public Task<XmlDocument> GetPrinterEncryptionSettingAsync()
        {
            var req = new XmlDocument();
            req.AppendChild(req.CreateElement("AppReqGetPrinterEncryptionSettingForDriver"));
            req.AppendOperatorInfo(OperatorInfoUserType.Driver);

            // Request by Admin user
            return _service.RequestAsync(req, UserInfo.Admin);
        }

        /// <summary>
        /// Set event notification
        /// </summary>
        /// <param name="notifyIpAddress">Notify IP address</param>
        /// <param name="notifyPort">Notify port</param>
        /// <returns>Xml document</returns>
        public Task<XmlDocument> SetEventNotificationAsync(string notifyIpAddress, int notifyPort)
        {
            var req = new XmlDocument();
            req.AppendChild(req.CreateElement("AppReqSetEventNotification"));
            req.DocumentElement?.AppendChild(MessageCreator.CreateCommon(req, IPAddress.Parse(notifyIpAddress), notifyPort));
            req.DocumentElement?.AppendChild(MessageCreator.CreateDeviceStatus(req));
            req.DocumentElement?.AppendChild(MessageCreator.CreateJobStatus(req));
            req.DocumentElement?.AppendChild(MessageCreator.CreatePartsStatus(req));

            // Request by Admin user
            return _service.RequestAsync(req, UserInfo.Admin);
        }

        /// <summary>
        /// Set job trace
        /// </summary>
        /// <param name="driverJobId">Driver job id</param>
        /// <param name="jobId">Job id</param>
        /// <param name="notifyIpAddress">Notify IP address</param>
        /// <param name="notifyPort">Notify port</param>
        /// <returns>Xml document</returns>
        public Task<XmlDocument> SetJobTraceAsync(string driverJobId, string jobId, string notifyIpAddress, int notifyPort)
        {
            var req = new XmlDocument();
            var driverJobIdElm = req.CreateElement("DriverJobId");
            req.AppendChild(req.CreateElement("AppReqSetJobTrace"));
            req.DocumentElement?.AppendChild(driverJobIdElm);
            req.DocumentElement?.AppendChild(MessageCreator.CreateJobId(req, jobId));
            req.DocumentElement?.AppendChild(MessageCreator.CreateTime(req));
            req.DocumentElement?.AppendChild(MessageCreator.CreateHostInfo(req, IPAddress.Parse(notifyIpAddress), notifyPort));
            driverJobIdElm.InnerText = driverJobId;

            // Request by Admin user
            return _service.RequestAsync(req, UserInfo.Admin);
        }

        /// <summary>
        /// Notify Device Network Setting.
        /// </summary>
        /// <param name="addressType">Ip address type.</param>
        /// <param name="address">Ip address.</param>
        /// <param name="ipv6Type">Ip v6 type.</param>
        /// <returns>
        /// Xml document
        /// </returns>
        /// <exception cref="InvalidOperationException">Device is not locked</exception>
        public async Task<XmlDocument> NotifyDeviceNetworkSettingAsync(
            IpAddressType addressType,
            string address,
            Ipv6Type? ipv6Type)
        {
            var logPrefix = $"[{nameof(OpenApiController)}.{nameof(NotifyDeviceNetworkSettingAsync)}]";
            if (!IsDeviceSeemedToBeLocked)
            {
                _logger.LogError($"{logPrefix} Exception Device Is Not Locked.");
                throw _exceptionDeviceIsNotLocked;
            }

            var req = new XmlDocument();
            req.AppendChild(req.CreateElement("AppReqSetSHIPAddress"));
            if (req.DocumentElement != null)
            {
                CreateChildElement(ref req, "LockKey", _currentDeviceLockInfo?.LockKey);
                CreateChildElement(ref req, "SHAddressType", addressType.ToString());
                if (addressType == IpAddressType.IPv4)
                {
                    CreateChildElement(ref req, "IPv4Address", address);
                }
                else if (addressType == IpAddressType.IPv6)
                {
                    CreateChildElement(ref req, "IPv6Address", address);
                    CreateChildElement(ref req, "IPv6Type", ipv6Type?.ToString());
                }
            }

            try
            {
                var result = await _service.RequestAsync(req, UserInfo.Admin);

                return result;
            }
            catch (WebException e)
            {
                _logger.LogTrace(default(EventId), e.InnerException, $"{logPrefix} Web exception:");
                var response = new XmlDocument();
                response.AppendChild(response.CreateElement("AppResSetSHIPAddress"));
                CreateChildElement(ref response, "Result", "");
                CreateChildElement(ref response, "ResultInfo", "Nack",
                    response.DocumentElement?.SelectSingleNode("./Result"));
                CreateChildElement(ref response, "Status",
                    e.Status == WebExceptionStatus.Timeout
                        ? OpenApiNamesConst.StatusTimeout
                        : OpenApiNamesConst.StatusServerError);

                return response;
            }
        }

        /// <summary>
        /// Set device info detail with lock.
        /// </summary>
        /// <param name="info">Info</param>
        /// <returns>Xml document</returns>
        /// <exception cref="InvalidOperationException">Device is not locked</exception>
        [Obsolete("This is not being used, please use SetDeviceInfoDetailAdminAsync() instead.")]
        public Task<XmlDocument> SetDeviceInfoDetailAsync(DeviceInfoDetail info)
        {
            return SetDeviceInfoDetailAdminAsync(info);
        }

        /// <summary>
        /// Set device info detail with lock by Admin user.
        /// </summary>
        /// <param name="info">Info</param>
        /// <returns>
        /// Xml document
        /// </returns>
        /// <exception cref="InvalidOperationException">Device is not locked</exception>
        public Task<XmlDocument> SetDeviceInfoDetailAdminAsync(DeviceInfoDetail info)
        {
            if (!IsDeviceSeemedToBeLocked)
            {
                throw _exceptionDeviceIsNotLocked;
            }

            return _service.RequestAsync(info.CreateRequest(_currentDeviceLockInfo?.LockKey), UserInfo.Admin);
        }

        /// <summary>
        /// Let MFP begin download the firmware.
        /// </summary>
        /// <returns>Xml document</returns>
        public Task<XmlDocument> LetBeginDownloadFirmwareAsync() => CreateAdminRequest("AppReqFwDownload");

        /// <summary>
        /// Set tray information of MFP
        /// </summary>
        /// <param name="trayInfoList">Tray setting value</param>
        /// <returns>OpenApi return Xml value</returns>
        public Task<XmlDocument> SetTrayInfoSettingAsync(List<TrayInfo> trayInfoList)
        {
            var req = new XmlDocument();
            MessageCreator.CreateTrayInfoSettingRequest(req, trayInfoList);

            return _service.RequestAsync(req, UserInfo.Admin);
        }

        /// <summary>
        /// Get firmware download status
        /// </summary>
        /// <returns>Xml document</returns>
        public Task<XmlDocument> GetFirmwareDownloadStatusAsync() => CreateAdminRequest("AppReqGetFwDownloadStatus");

        /// <summary>
        /// Update firmware
        /// </summary>
        /// <returns>Xml document</returns>
        public Task<XmlDocument> UpdateFirmwareAsync() => CreateAdminRequest("AppReqFwUpdate");

        /// <summary>
        /// Request file data.
        /// </summary>
        /// <param name="requestItem">request item</param>
        /// <param name="file">file (Animation or MachineImage -> file path, TintBlock or Stamp -> "1"-"8")</param>
        /// <returns>OpenAPIResponse with file</returns>
        public async Task<OpenApiResponse> RequestFileDataAsync(AppRequestItemType requestItem, string file)
        {
            var req = new XmlDocument();
            var appReq = req.AppendChild(req.CreateElement("AppReqGetFileData"));
            var reqItem = appReq.AppendChild(req.CreateElement("RequestItem"));
            reqItem.InnerText = requestItem.ModelValue();

            XmlNode filePath;
            switch (requestItem)
            {
                case AppRequestItemType.ShAnimationData:
                    filePath = appReq.AppendChild(req.CreateElement("AnimationFilePath"));
                    break;
                case AppRequestItemType.ShMachineChart:
                    filePath = appReq.AppendChild(req.CreateElement("MachineChartPath"));
                    break;
                default:
                    filePath = appReq.AppendChild(req.CreateElement("DownloadFileID"));
                    break;
            }

            filePath.InnerText = file;

            return await _service.RequestFileAsync(req, UserInfo.Admin).ConfigureAwait(false);
        }

        /// <summary>
        /// Get animation file list.
        /// </summary>
        /// <returns>Xml document</returns>
        public async Task<XmlDocument> GetAnimationFileListAsync()
        {
            var req = new XmlDocument();
            req.AppendChild(req.CreateElement("AppReqGetAnimationFileList"));

            // Request by Admin user
            return await _service.RequestAsync(req, UserInfo.Admin, true, true, false, AnimationListWaitTime);
        }

        /// <summary>
        /// Request wake up
        /// </summary>
        /// <returns>Xml document</returns>
        public Task<XmlDocument> WakeupAsync() => CreateAdminRequest("AppReqWakeup");

        /// <summary>
        /// Execute mfp settings
        /// </summary>
        /// <param name="req">Xml document</param>
        /// <param name="isAdmin">Admin user?</param>
        /// <param name="isDeviceLock">Device lock?</param>
        /// <returns>Result</returns>
        public Task<XmlDocument> MfpSettingsAsync(XmlDocument req, bool isAdmin, bool isDeviceLock)
        {
            if (isAdmin && isDeviceLock)
            {
                req.DocumentElement.AppendChild(req.CreateElement("LockKey")).InnerText = _currentDeviceLockInfo?.LockKey;
            }

            return _service.RequestAsync(req, UserInfo.Admin);
        }

        /// <summary>
        /// Cancel Warning
        /// </summary>
        /// <param name="request">Warning Service Setting</param>
        /// <returns>Xml document</returns>
        public async Task<XmlDocument> CancelWarningAsync(WarningServiceSetting request)
        {
            var req = new XmlDocument();
            req.AppendChild(req.CreateElement("AppReqRemoveWarning"));
            if (req.DocumentElement != null)
            {
                CreateChildElement(ref req, "JobID", request.JobId?.ToString());
                CreateChildElement(ref req, "WarningName", request.Name);

                // In the future, probably introducing a Chain of responsibility pattern or similar could be good.
                var warnings = new List<IWarningMessage>();
                if (request.ApsAcceptable != null)
                {
                    warnings.Add(_warningMessageFactory.CreateWarning(WarningMessage.APSAcceptable));
                }

                if (request.PaperEmptyCaution != null)
                {
                    warnings.Add(_warningMessageFactory.CreateWarning(WarningMessage.PaperEmptyCaution));
                }

                if (request.PaperEmptyError != null)
                {
                    warnings.Add(_warningMessageFactory.CreateWarning( WarningMessage.PaperEmptyError));
                }

                if (request.TwoSidedIncompatible != null)
                {
                    warnings.Add(_warningMessageFactory.CreateWarning(WarningMessage.TwoSidedIncompatible));
                }

                if (request.ManuscriptSizeDetectError != null)
                {
                    warnings.Add(_warningMessageFactory.CreateWarning( WarningMessage.ManuscriptSizeDetectError));
                }

                if (request.PrintIncompatible != null)
                {
                    warnings.Add(_warningMessageFactory.CreateWarning(WarningMessage.PrintIncompatible));
                }

                if (request.AmsMagnificationIncompatible != null)
                {
                    warnings.Add(_warningMessageFactory.CreateWarning(WarningMessage.AMSMagnificationIncompatible));
                }

                if (request.StapleForm != null)
                {
                    warnings.Add(_warningMessageFactory.CreateWarning(WarningMessage.StapleForm));
                }

                if (request.StaplePaperMismatch != null)
                {
                    warnings.Add(_warningMessageFactory.CreateWarning(WarningMessage.StaplePaperMismatch));
                }

                if (request.PunchPaperIncompatibility != null)
                {
                    warnings.Add(_warningMessageFactory.CreateWarning(WarningMessage.PunchPaperIncompatibility));
                }

                if (request.StapleDirectionNotAcceptable != null)
                {
                    warnings.Add(_warningMessageFactory.CreateWarning(WarningMessage.StapleDirectionNotAcceptable));
                }

                if (request.PunchDirectionNotAcceptable != null)
                {
                    warnings.Add(_warningMessageFactory.CreateWarning(WarningMessage.PunchDirectionNotAcceptable));
                }

                if (request.ApsSizeMismatch != null)
                {
                    warnings.Add(_warningMessageFactory.CreateWarning(WarningMessage.APSSizeMismatch));
                }

                if (request.TonerEmptyStop != null)
                {
                    warnings.Add(_warningMessageFactory.CreateWarning(WarningMessage.TonerEmptyStop));
                }
                if (request.IuLife != null)
                {
                    warnings.Add(_warningMessageFactory.CreateWarning(WarningMessage.IuLife));
                }

                if (request.PunchFormStaple != null)
                {
                    warnings.Add(_warningMessageFactory.CreateWarning(WarningMessage.PunchFormStaple));
                }

                if (request.ExtDocumentSizeAssign != null)
                {
                    warnings.Add(_warningMessageFactory.CreateWarning(WarningMessage.ExtDocumentSizeAssign));
                }

                // Assemble all the warnings into the XML document
                foreach (var warningMessage in warnings)
                {
                    req.DocumentElement?.AppendChild(warningMessage.ToXml(req, request));
                }
            }

            // Request by Admin user
            return await _service.RequestAsync(req, UserInfo.Admin);
        }

        /// <summary>
        /// Next Warning.
        /// </summary>
        /// <returns>Xml document</returns>
        public Task<XmlDocument> NextWarningAsync() => CreateAdminRequest("AppReqNextWarning");

        /// <summary>
        /// Get device description.
        /// </summary>
        /// <returns>DeviceDescription</returns>
        public DeviceDescription GetDeviceDescription()
        {
            return _service.GetDeviceDescription();
        }

        /// <summary>
        /// Get total counter
        /// </summary>
        /// <returns>Xml document</returns>
        public async Task<XmlDocument> GetCounterInfoAsync(MfpCounterType counterType)
        {
            var req = new XmlDocument();
            req.AppendChild(req.CreateElement("AppReqGetCounterInfo"));
            var item = req.CreateElement("RequestItem");
            item.InnerText = counterType.ToString();
            req.DocumentElement?.AppendChild(item);
            _logger.LogInformation(req.OuterXml);

            return await _service.RequestAsync(req, UserInfo.Admin);
        }

        /// <summary>
        /// Removes the current authentication keys.
        /// </summary>
        public void RemoveCurrentAuthKeys()
        {
            _service.RemoveCurrentAuthKeys();
        }

        /// <summary>
        /// Dispose the current instance.
        /// </summary>
        /// <param name="disposing">Dispose</param>
        protected virtual void Dispose(bool disposing)
        {
            if (_disposedValue)
            {
                return;
            }

            if (disposing)
            {
                // Free managed resource (if exists).
            }

            _disposedValue = true;
        }

        /// <summary>
        /// Append child element
        /// </summary>
        /// <param name="document">Document</param>
        /// <param name="elementName">Element name</param>
        /// <param name="innerText">Element inner text</param>
        /// <param name="target">Target element. If omitted, use document.DocumentElement</param>
        private void CreateChildElement(ref XmlDocument document, string elementName, string innerText, XmlNode target = null)
        {
            var elm = document.CreateElement(elementName);
            elm.InnerText = innerText;
            (target ?? document.DocumentElement)?.AppendChild(elm);
        }

        private Task<XmlDocument> CreateAdminRequest(string topElement)
        {
            var req = new XmlDocument();
            req.AppendChild(req.CreateElement(topElement));

            return _service.RequestAsync(req, UserInfo.Admin);
        }
    }
}
