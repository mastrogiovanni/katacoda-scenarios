﻿using System;
using Newtonsoft.Json;
using ServiceHub.Common.DeviceState;
using ServiceHub.Common.Model.DeviceInfo.NotifyToSh;
using ServiceHub.Common.Settings;
using ServiceHub.Common.Settings.PushNotification;
using ServiceHub.Connectors.MfpService;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using ServiceHub.Client.TokenProvider.Interfaces;

namespace ServiceHub.Connectors.OpenAPI.DeviceState
{
    /// <summary>
    /// MFP device state (Password error).
    /// </summary>
    public class PasswordErrorState : IDeviceState<PasswordErrorState>
    {
        private readonly IMfpService _mfpService;
        private readonly IDeviceStateContext _stateCotext;
        private readonly ILogger<PasswordErrorState> _logger;
        private readonly ITokenService _tokenService;
        private readonly MfpConnectorSetting _connctorSettings;

        private bool _hasQueuedTask;

        /// <summary>
        /// Initializes a new instance of sub class.
        /// </summary>
        /// <param name="logger">Logger</param>
        /// <param name="mfpService">MFP Service connector</param>
        /// <param name="stateContext">Device state context</param>
        /// <param name="tokenService">Token service</param>
        /// <param name="connectorSetting">MFP Connector setting</param>
        public PasswordErrorState(
            ILogger<PasswordErrorState> logger,
            IMfpService mfpService,
            IDeviceStateContext stateContext,
            ITokenService tokenService,
            MfpConnectorSetting connectorSetting)
        {
            _logger = logger;
            _mfpService = mfpService;
            _stateCotext = stateContext;
            _tokenService = tokenService;
            _connctorSettings = connectorSetting;
        }

        /// <summary>
        /// State of environment for connect MFP.
        /// </summary>
        public bool Environment => false;

        /// <summary>
        /// State of MFP's usable.
        /// </summary>
        public bool Usable => false;

        /// <summary>
        /// Event handler for change state.
        /// </summary>
        /// <param name="previousState">Previous state</param>
        public void OnChangeState(IDeviceState previousState)
        {
            if (_hasQueuedTask)
            {
                return;
            }
            _hasQueuedTask = true;
            _stateCotext.QueueTask(GetType().Name, async () =>
            {
                try
                {
                    var token = await _tokenService.CreateTokenAsync().ConfigureAwait(false);
                    // call mfp service
                    var headers = new Dictionary<string, string> { { "Authorization", token.AccessToken } };
                    // notify event
                    var content = new StringContent(JsonConvert.SerializeObject(new EventState("IllegalAdminPassword")), Encoding.UTF8, "application/json");
                    var response = await _mfpService.PostAsync(_connctorSettings.PushNotification[PushNotificationType.MfpService].CurrentSetting.SendDeviceEventPath, content, headers);
                    response.EnsureSuccessStatusCode();
                    _hasQueuedTask = false;
                }
                catch (Exception ex)
                {
                    _logger.LogError(default(EventId), ex, $"{GetType().Name}.ChangeState : Send failed.");
                    throw;
                }
            }, () => Task.Delay(TimeSpan.FromSeconds(OpenApiConstants.RetryIntervalSeconds)));
        }
    }
}
