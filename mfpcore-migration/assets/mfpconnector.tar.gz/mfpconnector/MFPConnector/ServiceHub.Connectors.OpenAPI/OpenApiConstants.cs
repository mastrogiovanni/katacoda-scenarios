﻿namespace ServiceHub.Connectors.OpenAPI
{
    internal static class OpenApiConstants
    {
        public const int RetryIntervalSeconds  = 5;
    }
}