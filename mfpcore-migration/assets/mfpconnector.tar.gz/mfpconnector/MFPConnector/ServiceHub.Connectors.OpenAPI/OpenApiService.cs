using KonicaMinolta.OpenApi;
using KonicaMinolta.OpenApi.DeviceDescriptions;
using Microsoft.Extensions.Logging;
using ServiceHub.Common.DeviceState;
using ServiceHub.Common.Settings;
using ServiceHub.Connectors.OpenAPI.DeviceState;
using ServiceHub.Connectors.OpenAPI.Exceptions;
using ServiceHub.Connectors.OpenAPI.Model;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using System.Xml;
using OpenApiNackException = KonicaMinolta.OpenApi.OpenApiNackException;

namespace ServiceHub.Connectors.OpenAPI
{
    /// <summary>
    /// Open API service
    /// </summary>
    public class OpenApiService : IOpenApiService, IDisposable
    {
        private const int OpenApiTimeoutAnimationList = 360_000;
        private const int OpenApiTimeoutOther = 120_000;

        private static readonly string[] ApiSystems = {
            "AppReqWakeup",
            "AppReqGetAnimationFileList",
            "AppReqGetDeviceInfoDetail",
            "AppReqSetJobTrace" };

        /// <summary>
        /// This semaphore represents a resource that must be synchronized
        /// so that only one thread at a time can enter.
        /// </summary>
        private static readonly SemaphoreSlim SemaphoreSystem = new SemaphoreSlim(1, 1);
        private static readonly SemaphoreSlim SemaphoreUser = new SemaphoreSlim(1, 1);

        private readonly IDeviceStateContext _deviceStateContext;
        private readonly OpenApiRequestSettings _openApiRequestSettings;
        private readonly Dictionary<UserInfo, UserAuthKeyInfo> _currentAuthKeys;
        private readonly IDeviceState<PasswordErrorState> _passwordErrorState;
        private readonly ILogger<OpenApiService> _logger;

        /// <summary>
        /// OpenApiRequest
        /// </summary>
        /// <remarks>
        /// TODO: If memory-leak problem is fixed, OpenApiRequest instance will be created every time the request occurs.
        /// </remarks>
        private readonly OpenApiRequest _openApiRequest;

        private int? _applicationId;

        /// <summary>
        /// Initializes a new instance of the <see cref="OpenApiService"/> class.
        /// </summary>
        /// <param name="logger">Logger</param>
        /// <param name="openApiRequestOpenApiRequestSettings">OpenAPI request settings</param>
        /// <param name="passwordErrorState">Password error state</param>
        /// <param name="deviceStateContext">Context of MFP device state</param>
        public OpenApiService(
            ILogger<OpenApiService> logger,
            OpenApiRequestSettings openApiRequestOpenApiRequestSettings,
            IDeviceState<PasswordErrorState> passwordErrorState,
            IDeviceStateContext deviceStateContext)
        {
            _logger = logger;
            _openApiRequestSettings = openApiRequestOpenApiRequestSettings;
            _deviceStateContext = deviceStateContext;
            _passwordErrorState = passwordErrorState;

            _currentAuthKeys = new Dictionary<UserInfo, UserAuthKeyInfo>();
            _applicationId = null;
            _openApiRequest = new OpenApiRequest(
                _openApiRequestSettings.MfpConnectorSetting.OpenApi.Devices.CurrentSetting.DeviceIp,
                _openApiRequestSettings.MfpConnectorSetting.OpenApi.Devices.CurrentSetting.DevicePort,
                _openApiRequestSettings.MfpConnectorSetting.OpenApi.Devices.CurrentSetting.UseSsl,
                string.Empty,
                string.Empty,
                GetExVersion())
            {
                WebProxy = null,
                RequestTimeout = _openApiRequestSettings.MfpConnectorSetting.OpenApi.Devices.CurrentSetting.Timeout
            };
        }


        /// <summary>
        /// Confirm connect
        /// </summary>
        /// <param name="timeout">Request time out</param>
        /// <returns>
        /// Confirm result
        /// </returns>
        public async Task<bool> ConfirmConnectAsync(int? timeout = null)
        {
            var result = false;

            await SemaphoreSystem.WaitAsync().ConfigureAwait(false);
            try
            {
                var req = new XmlDocument();
                req.AppendChild(req.CreateElement("AppReqConfirmConnect"));

                var response = await RequestToOpenApiAsync(req, 0).ConfigureAwait(false);
                if (response.TryGetXmlNode("./Result/ResultInfo", out var resultInfoNode))
                {
                    _logger.LogDebug($"[OpenApiService.ConfirmConnect] Result/ResultInfo: {resultInfoNode.InnerText}");
                    result = resultInfoNode.InnerText == "Ack";
                }
                else
                {
                    _logger.LogWarning("[OpenApiService.ConfirmConnect] Fault.");
                }
            }
            catch (Exception e)
            {
                _logger.LogTrace(default(EventId), e, $"[OpenApiService.ConfirmConnect] Returning default, failed with an error: {e}");
                result = false;
            }
            finally
            {
                SemaphoreSystem.Release();
            }

            return result;
        }

        /// <summary>
        /// Confirm admin login.
        /// </summary>
        /// <param name="password">Admin password</param>
        /// <returns>Confirm result</returns>
        public async Task<bool> ConfirmAdminLoginAsync(string password)
        {
            var result = false;

            var logPrefix = $"[{nameof(OpenApiService)}.{nameof(ConfirmAdminLoginAsync)}]";
            _logger.LogInformation($"{logPrefix} Started.");

            await SemaphoreSystem.WaitAsync().ConfigureAwait(false);
            try
            {
                var reqLogin = new XmlDocument();
                reqLogin.AppendChild(reqLogin.CreateElement("AppReqLogin"));
                reqLogin.AppendOperatorInfo(OperatorInfoUserType.Admin, password: password);
                reqLogin.AppendRequestSource();

                var response = await RequestToOpenApiAsync(reqLogin, 0).ConfigureAwait(false);
                if (response.TryGetXmlNode("./AuthKey", out var authKeyNode))
                {
                    result = true;
                    var authKey = authKeyNode.InnerText;

                    await LogoutAsync(authKey).ConfigureAwait(false);
                }
                else
                {
                    _logger.LogWarning("[OpenApiService.Login] failed: AuthKey not found.");
                }
            }
            catch (OpenApiFaultException ex)
            {
                if (ex.FaultMessage.ErrorDetails == "AuthIllegalPassword")
                {
                    _logger.LogWarning(default(EventId), ex, "[OpenApiService.Login] failed: Illegal password");
                }
                else
                {
                    throw;
                }
            }
            finally
            {
                SemaphoreSystem.Release();
            }

            _logger.LogInformation($"{logPrefix} Finished.");

            return result;
        }

        /// <summary>
        /// Request
        /// </summary>
        /// <param name="req">Xml</param>
        /// <param name="userInfo">User info</param>
        /// <param name="requireApplicationId">Add application ID to message</param>
        /// <param name="addOperatorInfoByAuthKey">Add operator info by holding AuthKey</param>
        /// <param name="jobDeleteFlg">Job delete flag</param>
        /// <param name="timeout">Request time out</param>
        /// <returns>Xml document</returns>
        public virtual async Task<XmlDocument> RequestAsync(
            XmlDocument req,
            UserInfo userInfo,
            bool requireApplicationId = true,
            bool addOperatorInfoByAuthKey = true,
            bool jobDeleteFlg = false,
            int? timeout = null)
        {
            var file = await RequestFileAsync(
                req,
                userInfo,
                null,
                requireApplicationId,
                addOperatorInfoByAuthKey,
                jobDeleteFlg,
                timeout).ConfigureAwait(false);

            return file.Message;
        }

        /// <summary>
        /// Request
        /// </summary>
        /// <param name="req">Xml</param>
        /// <param name="userInfo">User info</param>
        /// <param name="stream">Stream</param>
        /// <param name="requireApplicationId">Add application ID to message</param>
        /// <param name="addOperatorInfoByAuthKey">Add operator info by holding AuthKey</param>
        /// <param name="jobDeleteFlg">Job delete flag</param>
        /// <param name="timeout">Request time out</param>
        /// <returns>
        /// Xml document
        /// </returns>
        /// <exception cref="OpenApiRequestException">
        /// </exception>
        /// <remarks>
        /// This method can't be async since it's using a synchronization with mutex
        /// </remarks>
        public virtual async Task<OpenApiResponse> RequestFileAsync(
            XmlDocument req,
            UserInfo userInfo,
            Stream stream = null,
            bool requireApplicationId = true,
            bool addOperatorInfoByAuthKey = true,
            bool jobDeleteFlg = false,
            int? timeout = null)
        {
            OpenApiMessage rawResponse = null;
            var currentSemaphore = ApiSystems.FirstOrDefault(
                                    api => req.OuterXml.IndexOf(api, StringComparison.OrdinalIgnoreCase) >= 0) != null
                                        ? SemaphoreSystem
                                        : SemaphoreUser;

            var requireReconnect = false;
            do
            {
                await currentSemaphore.WaitAsync().ConfigureAwait(false);

                try
                {
                    if (!_deviceStateContext.Usable)
                    {
                        throw new OpenApiRequestException(OpenApiResultStatus.ConnectError);
                    }

                    if (!_deviceStateContext.Environment)
                    {
                        throw new OpenApiRequestException(OpenApiResultStatus.OtherError);
                    }

                    string authKey;
                    var hasAuthKey = _currentAuthKeys.TryGetValue(userInfo, out var authKeyInfo);

                    if (!hasAuthKey)
                    {
                        authKey = await LoginAsync(userInfo, jobDeleteFlg).ConfigureAwait(false);
                        if (string.IsNullOrEmpty(authKey))
                        {
                            throw new OpenApiRequestException(OpenApiResultStatus.LoginError);
                        }
                    }
                    else
                    {
                        authKey = authKeyInfo.AuthKey;
                    }
                    
                    if (!_applicationId.HasValue && requireApplicationId)
                    {
                        await InitConnectAsync(authKey).ConfigureAwait(false);
                    }

                    if (addOperatorInfoByAuthKey)
                    {
                        req.AppendOperatorInfo(authKey);
                    }

                    if (_openApiRequestSettings.MfpConnectorSetting.OpenApi.Devices.CurrentSetting.BackUp)
                    {
                        req.AppendBackUpPassword(_openApiRequestSettings.MfpConnectorSetting.OpenApi.Devices
                            .CurrentSetting
                            .BackUpPassword);
                    }

                    rawResponse = await RequestToOpenApiAsync(req, _applicationId, stream, timeout)
                        .ConfigureAwait(false);

                    // if no response check was performed, check here
                    requireReconnect = !requireReconnect && RequiredReconnect(rawResponse, userInfo);

                    // If OpenAPI is change power and erp mode then logout
                    await ErpLogoutAsync(rawResponse).ConfigureAwait(false);
                }
                catch (OpenApiFaultException e)
                {
                    if (requireReconnect || !RequiredReconnect(e.FaultMessage, userInfo))
                    {
                        throw;
                    }
                }
                finally
                {
                    currentSemaphore.Release();
                }

                if (requireReconnect)
                {
                    // Sleep a bit to give opportunity to other threads.
                    await Task.Delay(10).ConfigureAwait(false);
                }
            } while (requireReconnect);

            return new OpenApiResponse(rawResponse);
        }

        /// <summary>
        /// Report disconnect message
        /// </summary>
        public void ReportDisconnect()
        {
            _applicationId = null;
        }

        /// <summary>
        /// Get current user info
        /// </summary>
        /// <returns>Returns the current auth keys</returns>
        public Dictionary<UserInfo, UserAuthKeyInfo> GetCurrentUserInfo() => _currentAuthKeys;

        /// <summary>
        /// Get Device Description. 
        /// </summary>
        /// <returns>DeviceDescription</returns>
        public DeviceDescription GetDeviceDescription()
        {
            var address = _openApiRequestSettings.MfpConnectorSetting.OpenApi.Devices.CurrentSetting.DeviceIp;

            return new DeviceDescriptionRequest().GetDeviceDescription(address);
        }

        /// <summary>
        /// Removes the current authentication keys.
        /// </summary>
        public void RemoveCurrentAuthKeys()
        {
            _currentAuthKeys.Clear();
        }

        /// <summary>
        /// Releases unmanaged and - optionally - managed resources.
        /// </summary>
        /// <remarks>Will release the OpenApiRequest</remarks>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Releases unmanaged and - optionally - managed resources.
        /// </summary>
        /// <param name="disposing"><c>true</c> to release both managed and unmanaged resources;
        /// <c>false</c> to release only unmanaged resources.</param>
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                _openApiRequest?.Dispose();
            }
        }

        private Version GetExVersion()
        {
            return new Version(
                _openApiRequestSettings.MfpConnectorSetting.OpenApi.Version.Major,
                _openApiRequestSettings.MfpConnectorSetting.OpenApi.Version.Minor);
        }

        private bool RequiredReconnect<TMessage>(TMessage res, UserInfo userInfo) where TMessage : ISoapMessage
        {
            if (res is OpenApiMessage || !(res is FaultMessage))
            {
                return false;
            }

            var errorDetails = (res as FaultMessage).ErrorDetails;
            switch (errorDetails)
            {
                case "AuthNotFoundAuthKey":
                    _currentAuthKeys.Remove(userInfo);
                    return true;
                case "OpenApiIllegalApplicationID":
                    _applicationId = null;
                    return true;
                default:
                    return false;
            }
        }

        private async Task<OpenApiMessage> RequestToOpenApiAsync(
            XmlDocument requestBody,
            int? applicationId,
            Stream stream = null,
            int? timeout = null)
        {
            var logPrefix = $"[{nameof(OpenApiService)}.{nameof(RequestToOpenApiAsync)}]";

            try
            {
                var message = new OpenApiMessage(requestBody.OuterXml);
                _logger.LogInformation($"{logPrefix} Started.  MessageName: {message.Name}");

                var watch = Stopwatch.StartNew();
                var request = GetOpenApiRequest(applicationId, timeout);

                if (stream != null)
                {
                    message.Attachment = new OpenApiAttachment(stream);
                }

                var task = request.SendAsync(message);

                OpenApiMessage response;
                var maxTimeout = OpenApiTimeout(requestBody);
                if (await Task.WhenAny(Task.Delay(maxTimeout), task) == task)
                {
                    response = await task;
                }
                else
                {
                    _logger.LogWarning("[OpenApiService] failed. : Request Timeout " + message.Name);
                    throw new TimeoutException($"{logPrefix} Timeout exception " + message.Name);
                }

                watch.Stop();
                _logger.LogInformation(
                    $"{logPrefix} Finished. MessageName: {message.Name}, Time: {watch.ElapsedMilliseconds}ms");

                if (response.HasNackResponse)
                {
                    _logger.LogError(
                        $"{logPrefix} Nack.    MessageName: {message.Name}, Response: {response.NackResponse}");
                    throw new OpenApiNackException($"{logPrefix} Nack", message, response);
                }

                return response;
            }
            catch (OpenApiFaultException e)
            {
                _logger.LogTrace(default(EventId), e,
                    $"{logPrefix} Fault. The fault is propagated as OpenApiFaultException on higher level \n" +
                    $"\tFaultCode: {e.FaultMessage.FaultCode}, \n" +
                    $"\tFaultString: {e.FaultMessage.FaultString}, \n" +
                    $"\tFaultRequest: {e.FaultMessage.FaultRequest}, \n" +
                    $"\tErrorDetails: {e.FaultMessage.ErrorDetails}, \n" +
                    $"\tTroubleCode: {e.FaultMessage.TroubleCode}, \n" +
                    $"\tErrorDescription: {e.FaultMessage.ErrorDescription}:{e.Message}\n\n" +
                    $"\tApplicationId: {applicationId}");

                throw;
            }
            catch (OpenApiNackException e)
            {
                throw new Exceptions.OpenApiNackException(e.NackResponse);
            }
            catch (AggregateException e)
            {
                _logger.LogError(default(EventId), e, $"{logPrefix} Aggregated exception: {e.Message}");
                throw;
            }
            catch (TimeoutException e)
            {
                _logger.LogError(default(EventId), e, $"{logPrefix} Timeout exception: {e.Message}");
                throw;
            }
            catch (HttpRequestException e)
            {
                var message = $"{logPrefix} OpenApi request exception: {e.Message}";

                if (e.InnerException != null)
                {
                    message += $"\n\nInner Exception: {e.InnerException.Message}";
                }

                _logger.LogError(default(EventId), e, message);
                throw;
            }
            catch (Exception e)
            {
                _logger.LogError(default(EventId), e, $"{logPrefix} Unexpected exception: {e.Message}");
                throw;
            }
        }

        private async Task<string> LoginAsync(UserInfo userInfo, bool jobDeleteFlg = false)
        {
            var req = new XmlDocument();
            req.AppendChild(req.CreateElement("AppReqLogin"));

            if (userInfo.UserType == OperatorInfoUserType.Admin)
            {
                req.AppendOperatorInfo(OperatorInfoUserType.Admin,
                    password: _openApiRequestSettings.MfpConnectorSetting.OpenApi.Devices.CurrentSetting.Password);
            }
            else if (userInfo.UserType == OperatorInfoUserType.Public)
            {
                req.AppendOperatorInfo(OperatorInfoUserType.Public);
            }
            else if (_openApiRequestSettings.MfpConnectorSetting.OpenApi.Devices.CurrentSetting.EnhancedServerAuth.Use)
            {
                req.AppendCustomSetting(
                    _openApiRequestSettings.MfpConnectorSetting.OpenApi.Devices.CurrentSetting.EnhancedServerAuth.CustomSetting,
                    new Dictionary<EnhancedServerAuthValueType, string>
                    {
                        {EnhancedServerAuthValueType.AuthParameterCode, userInfo.EnhancedAuthParameterCode}
                    },
                    jobDeleteFlg);
            }
            else
            {
                req.AppendOperatorInfo(OperatorInfoUserType.User, userInfo.UserName, userInfo.UserPassword);
            }

            req.AppendRequestSource();

            var authKey = string.Empty;
            try
            {
                var response = await RequestToOpenApiAsync(req, 0);
                if (response.TryGetXmlNode("./AuthKey", out var authKeyNode))
                {
                    authKey = authKeyNode.InnerText;
                    if (!_currentAuthKeys.ContainsKey(userInfo))
                    {
                        _currentAuthKeys.Add(userInfo, new UserAuthKeyInfo(authKey));
                    }
                    else
                    {
                        _logger.LogInformation(
                            $"[OpenApiService.Login] Already in the authkeys cache.");
                    }
                }
                else
                {
                    _logger.LogWarning("[OpenApiService.Login] failed: AuthKey not found.");
                }
            }
            catch (OpenApiFaultException ex)
            {
                _logger.LogError(default(EventId), ex, "[OpenApiService.Login] fault.");
                if (ex.FaultMessage.ErrorDetails == "AuthIllegalPassword" &&
                    userInfo.UserType == OperatorInfoUserType.Admin)
                {
                    _logger.LogInformation("Change state PasswordErrorState");
                    _deviceStateContext.ChangeState(_passwordErrorState);
                }

                throw;
            }

            return authKey;
        }

        private async Task LogoutAsync(string authKey)
        {
            var reqLogout = new XmlDocument();
            reqLogout.AppendChild(reqLogout.CreateElement("AppReqLogout"));
            reqLogout.AppendOperatorInfo(authKey);

            try
            {
                await RequestToOpenApiAsync(reqLogout, 0);
            }
            catch (Exception ex)
            {
                // continuable
                _logger.LogWarning(default(EventId), ex, $"[OpenApiService.Logout] Exception happened, but we continue. Details: {ex}");
            }
        }

        private async Task InitConnectAsync(string authKey)
        {
            var req = new XmlDocument();
            req.AppendChild(req.CreateElement("AppReqInitConnect"));
            req.AppendOperatorInfo(authKey);
            req.DocumentElement?.AppendChild(MessageCreator.CreateApplicationInfo(req));
            req.DocumentElement?.AppendChild(MessageCreator.CreateCommon(req,
                IPAddress.Parse(_openApiRequestSettings.MfpConnectorSetting.OpenApi.Devices.CurrentSetting.NotifyIp),
                _openApiRequestSettings.MfpConnectorSetting.OpenApi.Devices.CurrentSetting.NotifyPort));
            var shConnection = req.CreateElement("ServiceHubConnection");
            shConnection.InnerText = "true";
            req.DocumentElement?.AppendChild(shConnection);

            var response = await RequestToOpenApiAsync(req, 0);
            if (response.TryGetXmlNode("./ApplicationID", out var applicationIdNode))
            {
                var isNumber = int.TryParse(applicationIdNode.InnerText, out var applicationId);
                _applicationId = isNumber ? applicationId : default(int?);
            }
            else
            {
                _logger.LogWarning("[OpenApiService.InitConnect] failed: ApplicationID not found.");
            }
        }

        private OpenApiRequest GetOpenApiRequest(int? applicationId, int? timeout = null)
        {
            _openApiRequest.OpenApiApplicationId = applicationId.GetValueOrDefault(0);
            var defaultTimeout = _openApiRequestSettings.MfpConnectorSetting.OpenApi.Devices.CurrentSetting.Timeout;
            _openApiRequest.RequestTimeout = timeout ?? defaultTimeout;

            return _openApiRequest;
        }

        private int OpenApiTimeout(XmlDocument request)
        {
            var nodes = request.GetElementsByTagName("AppReqGetAnimationFileList");

            return nodes.Count > 0 ? OpenApiTimeoutAnimationList : OpenApiTimeoutOther;
        }

        private async Task ErpLogoutAsync(ISoapMessage response)
        {
            var xml = new XmlDocument();
            xml.LoadXml(response.Text);
            var nodeList = xml.GetElementsByTagName("AppResChangePowerMode");
            if (nodeList.Count == 0 || nodeList[0].InnerText != "Ack")
            {
                return;
            }

            var keys = new List<UserInfo>();
            foreach (var userInfo in _currentAuthKeys)
            {
                var reqLogout = new XmlDocument();
                reqLogout.AppendChild(reqLogout.CreateElement("AppReqLogout"));
                reqLogout.AppendOperatorInfo(userInfo.Value.AuthKey);
                reqLogout.AppendRequestSource();
                var resLogout = await RequestToOpenApiAsync(reqLogout, 0);
                if (resLogout.TryGetXmlNode("./Result/ResultInfo", out var resultInfoNode) && resultInfoNode.InnerText == "Ack")
                {
                    keys.Add(userInfo.Key);
                }
            }

            _currentAuthKeys.RemoveAll(keys);
        }
    }
}
