using ServiceHub.Common.Settings.Fax;
using ServiceHub.Connectors.OpenAPI.Model;
using ServiceHub.Connectors.OpenAPI.Model.PermanentSettings.Security;
using System;
using System.Collections.Generic;
using System.Net;
using System.Xml;

namespace ServiceHub.Connectors.OpenAPI
{
    /// <summary>
    /// Notify xml.
    /// </summary>
    public static class MessageCreator
    {
        private const string Auto = "Auto";
        private const string PaperSize = "PaperSize";
        private const string SizeCode = "SizeCode";
        private const string FeedDirection = "FeedDirection";
        private const string Dimension2 = "Dimension2";
        private const string X = "X";
        private const string Y = "Y";
        private const string IndexListStart = "1";
        private const string IndexListEnd = "100";
        private const int ReceiveNotificationTime = 1440;

        /// <summary>
        /// Create ext-auth authorized operator info.
        /// </summary>
        /// <param name="doc">Xml document</param>
        /// <param name="authKeyCode">Authentication key code</param>
        /// <returns>Element</returns>
        public static XmlElement CreateOperatorInfoExtAuth(XmlDocument doc, string authKeyCode)
        {
            var result = doc.CreateElement("OperatorInfo");
            result.AppendChild(doc.CreateElement("AuthKey")).InnerText = authKeyCode;

            return result;
        }

        /// <summary>
        /// Create obtain condition.
        /// </summary>
        /// <param name="doc">Xml document</param>
        /// <param name="type">Obtain type</param>
        /// <param name="mfpJobId">Mfp Job Id</param>
        /// <returns>Element</returns>
        public static XmlElement CreateObtainCondition(XmlDocument doc, ObtainCondition type, ulong? mfpJobId)
        {
            var result = doc.CreateElement("ObtainCondition");
            var obtainType = doc.CreateElement("Type");
            obtainType.InnerText = type.ToString();
            result.AppendChild(obtainType);

            if (type == ObtainCondition.IndexList)
            {
                var structure = doc.CreateElement("IndexRange");
                var start = doc.CreateElement("Start");
                start.InnerText = IndexListStart;
                structure.AppendChild(start);
                var end = doc.CreateElement("End");
                end.InnerText = IndexListEnd;
                structure.AppendChild(end);
                result.AppendChild(structure);
            }
            else if (mfpJobId.HasValue)
            {
                var no = doc.CreateElement("SpecifiedNo");
                no.InnerText = mfpJobId.Value.ToString();
                result.AppendChild(no);
            }

            return result;
        }

        /// <summary>
        /// Create common.
        /// </summary>
        /// <param name="doc">Xml document</param>
        /// <param name="localIp">Ip Address</param>
        /// <param name="port">Port</param>
        /// <returns>Element</returns>
        public static XmlElement CreateCommon(XmlDocument doc, IPAddress localIp, int port)
        {
            var result = CreateXmlElement("Common", doc,  localIp, port);
            var time = CreateTime(doc, ReceiveNotificationTime);
            result.AppendChild(time);
            return result;
        }

        /// <summary>
        /// Create host info.
        /// </summary>
        /// <param name="doc">Xml document</param>
        /// <param name="localIp">Ip Address</param>
        /// <param name="port">Port</param>
        /// <returns>Element</returns>
        public static XmlElement CreateHostInfo(XmlDocument doc, IPAddress localIp, int port)
        {
            return CreateXmlElement("HostInfo",doc,localIp, port);
        }

        /// <summary>
        /// Create device status.
        /// </summary>
        /// <param name="doc">Xml document</param>
        /// <returns>Element</returns>
        public static XmlElement CreateDeviceStatus(XmlDocument doc)
        {
            var result = doc.CreateElement("DeviceStatus");
            result.AppendChild(doc.CreateElement("Type")).InnerText = "DetailStatus";
            return result;
        }

        /// <summary>
        /// Create parts status.
        /// </summary>
        /// <param name="doc">Xml document</param>
        /// <returns>Element</returns>
        public static XmlElement CreatePartsStatus(XmlDocument doc)
        {
            var result = doc.CreateElement("PartsStatus");
            result.AppendChild(doc.CreateElement("FeedTray")).InnerText = "true";
            result.AppendChild(doc.CreateElement("OutputTray")).InnerText = "true";
            result.AppendChild(doc.CreateElement("KeyDevice")).InnerText = "true";
            result.AppendChild(doc.CreateElement("Adf")).InnerText = "true";
            result.AppendChild(doc.CreateElement("Platen")).InnerText = "true";
            return result;
        }

        /// <summary>
        /// Create parts status.
        /// </summary>
        /// <param name="doc">Xml document</param>
        /// <returns>Element</returns>
        public static XmlElement CreateJobStatus(XmlDocument doc)
        {
            var result = doc.CreateElement("JobStatus");
            result.AppendChild(doc.CreateElement("Type")).InnerText = "DetailStatus";
            return result;
        }

        /// <summary>
        /// Create application info.
        /// </summary>
        /// <param name="doc">Xml document</param>
        /// <returns>Element</returns>
        public static XmlElement CreateApplicationInfo(XmlDocument doc)
        {
            var result = doc.CreateElement("ApplicationInfo");
            result.AppendChild(doc.CreateElement("ApplicationName"));
            return result;
        }

        /// <summary>
        /// Create time.
        /// </summary>
        /// <param name="doc">Xml document</param>
        /// <param name="time">Time</param>
        /// <returns>Element</returns>
        public static XmlElement CreateTime(XmlDocument doc, int time = 60)
        {
            var result = doc.CreateElement("Time");
            result.InnerText = time.ToString();
            return result;
        }

        /// <summary>
        /// Create job id.
        /// </summary>
        /// <param name="doc">Xml document</param>
        /// <param name="jobId">Job id</param>
        /// <returns>Element</returns>
        public static XmlElement CreateJobId(XmlDocument doc, string jobId)
        {
            var result = doc.CreateElement("JobID");
            result.InnerText = jobId;
            return result;
        }

        /// <summary>
        /// Create condition.
        /// </summary>
        /// <param name="doc">Xml document</param>
        /// <returns>Element</returns>
        public static XmlElement CreateCondition(XmlDocument doc)
        {
            var result = doc.CreateElement("CreateCondition");
            result.AppendChild(doc.CreateElement(Auto)).InnerText = "false";
            result.AppendChild(doc.CreateElement("OverWrite")).InnerText = "true";
            return result;
        }

        /// <summary>
        /// Create abbreviation address.
        /// </summary>
        /// <param name="doc">Xml document</param>
        /// <param name="faxReceiveSetting">Fax Receive Setting</param>
        /// <returns>Element</returns>
        public static XmlElement CreateAbbr(XmlDocument doc, FaxReceiveSetting faxReceiveSetting)
        {
            var result = doc.CreateElement("Abbr");
            var sendConfiguration = doc.CreateElement("SendConfiguration");
            var addressInfo = doc.CreateElement("AddressInfo");
            var webDavMode = doc.CreateElement("WebDavMode");
            webDavMode.AppendChild(doc.CreateElement("User")).InnerText = faxReceiveSetting.WebDav.User;
            webDavMode.AppendChild(doc.CreateElement("Password")).InnerText = faxReceiveSetting.WebDav.Password;
            webDavMode.AppendChild(doc.CreateElement("Folder")).InnerText = faxReceiveSetting.WebDav.Dir;
            webDavMode.AppendChild(doc.CreateElement("Address")).InnerText = faxReceiveSetting.WebDav.Host;
            webDavMode.AppendChild(doc.CreateElement("PortNo")).InnerText = faxReceiveSetting.WebDav.Port.ToString();
            webDavMode.AppendChild(doc.CreateElement("Proxy")).InnerText = "Off";
            webDavMode.AppendChild(doc.CreateElement("Ssl")).InnerText = "Off";
            addressInfo.AppendChild(doc.CreateElement("SendMode")).InnerText = "WebDav";
            addressInfo.AppendChild(webDavMode);
            sendConfiguration.AppendChild(doc.CreateElement("SendGroup")).InnerText = "Send";
            sendConfiguration.AppendChild(addressInfo);
            result.AppendChild(doc.CreateElement("AbbrNo")).InnerText = faxReceiveSetting.AbbreviationAddress.AbbrNo.ToString();
            result.AppendChild(doc.CreateElement("Name")).InnerText = faxReceiveSetting.AbbreviationAddress.Name;
            result.AppendChild(doc.CreateElement("Furigana")).InnerText = faxReceiveSetting.AbbreviationAddress.Furigana;
            result.AppendChild(doc.CreateElement("Language")).InnerText = faxReceiveSetting.AbbreviationAddress.Language;
            result.AppendChild(doc.CreateElement("SearchKey")).InnerText = faxReceiveSetting.AbbreviationAddress.SearchKey;
            result.AppendChild(doc.CreateElement("WellUse")).InnerText = faxReceiveSetting.AbbreviationAddress.WellUse.ToString().ToLower();
            result.AppendChild(doc.CreateElement("AddressKind")).InnerText = faxReceiveSetting.AbbreviationAddress.AddressKind;
            result.AppendChild(sendConfiguration);
            return result;
        }

        /// <summary>
        /// Create request item.
        /// </summary>
        /// <param name="doc">Xml document</param>
        /// <returns>Element</returns>
        public static XmlElement CreateRequestItem(XmlDocument doc)
        {
            var result = doc.CreateElement("RequestItem");
            result.InnerText = "Fax";
            return result;
        }

        /// <summary>
        /// Create fax forward.
        /// </summary>
        /// <param name="doc">Xml document</param>
        /// <param name="faxReceiveSetting">Fax Receive Setting</param>
        /// <returns>Element</returns>
        public static XmlElement CreateFax(XmlDocument doc, FaxReceiveSetting faxReceiveSetting)
        {
            var result = doc.CreateElement("Fax");
            var forwarding = doc.CreateElement("Forwarding");
            var forwardingFile = doc.CreateElement("ForwardingFile");
            forwardingFile.AppendChild(doc.CreateElement("FileFormat")).InnerText = faxReceiveSetting.FaxForwarding.FileFormat;
            forwardingFile.AppendChild(doc.CreateElement("OutputPageMode")).InnerText = faxReceiveSetting.FaxForwarding.OutputPageMode;
            forwarding.AppendChild(doc.CreateElement("LineType")).InnerText = faxReceiveSetting.FaxForwarding.LineType;
            forwarding.AppendChild(doc.CreateElement("Kind")).InnerText = faxReceiveSetting.FaxForwarding.Kind;
            forwarding.AppendChild(doc.CreateElement("TargetNo")).InnerText = faxReceiveSetting.FaxForwarding.TargetNo;
            forwarding.AppendChild(doc.CreateElement("Condition")).InnerText = faxReceiveSetting.FaxForwarding.Condition;
            forwarding.AppendChild(forwardingFile);
            result.AppendChild(forwarding);
            return result;
        }

        /// <summary>
        /// Creates the security.
        /// </summary>
        /// <param name="doc">The document.</param>
        /// <param name="personalInfo">The personal information.</param>
        /// <returns></returns>
        public static XmlElement CreateSecurity(XmlDocument doc, PersonalInfoProtect personalInfo)
        {
            var result = doc.CreateElement("Security");
            var personalInfoProtect = doc.CreateElement("PersonalInfoProtect");
            var jobHistory = doc.CreateElement("JobHistory");
            var executingJob = doc.CreateElement("ExecutingJob");

            personalInfoProtect.AppendChild(AppendChildElementSecurity(jobHistory, 
                doc, 
                personalInfo.JobHistory.Enable, 
                personalInfo.JobHistory.DisplayMode, 
                personalInfo.JobHistory.PublicUser));
            personalInfoProtect.AppendChild(AppendChildElementSecurity(executingJob,
                doc,
                personalInfo.ExecutingJob.Enable,
                personalInfo.ExecutingJob.DisplayMode,
                personalInfo.ExecutingJob.PublicUser));

            result.AppendChild(personalInfoProtect);
            result.AppendChild(doc.CreateElement("RequestSourceSH"))
                .InnerText = PermanentSettingsRequestSourceSH.On.ToString();

            return result;
        }

        /// <summary>
        /// Appends the child element security.
        /// </summary>
        /// <param name="xmlElement">The XML element.</param>
        /// <param name="doc">The document.</param>
        /// <param name="enable">The enable.</param>
        /// <param name="displayMode">The display mode.</param>
        /// <param name="publicUser">The public user.</param>
        /// <returns></returns>
        private static XmlElement AppendChildElementSecurity(
            XmlElement xmlElement, 
            XmlDocument doc,
            string enable,
            string displayMode,
            string publicUser)
        {
            xmlElement.AppendChild(doc.CreateElement("Enable")).InnerText = enable;
            xmlElement.AppendChild(doc.CreateElement("DisplayMode")).InnerText = displayMode;
            xmlElement.AppendChild(doc.CreateElement("PublicUser")).InnerText = publicUser;

            return xmlElement;
        }

        /// <summary>
        /// Create Request
        /// </summary>
        /// <param name="req">Xml document</param>
        /// <param name="trayInfoList">Tray setting value</param>
        internal static void CreateTrayInfoSettingRequest(XmlDocument req, List<TrayInfo> trayInfoList)
        {
            req.AppendChild(req.CreateElement("AppReqChangeTraySettingForSH"));
            XmlElement result = req.CreateElement("TraySettingList");
            result.AppendChild(req.CreateElement("ArraySize")).InnerText = trayInfoList.Count.ToString();

            foreach (var trayInfo in trayInfoList)
            {
                XmlElement traySetting = req.CreateElement("TraySetting");
                traySetting.AppendChild(req.CreateElement("TrayID")).InnerText = trayInfo.TrayId;
                traySetting.AppendChild(req.CreateElement("MediaType")).InnerText = trayInfo.MediaType;
                traySetting.AppendChild(req.CreateElement(Auto)).InnerText = trayInfo.PaperInfo?.PaperSize == "AUTO" ? "true" : "false";
                
                if (traySetting.ChildNodes.Item(2).InnerText != "true")
                {
                    XmlElement paperSize = req.CreateElement(PaperSize);
                    paperSize.AppendChild(req.CreateElement(SizeCode)).InnerText = trayInfo.PaperInfo.PaperSize;

                    if (!String.IsNullOrEmpty(trayInfo.PaperInfo.FeedDirection))
                    {
                        paperSize.AppendChild(req.CreateElement(FeedDirection)).InnerText = trayInfo.PaperInfo.FeedDirection;
                    }

                    if (trayInfo.PaperInfo.Dimension?.X != null || trayInfo.PaperInfo.Dimension?.Y != null)
                    {
                        XmlElement dimension = req.CreateElement(Dimension2);
                        dimension.AppendChild(req.CreateElement(X)).InnerText = trayInfo.PaperInfo.Dimension.X.ToString();
                        dimension.AppendChild(req.CreateElement(Y)).InnerText = trayInfo.PaperInfo.Dimension.Y.ToString();
                        paperSize.AppendChild(dimension);
                    }

                    traySetting.AppendChild(paperSize);
                }

                result.AppendChild(traySetting);
                req.DocumentElement?.AppendChild(result);
            }
        }
        
        /// <summary>
        /// Creates the XML element.
        /// </summary>
        /// <param name="element">The element.</param>
        /// <param name="doc">The document.</param>
        /// <param name="ipAddress">The ip address.</param>
        /// <param name="port">The port.</param>
        /// <returns></returns>
        private static XmlElement CreateXmlElement(string element, XmlDocument doc, IPAddress ipAddress, int port)
        {
            var result = doc.CreateElement(element);
            var address = doc.CreateElement("Address");
            var portNo = doc.CreateElement("PortNo");
            result.AppendChild(address).InnerText = ipAddress.ToString();
            result.AppendChild(portNo).InnerText = port.ToString();

            return result;
        }
    }
}
