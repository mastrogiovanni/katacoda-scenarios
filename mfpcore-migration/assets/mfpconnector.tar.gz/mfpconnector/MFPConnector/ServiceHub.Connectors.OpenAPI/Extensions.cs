using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using ServiceHub.Common.Settings;
using ServiceHub.Common.Settings.OpenApi;

namespace ServiceHub.Connectors.OpenAPI
{
    internal static class Extensions
    {
        /// <summary>
        /// For Login with Admin/Public/Driver/User
        /// </summary>
        /// <param name="message">Base message</param>
        /// <param name="userType">User type</param>
        /// <param name="userName">User name(Only use for "User" user type.)</param>
        /// <param name="password">Password(Only use for "User", "Admin" user type.)</param>
        public static void AppendOperatorInfo(this XmlDocument message, OperatorInfoUserType userType, string userName = null, string password = null)
        {
            var operatorInfo = message.CreateDocumentFragment();

            switch (userType)
            {
                case OperatorInfoUserType.Admin:
                    // For Admin
                    operatorInfo.InnerXml = $"<OperatorInfo><UserType>Admin</UserType><Password>{password}</Password></OperatorInfo>";
                    break;
                case OperatorInfoUserType.Public:
                    // For Public 
                    operatorInfo.InnerXml = "<OperatorInfo><UserType>Public</UserType></OperatorInfo>";
                    break;
                case OperatorInfoUserType.Driver:
                    // For driver
                    operatorInfo.InnerXml = "<OperatorInfo><UserType>DriverUser</UserType></OperatorInfo>";
                    break;
                default:
                    // For User
                    operatorInfo.InnerXml = $"<OperatorInfo><UserType>User</UserType><UserName>{userName}</UserName><Password>{password}</Password></OperatorInfo>";
                    break;
            }

            message.DocumentElement?.AppendChild(operatorInfo);
        }

        /// <summary>
        /// For login with Enhanced authentication
        /// </summary>
        /// <param name="message">base message</param>
        /// <param name="setting">enhanced setting</param>
        /// <param name="values">value</param>
        /// <param name="jobDeleteFlg">Job delete flag</param>
        public static void AppendCustomSetting(
            this XmlDocument message,
            OpenApiEnhancedServerAuthCustomSetting setting,
            Dictionary<EnhancedServerAuthValueType, string> values,
            bool jobDeleteFlg = false)
        {
            // Language
            var language = message.CreateDocumentFragment();
            language.InnerXml = $"<Language>{setting.PanelLanguage}</Language>";
            message.DocumentElement?.AppendChild(language);

            // CustomSetting
            var screenId = jobDeleteFlg ? string.Empty : setting.ScreenId;
            var customSetting = message.CreateDocumentFragment();
            var valueValueList = new StringBuilder();

            if (setting.Values.Count > 0)
            {
                var valueList = string.Join(string.Empty,
                    setting.Values.Select(v => $"<ValueList><Id>{v.ControlId}</Id>" +
                        $"<ArraySize>{v.ArraySize}</ArraySize><Value>{values[v.ValueType]}</Value>" +
                        "</ValueList>"));

                valueValueList.Append("<ValueListList>");
                valueValueList.Append($"<ArraySize>{setting.Values.Count}</ArraySize>");
                valueValueList.Append($"{valueList}");
                valueValueList.Append("</ValueListList>");
            }

            customSetting.InnerXml = $"<CustomSetting><Id>{screenId}</Id>{valueValueList}</CustomSetting>";
            message.DocumentElement?.AppendChild(customSetting);
        }

        /// <summary>
        /// For Other Message
        /// </summary>
        /// <param name="message">base message</param>
        /// <param name="authKey">AuthKey issued by AppReqLogin</param>
        public static void AppendOperatorInfo(this XmlDocument message, string authKey)
        {
            var operatorInfo = message.CreateDocumentFragment();
            operatorInfo.InnerXml = $"<OperatorInfo><AuthKey>{authKey}</AuthKey></OperatorInfo>";
            if ((message.DocumentElement?.HasChildNodes).GetValueOrDefault())
            {
                var existOperatorInfo = message.DocumentElement?.ChildNodes
                    .Cast<XmlNode>()
                    .Where(c => c.Name == "OperatorInfo")
                    .ToList();

                if (existOperatorInfo != null && existOperatorInfo.Any())
                {
                    foreach (var oldOperatorInfo in existOperatorInfo)
                    {
                        if (oldOperatorInfo.ChildNodes.Cast<XmlNode>().Any(c => c.Name == "AuthKey"))
                        {
                            message.DocumentElement?.RemoveChild(oldOperatorInfo);
                        }
                    }
                }

                message.DocumentElement?.InsertBefore(operatorInfo, message.DocumentElement.FirstChild);
            }
            else
            {
                message.DocumentElement?.AppendChild(operatorInfo);
            }
        }

        /// <summary>
        /// For Login from Workplace Hub
        /// </summary>
        /// <param name="message">Base message</param>
        public static void AppendRequestSource(this XmlDocument message)
        {
            var reqSource = message.CreateElement("RequestSourceSH");
            reqSource.InnerText = "On";
            message.DocumentElement?.AppendChild(reqSource);
        }

        /// <summary>
        /// Add a backup password at login
        /// </summary>
        /// <param name="message">Base message</param>
        /// <param name="password">Back up password</param>
        public static void AppendBackUpPassword(this XmlDocument message, string password)
        {
            var backUpFlg = message.CreateElement("BackUp");
            backUpFlg.InnerText = "true";
            message.DocumentElement?.AppendChild(backUpFlg);

            var backUpPass = message.CreateElement("BackUpPassword");
            backUpPass.InnerText = password;
            message.DocumentElement?.AppendChild(backUpPass);
        }

        /// <summary>
        /// Removes all items from the dictionary where it match the keys.
        /// </summary>
        /// <typeparam name="TKey">The type of the key.</typeparam>
        /// <typeparam name="TValue">The type of the value.</typeparam>
        /// <param name="theDictionary">The dictionary.</param>
        /// <param name="keys">The keys.</param>
        public static void RemoveAll<TKey, TValue>(this Dictionary<TKey, TValue> theDictionary, List<TKey> keys)
        {
            if (theDictionary != null && theDictionary.Any() && keys != null && keys.Any())
            {
                foreach (var key in keys)
                {
                    theDictionary.Remove(key);
                }
            }
        }
    }

    /// <summary>
    /// OperatorInfo user type
    /// </summary>
    public enum OperatorInfoUserType
    {
        Admin,
        Public,
        Driver,
        User,
        Enhanced
    }
}