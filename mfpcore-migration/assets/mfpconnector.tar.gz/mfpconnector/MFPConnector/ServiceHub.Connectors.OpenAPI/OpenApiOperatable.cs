using ServiceHub.Connectors.OpenAPI.Model;

namespace ServiceHub.Connectors.OpenAPI
{
    /// <summary>
    /// Open Api Operatable
    /// </summary>
    public class OpenApiOperatable
    {
        /// <summary>
        /// The settings
        /// </summary>
        protected readonly OpenApiRequestSettings OpenApiOpenApiRequestSettings;

        /// <summary>
        /// The open API controller
        /// </summary>
        protected readonly IOpenApiController OpenApiController;

        /// <summary>
        /// Initializes a new instance of the <see cref="OpenApiOperatable"/> class.
        /// </summary>
        /// <param name="openApiRequestSettings">The open API request settings.</param>
        /// <param name="openApiController">The open API controller.</param>
        public OpenApiOperatable(OpenApiRequestSettings openApiRequestSettings, IOpenApiController openApiController)
        {
            OpenApiOpenApiRequestSettings = openApiRequestSettings;
            OpenApiController = openApiController;
        }
    }
}