﻿using ServiceHub.Connectors.OpenAPI.Model;

namespace ServiceHub.Connectors.OpenAPI
{
    /// <summary>
    /// Device lock task manager interface.
    /// </summary>
    public interface ILockTaskManager
    {
        /// <summary>
        /// Add a device lock task.
        /// </summary>
        /// <param name="lockTask">The lock task.</param>
        void AddTask(DeviceLockInfo lockTask);

        /// <summary>
        /// Remove a device lock task.
        /// </summary>
        /// <param name="lockTask">The lock task.</param>
        void RemoveTask(DeviceLockInfo lockTask);

        /// <summary>
        /// Touch current lock task for notify.
        /// </summary>
        bool TouchCurrentTaskForNotify();
    }
}
