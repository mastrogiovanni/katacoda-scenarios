﻿using System.Xml;
using ServiceHub.Connectors.OpenAPI.Model;
using ServiceHub.Connectors.OpenAPI.WarningMessages;

namespace ServiceHub.Connectors.OpenAPI
{
    public interface IWarningMessageFactory
    {
        /// <summary>
        /// Create warning.
        /// </summary>
        /// <param name="warningMessage"></param>
        /// <returns>XML Element</returns>
        IWarningMessage CreateWarning(WarningMessage warningMessage);
    }
}