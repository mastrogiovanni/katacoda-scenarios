using System;

namespace ServiceHub.Connectors.OpenAPI.Exceptions
{
    /// <summary>
    /// OpenAPI request status
    /// </summary>
    public enum OpenApiResultStatus
    {
        LoginError,
        ConnectError,
        OtherError
    }

    /// <summary>
    /// OpenAPI request exception
    /// </summary>
    public class OpenApiRequestException : Exception
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="OpenApiRequestException" /> class.
        /// </summary>
        /// <param name="status">OpenApi result status</param>
        public OpenApiRequestException(OpenApiResultStatus status)
        {
            Status = status;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="OpenApiRequestException" /> class.
        /// </summary>
        /// <param name="status">OpenApi result status</param>
        /// <param name="message">Error message</param>
        public OpenApiRequestException(OpenApiResultStatus status, string message) : base(message)
        {
            Status = status;
        }

        /// <summary>
        /// OpenApi request status
        /// </summary>
        public OpenApiResultStatus Status { get; set; }
    }
}