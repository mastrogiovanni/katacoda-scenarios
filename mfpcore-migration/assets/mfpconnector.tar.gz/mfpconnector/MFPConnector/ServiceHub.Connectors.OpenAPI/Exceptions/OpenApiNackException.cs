using System;
using System.Xml;
using KonicaMinolta.OpenApi;

namespace ServiceHub.Connectors.OpenAPI.Exceptions
{
    /// <summary>
    /// OpenAPI Nack response
    /// </summary>
    public class OpenApiNackException : Exception
    {
        /// <summary>
        /// Fault request message name
        /// </summary>
        public string FaultRequest { get; private set; }

        /// <summary>
        /// Error details
        /// </summary>
        public string ErrorDetails { get; private set; }

        /// <summary>
        /// Error description
        /// </summary>
        public string ErrorDescription { get; private set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="OpenApiNackException" /> class.
        /// </summary>
        /// <param name="response">Response from IOpenApiController</param>
        /// <param name="message">Message to describe error</param>
        public OpenApiNackException(XmlDocument response, string message = null)
            : base(message)
        {
            ParseXml(response);
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="OpenApiNackException" /> class.
        /// </summary>
        /// <param name="response">Response from IOpenApiController</param>
        /// <param name="message">Message to describe error</param>
        public OpenApiNackException(OpenApiMessage response, string message = null)
            : base(message)
        {
            var doc = new XmlDocument();
            doc.LoadXml(response.Text);
            ParseXml(doc);
        }

        /// <summary>
        /// Returns a string that represents the current object.
        /// </summary>
        /// <returns>A string that represents the current object.</returns>
        public override string ToString()
        {
            var message =
                $"{ GetType().Name }: "
                + (string.IsNullOrWhiteSpace(Message) ? "OpenAPI returns Nack." : Message)
                + $" FaultRequest = { FaultRequest ?? "(null)" },"
                + $" ErrorDetails = { ErrorDetails ?? "(null)" },"
                + $" ErrorDescription = { ErrorDescription ?? "(null)" }";

            return message;
        }

        /// <summary>
        /// Parse XML document
        /// </summary>
        /// <param name="xml"></param>
        private void ParseXml(XmlDocument xml)
        {
            FaultRequest = xml.GetElementsByTagName("FaultRequest")?[0]?.InnerText;
            ErrorDetails = xml.GetElementsByTagName("ErrorDetails")?[0]?.InnerText;
            ErrorDescription = xml.GetElementsByTagName("ErrorDescription")?[0]?.InnerText;
        }
    }
}
