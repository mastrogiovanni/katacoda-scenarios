using System.Collections.Generic;
using System.Threading.Tasks;
using System.Xml;
using KonicaMinolta.OpenApi.DeviceDescriptions;
using ServiceHub.Common.Settings.Fax;
using ServiceHub.Connectors.OpenAPI.Model;
using ServiceHub.Connectors.OpenAPI.Model.DeviceInfoDetail;
using ServiceHub.Connectors.OpenAPI.Model.PermanentSettings.Security;

namespace ServiceHub.Connectors.OpenAPI
{
    /// <summary>
    /// Sequential connection interface.
    /// </summary>
    public interface IOpenApiController
    {
        /// <summary>
        /// Device is seemed to be locked?
        /// </summary>
        bool IsDeviceSeemedToBeLocked { get; }

        /// <summary>
        /// Confirm connect by OpenAPI.
        /// </summary>
        /// <param name="timeout">Reques time out</param>
        /// <returns>Confirm result</returns>
        Task<bool> ConfirmConnectAsync(int? timeout = null);

        /// <summary>
        /// Confirm admin login by OpenAPI.
        /// </summary>
        /// <param name="password">Admin password</param>
        /// <returns>Confirm result</returns>
        Task<bool> ConfirmAdminLoginAsync(string password);

        /// <summary>
        /// Enter device lock.
        /// </summary>
        /// <returns>Lock key</returns>
        /// <param name="timeoutMin">Lock time out [minute]</param>
        Task EnterDeviceLockAsync(int timeoutMin = 1);

        /// <summary>
        /// Exit device lock.
        /// </summary>
        Task ExitDeviceLockAsync();

        /// <summary>
        /// Get device list status.
        /// </summary>
        /// <returns>Xml document</returns>
        Task<XmlDocument> GetDeviceListStatusAsync();

        /// <summary>
        /// Get device Parts status.
        /// </summary>
        /// <param name="deviceType">Device Type</param>
        /// <returns>Xml document</returns>
        Task<XmlDocument> GetDevicePartsStatusAsync(string deviceType);

        /// <summary>
        /// Delete job.
        /// </summary>
        /// <param name="jobId">Job id</param>
        /// <param name="enhancedAuthParameterCode">Enhanced auth parameter code</param>
        /// <returns>Xml document</returns>
        Task<XmlDocument> DeleteJobAsync(string jobId, string enhancedAuthParameterCode);

        /// <summary>
        /// Get job list.
        /// </summary>
        /// <param name="mfpJobId">Mfp Job Id</param>
        /// <returns>Xml Document</returns>
        Task<XmlDocument> GetJobListAsync(ulong? mfpJobId);

        /// <summary>
        /// Get job list(activated).
        /// </summary>
        /// <param name="mfpJobId">Mfp Job Id</param>
        /// <returns>Xml Document</returns>
        Task<XmlDocument> GetJobActiveListAsync(ulong? mfpJobId);

        /// <summary>
        /// Get job status list .
        /// </summary>
        /// <param name="mfpJobId">Mfp Job Id</param>
        /// <returns>Xml Document</returns>
        Task<XmlDocument> GetJobStatusListAsync(ulong? mfpJobId);

        /// <summary>
        /// Get job history.
        /// </summary>
        /// <returns>Xml Document</returns>
        Task<XmlDocument> GetJobHistoryAsync();

        /// <summary>
        /// Restart job.
        /// </summary>
        /// <param name="jobId">Job id</param>
        /// <param name="enhancedAuthParameterCode">Enhanced auth parameter code</param>
        /// <param name="jobDeleteFlg">Job delete flag</param>
        /// <returns>Xml document</returns>
        Task<XmlDocument> RestartJobAsync(string jobId, string enhancedAuthParameterCode = null, bool jobDeleteFlg = false);

        /// <summary>
        /// Set abbreviation addressbook.
        /// </summary>
        /// <param name="faxReceiveSetting">Fax receive setting</param>
        Task SetAbbreviationAddressbookAsync(FaxReceiveSetting faxReceiveSetting);

        /// <summary>
        /// Set device permanent setting.
        /// </summary>
        /// <param name="faxReceiveSetting">FaxReceiveSetting</param>
        Task SetDevicePermanentSettingAsync(FaxReceiveSetting faxReceiveSetting);

        /// <summary>
        /// Sets the device permanent setting security asynchronous.
        /// </summary>
        /// <param name="personalInfoProtect">The personal information protect.</param>
        /// <returns></returns>
        Task<XmlDocument> SetDevicePermanentSettingSecurityAsync(PersonalInfoProtect personalInfoProtect);

        /// <summary>
        /// Get device permanent settings
        /// </summary>
        /// <param name="requestItem">Request item</param>
        /// <returns>Xml document</returns>
        Task<XmlDocument> GetDevicePermanentSettingsAsync(PermanentSettingsRequestItems requestItem);

        /// <summary>
        /// Get device detail settings
        /// </summary>
        /// <param name="requestItem">Request item</param>
        /// <returns>Xml document</returns>
        Task<XmlDocument> GetDeviceInfoDetailAsync(DetailSettingsRequestItems requestItem);

        /// <summary>
        /// Get device info
        /// </summary>
        /// <param name="requestItem">Get device info request items</param>
        /// <returns>Xml document</returns>
        Task<XmlDocument> GetDeviceInfoAsync(GetDeviceInfoRequestItems requestItem);

        /// <summary>
        /// Get device enable function info2
        /// </summary>
        /// <param name="deviceSerialNumber">Device serial number</param>
        /// <returns>Xml document</returns>
        Task<XmlDocument> GetDeviceEnableFunctionInfo2Async(string deviceSerialNumber);

        /// <summary>
        /// Change device screen.
        /// </summary>
        /// <param name="switchType">SwitchType</param>
        /// <param name="screenType">ScreenType</param>
        /// <param name="appNo">AppNumber</param>
        /// <returns>Xml document</returns>
        Task<XmlDocument> ChangeDeviceScreenAsync(SwitchType switchType, ScreenType? screenType, int? appNo);

        /// <summary>
        /// Set the installed mode to WPH installed mode.
        /// </summary>
        /// <returns>Xml document</returns>
        Task<XmlDocument> SetInstalledAsync();

        /// <summary>
        /// Change power mode.
        /// </summary>
        /// <param name="powerMode">PowerMode</param>
        /// <returns>Xml document</returns>
        Task<XmlDocument> ChangePowerModeAsync(PowerMode powerMode);

        /// <summary>
        /// Get Device Power Status.
        /// </summary>
        /// <returns>Xml document</returns>
        Task<XmlDocument> GetDevicePowerStatusAsync();

        /// <summary>
        /// Get printer encryption setting
        /// </summary>
        /// <returns>Xml document</returns>
        Task<XmlDocument> GetPrinterEncryptionSettingAsync();

        /// <summary>
        /// Set event notification
        /// </summary>
        /// <param name="notifyIpAddress">Notify IP address</param>
        /// <param name="notifyPort">Notify port</param>
        /// <returns>Xml document</returns>
        Task<XmlDocument> SetEventNotificationAsync(string notifyIpAddress, int notifyPort);

        /// <summary>
        /// Set job trace
        /// </summary>
        /// <param name="driverJobId">Driver job id</param>
        /// <param name="jobId">Job id</param>
        /// <param name="notifyIpAddress">Notify IP address</param>
        /// <param name="notifyPort">Notify port</param>
        /// <returns>Xml document</returns>
        Task<XmlDocument> SetJobTraceAsync(string driverJobId, string jobId, string notifyIpAddress, int notifyPort);

        /// <summary>
        /// Notify Device Network Setting.
        /// </summary>
        /// <param name="addressType">Ip address type.</param>
        /// <param name="address">Ip address.</param>
        /// <param name="ipv6Type">Ip v6 type.</param>
        /// <returns>Success/Fail</returns>
        Task<XmlDocument> NotifyDeviceNetworkSettingAsync(IpAddressType addressType, string address, Ipv6Type? ipv6Type);

        /// <summary>
        /// Get animation file list.
        /// </summary>
        /// <returns>Xml document</returns>
        Task<XmlDocument> GetAnimationFileListAsync();

        /// <summary>
        /// Request file data.
        /// </summary>
        /// <param name="requestItem">Request item</param>
        /// <param name="file">File (Animation or MachineImage -> file path, TintBlock or Stamp -> "1"-"8")</param>
        /// <returns>OpenAPIResponse with file</returns>
        Task<OpenApiResponse> RequestFileDataAsync(AppRequestItemType requestItem, string file);

        /// <summary>
        /// Request wake up
        /// </summary>
        /// <returns>Xml document</returns>
        Task<XmlDocument> WakeupAsync();

        /// <summary>
        /// Execute mfp settings
        /// </summary>
        /// <param name="req">Xml document</param>
        /// <param name="isAdmin">Admin user?</param>
        /// <param name="isDeviceLock">Device lock?</param>
        /// <returns>Result</returns>
        Task<XmlDocument> MfpSettingsAsync(XmlDocument req, bool isAdmin, bool isDeviceLock);

        /// <summary>
        /// Set device info detail.
        /// </summary>
        /// <param name="info">Info</param>
        /// <returns>Xml document</returns>
        Task<XmlDocument> SetDeviceInfoDetailAsync(DeviceInfoDetail info);

        /// <summary>
        /// Set device info detail with lock by Admin user.
        /// </summary>
        /// <param name="info">Info</param>
        /// <returns>Xml document</returns>
        Task<XmlDocument> SetDeviceInfoDetailAdminAsync(DeviceInfoDetail info);

        /// <summary>
        /// Set tray information of MFP
        /// </summary>
        /// <param name="trayInfoList">Tray setting value</param>
        /// <returns>OpenApi return Xml value</returns>
        Task<XmlDocument> SetTrayInfoSettingAsync(List<TrayInfo> trayInfoList);

        /// <summary>
        /// Let MFP begin download the firmware.
        /// </summary>
        /// <returns>Xml document</returns>
        Task<XmlDocument> LetBeginDownloadFirmwareAsync();

        /// <summary>
        /// Get firmware download status
        /// </summary>
        /// <returns>Xml document</returns>
        Task<XmlDocument> GetFirmwareDownloadStatusAsync();

        /// <summary>
        /// Update firmware
        /// </summary>
        /// <returns>Xml document</returns>
        Task<XmlDocument> UpdateFirmwareAsync();

        /// <summary>
        /// Cancel Warning.
        /// </summary>
        /// <returns>Xml document</returns>
        Task<XmlDocument> CancelWarningAsync(WarningServiceSetting request);

        /// <summary>
        /// Get Device Description.
        /// </summary>
        /// <returns>DeviceDescription</returns>
        DeviceDescription GetDeviceDescription();

        /// <summary>
        /// Next Warning.
        /// </summary>
        /// <returns>Xml document</returns>
        Task<XmlDocument> NextWarningAsync();

        /// <summary>
        /// Get Counter Info.
        /// </summary>
        /// <returns>Xml document</returns>
        Task<XmlDocument> GetCounterInfoAsync(MfpCounterType counterType);

        /// <summary>
        /// Removes the authentication keys asynchronous.
        /// </summary>
        /// <returns></returns>
        void RemoveCurrentAuthKeys();
    }
}
