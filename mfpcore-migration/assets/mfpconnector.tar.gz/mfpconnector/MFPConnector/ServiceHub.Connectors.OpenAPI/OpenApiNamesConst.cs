namespace ServiceHub.Connectors.OpenAPI
{
    public static class OpenApiNamesConst
    {
        public const string ExceptionTimeout = "timeout";
        public const string Exception = "exception";
        public const string StatusBadRequest = "BadRequest";
        public const string StatusServerError = "ServerError";
        public const string StatusTimeout = "Timeout";

        public const int NotifyDeviceNetworkSettingTimeout = 100000;
        public const int DeviceLockTimeout = 100000;
    }
}