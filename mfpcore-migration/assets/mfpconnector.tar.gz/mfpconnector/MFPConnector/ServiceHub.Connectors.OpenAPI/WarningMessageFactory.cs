﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using ServiceHub.Connectors.OpenAPI.Model;
using ServiceHub.Connectors.OpenAPI.WarningMessages;

namespace ServiceHub.Connectors.OpenAPI
{
    public class WarningMessageFactory: IWarningMessageFactory
    {
        private readonly Dictionary<WarningMessage, Type> _warningMessages = new Dictionary<WarningMessage, Type>
        {
            { WarningMessage.AMSMagnificationIncompatible,  typeof(AMSMagnificationIncompatible)},
            { WarningMessage.APSAcceptable,  typeof(APSAcceptable)},
            { WarningMessage.APSSizeMismatch,  typeof(APSSizeMismatch)},
            { WarningMessage.ExtDocumentSizeAssign,  typeof(ExtDocumentSizeAssign)},
            { WarningMessage.IuLife,  typeof(IuLife)},
            { WarningMessage.ManuscriptSizeDetectError,  typeof(ManuscriptSizeDetectError)},
            { WarningMessage.PaperEmptyCaution,  typeof(PaperEmptyCaution)},
            { WarningMessage.PaperEmptyError,  typeof(PaperEmptyError)},
            { WarningMessage.PrintIncompatible,  typeof(PrintIncompatible)},
            { WarningMessage.PunchDirectionNotAcceptable,  typeof(PunchDirectionNotAcceptable)},
            { WarningMessage.PunchFormStaple,  typeof(PunchFormStaple)},
            { WarningMessage.PunchPaperIncompatibility,  typeof(PunchPaperIncompatibility)},
            { WarningMessage.StapleDirectionNotAcceptable,  typeof(StapleDirectionNotAcceptable)},
            { WarningMessage.StapleForm,  typeof(StapleForm)},
            { WarningMessage.StaplePaperMismatch,  typeof(StaplePaperMismatch)},
            { WarningMessage.TonerEmptyStop,  typeof(TonerEmptyStop)},
            { WarningMessage.TwoSidedIncompatible,  typeof(TwoSidedIncompatible)},
        };

        /// <inheritdoc cref="IWarningMessageFactory"/>
        public IWarningMessage CreateWarning(WarningMessage warningMessage)
        {
            if (_warningMessages.TryGetValue(warningMessage, out var warningType))
            {
                return (IWarningMessage)Activator.CreateInstance(warningType);
            }

            throw new NotImplementedException($"The warning message: \"{warningMessage.ToString()}\" does not exists");
        }
    }
}
