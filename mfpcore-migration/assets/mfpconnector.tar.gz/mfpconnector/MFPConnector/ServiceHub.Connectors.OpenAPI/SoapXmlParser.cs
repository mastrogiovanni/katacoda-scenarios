using System;
using System.Xml;
using ServiceHub.Common.Settings.OpenApi;

namespace ServiceHub.Connectors.OpenAPI
{
    /// <summary>
    /// Soap xml parser.
    /// </summary>
    public class SoapXmlParser
    {
        /// <summary>
        /// OpenAPI Version
        /// </summary>
        private readonly OpenApiVersion _openApiVersion;

        /// <summary>
        ///  Initializes a new instance of the SoapXmlParser class.
        /// </summary>
        /// <param name="xml">Xml data.</param>
        /// <param name="openApiVersion">OpenAPI Version</param>
        public SoapXmlParser(string xml, OpenApiVersion openApiVersion)
        {
            _openApiVersion = openApiVersion;
            LoadSoapXml(xml);
        }

        private XmlNamespaceManager Manager { get; set; }

        private XmlDocument Document { get; set; }

        /// <summary>
        /// Get node.
        /// </summary>
        /// <param name="path">Path of xml.</param>
        /// <param name="manager">Exsist of manager.</param>
        /// <returns>XmlNode.</returns>
        public XmlNode GetNode(string path, bool manager = true)
        {
            return manager ? Document.SelectSingleNode(path, Manager) : Document.SelectSingleNode(path);
        }

        /// <summary>
        /// Get node list.
        /// </summary>
        /// <param name="path">Path of xml.</param>
        /// <param name="manager">Exsist of manager.</param>
        /// <returns>XmlNode.</returns>
        public XmlNodeList GetNodes(string path, bool manager = true)
        {
            return manager ? Document.SelectNodes(path, Manager) : Document.SelectNodes(path);
        }

        /// <summary>
        /// Get node.
        /// </summary>
        /// <param name="path">Path of xml.</param>
        /// <param name="manager">Exsist of manager.</param>
        /// <returns>XmlNode.</returns>
        public bool ExistNode(string path, bool manager = true)
        {
            var node = manager ? Document.SelectSingleNode(path, Manager) : Document.SelectSingleNode(path);

            return node != null;
        }

        /// <summary>
        /// Get value.
        /// </summary>
        /// <param name="node">Node of xml.</param>
        /// <param name="path">Path of xml.</param>
        /// <param name="manager">Exsist of manager.</param>
        /// <returns>Value of XmlNode.</returns>
        public string GetValue(XmlNode node, string path, bool manager = true)
        {
            string result = null;
            try
            {
                if (path != null)
                {
                    result = manager ? node.SelectSingleNode(path, Manager)?.Value : node.SelectSingleNode(path)?.Value;
                }
            }
            catch (NullReferenceException)
            {
                return result;
            }

            return result;
        }

        /// <summary>
        /// Get integer.
        /// </summary>
        /// <param name="node">Node of xml.</param>
        /// <param name="path">Path of xml.</param>
        /// <param name="manager">Exsist of manager.</param>
        /// <returns>Value of XmlNode.</returns>
        public int? GetInteger(XmlNode node, string path, bool manager = true)
        {
            int? result = null;
            try
            {
                var nodeValue = GetValue(node, path, manager);
                int outValue;
                result = int.TryParse(nodeValue, out outValue) ? outValue : (int?)null;
            }
            catch (NullReferenceException)
            {
                return result;
            }

            return result;
        }

        /// <summary>
        /// Load soap xml.
        /// </summary>
        /// <param name="xml">Xml data.</param>
        public void LoadSoapXml(string xml)
        {
            Document = new XmlDocument();
            Document.LoadXml(xml);
            Manager = new XmlNamespaceManager(Document.NameTable);
            Manager.AddNamespace("SOAP-ENV", "http://schemas.xmlsoap.org/soap/envelope/");
            Manager.AddNamespace("SOAP-ENC", "http://schemas.xmlsoap.org/soap/encoding/");
            Manager.AddNamespace("OpenAPI", "http://www.konicaminolta.com/service/OpenAPI-" + _openApiVersion.Major + "-" + _openApiVersion.Minor);
        }

        /// <summary>
        /// Load xml.
        /// </summary>
        /// <param name="xml">Xml data..</param>
        /// <returns>XmlDocument.</returns>
        public XmlDocument LoadXml(string xml)
        {
            Document = new XmlDocument();
            Document.LoadXml(xml);
            return Document;
        }
    }
}