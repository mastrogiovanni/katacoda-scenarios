﻿using System.Xml;
using ServiceHub.Connectors.OpenAPI.Model;

namespace ServiceHub.Connectors.OpenAPI.WarningMessages
{
    internal class ExtDocumentSizeAssign : BaseWarningMessage
    {
        /// <summary>
        /// Messages the creator.
        /// </summary>
        /// <param name="doc">The document.</param>
        /// <param name="request">The request.</param>
        /// <returns></returns>
        public override XmlElement ToXml(XmlDocument doc, WarningServiceSetting request)
        {
            var result = doc.CreateElement("ExtDocumentSizeAssign");
            result.AppendChild(AppendChildElement(
                doc,
                request.ExtDocumentSizeAssign.PaperSize?.SizeCode,
                request.ExtDocumentSizeAssign.PaperSize.Dimension2?.X.ToString(),
                request.ExtDocumentSizeAssign.PaperSize.Dimension2?.Y.ToString(),
                request.ExtDocumentSizeAssign.PaperSize.FeedDirection));

            return result;
        }
    }
}