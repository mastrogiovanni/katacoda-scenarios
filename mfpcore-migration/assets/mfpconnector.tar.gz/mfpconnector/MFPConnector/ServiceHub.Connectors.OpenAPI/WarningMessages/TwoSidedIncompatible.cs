﻿using System.Xml;
using ServiceHub.Connectors.OpenAPI.Model;

namespace ServiceHub.Connectors.OpenAPI.WarningMessages
{
    internal class TwoSidedIncompatible : BaseWarningMessage
    {
        /// <summary>
        /// Messages the creator.
        /// </summary>
        /// <param name="doc">The document.</param>
        /// <param name="request">The request.</param>
        /// <returns></returns>
        public override XmlElement ToXml(XmlDocument doc, WarningServiceSetting request)
        {
            return CreateXmlElement(
                doc,
                "TwoSidedIncompatible",
                "TwoSidedIncompatibleType",
                "TraySelection",
                request.TwoSidedIncompatible.TwoSidedIncompatibleType,
                request.TwoSidedIncompatible.TraySelection);
        }
    }
}