﻿using System.Xml;
using ServiceHub.Connectors.OpenAPI.Model;

namespace ServiceHub.Connectors.OpenAPI.WarningMessages
{
    internal class StapleDirectionNotAcceptable : BaseWarningMessage
    {
        /// <summary>
        /// Messages the creator.
        /// </summary>
        /// <param name="doc">The document.</param>
        /// <param name="request">The request.</param>
        /// <returns></returns>
        public override XmlElement ToXml(XmlDocument doc, WarningServiceSetting request)
        {
            return CreateXmlElement(
                doc,
                "StapleDirectionNotAcceptable",
                "StapleDirectionChangeType",
                "StaplePosition",
                request.StapleDirectionNotAcceptable.StapleDirectionChangeType,
                request.StapleDirectionNotAcceptable.StaplePosition);
        }
    }
}