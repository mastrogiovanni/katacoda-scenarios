﻿using System.Xml;
using ServiceHub.Connectors.OpenAPI.Model;

namespace ServiceHub.Connectors.OpenAPI.WarningMessages
{
    internal class PrintIncompatible : BaseWarningMessage
    {
        /// <summary>
        /// Messages the creator.
        /// </summary>
        /// <param name="doc">The document.</param>
        /// <param name="request">The request.</param>
        /// <returns></returns>
        public override XmlElement ToXml(XmlDocument doc, WarningServiceSetting request)
        {
            string elementOption = null;
            string innerTextOption = null;
            if ("TraySelection".Equals(request.PrintIncompatible.PrintIncompatibleType))
            {
                elementOption = "TraySelection";
                innerTextOption = request.PrintIncompatible.TraySelection;
            }

            return CreateXmlElement(doc,
                "PrintIncompatible",
                "PrintIncompatibleType",
                elementOption,
                request.PrintIncompatible.PrintIncompatibleType,
                innerTextOption);
        }
    }
}