using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using ServiceHub.Connectors.OpenAPI.Model;

namespace ServiceHub.Connectors.OpenAPI
{
    /// <summary>
    /// Device lock task manager class.
    /// </summary>
    public class LockTaskManager : BackgroundService, ILockTaskManager
    {
        private readonly ILogger<LockTaskManager> _logger;
        private static readonly List<DeviceLockInfo> TaskList = new List<DeviceLockInfo>();

        /// <summary>
        /// Initializes a new instance of the <see cref="LockTaskManager"/> class.  
        /// </summary>
        /// <param name="logger">Logger</param>
        public LockTaskManager(ILogger<LockTaskManager> logger)
        {
            _logger = logger;
        }

        /// <summary>
        /// This method is called when the <see cref="T:Microsoft.Extensions.Hosting.IHostedService" /> starts.
        /// The implementation should return a task that represents the lifetime of the long running operation(s)
        /// being performed.
        /// </summary>
        /// <param name="stoppingToken">Triggered when
        /// <see cref="M:Microsoft.Extensions.Hosting.IHostedService.StopAsync(System.Threading.CancellationToken)" />
        /// is called.</param>
        /// <returns>
        /// A <see cref="T:System.Threading.Tasks.Task" /> that represents the long running operations.
        /// </returns>
        /// <remarks>
        /// For more details on how it works, read the MSDN article: https://bit.ly/2tV2zJJ
        /// </remarks>
        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            _logger.LogInformation("LockTaskManager background task is starting.");
            stoppingToken.Register(() => _logger.LogInformation("LockTaskManager background task is stopping."));

            while (!stoppingToken.IsCancellationRequested)
            {
                await CheckTaskAsync().ConfigureAwait(false);
                await Task.Delay(100, stoppingToken).ConfigureAwait(false);
            }

            _logger.LogInformation("LockTaskManager background task is stopping.");
        }

        /// <summary>
        /// Stops the asynchronous.
        /// </summary>
        /// <param name="cancellationToken">The stopping token.</param>
        /// <returns>Returns the task</returns>
        public override Task StopAsync(CancellationToken cancellationToken)
        {
            // Run your graceful clean-up actions or dispose extra resources.
            return Task.CompletedTask;
        }

        /// <summary>
        /// Add a device lock task.
        /// </summary>
        /// <param name="lockTask">The lock task.</param>
        public void AddTask(DeviceLockInfo lockTask)
        {
            _logger.LogDebug("[Enter] Add lock task. id : " + lockTask.Event.GetHashCode());
            lock (TaskList)
            {
                TaskList.Add(lockTask);
            }

            _logger.LogDebug("[Exit] Add lock task. id : " + lockTask.Event.GetHashCode());
        }

        /// <summary>
        /// Remove a device lock task.
        /// </summary>
        /// <param name="lockTask">The lock task.</param>
        public void RemoveTask(DeviceLockInfo lockTask)
        {
            _logger.LogDebug("[Enter] Remove lock task. id : " + lockTask.Event.GetHashCode());
            lock (TaskList)
            {
                TaskList.Remove(lockTask);
            }

            _logger.LogDebug("[Exit] Remove lock task. id : " + lockTask.Event.GetHashCode());
        }

        /// <summary>
        /// Touch current lock task for notify.
        /// </summary>
        /// <returns>
        /// true: touch, false: not exist
        /// </returns>
        public bool TouchCurrentTaskForNotify()
        {
            lock (TaskList)
            {
                if (TaskList.Count == 0)
                {
                    return false;
                }

                var lockTask = TaskList[0];
                lockTask.ReferenceEvent.Set();

                return true;
            }
        }

        /// <summary>
        /// Check device lock task list.
        /// </summary>
        /// <returns></returns>
        private async Task CheckTaskAsync()
        {
            DeviceLockInfo lockTask = null;

            try
            {
                lock (TaskList)
                {
                    if (TaskList.Count == 0)
                    {
                        return;
                    }

                    lockTask = TaskList[0];
                }

                lockTask.Event.Set();
                var waitTimeMs = lockTask.TimeoutMin * 60 * 1000;
                var watch = Stopwatch.StartNew();

                while (true)
                {
                    lock (TaskList)
                    {
                        if (!TaskList.Contains(lockTask) || watch.ElapsedMilliseconds > waitTimeMs)
                        {
                            // exit lock normally
                            // or wait time out
                            break;
                        }
                    }

                    await Task.Delay(100).ConfigureAwait(false);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(default(EventId), ex, ex.Message);
            }
            finally
            {
                if (lockTask != null)
                {
                    lock (TaskList)
                    {
                        TaskList.Remove(lockTask);
                    }
                }
            }
        }
    }
}
