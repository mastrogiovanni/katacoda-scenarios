using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;

namespace ServiceHub.Connectors.MfpService
{
    /// <summary>
    /// Push notifications to somewhere
    /// </summary>
    public interface IMfpService
    {
        /// <summary>
        /// GET method
        /// </summary>
        /// <param name="path">URL path to push (protocol, domain, port are not specifiable, just only path and query)</param>
        /// <param name="headers">Request headers</param>
        /// <returns>HTTP response</returns>
        Task<HttpResponseMessage> GetAsync(string path, Dictionary<string, string> headers = null);

        /// <summary>
        /// POST method
        /// </summary>
        /// <param name="path">URL path to POST (protocol, domain, port are not specifiable, just only path and query)</param>
        /// <param name="content">Http request content</param>
        /// <param name="headers">Request headers</param>
        /// <returns>HTTP response</returns>
        Task<HttpResponseMessage> PostAsync(string path, HttpContent content, Dictionary<string, string> headers = null);
    }
}
