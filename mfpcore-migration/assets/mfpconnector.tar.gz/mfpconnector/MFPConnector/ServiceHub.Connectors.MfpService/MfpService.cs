using Microsoft.Extensions.Logging;
using ServiceHub.Common.Settings;
using ServiceHub.Common.Settings.PushNotification;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;

namespace ServiceHub.Connectors.MfpService
{
    /// <summary>
    /// Connector for service.
    /// </summary>
    public class MfpService : IMfpService
    {
        /// <summary>
        /// Logger
        /// </summary>
        private readonly ILogger<MfpService> _logger;

        /// <summary>
        /// MFP Connector setting
        /// </summary>
        private readonly MfpConnectorSetting _mfpConnectorSetting;

        /// <summary>
        /// Base URL
        /// </summary>
        private string BaseUrl => _mfpConnectorSetting.PushNotification[PushNotificationType.MfpService].CurrentSetting.BaseUrl;

        /// <summary>
        /// Initializes a new instance of the <see cref="MfpService"/> class
        /// </summary>
        /// <param name="setting">MfpConnectorSetting</param>
        /// <param name="logger">_logger</param>
        public MfpService(MfpConnectorSetting setting, ILogger<MfpService> logger)
        {
            _mfpConnectorSetting = setting;
            _logger = logger;
        }

        /// <summary>
        /// GET method
        /// </summary>
        /// <param name="path">URL path to push (protocol, domain, port are not specifiable, just only path and query)</param>
        /// <param name="headers">Request headers</param>
        /// <returns>HTTP response</returns>
        public async Task<HttpResponseMessage> GetAsync(string path, Dictionary<string, string> headers = null)
        {
            using (var handler = new HttpClientHandler())
            {
                handler.ServerCertificateCustomValidationCallback += (message, xcert, chain, errors) => true;
                using (var httpClient = new HttpClient(handler))
                {
                    if (headers != null)
                    {
                        foreach (var header in headers)
                        {
                            httpClient.DefaultRequestHeaders.Add(header.Key, header.Value);
                        }
                    }

                    var result = await httpClient.GetAsync(BaseUrl + path);
                    if (!result.IsSuccessStatusCode)
                    {
                        _logger.LogWarning($"Http GET request failed. [Url = {BaseUrl + path}, " +
                                           $"StatusCode = {(int)result.StatusCode}]");
                    }

                    return result;
                }
            }
        }

        /// <summary>
        /// POST method
        /// </summary>
        /// <param name="path">URL path to POST (protocol, domain, port are not specifiable, just only path and query)</param>
        /// <param name="content">Http request content</param>
        /// <param name="headers">Request headers</param>
        /// <returns>HTTP response</returns>
        public async Task<HttpResponseMessage> PostAsync(string path, HttpContent content, Dictionary<string, string> headers = null)
        {
            using (var handler = new HttpClientHandler())
            {
                handler.ServerCertificateCustomValidationCallback += (message, xcert, chain, errors) => true;
                using (var httpClient = new HttpClient(handler))
                {
                    if (headers != null)
                    {
                        foreach (var header in headers)
                        {
                            httpClient.DefaultRequestHeaders.Add(header.Key, header.Value);
                        }
                    }

                    var result = await httpClient.PostAsync(BaseUrl + path, content);
                    if (!result.IsSuccessStatusCode)
                    {
                        _logger.LogWarning($"Http POST request failed. [Url = {BaseUrl + path}, " +
                                           $"StatusCode = {(int)result.StatusCode}]");
                    }

                    return result;
                }
            }
        }
    }
}
