using ServiceHub.Connectors.OpenAPI.Model;
using ServiceHub.Connectors.OpenAPI.Model.PermanentSettings.Security;
using ServiceHub.Processors.Tests;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Xml;
using Xunit;

namespace ServiceHub.Connectors.OpenAPI.Tests
{
    [Trait("MessageCreatorTests", "Unit")]
    public class MessageCreatorTests
    {
        private static string apsAcceptableXml =
            "<?xml version=\"1.0\" encoding=\"utf-16\"?><AppReqRemoveWarning><JobID>1234</JobID><WarningName>DummyName</WarningName><ApsAcceptable><AcceptableType>DummyAcceptableType</AcceptableType><TraySelection>DummyTraySelection</TraySelection><Dimension><X>111</X><Y>999</Y></Dimension></ApsAcceptable></AppReqRemoveWarning>";

        private static string paperEmptyCautionXml =
            "<?xml version=\"1.0\" encoding=\"utf-16\"?><AppReqRemoveWarning><JobID>1234</JobID><WarningName>DummyName</WarningName><PaperEmptyCaution><PaperEmptyCautionType>DummyPaperEmptyCautionType</PaperEmptyCautionType><TraySelection>Tray1</TraySelection></PaperEmptyCaution></AppReqRemoveWarning>";

        private static string paperEmptyErrorXml =
            "<?xml version=\"1.0\" encoding=\"utf-16\"?><AppReqRemoveWarning><JobID>1234</JobID><WarningName>DummyName</WarningName><PaperEmptyError><TraySelection>Tray1</TraySelection></PaperEmptyError></AppReqRemoveWarning>";

        private static string twoSidedIncompatibleXml =
            "<?xml version=\"1.0\" encoding=\"utf-16\"?><AppReqRemoveWarning><JobID>1234</JobID><WarningName>DummyName</WarningName><TwoSidedIncompatible><TwoSidedIncompatibleType>DummyTwoSidedIncompatibleType</TwoSidedIncompatibleType><TraySelection>Tray1</TraySelection></TwoSidedIncompatible></AppReqRemoveWarning>";

        private static string printIncompatibleXml =
            "<?xml version=\"1.0\" encoding=\"utf-16\"?><AppReqRemoveWarning><JobID>1234</JobID><WarningName>DummyName</WarningName><PrintIncompatible><PrintIncompatibleType>TraySelection</PrintIncompatibleType><TraySelection>Tray1</TraySelection></PrintIncompatible></AppReqRemoveWarning>";

        private static string printIncompatibleOtherThanTraySelectionXml =
            "<?xml version=\"1.0\" encoding=\"utf-16\"?><AppReqRemoveWarning><JobID>1234</JobID><WarningName>DummyName</WarningName><PrintIncompatible><PrintIncompatibleType>DummyPrintIncompatibleType</PrintIncompatibleType></PrintIncompatible></AppReqRemoveWarning>";

        private static string amsMagnificationIncompatibleXml =
            "<?xml version=\"1.0\" encoding=\"utf-16\"?><AppReqRemoveWarning><JobID>1234</JobID><WarningName>DummyName</WarningName><AMSMagnificationIncompatible><AMSMagnificationIncompatibleType>DummyAmsMagnificationIncompatibleType</AMSMagnificationIncompatibleType><TraySelection>Tray1</TraySelection><Dimension><X>444</X><Y>666</Y></Dimension></AMSMagnificationIncompatible></AppReqRemoveWarning>";

        private static string stapleFormXml =
            "<?xml version=\"1.0\" encoding=\"utf-16\"?><AppReqRemoveWarning><JobID>1234</JobID><WarningName>DummyName</WarningName><StapleForm><StapleFormType>DummyStapleFormType</StapleFormType><TraySelection>Tray1</TraySelection></StapleForm></AppReqRemoveWarning>";

        private static string aPSSizeMismatchXml =
            "<?xml version=\"1.0\" encoding=\"utf-16\"?><AppReqRemoveWarning><JobID>1234</JobID><WarningName>DummyName</WarningName><APSSizeMismatch><TraySelection>Tray1</TraySelection></APSSizeMismatch></AppReqRemoveWarning>";

        private static string punchPaperIncompatibilityXml =
            "<?xml version=\"1.0\" encoding=\"utf-16\"?><AppReqRemoveWarning><JobID>1234</JobID><WarningName>DummyName</WarningName><PunchPaperIncompatibility><PunchPaperIncompatibilityType>DummyPunchPaperIncompatibilityType</PunchPaperIncompatibilityType><TraySelection>Tray1</TraySelection></PunchPaperIncompatibility></AppReqRemoveWarning>";

        private static string punchFormStapleXml =
            "<?xml version=\"1.0\" encoding=\"utf-16\"?><AppReqRemoveWarning><JobID>1234</JobID><WarningName>DummyName</WarningName><PunchFormStaple><PunchFormStapleType>DummyPunchFormStapleType</PunchFormStapleType><TraySelection>Tray1</TraySelection></PunchFormStaple></AppReqRemoveWarning>";

        private static string tonerEmptyStopXml =
            "<?xml version=\"1.0\" encoding=\"utf-16\"?><AppReqRemoveWarning><JobID>1234</JobID><WarningName>DummyName</WarningName><TonerEmptyStop><TempRescueStatus>DummyTempRescueStatus</TempRescueStatus></TonerEmptyStop></AppReqRemoveWarning>";

        private static string extDocumentSizeAssignXml =
            "<?xml version=\"1.0\" encoding=\"utf-16\"?><AppReqRemoveWarning><JobID>1234</JobID><WarningName>DummyName</WarningName><ExtDocumentSizeAssign><PaperSize><SizeCode>Custom</SizeCode><Dimension2><X>555</X><Y>666</Y></Dimension2></PaperSize></ExtDocumentSizeAssign></AppReqRemoveWarning>";

        private static string punchDirectionNotAcceptableXml =
            "<?xml version=\"1.0\" encoding=\"utf-16\"?><AppReqRemoveWarning><JobID>1234</JobID><WarningName>DummyName</WarningName><PunchDirectionNotAcceptable><PunchDirectionNotAcceptableType>DummyPunchDirectionNotAcceptableType</PunchDirectionNotAcceptableType><PunchPosition>DummyPunchPosition</PunchPosition></PunchDirectionNotAcceptable></AppReqRemoveWarning>";

        private static string staplePaperMismatchXml =
            "<?xml version=\"1.0\" encoding=\"utf-16\"?><AppReqRemoveWarning><JobID>1234</JobID><WarningName>DummyName</WarningName><StaplePaperMismatch><StaplePaperMismatchType>DummyStaplePaperMismatchType</StaplePaperMismatchType><TraySelection>Tray1</TraySelection></StaplePaperMismatch></AppReqRemoveWarning>";

        private static string iuLifeXml =
            "<?xml version=\"1.0\" encoding=\"utf-16\"?><AppReqRemoveWarning><JobID>1234</JobID><WarningName>DummyName</WarningName><IuLife><TempRescueStatus>DummyTempRescueStatus</TempRescueStatus></IuLife></AppReqRemoveWarning>";

        private static string stapleDirectionNotAcceptableXml =
            "<?xml version=\"1.0\" encoding=\"utf-16\"?><AppReqRemoveWarning><JobID>1234</JobID><WarningName>DummyName</WarningName><StapleDirectionNotAcceptable><StapleDirectionChangeType>DummyStapleDirectionChangeType</StapleDirectionChangeType><StaplePosition>DummyStaplePosition</StaplePosition></StapleDirectionNotAcceptable></AppReqRemoveWarning>";

        private static string manuscriptSizeDetectErrorXml =
            "<?xml version=\"1.0\" encoding=\"utf-16\"?><AppReqRemoveWarning><JobID>1234</JobID><WarningName>DummyName</WarningName><ManuscriptSizeDetectError><ManuscriptSizeDetectErrorType>MagnificationSelection</ManuscriptSizeDetectErrorType><Dimension><X>222</X><Y>888</Y></Dimension></ManuscriptSizeDetectError></AppReqRemoveWarning>";

        private static string manuscriptSizeDetectErrorTrayXml =
            "<?xml version=\"1.0\" encoding=\"utf-16\"?><AppReqRemoveWarning><JobID>1234</JobID><WarningName>DummyName</WarningName><ManuscriptSizeDetectError><ManuscriptSizeDetectErrorType>TraySelection</ManuscriptSizeDetectErrorType><TraySelection>Tray1</TraySelection></ManuscriptSizeDetectError></AppReqRemoveWarning>";

        private static string manuscriptSizeDetectErrorOriginalSizeXml =
            "<?xml version=\"1.0\" encoding=\"utf-16\"?><AppReqRemoveWarning><JobID>1234</JobID><WarningName>DummyName</WarningName><ManuscriptSizeDetectError><ManuscriptSizeDetectErrorType>OriginalSizeSelection</ManuscriptSizeDetectErrorType><PaperSize><SizeCode>Custom</SizeCode><Dimension2><X>333</X><Y>777</Y></Dimension2></PaperSize></ManuscriptSizeDetectError></AppReqRemoveWarning>";

        [Fact]
        public void CreateOperatorInfoExtAuth_WhenNormalCase_ExpectOperatorInfoExtAuth()
        {
            var doc = new XmlDocument();
            var authKeyCode = "dummyAuthKey";

            // Execute
            var opertorInfoNode = MessageCreator.CreateOperatorInfoExtAuth(doc, authKeyCode);

            // Validate
            var authKeyNode = opertorInfoNode.GetElementsByTagName("AuthKey");
            Assert.Single(authKeyNode);
            Assert.Equal(authKeyCode, authKeyNode[0].InnerText);
        }

        [Theory]
        [InlineData(null)]
        [InlineData("")]
        [InlineData(" ")]
        [InlineData("\t")]
        [InlineData("\\t")]
        [InlineData("\r\n")]
        [InlineData("\\r\\n")]
        [InlineData("\n")]
        [InlineData("\\n")]
        [InlineData("①②③④⑤⑥⑦⑧⑨")]
        [InlineData("</AuthKey>")]
        [InlineData("&lt;/AuthKey&gt;")]
        public void CreateOperatorInfoExtAuth_WhenIllegalAuthKeyCase_ExpectOperatorInfoExtAuth(string authKeyCode)
        {
            var doc = new XmlDocument();
            var opertorInfoNode = MessageCreator.CreateOperatorInfoExtAuth(doc, authKeyCode);
            var authKeyNode = opertorInfoNode.GetElementsByTagName("AuthKey");
            Assert.Single(authKeyNode);
            Assert.Equal(authKeyCode ?? string.Empty, authKeyNode[0].InnerText);
        }

        [Fact]
        public void CreateSecurity_WhenNormalCase_ExpectDevicePermanentSettingSecurityInfo()
        {
            //Prepare
            var doc =
                "<AppReqSetDevicePermanentSetting>" +
                "<RequestItem>Security</RequestItem>" +
                "<LockKey>0123456789</LockKey>" +
                "<RequestItem>Security</RequestItem>" +
                "</AppReqSetDevicePermanentSetting>";

            var expect =
                "<?xml version=\"1.0\" encoding=\"utf-16\"?>" +
                "<AppReqSetDevicePermanentSetting>" +
                "<RequestItem>Security</RequestItem>" +
                "<LockKey>0123456789</LockKey>" +
                "<RequestItem>Security</RequestItem>" +
                "<Security>" +
                "<PersonalInfoProtect>" +
                "<JobHistory>" +
                "<Enable>On</Enable>" +
                "<DisplayMode>Mode2</DisplayMode>" +
                "<PublicUser>Mode3</PublicUser>" +
                "</JobHistory>" +
                "<ExecutingJob>" +
                "<Enable>On</Enable>" +
                "<DisplayMode>Mode2</DisplayMode>" +
                "<PublicUser>Mode3</PublicUser>" +
                "</ExecutingJob>" +
                "</PersonalInfoProtect>" +
                "<RequestSourceSH>On</RequestSourceSH>" +
                "</Security>" +
                "</AppReqSetDevicePermanentSetting>";

            var personalInfoProtect = new PersonalInfoProtect(
                new JobHistory(
                    PermanentSettingsEnable.On.ToString(),
                    PermanentSettingsDisplayMode.Mode2.ToString(),
                    PermanentSettingsPublicUser.Mode3.ToString()),
                new ExecutingJob(
                    PermanentSettingsEnable.On.ToString(),
                    PermanentSettingsDisplayMode.Mode2.ToString(),
                    PermanentSettingsPublicUser.Mode3.ToString()));

            //Execute
            var req = TestHelper.StringToXmlDoc(doc);
            req.DocumentElement?.AppendChild(MessageCreator.CreateSecurity(req,personalInfoProtect));

            // Validate
            string str;
            using (var stringWriter = new StringWriter())
            using (var xmlTextWriter = XmlWriter.Create(stringWriter))
            {
                req.WriteTo(xmlTextWriter);
                xmlTextWriter.Flush();
                str = stringWriter.GetStringBuilder().ToString();
            }

            Assert.Equal(expect, str);
        }

        [Fact]
        public void CreateCommon_WhenNormalCase_ExpectXmlElement()
        {
            //prepare
            var localIp = "127.0.0.1";
            var port = 1234;
            var expect = $"<Common><Address>{localIp}</Address><PortNo>{port}</PortNo><Time>1440</Time></Common>";
            var req = new XmlDocument();
            req.AppendChild(req.CreateElement("Dummy"));

            // Execute
            var result = MessageCreator.CreateCommon(req, IPAddress.Parse(localIp), port);

            // Validate
            Assert.Equal(expect, result.OuterXml);
        }

        [Fact]
        public void CreateHostInfo_WhenNormalCase_ExpectXmlElement()
        {
            //prepare
            var localIp = "127.0.0.1";
            var port = 1234;
            var expect = $"<HostInfo><Address>{localIp}</Address><PortNo>{port}</PortNo></HostInfo>";
            var req = new XmlDocument();
            req.AppendChild(req.CreateElement("Dummy"));

            // Execute
            var result = MessageCreator.CreateHostInfo(req, IPAddress.Parse(localIp), port);
            
            // Validate
            Assert.Equal(expect, result.OuterXml);
        }

        [Fact]
        public void CreateObtainCondition_WhenObtainConditionIndexList_ExpectXmlElement()
        {
            //prepare
            var expect = "<ObtainCondition><Type>IndexList</Type><IndexRange><Start>1</Start><End>100</End></IndexRange></ObtainCondition>";
            var req = new XmlDocument();
            req.AppendChild(req.CreateElement("Dummy"));

            // Execute
            var result = MessageCreator.CreateObtainCondition(req, ObtainCondition.IndexList, null);

            Assert.Equal(expect, result.OuterXml);
        }

        [Fact]
        public void CreateObtainCondition_WhenMfpJobIdHasValueTrue_ExpectXmlElement()
        {
            //prepare
            ulong mfpJobId = 1234;
            var expect = $"<ObtainCondition><Type>SpecifiedNo</Type><SpecifiedNo>{mfpJobId}</SpecifiedNo></ObtainCondition>";
            var req = new XmlDocument();
            req.AppendChild(req.CreateElement("Dummy"));

            // Execute
            var result = MessageCreator.CreateObtainCondition(req, ObtainCondition.SpecifiedNo, mfpJobId);

            // Validate
            Assert.Equal(expect, result.OuterXml);
        }

        [Theory]
        [MemberData(nameof(CreateWarningTestData))]
        public void CreateWarning_WhenNormalCase_ExpectXmlDocument(WarningMessage type, string typeName, string expect)
        {
            //prepare
            var jobId = "1234";
            var warningName = "DummyName";
            var req = new XmlDocument();
            var warningMessageFactory = new WarningMessageFactory();
            req.AppendChild(req.CreateElement("AppReqRemoveWarning"));
            CreateChildElement(ref req, "JobID", jobId);
            CreateChildElement(ref req, "WarningName", warningName);

            // Execute
            req.DocumentElement?.AppendChild(warningMessageFactory.CreateWarning(type).ToXml(req, CreateWarningServiceSetting(typeName)));

            // Validate
            string str;
            using (var stringWriter = new StringWriter())
            using (var xmlTextWriter = XmlWriter.Create(stringWriter))
            {
                req.WriteTo(xmlTextWriter);
                xmlTextWriter.Flush();
                str = stringWriter.GetStringBuilder().ToString();
            }

            Assert.Equal(expect, str);
        }

        /// <summary>
        /// Gets the create warning test data.
        /// </summary>
        public static IEnumerable<object[]> CreateWarningTestData => new List<object[]>()
        {
            new object[] {WarningMessage.APSAcceptable, "DummyAcceptableType", apsAcceptableXml },
            new object[] {WarningMessage.PaperEmptyCaution, "DummyPaperEmptyCautionType", paperEmptyCautionXml },
            new object[] {WarningMessage.PaperEmptyError, null, paperEmptyErrorXml },
            new object[] {WarningMessage.TwoSidedIncompatible, "DummyTwoSidedIncompatibleType", twoSidedIncompatibleXml },
            new object[] {WarningMessage.ManuscriptSizeDetectError, "MagnificationSelection", manuscriptSizeDetectErrorXml },
            new object[] {WarningMessage.ManuscriptSizeDetectError, "TraySelection", manuscriptSizeDetectErrorTrayXml },
            new object[] {WarningMessage.ManuscriptSizeDetectError, "OriginalSizeSelection", manuscriptSizeDetectErrorOriginalSizeXml },
            new object[] {WarningMessage.PrintIncompatible, "TraySelection", printIncompatibleXml },
            new object[] {WarningMessage.PrintIncompatible, "DummyPrintIncompatibleType", printIncompatibleOtherThanTraySelectionXml },
            new object[] {WarningMessage.AMSMagnificationIncompatible, "DummyAmsMagnificationIncompatibleType", amsMagnificationIncompatibleXml },
            new object[] {WarningMessage.StapleForm, "DummyStapleFormType", stapleFormXml },
            new object[] {WarningMessage.StaplePaperMismatch, "DummyStaplePaperMismatchType", staplePaperMismatchXml },
            new object[] {WarningMessage.PunchPaperIncompatibility, "DummyPunchPaperIncompatibilityType", punchPaperIncompatibilityXml },
            new object[] {WarningMessage.StapleDirectionNotAcceptable, "DummyStapleDirectionChangeType", stapleDirectionNotAcceptableXml },
            new object[] {WarningMessage.PunchDirectionNotAcceptable, "DummyPunchDirectionNotAcceptableType", punchDirectionNotAcceptableXml },
            new object[] {WarningMessage.APSSizeMismatch, null, aPSSizeMismatchXml },
            new object[] {WarningMessage.TonerEmptyStop, null,tonerEmptyStopXml },
            new object[] {WarningMessage.IuLife, null, iuLifeXml },
            new object[] {WarningMessage.PunchFormStaple, "DummyPunchFormStapleType", punchFormStapleXml },
            new object[] {WarningMessage.ExtDocumentSizeAssign, null, extDocumentSizeAssignXml }
        };

        /// <summary>
        /// Creates the warning service setting.
        /// </summary>
        /// <returns></returns>
        private WarningServiceSetting CreateWarningServiceSetting(string typeName)
        {
            return new WarningServiceSetting()
            {
                JobId = 1234,
                Name = "DummyName",
                ApsAcceptable = new WarningServiceSetting.ApsAcceptableModel()
                {
                    AcceptableType = typeName,
                    TraySelection = "DummyTraySelection",
                    Dimension = new WarningServiceSetting.DimensionModel()
                    {
                        X = 111,
                        Y = 999
                    }
                },
                PaperEmptyCaution = new WarningServiceSetting.PaperEmptyCautionModel()
                {
                    PaperEmptyCautionType = typeName,
                    TraySelection = "Tray1"
                },
                PaperEmptyError = new WarningServiceSetting.PaperEmptyErrorModel()
                {
                    TraySelection = "Tray1"
                },
                TwoSidedIncompatible = new WarningServiceSetting.TwoSidedIncompatibleModel()
                {
                    TwoSidedIncompatibleType = typeName,
                    TraySelection = "Tray1"
                },
                ManuscriptSizeDetectError = new WarningServiceSetting.ManuscriptSizeDetectErrorModel()
                {
                    ManuscriptSizeDetectErrorType = typeName,
                    Dimension = new WarningServiceSetting.DimensionModel()
                    {
                        X = 222,
                        Y = 888
                    },
                    TraySelection = "Tray1",
                    PaperSize = new WarningServiceSetting.PaperSizeModel()
                    {
                        SizeCode = "Custom",
                        Dimension2 = new WarningServiceSetting.DimensionModel()
                        {
                            X=333,
                            Y=777
                        }
                    }
                },
                PrintIncompatible = new WarningServiceSetting.PrintIncompatibleModel()
                {
                    PrintIncompatibleType = typeName,
                    TraySelection = "Tray1"
                },
                AmsMagnificationIncompatible = new WarningServiceSetting.AmsMagnificationIncompatibleModel()
                {
                    AmsMagnificationIncompatibleType = typeName,
                    TraySelection = "Tray1",
                    Dimension = new WarningServiceSetting.DimensionModel()
                    {
                        X = 444,
                        Y = 666
                    }
                },
                StapleForm = new WarningServiceSetting.StapleFormModel()
                {
                    StapleFormType = typeName,
                    TraySelection = "Tray1"
                },
                StaplePaperMismatch = new WarningServiceSetting.StaplePaperMismatchModel()
                {
                    StaplePaperMismatchType = typeName,
                    TraySelection = "Tray1"
                },
                PunchPaperIncompatibility = new WarningServiceSetting.PunchPaperIncompatibilityModel()
                {
                    PunchPaperIncompatibilityType = typeName,
                    TraySelection = "Tray1"
                },
                StapleDirectionNotAcceptable = new WarningServiceSetting.StapleDirectionNotAcceptableModel()
                {
                    StapleDirectionChangeType = typeName,
                    StaplePosition = "DummyStaplePosition"
                },
                PunchDirectionNotAcceptable = new WarningServiceSetting.PunchDirectionNotAcceptableModel()
                {
                    PunchDirectionNotAcceptableType = typeName,
                    PunchPosition = "DummyPunchPosition"
                },
                ApsSizeMismatch = new WarningServiceSetting.ApsSizeMismatchModel()
                {
                    TraySelection = "Tray1"
                },
                TonerEmptyStop = new WarningServiceSetting.TonerEmptyStopModel()
                {
                    TempRescueStatus = "DummyTempRescueStatus"
                },
                IuLife = new WarningServiceSetting.IuLifeModel()
                {
                    TempRescueStatus = "DummyTempRescueStatus"
                },
                PunchFormStaple = new WarningServiceSetting.PunchFormStapleModel()
                {
                    PunchFormStapleType = typeName,
                    TraySelection = "Tray1"
                },
                ExtDocumentSizeAssign = new WarningServiceSetting.ExtDocumentSizeAssignModel()
                {
                    PaperSize = new WarningServiceSetting.PaperSizeModel()
                    {
                        SizeCode = "Custom",
                        Dimension2 = new WarningServiceSetting.DimensionModel()
                        {
                            X=555,
                            Y = 666
                        }
                    }
                }
            };
        }

        private void CreateChildElement(ref XmlDocument document, string elementName, string innerText, XmlNode target = null)
        {
            var elm = document.CreateElement(elementName);
            elm.InnerText = innerText;
            (target ?? document.DocumentElement)?.AppendChild(elm);
        }
    }
}
