﻿using System;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Moq;
using ServiceHub.Connectors.OpenAPI.Model;
using Xunit;

namespace ServiceHub.Connectors.OpenAPI.Tests
{
    [Trait("LockTaskManagerTests", "Unit")]
    [Collection("LockTask No parallelism")]
    public class LockTaskManagerTests
    {
        private readonly ILogger<LockTaskManager> _logger;

        public LockTaskManagerTests()
        {
            _logger = Mock.Of<ILogger<LockTaskManager>>();
        }

        [Fact(Skip = "Does not work on bamboo only. Works locally. Issue with multiple thread.")]
        public async Task AddTask_WhenDeviceLockByOneThread()
        {
            var lockTaskManager = new LockTaskManager(_logger);
            var cancellationToken = new CancellationToken(false);
            var lockTaskMgrTask = lockTaskManager.StartAsync(cancellationToken).ConfigureAwait(false);
            var lockInfo = new DeviceLockInfo { TimeoutMin = 1 };

            lockTaskManager.AddTask(lockInfo);

            if (!lockInfo.Event.WaitOne(10_000))
            {
                throw new Exception("Should not be taking 10 seconds.");
            }

            await lockTaskManager.StopAsync(cancellationToken);
            await lockTaskMgrTask;
        }

        [Fact(Skip = "Does not work on bamboo only. Works locally. Issue with multiple thread.")]
        public async Task AddTask_WhenDeviceLockByTwoThread()
        {
            var lockTaskManager = new LockTaskManager(_logger);
            var lockInfo1 = new DeviceLockInfo { TimeoutMin = 1 };
            var lockInfo2 = new DeviceLockInfo { TimeoutMin = 1 };
            var cancellationToken = new CancellationToken(false);
            var lockTaskMgrTask = lockTaskManager.StartAsync(cancellationToken).ConfigureAwait(false);

            lockTaskManager.AddTask(lockInfo1);
            lockTaskManager.AddTask(lockInfo2);

            var task1 = Task.Run(async () =>
            {
                if (!lockInfo1.Event.WaitOne(1_000))
                {
                    throw new Exception("Should be unlocked under 1 second (timeout).");
                }

                await Task.Delay(500, cancellationToken);
                lockTaskManager.RemoveTask(lockInfo1);
            }, cancellationToken);

            var task2 = Task.Run(() =>
            {
                if (!lockInfo2.Event.WaitOne(2000))
                {
                    throw new Exception("Should be unlocked under 2 seconds (timeout)");
                }
            }, cancellationToken);

            Task.WaitAll(task1, task2);
            await lockTaskManager.StopAsync(cancellationToken);
            await lockTaskMgrTask;
        }

        [Fact(Skip = "Does not work on bamboo only. Works locally. Issue with multiple thread.")]
        public async Task AddTask_WhenDeviceLockByTwoThreadLockTimeout()
        {
            var lockTaskManager = new LockTaskManager(_logger);

            var lockInfo1 = new DeviceLockInfo { TimeoutMin = 1 };
            var lockInfo2 = new DeviceLockInfo { TimeoutMin = 1 };
            var cancellationToken = new CancellationToken(false);
            var lockTaskMgrTask = lockTaskManager.StartAsync(cancellationToken).ConfigureAwait(false);

            lockTaskManager.AddTask(lockInfo1);
            lockTaskManager.AddTask(lockInfo2);

            var task1 = Task.Run(async () =>
            {
                if (!lockInfo1.Event.WaitOne(250))
                {
                    throw new Exception("Should not be locked");
                }

                await Task.Delay(500, cancellationToken).ConfigureAwait(false);
                lockTaskManager.RemoveTask(lockInfo1);
            }, cancellationToken);

            var task2 = Task.Run(() =>
            {
                if (lockInfo2.Event.WaitOne(100))
                {
                    throw new Exception("Should be unlocked");
                }
            }, cancellationToken);

            Task.WaitAll(task1, task2);
            await lockTaskManager.StopAsync(cancellationToken).ConfigureAwait(false);
            await lockTaskMgrTask;
        }

        [Fact(Skip = "This test is taking way too much time. It needs refactor in the code before reactivating")]
        public void AddTask_WhenDeviceLockByTwoThreadTaskTimeout()
        {
            var lockTaskManager = new LockTaskManager(_logger);
            var lockInfo1 = new DeviceLockInfo { TimeoutMin = 1 };
            var lockInfo2 = new DeviceLockInfo { TimeoutMin = 1 };

            lockTaskManager.AddTask(lockInfo1);
            lockTaskManager.AddTask(lockInfo2);

            var task1 = Task.Run(async () =>
            {
                if (!lockInfo1.Event.WaitOne(10_000))
                {
                    ////Assert.Fail("Unlock.");
                    Assert.False(true);
                }

                await Task.Delay(61_000);
            });
            var task2 = Task.Run(async () =>
            {
                await Task.Delay(1_000);
                if (!lockInfo2.Event.WaitOne())
                {
                    Assert.False(true);
                    ////Assert.Fail("Unlock.");
                }
            });

            Task.WaitAll(task1, task2);
        }
    }
}
