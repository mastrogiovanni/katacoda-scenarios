using System.Xml;

namespace ServiceHub.Processors.Tests
{
    internal static class TestHelper
    {
        /// <summary>
        /// Convert a String to XML document.
        /// </summary>
        /// <param name="stringToXml">The string to XML.</param>
        /// <returns>The XmlDocument object</returns>
        public static XmlDocument StringToXmlDoc(string stringToXml)
        {
            var xmlDocument = new XmlDocument();
            xmlDocument.LoadXml(stringToXml);

            return xmlDocument;
        }
    }
}
