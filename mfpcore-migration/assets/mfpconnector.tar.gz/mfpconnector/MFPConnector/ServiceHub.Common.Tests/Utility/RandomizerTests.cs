﻿using System;
using System.Linq;
using ServiceHub.Common.Utility;
using Xunit;

namespace ServiceHub.Common.Tests.Utility
{
    [Trait("RandomizerTests", "Unit")]
    public class RandomizerTests
    {
        [Theory]
        [InlineData(1)]
        [InlineData(10)]
        public void GetNextInt_WhenQuantityIsValid_ExpectSameQuantityResults(int quantityToGenerate)
        {
            var randomizer = new SecureRandom();

            var result = randomizer.GetNextInt(quantityToGenerate);
            Assert.Equal(quantityToGenerate, result.Count());
        }

        [Theory]
        [InlineData(-1)]
        [InlineData(0)]
        public void GetNextInt_WhenQuantityIsInvalid_ExpectArgumentException(int quantityToGenerate)
        {
            var randomizer = new SecureRandom();

            Assert.Throws<ArgumentException>(() => randomizer.GetNextInt(quantityToGenerate));
        }
    }
}
