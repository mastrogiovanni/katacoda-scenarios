﻿using System.IO;
using ServiceHub.Common.Extensions;
using ServiceHub.Common.Settings;
using Xunit;

namespace ServiceHub.Common.Tests.Settings
{
    [Trait("MfpConnectorSettingTests", "Unit")]
    public class MfpConnectorSettingTests
    {
        /// <summary>
        /// Setting.json path
        /// </summary>
        public const string SettingJsonPath = "~/App_Data/TestSetting.json";
        private const string ChangedPassword = "12345678";

        [Fact]
        public void Load_WhenLoadingValidConfiguration_ExpectSuccess()
        {
            // Todo split this in multiple tests.
            var connectorSetting = MfpConnectorSetting.Load(SettingJsonPath.MapPath(Directory.GetCurrentDirectory()));
            Assert.NotNull(connectorSetting);

            connectorSetting.OpenApi.Devices.CurrentSetting.Password = string.Empty;
            Assert.Equal(string.Empty, connectorSetting.OpenApi.Devices.CurrentSetting.Password);
            connectorSetting.Save();

            connectorSetting = MfpConnectorSetting.Load(SettingJsonPath.MapPath(Directory.GetCurrentDirectory()));
            Assert.Equal(string.Empty, connectorSetting.OpenApi.Devices.CurrentSetting.Password);

            connectorSetting.OpenApi.Devices.CurrentSetting.Password = ChangedPassword;
            connectorSetting.Save();
            connectorSetting = MfpConnectorSetting.Load(SettingJsonPath.MapPath(Directory.GetCurrentDirectory()));
            Assert.Equal(ChangedPassword, connectorSetting.OpenApi.Devices.CurrentSetting.Password);
        }
    }
}
