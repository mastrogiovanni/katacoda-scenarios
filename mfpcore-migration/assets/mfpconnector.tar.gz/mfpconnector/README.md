# MFPCore

This project is an experimental project for Story [SHUBWP-336](https://jira.kmiservicehub.com/browse/SHUBWP-336) and [SHUBWP-429](https://jira.kmiservicehub.com/browse/SHUBWP-429).

# Directory Structure

## LightningCompatibility

> This directory contains Lightning compatibility projects.

    ├ LightningCompatibility.sln
    │
    ├ packages/  --  NuGet Packages
    │
    ├ libOpenAPI/  --  OpenAPI libraries
    │
    └ Lightning*/, KMTCPSocket/, WSDScanLibrary/  --  Other projects

## MFPConnector

> This directory contains brand-new MFP Connector projects.

    ├ MFPConnector.sln
    │
    ├ packages/  --  NuGet Packages
    │
    ├ Common.*/  --  Common using libraries
    │ 　├ Common.Logging
    │ 　├ Common.WebSocket
    │
    ├ MfpConnectorWeb/  --  MFPConnector Web Application
    │
    ├ Processors.*/  --  Job processors libraries
    │ 　├ Processors.Common
    │ 　├ Processors.Print
    │
